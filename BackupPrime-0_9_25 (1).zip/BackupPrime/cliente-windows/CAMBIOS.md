# Historial de cambios — BackupPrime

## 0.9.25 — Borrar carpetas, y ver cuánto espacio se libera

**El recolector de bloques, construido y en simulación.** Es lo que hace que
borrar libere espacio de verdad en el almacenamiento: hasta ahora la papelera y
la poda marcaban, pero los bloques seguían ocupando lugar. Está escrito con
todas las barandas y **todavía no borra nada**: informa qué borraría. Primero se
mira el inventario contra la cuenta real, después se habilita.

**Solo se podían borrar archivos sueltos.** El botón de papelera estaba limitado
a los archivos: para vaciar una carpeta había que ir uno por uno. Ahora está
también en las carpetas, junta todo lo que tienen adentro y antes de confirmar
dice qué se va: «la carpeta Viejos con 40 archivos. Son 6,2 GB».

**Y el espacio no se veía.** Peor: el servidor recibía UN solo tamaño para todo
el pedido, así que mandar una carpeta habría guardado ese número repetido en
cada archivo y la cuota habría bajado cualquier cosa. Ahora viaja la lista con
el tamaño de cada uno, y la papelera muestra el total y lo que ocupa cada
archivo.

**Textos del sitio.** Se sacaron cinco promesas que el producto no cumplía: el
bloqueo de objetos «probado» que nunca se probó contra e2, la factura
electrónica que no existe, «hasta 30 versiones» cuando la política cambió a
ventanas de tiempo, el aviso por mail de equipo caído que no se manda, y la
restauración web sin aclarar que con frase privada no puede funcionar. Las seis
frases quedaron en la guarda de `pruebas/interfaz.cjs` para que no vuelvan.

Y las historias de la portada pasaron de nueve a doce.

## 0.9.24 — El programa muestra tu plan, tu espacio y tu papelera

Tres cosas estaban en el portal y no en el programa. El cliente vive en el
programa: si tiene que abrir la web para saber cuánto espacio le queda, la
información no existe.

**El espacio ocupado.** La tarjeta estaba hecha, pero la cuota solo se llenaba
DESPUÉS de un respaldo, así que al abrir el programa quedaba oculta. Ahora se
consulta al arrancar.

**El plan contratado.** Venía en la respuesta del login y se descartaba. Ahora se
guarda y se muestra al lado del espacio.

**La papelera.** Se dibujaba dentro del cargado del árbol de restauración: si el
servidor no respondía —por ejemplo, por un certificado vencido— no había dónde
ver lo borrado ni cómo recuperarlo. Ahora se carga sola al entrar a Restaurar y
dice algo en los tres casos: con archivos, vacía, y sin conexión.

## 0.9.23 — Restaurar desde la web, y papelera

**Restauración desde la web.** El sitio la prometía desde el día uno y no
existía. Ahora el portal lista los archivos respaldados, con buscador, y los
baja: el servidor lee el índice, junta los bloques, los descifra y arma el
archivo. La prueba cifra con el módulo del agente y descifra con el del
servidor, así los dos formatos no se pueden separar sin que algo se ponga en
rojo.

Con **frase privada** no se puede, y la pantalla lo dice: el servidor no tiene
esa clave. Si pudiera leer esos archivos, la frase privada sería decoración.

Si falta un bloque, la descarga se corta en vez de entregar un archivo cortado
que parece bueno. Y se verifica la huella del archivo armado antes de darlo.

**Papelera, una sola por cliente.** Los archivos son del cliente y tiene derecho
a borrarlos, pero no se borran de una: van a la papelera, dejan de contar en su
cuota **en el momento** —si no bajara el número, el cliente aprieta borrar, no ve
nada y llama— y siguen recuperables 30 días.

Vive en el servidor, no en cada equipo: un estudio con cuatro PCs vería cuatro
papeleras distintas, y lo borrado desde la web no aparecería en el programa. Se
ve igual desde los dos lados. El vencimiento también corre en el servidor: si
dependiera del agente, un cliente que apaga la máquina un mes nunca liberaría
espacio.

**El vencimiento saca la marca pero todavía NO borra los bloques.** Eso necesita
recolección con conteo de referencias —los bloques se comparten entre versiones
y entre archivos— y queda registrado en Auditoría como pendiente. Hasta que
exista, ese espacio se sigue pagando.

## 0.9.22 — El guardia anti-ransomware, enchufado

**Los archivos que el respaldo actual ya no cubre, marcados.** Cuando el cliente
saca una carpeta del trabajo, mueve un directorio o cambia una letra de unidad,
lo que ya se subió queda guardado. Eso está bien y siempre estuvo: la
restauración lee el destino, no el trabajo, así que esos archivos **ya se veían
y se podían recuperar**.

Lo que faltaba era distinguirlos. Un archivo cuya última copia es de marzo se
veía igual que uno de esta mañana, y esa confusión es la peor que puede tener un
producto de respaldo: el cliente cree que una carpeta se sigue respaldando y hace
tres meses que no.

Ahora, en Restaurar, esos archivos llevan una etiqueta ámbar —no roja: el archivo
está y se puede traer— y arriba aparece un cartel que dice, en este orden, que se
pueden restaurar y que no se están actualizando. Una carpeta se marca solo si
**todo** lo que tiene adentro quedó afuera: marcarla con una parte cubierta
mentiría al revés.

Y si no se sabe qué carpetas cubre el trabajo —configuración vacía o ilegible—
**no se marca nada**. Decirle al cliente que todo quedó fuera del respaldo porque
no pudimos leer la configuración sería el peor aviso posible.

No se borra ni se mueve nada. El botón para que el cliente elija borrar lo que
ya no quiere, con papelera de 30 días, es el paso siguiente.

**El error rojo permanente que no significaba nada.** La pantalla de Actividad
mostraba, en cada corrida:

    No se pudo leer "app.asar": el archivo o la carpeta ya no existe

Tres problemas en una línea. Decía el nombre pelado sin la ruta —hay decenas de
`app.asar` en un equipo y el cliente no puede saber cuál es—; no aclaraba que
hablaba de SU equipo y no de la nube, que es la duda razonable; y lo contaba
como **error**, así que el resumen decía "fallaron 1 archivo(s)" siempre, por lo
mismo. Un aviso rojo permanente que no significa nada le enseña al cliente a
ignorar todos los avisos, incluidos los que sí importan.

Ahora un archivo que desapareció durante el respaldo se registra como **aviso**
y va a salteados, con la ruta completa y la aclaración de que si es un temporal
es normal. Lo demás sigue contando como error.

**El guardia existía y no lo llamaba nadie.** `guardia-cifrado.cjs` estaba
escrito, bien diseñado y con pruebas propias desde hacía varias versiones. Pero
ninguna línea del motor lo invocaba: el producto no tenía ninguna protección
contra cifrado masivo, y las pruebas del módulo pasaban en verde igual porque
probaban el módulo aislado, no que el respaldo lo usara.

Ahora se consulta archivo por archivo durante el recorrido, **antes de encolar
nada para subir**. Si no cortara ahí, las versiones cifradas se subirían y
empujarían a las sanas fuera del historial: el ataque terminaría el trabajo
usando nuestro propio producto.

Cuando dispara: frena el respaldo, deja los motivos con números en el registro,
muestra una notificación crítica —sin respetar el horario de silencio, porque un
cifrado a las tres de la mañana es cuando hay que despertar a alguien— y avisa
al servidor, que lo registra en Auditoría y manda mail al cliente **y al
administrador**, porque el cliente puede estar sin poder leer el correo.

Necesita **dos señales cruzadas** para disparar, no una: tasa de archivos
modificados por minuto, proporción con entropía de cifrado, y cantidad de
archivos con una extensión nunca vista. Con una sola señal no corta —exportar un
lote desde Tango dispara la tasa, instalar un programa dispara las extensiones—.
Y nunca dispara en el primer respaldo, donde todo es nuevo por definición.

**Retención por ventanas de tiempo, en lugar de contar versiones.**

Antes era "conservar las últimas 10 versiones", con tope de 30. El problema no
era el número, era la unidad: un PST que Outlook toca diez veces por día gasta
30 versiones en tres días. Como un ransomware se detecta entre 3 y 20 días
después, cuando el estudio se da cuenta las 30 versiones ya son todas cifradas
— la copia sana se pisó sola, sin que ningún atacante borrara nada.

La política nueva conserva todas las versiones de los últimos 7 días, una por
día hasta los 30, una por semana hasta los 6 meses y una por mes hasta los 2
años. Medido: con un año de versiones a diez por día, la política vieja llegaba
a 3 días de historial y la nueva pasa los 300, guardando menos de 150 versiones
de 3650.

Manda una regla sobre todas las demás: **ante la duda, no se borra.** La versión
más nueva nunca sobra, una sola versión no se toca, las que no tienen fecha
legible se conservan y se avisa, y una fecha futura se trata como un reloj mal
puesto y no como una versión vieja.

**Todavía no borra nada.** El módulo decide qué sobra; falta la recolección de
bloques que ejecute esa decisión. Con deduplicación los bloques se comparten
entre versiones y entre archivos, así que borrar uno todavía referenciado deja
un archivo vivo sin un pedazo — y eso no se nota hasta que alguien restaura.

## 0.9.21 — Cuánto falta

Estaba pedido desde muchas versiones atrás y es lo primero que mira alguien que
deja un respaldo corriendo y quiere saber si se va a dormir o espera.

**Por qué no estaba.** El motor descubre los archivos mientras los copia: el
recorrido de carpetas llena una reserva de 500 y los trabajadores comen de ahí,
así que nunca va más de 500 archivos adelante. Como total no sirve —siempre
diría "procesados + 500"—. Sin denominador no hay porcentaje honesto ni tiempo
restante del trabajo completo.

**Ahora hay un segundo recorrido que solo cuenta**, en paralelo, que no lee ni
sube nada: solo pide el tamaño de cada archivo. Usa los **mismos filtros** que
el recorrido del respaldo, no una copia — dos listas separadas se
desincronizan, y ya pasó entre el motor y el selector.

Medido antes de hacerlo, con 50.000 archivos y el productor, la reserva y los
seis trabajadores reales:

| | |
|---|---|
| Respaldo sin conteo | 9.593 ms |
| Respaldo con conteo en paralelo | 9.476 ms (−1,2 %: es ruido) |
| Total listo a los | 1.849 ms, o sea al 19 % de la corrida |

No cuesta nada porque el conteo no lee ni sube, y de paso le deja la caché
caliente al recorrido de verdad.

**Y una medición que cambió el diseño.** La primera versión reusaba `walkDir`
con un `for await`, que cede el control una vez por CADA archivo. Aislado no se
nota; con seis trabajadores subiendo al mismo tiempo, cada cesión espera detrás
de toda la cola de trabajo pendiente. Con 6.000 archivos el conteo tardaba
**4.703 ms de una corrida de 5.335 ms** — el total quedaba listo cuando el
respaldo ya estaba por terminar, justo lo que esto viene a resolver. Con una
vuelta por carpeta y los tamaños pedidos de a 500 juntos: **167 ms**.
Veintiocho veces más rápido, el mismo trabajo. (Se descartó por medición que
fuera el pool de hilos: subirlo a 16 y a 64 no cambió nada.)

**El tiempo restante viejo estaba mal y nadie lo había notado.** Se calculaba
sobre `bytesTotales`, que son los bytes **encolados para subir en ese
momento** —los cinco o seis archivos en vuelo—, no el trabajo. En un respaldo
de 200 GB decía "falta menos de un minuto" durante horas. Ese error no lo
detecta ninguna comprobación de coherencia: el número es prolijo, positivo,
baja, y está mal.

Ahora se proyecta sobre el trabajo completo: `transcurrido × (lo que falta / lo
masticado)`. **Lo masticado incluye lo salteado**, porque revisar un archivo y
decidir que no cambió también lleva tiempo y también es avance. Sin eso, un
incremental donde no cambia nada nunca llegaría a 100.

El promedio es de **toda la corrida**, no de los últimos segundos. Con una
ventana corta, un PST de 651 MB que se saltea entero en un milisegundo dispara
la tasa a miles de MB/s y el estimado se cae a cero.

**Nada de esto sale hasta que el conteo terminó.** Con un total todavía
creciendo, el estimado baja solo porque sube el denominador: la pantalla diría
"faltan 4 minutos" y un minuto después "faltan 20". Mientras cuenta, el cuadro
dice que está midiendo el trabajo y la barra sigue siendo de actividad.

**El porcentaje va por bytes, no por archivos.** Con 165.000 archivos chicos y
un PST de 651 MB, contar por archivo deja la barra en 99 % durante los veinte
minutos que tarda el archivo grande.

**En pantalla:** barra real con su porcentaje, el porcentaje también en la
cabecera —se ve desde cualquier pestaña—, y el total con los dos números otra
vez: `12.480 de 165.320 archivos · 19,57 GB de 195,58 GB`.

**Si el conteo falla, el respaldo sigue.** Se pierden el porcentaje y el tiempo
estimado, que es exactamente lo que había hasta esta versión. Y "Detener" corta
también el conteo: es una fase larga más.

### Tres bugs que aparecieron al cargar la pantalla, no al leer el código

- **Las tres claves de idioma nuevas no existían en el diccionario.** La
  pantalla le mostraba literalmente `prog-de-total` al cliente. `t()` devuelve
  la clave cuando no la encuentra: sin error, sin excepción, sin nada en el
  registro. **`auditoria-idioma.cjs --estricto` pasó en verde con eso puesto**,
  porque busca texto sin traducir en el HTML, no claves que se usan y no
  existen. Es la cuarta prueba que se encuentra verde sin probar nada.
- **Al terminar quedaba "restante: 3 h 25 min" al lado de "✓ Respaldo
  terminado".** Esa rama corta con `return` y no pasaba por el pintado normal.
  Dos cosas que se contradicen en el mismo cuadro hacen dudar de las dos, y es
  el cuadro donde el cliente decide si puede apagar la máquina.
- **Una edición duplicó claves dentro del objeto `progreso`.** En JS gana la
  última y no hay error a la vista. Se sacó y se pasó un control de AST por
  todo el motor: cero duplicadas.

Prueba nueva: `total-del-trabajo.cjs` (35), con la mitad del motor y la mitad
cargando la pantalla con avisos reales. Se reintrodujeron **seis** bugs a
propósito y los seis la ponen en rojo: estimar sin esperar el conteo, no contar
lo salteado como avance, que el conteo filtre distinto que el motor, sacar una
clave de un solo idioma, dejar el tiempo restante colgado al terminar, y pintar
una barra de porcentaje sobre un total que todavía crece.

**923 pruebas en el cliente, 473 en el servidor, cero fallas.**

## 0.9.12 — El selector

Estaba pedido desde la primera sesión y se pospuso tres veces. Es la primera
pantalla que toca un cliente nuevo y la que decide si su respaldo va a servir:
un selector malo no da un error, da un **respaldo incompleto**, y eso no se
descubre hasta el día del desastre.

**La basura del sistema ya no se ofrece.** En el selector aparecía, mezclado con
los documentos del estudio, `snx_rhive{…}.TMContainer0000…0001.regtrans-ms`:
transacciones del registro de Windows. No son datos del cliente, están siempre
abiertas y no sirven de nada restauradas. Tres costos concretos: llenan la lista
y el cliente no encuentra lo suyo; si las elige generan errores de archivo
bloqueado en CADA respaldo —y un cliente que ve errores todos los días deja de
mirarlos—; y `hiberfil.sys` o `pagefile.sys` son gigas de nada que se le cobran.
Se filtran también `NTUSER.DAT`, `.blf`, `.lnk`, `Thumbs.db`, `desktop.ini`, y
las carpetas `$Recycle.Bin`, `System Volume Information`, `Recovery`,
`node_modules`.

El filtro mira el **nombre completo**, no un pedazo: un archivo llamado
`Balance ntuser.xlsx` se respalda. Un filtro que se pasa de listo deja afuera
datos del cliente en silencio, que es peor que no filtrar.

**Accesos rápidos, con el correo de Outlook entre ellos.** Nadie que no sea
técnico sabe que sus mails están en `AppData\Local\Microsoft\Outlook`.
Obligarlo a navegar hasta ahí es garantizar que su PST no se respalde nunca:
justo el archivo que más le va a doler perder. Solo se ofrecen las carpetas que
existen de verdad en ese equipo.

**Casilla intermedia.** Sin ella, el cliente que eligió tres subcarpetas de
Documentos ve la casilla de Documentos vacía y no tiene forma de saber que ahí
adentro hay algo elegido. Termina marcando la carpeta entera "por las dudas" y
respaldando 80 GB que no quería. Se dice además con palabras —"algo elegido
adentro"—, no solo con un color: un color solo no lo entiende quien no sabe qué
significa.

**Elegir una carpeta entera limpia lo redundante** que ya estaba elegido adentro.

**Buscador** dentro de la carpeta actual, **migas de pan navegables** (volver
tres carpetas atrás de un clic), y **total en vivo**: cuántos archivos y cuánto
pesan. Sin el número, elegir es a ciegas: se marca "Descargas" sin saber que son
80 GB. La medición se cancela sola si el cliente sigue marcando, y tiene tope
para no dejar la ventana esperando.

**Ruta de red**, para el estudio que tiene los datos en `\\SERVIDOR\Contabilidad`
y no puede llegar ahí navegando unidades locales. **No usa `prompt()`**: Electron
no lo implementa y el botón queda muerto sin ningún error visible. Ya había
pasado con las exclusiones. Va un campo propio, y el error se muestra al lado del
campo en vez de como un aviso que se va solo.

**Vuelve el contador de archivos**, junto a los GB. Los dos, porque cada uno tapa
el hueco del otro: con 165.000 archivos chicos los GB se mueven despacio y parece
que no avanza; con un archivo de 6 GB el contador no se mueve en veinte minutos.

Pruebas nuevas: `selector-carpetas.cjs` (20), `basura-del-sistema.cjs` (40).
**769 pruebas en el cliente, 473 en el servidor, cero fallas.**

## 0.9.11

**"Se colgaba" con 165.000 archivos. El motor estaba sano; la ventana no.**

Visto en producción con un cliente real. El administrador de tareas mostraba
24,6 MB/s de disco, 26% de CPU y el contador subiendo: el respaldo funcionaba.
Lo que quedaba muerta era la ventana. Para el cliente eso es lo mismo que un
respaldo colgado — mata el proceso y se queda sin respaldo.

Tres causas, las tres invisibles con pocos archivos:

1. **`logs.textContent += texto` no agrega texto.** LEE todo lo que hay en el
   nodo, lo concatena y lo reescribe entero. Con 25.000 mensajes y cientos de KB
   acumulados son gigabytes de copiado inútil: trabajo al cuadrado, y a partir de
   cierto punto la ventana no vuelve más. Ahora el texto se acumula en una
   variable de JavaScript y el nodo se escribe una sola vez por cuadro.
2. **La lista de actividad se repintaba en CADA mensaje.** Con miles por minuto,
   el navegador nunca terminaba un repintado antes del siguiente. Ahora se
   agrupan con `requestAnimationFrame`: llegan mil mensajes, se repinta una vez.
3. **El motor salteaba su propio limitador.** Había un freno de 400 ms, pero se
   forzaba un aviso al empezar y al terminar CADA archivo. Con archivos chicos
   —casi todos, en un estudio— eran miles de avisos por segundo hacia la
   ventana. Ahora hay un piso de 80 ms que ni el forzado saltea: doce refrescos
   por segundo, fluido y sin ahogar la pantalla. El aviso de cierre es la única
   excepción, para que no quede el penúltimo estado.

Medido: 25.000 líneas tardaban **13,3 segundos** solo en procesarse. Al
reintroducir el defecto a propósito, **la prueba se cuelga y hay que matarla** —
exactamente como se colgaba el programa.

Prueba nueva: `pantalla-muchos-archivos.cjs` (7).

**La franja de verificación decía dos cosas contradictorias y no se apagaba**

Decía "todavía hay archivos sin comprobar" en ámbar y, abajo, "no hace falta
hacer nada". Y seguía ahí después de apretar "Verificar respaldo". Dos bugs:

- **El cálculo estaba mal.** Se recorría `state.json` ENTERO, que guarda también
  archivos que ya no existen: borrados, renombrados o sacados de la selección.
  Esos nunca se procesan, así que nunca reciben la marca de comprobado, y con
  165.600 entradas siempre queda alguno. La franja quedaba en ámbar para siempre,
  incluso recién terminada una verificación completa. Ahora se cuenta solo sobre
  los archivos de la corrida.
- **El criterio estaba mal.** Una advertencia que dice "no hace falta hacer nada"
  no es una advertencia. Ahora ámbar y rojo son solo para cosas que están mal; si
  el programa se encarga solo, va en verde como información. Un aviso que no se
  puede apagar deja de leerse, y el día que avise algo de verdad tampoco se lee.

**Los destinos locales ahora cuentan como verificación.** Se comprueban contra el
disco en cada corrida —que el archivo esté y con el tamaño correcto— pero eso no
se contaba. Un cliente que respalda solo a un disco externo tenía la franja en
ámbar para siempre, avisándole de algo que el programa comprobaba siempre.

**709 pruebas en el cliente, 473 en el servidor, cero fallas.**

## 0.9.10

**Los archivos ya NO salen de la máquina en claro. Era el agujero más grave.**

Hasta la 0.9.9 el cifrado estaba a medias, y lo que faltaba era la mayor parte:

- Los archivos que van por **bloques** sí se cifraban.
- Los que van **enteros** —todo lo que está por debajo del umbral de 25 MB: los
  Excel, los Word, los PDF, o sea la mayoría de los archivos de un estudio
  contable— se subían **tal cual**. Protegidos solo por TLS en tránsito y por el
  cifrado del proveedor. El proveedor, o cualquiera con acceso a esa cuenta,
  podía leerlos.
- Y estaba anotado como pendiente en un documento en vez de estar cerrado.
  Anotar un riesgo no lo administra.

Ahora `s3Upload` cifra en flujo antes de subir. Se cifra a un archivo temporal
—la etiqueta de AES-GCM va en la cabecera y recién se conoce al terminar, así
que hay que tener el resultado completo— y el temporal se borra siempre, salga
bien o mal. Cargar un archivo de cientos de megas en memoria no era opción en un
equipo de estudio contable.

**La firma SigV4 cubre los bytes CIFRADOS**, que son los que viajan. Firmar con
la huella del original habría dado un 403 imposible de rastrear.

**Y algo peor que se encontró en el camino: los respaldos cifrados NO se podían
restaurar.**

La restauración llamaba al almacén de bloques y a la descarga directa **sin la
clave**, en los cuatro caminos. Un respaldo cifrado se guardaba bien y no se
podía devolver. Guardar bien y no devolver es la peor combinación posible en un
producto de backup: el cliente cree que está cubierto hasta el día que necesita
los archivos.

Se resolvió con una sola función, `claveDeCuenta()`, usada por los cuatro
caminos. La clave se resuelve una vez por operación y no por archivo: derivarla
cuesta cerca de un segundo a propósito, y hacerlo por archivo dejaría la
restauración inutilizable.

**El descifrado trabaja sobre el temporal, antes de renombrar.** Si la clave no
sirve, el archivo con su nombre definitivo nunca llega a existir. Un archivo
ilegible con nombre definitivo es lo peor que puede pasar: parece restaurado.

**Guarda: nada sale sin cifrar.** Si la cuenta tiene cifrado activo y por
cualquier motivo la clave no estuviera disponible, el respaldo **se detiene** en
lugar de subir. Subir sin cifrar sería peor que fallar, porque el cliente creería
que sus archivos están protegidos.

**Los respaldos viejos, sin cifrar, se siguen restaurando.** Un archivo sin la
marca se devuelve tal cual. Sin esto, activar el cifrado dejaría ilegible todo lo
anterior.

**Pantalla para elegir el modo y fijar la frase**

- Dos modos, con las consecuencias dichas de frente, no en letra chica.
- Del modo administrado se dice que **BackupPrime puede técnicamente leer los
  archivos**. Si no se dice, el cliente elige el modo por defecto creyendo que
  nadie puede leer sus datos.
- Del modo privado se dice que **si se pierde la frase se pierden los archivos, y
  no hay forma de recuperarlos**. Es la única función del programa que es
  irreversible por matemática y no por decisión nuestra.
- La frase se pide dos veces y en campos de contraseña. Se limpian al guardar.
- La frase **no se guarda en la configuración en claro**: se guarda la sal y un
  comprobante, que permite avisar "esa no es tu frase" ANTES de bajar gigabytes.
- **Cambiar la frase con respaldos ya hechos se rechaza con una explicación**, en
  lugar de dejar lo anterior ilegible en silencio.
- **El modo administrado NO se puede activar todavía**, y la pantalla lo dice:
  falta el circuito del servidor que genere y guarde la clave de cada cuenta.
  Activarlo a medias sería prometerle al cliente algo que no se puede cumplir.

**Pruebas nuevas**

- `nada-en-claro.cjs` (14): lee los **bytes que efectivamente llegaron al
  destino** y busca ahí el contenido original. Es la prueba que no se puede
  falsear leyendo el código. Con el bug reintroducido, el CUIT del archivo de
  prueba aparece en el destino y la prueba se pone en rojo.
- `pantalla-cifrado.cjs` (16): que la pantalla no prometa lo que no puede
  cumplir.

**695 pruebas en el cliente, 473 en el servidor, cero fallas.** La suite del
cliente corrió dos veces seguidas en verde.

## 0.9.9

**El destino del cliente se llenaba de archivos sueltos, y en restaurar se veían**

Es lo que se detectó mirando el bucket real: al lado de cada
`backup ASSOFT 2026-08-13 (Completo).zip` había un
`backup ASSOFT 2026-08-13 (Completo).zip.bpi` de 3 KB.

- Un `.bpi` es el **índice**: el JSON que dice qué bloques, en qué orden y con
  qué tamaño rearman el archivo. La receta. No son los bloques — esos siempre
  estuvieron escondidos en `bloques/`.
- Se guardaba en dos lugares por redundancia, y la segunda copia caía **pegada
  al archivo original**, dentro del árbol del cliente.
- Y lo grave: el listado de restaurar filtraba `bloques/` e `indices/`, pero no
  esa copia. El cliente veía su `.zip` y, al lado, un `.zip.bpi` de 3 KB.
  **Quien elegía el equivocado se llevaba un JSON creyendo que restauró su
  respaldo**, y se enteraba con el original ya borrado. En un producto de
  backup no hay peor falla que esa.
- Ahora la segunda copia va a `indices-copia/`. La redundancia se mantiene:
  siguen siendo dos objetos en ramas distintas, y perder `indices/` entera no
  deja al cliente sin sus archivos.
- El filtro dejó de estar duplicado en cada pantalla y pasó a ser una sola
  función, `Bloques.esRutaDeServicio`. Estaba escrito dos veces y una de las dos
  se había olvidado de los `.bpi`: por eso el listado los mostraba.
- **Los respaldos ya hechos se ven limpios sin tocar el destino.** El filtro por
  extensión se queda para siempre, no hasta una migración: los objetos viejos
  siguen en el bucket del cliente y no se borra ninguno. Un producto de backup
  no borra cosas del bucket del cliente por su cuenta.
- **Y se siguen restaurando.** La restauración busca el índice en tres
  ubicaciones, y la tercera es la vieja. Probado borrando las dos copias nuevas
  y dejando solo la de antes: el archivo vuelve idéntico byte por byte.

**El archivo al que solo le mueven la fecha ya no gasta nada**

No es un caso raro: es el caso más común del producto. Outlook le toca la fecha
al PST todos los días sin cambiar el contenido.

- El motor guardaba **`hash: null` para TODO archivo grande**, aunque
  `subirPorBloques` ya devolvía la huella calculada en su única pasada. Sin
  huella guardada no había con qué comparar, y un archivo con la fecha movida
  era indistinguible de uno que cambió de verdad.
- Consecuencia: se reescribía el índice en cada corrida. Con versionado en el
  destino eso crea una versión nueva por día, y como la retención tiene tope,
  **las versiones de índice le van corriendo el historial al archivo**: el
  cliente pide "volvé al lunes" y encuentra treinta versiones de esta semana y
  ninguna del lunes. Es también lo que multiplicaba los `.bpi` del bucket.
- Ahora el archivo se recorre —eso es inevitable, sin leerlo no hay forma de
  saber que es el mismo— pero **no se sube ni un objeto y no se gasta una
  versión**. Se guarda la fecha nueva, así que al día siguiente ni se abre.
- El catálogo tampoco se reescribe si no cambió: gastaba una versión por corrida.
- Un archivo así ya no se cuenta como "subido" en el resumen. Contarlo inflaba
  los MB y el cliente veía actividad que nunca viajó — en un producto que se
  paga por almacenamiento, eso parece un cargo.

**Verificación programada y revalidación rotativa**

Saltear un archivo sin tocar la red es correcto, pero deja a `state.json` como
única verdad sobre lo que hay en el destino. Si el destino perdió un objeto, el
cliente no se entera nunca: cada corrida dice "sin cambios" y el archivo no
está. **Un respaldo que parece estar y no está es peor que no tener respaldo.**

Dos redes, y son distintas:

- **Verificación programada**: cada 7 días revisa TODO contra el destino, sola,
  sin que nadie apriete nada (`verificacionCadaDias`).
- **Revalidación rotativa**: en cada corrida revisa los archivos que llevan más
  de 14 días sin comprobarse (`revalidarMaxDias`). Existe porque la programada
  depende de que la máquina esté prendida ese día, y en un estudio contable el
  domingo está apagada. Con la rotativa, **ningún archivo pasa más de dos
  semanas sin que alguien lo mire de verdad**, sin importar qué día se prenda.
- El costo es un listado por corrida, no un pedido por archivo. Preguntar de a
  uno con HEAD sería peor: son cientos de viajes, y varios servicios compatibles
  con S3 contestan 403 en vez de 404 cuando el objeto no existe — con esa
  respuesta el programa concluye que no está nada y resube todo. Ya pasó.
- **Si el destino no se puede listar, NO se anota como verificado.** Anotarlo
  haría que la próxima recién sea en una semana sin haber comprobado nada.
- El primer respaldo cuenta como verificación: cada archivo se acaba de escribir
  y la subida se confirmó una por una. Solo si no hubo errores.

**Lo que se le muestra al cliente**

- Franja de estado en Actividad, en los tres idiomas.
- El número que se muestra **no es la fecha de la última revisión**, es cuántos
  días hace que no se comprueba el **archivo más olvidado**. "Verificado el
  martes" puede ser cierto y engañoso a la vez: se puede haber verificado el
  martes y tener archivos que nadie mira desde hace dos meses.
- Verde comprobado, ámbar hace demasiado, rojo faltaban archivos.
- "Todavía no se comprobó" se dice con palabras, no con un número inventado.
- Bug encontrado al escribir la prueba: la franja daba por bueno cualquier dato.
  Un objeto incompleto caía en la última rama y pintaba **"todo comprobado" en
  verde sin que nadie hubiera comprobado nada**.

**Dos pruebas que fallaban solas — y una que no probaba nada**

- `bloques-e2e.cjs`, control 8, decía "no aparece ni un bloque ni un índice" y
  **pasaba en verde con el bug presente**: solo miraba que ninguna clave
  EMPEZARA con `bloques/` o `indices/`, y `…/Outlook.pst.bpi` no empieza con
  ninguno de los dos. Corregido, más el control 19b.
- `una-sola-lectura.cjs` —una de las guardas del EBUSY del PST— usaba
  `crypto.randomBytes`. Como los cortes por contenido dependen del contenido,
  los bloques caían distinto en cada corrida y el control de deduplicación
  fallaba una de cada tantas. Ahora usa datos deterministas con semilla fija. Es
  el mismo defecto ya corregido en otra prueba en la 0.9.8, que había quedado
  latente acá.
- `fecha-movida.cjs` pasaba sola y fallaba en la suite: tocaba la fecha con
  "ahora" y el chequeo rápido tolera un segundo, así que si el primer respaldo
  terminaba rápido el archivo se salteaba y la prueba no ejercitaba nada de lo
  que decía probar.

**Pruebas nuevas**: `destino-limpio.cjs` (13), `fecha-movida.cjs` (14),
`verificacion-programada.cjs` (22), `pantalla-verificacion.cjs` (17).

**Nueve bugs reintroducidos a propósito, los nueve detectados por su prueba.**
La suite corrió tres veces seguidas en verde para descartar inestabilidad:
**665 en el cliente, 473 en el servidor**.


## 0.9.8

**Los bloques ahora suben en paralelo: hasta 3 veces más rápido**

Esto sí corrige la demora. La 0.9.7 solo había ganado un 5%.

- El bucle de bloques era estrictamente secuencial: por cada bloque se esperaba
  un `existe()` —un pedido a la red— y después la subida, y **mientras tanto la
  lectura del archivo se frenaba**.
- Con un archivo de 300 MB son unos 75 bloques. A 80 ms de ida y vuelta contra el
  almacenamiento, son varios segundos gastados solo en preguntar si cada bloque
  ya está. **Y se pagan igual en el respaldo incremental, donde no se sube nada**:
  esa es la razón por la que un cliente con archivos de 150 a 300 MB ve demoras
  aunque "no haya cambiado nada".
- Ahora el archivo se sigue leyendo y cortando mientras los bloques viajan.
- Medido con 200 MB y 80 ms de latencia:
  · primer respaldo: **12,6 s → 4,0 s**
  · incremental sin cambios: 4,8 s → 3,9 s
- El tope es 4 en paralelo, configurable hasta 8. Más no acelera —la red se
  satura— y sí arriesga la memoria: cada bloque en vuelo son hasta 16 MB.

**Lo que hubo que asegurar al paralelizar**
- El índice queda en el ORDEN de lectura aunque las subidas terminen
  desordenadas. La prueba rearma el archivo desde el índice y lo compara con el
  original: un índice desordenado produce un archivo roto que no se nota hasta
  abrirlo.
- Si un bloque falla, **falla el archivo entero y NO se escribe el índice**. Un
  índice que apunta a bloques que no llegaron es un archivo irrecuperable.
- El índice se escribe recién cuando todos los bloques llegaron.
- El resultado guardado es idéntico con 1 que con 8 en paralelo.

**Dónde está el resto del tiempo, medido**
- Cifrar: 737 MB/s. No es el problema.
- Partir el archivo en bloques: 85 MB/s. Es un bucle byte por byte inherente al
  corte por contenido. Para bajarlo de verdad habría que llevarlo a código
  nativo, lo que agrega una dependencia compilada al instalador: queda anotado
  como decisión para cuando el producto esté vendiendo.

**La prueba nueva fallaba una de cada tres corridas**
- Usaba datos al azar y trozos chicos, así que los cortes caían distinto en cada
  repetición. Corregida con datos deterministas. Una prueba que falla sola es
  peor que no tenerla: enseña a ignorar los resultados.

## 0.9.7

**Medición: el cifrado NO es lo que hace lento el respaldo**
- Cifrar va a **737 MB/s**. Un archivo de 300 MB suma 0,4 segundos. Imperceptible.
- El cuello real es **partir el archivo en bloques: 81 MB/s**, contra 675 MB/s de
  solo leerlo y calcular su huella. Es un bucle byte por byte inherente al corte
  por contenido, y estuvo ahí siempre — no lo trajo ninguna versión reciente.
- Se agregó una optimización: saltear la zona donde el corte está prohibido (por
  debajo del mínimo de 1 MB), donde calcular la huella rodante no sirve para nada.
  Ganancia medida: 81 → 85 MB/s. Modesta.
- **Verificado que los puntos de corte no cambiaron** comparando contra la versión
  0.7.1 con un archivo determinista. Era imprescindible: si se movían, el próximo
  respaldo de cada cliente subía todo de nuevo.

**Prueba nueva: `pruebas/cortes-estables.cjs` — de las más importantes del proyecto**
- Congela los puntos de corte contra valores medidos en la 0.7.1.
- La deduplicación funciona porque un archivo se corta siempre en los mismos
  lugares. Si un cambio los mueve aunque sea un byte, ningún bloque coincide con
  lo guardado y **cada cliente vuelve a subir todo**. Para uno con 200 GB, eso son
  200 GB de subida y 200 GB más de consumo, de un día para el otro, sin que nadie
  lo pida — y sin forma de notarlo mirando la pantalla: el respaldo "funciona",
  solo que tarda días y duplica la factura.
- Comprueba además que insertar datos al principio NO mueva los cortes de más
  adelante, que es la propiedad que hace que un mail nuevo no obligue a resubir
  el PST entero.
- Si esta prueba falla, la respuesta casi nunca es actualizar los números: es
  revisar qué se rompió. Para cambiar el algoritmo de verdad hay que subir
  `VERSION_FORMATO` y mantener el lector anterior.

## 0.9.6

**Los archivos NO se estaban cifrando. Ahora sí, y el cliente elige cómo.**

Hallazgo de la auditoría: hasta la 0.9.5 los archivos se subían **tal cual**.
Estaban protegidos por TLS en tránsito y por el cifrado en reposo del proveedor,
y nada más — el proveedor, o cualquiera con acceso a esa cuenta, podía leerlos.
No había cifrado del lado del cliente en ninguna parte del código.

**Dos modos, y el cliente elige:**
- **Gestionada** (por defecto): la clave la guarda BackupPrime. Si el cliente
  pierde la contraseña, se le puede restablecer el acceso y bajar sus archivos, y
  habilita restaurar desde la web. A cambio, BackupPrime puede técnicamente leer
  los archivos.
- **Privada**: la clave se deriva de una frase que solo conoce el cliente y que
  **nunca viaja al servidor**. Nadie más puede leer los archivos. A cambio, si el
  cliente pierde la frase pierde todo, y no es una limitación sorteable: es
  matemática.

Es el mismo esquema que ofrece IDrive, y existe porque los dos casos son reales.

**Decisiones técnicas**
- AES-256-GCM, que además de cifrar detecta si los datos fueron alterados. Un
  byte cambiado falla en lugar de devolver basura que parece correcta.
- Vector de inicialización **al azar**, no derivado del contenido. Derivarlo haría
  que dos archivos idénticos den bytes idénticos, y eso permite confirmar si un
  archivo concreto está guardado sin tener la clave.
- **La deduplicación se mantiene**: los bloques se guardan bajo la huella del
  contenido sin cifrar, así que si ya está no se sube. Verificado con prueba.
- El cifrado se enchufa en `almacenDeBloques`, un solo punto por donde pasan
  todas las lecturas y escrituras. Repartirlo sería garantizar que en algún
  camino se olvide.
- **El índice también se cifra**: lleva nombres y rutas de los archivos del
  cliente, y eso ya es información sensible.
- La clave se resuelve UNA vez por corrida. Derivarla cuesta cerca de un segundo
  a propósito, para que probar frases al azar salga caro.
- Hay un comprobante que valida la frase **antes** de empezar: sin eso, alguien
  que la escribe mal se entera después de bajar gigabytes.
- Con la frase equivocada el respaldo **se detiene**. No sube sin cifrar como
  alternativa: eso sería peor que fallar, porque el cliente creería que sus
  archivos están protegidos.
- **Los respaldos hechos antes del cifrado se siguen restaurando.** Los datos sin
  la marca se devuelven tal cual. Sin esto, activar el cifrado dejaría ilegible
  todo lo anterior.

**Lo que FALTA para que esto esté completo** (no usar en producción todavía):
- El servidor tiene que generar y guardar la clave de cada cuenta, y entregarla
  al agente en el modo gestionado.
- La pantalla de configuración para que el cliente elija el modo y escriba su
  frase.
- El camino de archivos enteros (los que NO van por bloques) todavía sube sin
  cifrar: `s3Upload` transmite desde disco y necesita cifrado en flujo.
- Las tres puertas de rescate desde el panel de administración.

## 0.9.5

**Auditoría de fallas silenciosas — dos agujeros graves en la restauración**

En un producto de backup el peor modo de falla no es que algo falle: es que
PAREZCA haber funcionado. Un archivo restaurado a medias, abierto cuando el
original ya no existe, es la situación que el producto entero está para evitar.

- **Una descarga cortada dejaba el archivo truncado con su nombre definitivo.**
  `s3Descargar` escribía a un temporal y lo renombraba en cuanto el flujo
  cerraba, sin comparar contra el `Content-Length`. Un corte de red a mitad de
  camino producía un PST truncado que parece entero: el cliente lo abre, está
  roto, y ya borró el original.
- **Un bloque incompleto se usaba para rearmar el archivo.** `s3BajarDatos`
  devolvía lo que hubiera llegado. Con un pedazo truncado se rearma un archivo
  roto que parece correcto.
- Ahora las dos rutas verifican el tamaño recibido contra el anunciado Y detectan
  la conexión cortada. Son defensas distintas: una cubre el corte de socket, la
  otra el flujo que cierra limpio pero corto (un proxy que corta la respuesta).
- Los errores de red ya no llegan como "socket hang up" o "ECONNRESET". Ahora
  dicen que se cortó la conexión, que el archivo NO quedó a medias, y que se
  puede reintentar.

**La primera versión de la prueba no probaba lo que decía**
- Pasaba igual con la verificación de tamaño desactivada, porque en la simulación
  saltaba antes la defensa de conexión cortada. Se corrigió para comprobar las dos
  por separado, y se verificó que falla al sacar cualquiera de las dos.
- Es el mismo error que ya costó caro antes: una prueba que no falla con el bug
  presente no cubre nada.

**Lo que se revisó y estaba bien**
- El estado local se marca DESPUÉS de confirmar la subida, por destino. Un
  destino que falla no marca el archivo como respaldado.
- Si el índice de un archivo por bloques no se puede escribir, el error propaga y
  el archivo no se da por respaldado. Se guardan dos copias del índice.
- Rearmar por bloques verifica la huella completa antes de entregar el archivo, y
  trabaja sobre un temporal que se renombra al final.
- Los `catch` vacíos del motor son limpieza legítima (cerrar sockets, borrar
  temporales), no errores tragados.

## 0.9.4

**Nuevo: "Verificar respaldo" — comprueba sin duplicar**
- Cuando un respaldo se corta a mitad de camino —se colgó la máquina, se cortó la
  luz, se cayó la red— queda la duda de si lo que figura como subido está en el
  destino y está entero.
- La respuesta fácil sería "forzá un respaldo completo", y es la equivocada:
  `forceFullBackup` borra el registro y vuelve a subir TODO. Con versionado
  activo cada archivo se guarda otra vez como versión nueva. Para un cliente con
  134 GB respaldados, son **134 GB más de su cuota sin ningún beneficio**.
- "Verificar respaldo" lista el destino, compara cada archivo por clave **y por
  tamaño**, y sube únicamente lo que falta. No toca el registro local.
- Detecta también el caso peor: un archivo que existe en el destino pero quedó
  cortado por la mitad. Figura como respaldado y no sirve.
- El texto de ayuda del respaldo completo ahora advierte que consume cuota otra
  vez y sugiere verificar en su lugar.

**Un bug que la prueba encontró antes de que llegara a un cliente**
- La verificación leía `a.bytes` cuando `s3Listar` devuelve el campo como `size`.
  Todos los tamaños daban 0, ningún archivo coincidía y la verificación
  **resubía todo** — exactamente lo que este modo existe para evitar.
- La prueba mide la cantidad de versiones en el destino antes y después, así que
  lo agarró de inmediato. Comprobar el mensaje de "terminado" no habría servido.

## 0.9.3

**Se controla el espacio libre antes de respaldar (un cliente colgó su máquina)**
- Caso real: un cliente con el disco casi lleno respaldó 134 GB y la PC se colgó.
- La causa NO es el respaldo en sí. Los bloques se arman en memoria y se suben
  directo, sin copia temporal: el motor casi no toca el disco. El que consume es
  la **instantánea de volumen**: Windows reserva espacio en el mismo disco y lo va
  llenando con cada bloque que cambia mientras el respaldo corre, hasta un 10% del
  volumen por defecto. Con el disco al límite, Windows pelea por espacio y la
  máquina se arrastra hasta trabarse.
- No había ningún control: el programa arrancaba igual y dejaba que pasara.
- Ahora se revisa antes de empezar. Si el disco está apretado (menos de 10 GB
  libres **y** menos del 15%), se avisa y **no se crean instantáneas** — pero el
  respaldo se hace igual, porque leer los archivos directamente casi no usa disco.
- Si además está al límite (menos del 3% o menos de 2 GB), se agrega que conviene
  liberar espacio y por qué. Con el disco lleno es cuando MÁS conviene tener los
  archivos a salvo, así que nunca se cancela el respaldo.
- El aviso sale una vez por unidad, no por carpeta.
- En pantalla, arriba de todo aviso: con el disco al límite la máquina se puede
  trabar, y eso es más grave que cualquier detalle del respaldo.

**Cuánto espacio necesita BackupPrime (queda documentado)**
- Respaldar: prácticamente nada. Sin copias temporales del archivo.
- Instantáneas: hasta 10% del volumen mientras dura el respaldo.
- Restaurar: el tamaño completo de lo que se restaura.
- Recomendado: 15% del disco libre, y nunca menos de 10 GB.

**Íconos de Office reconocibles**
- La planilla era una tabla genérica que podía ser cualquier cosa. Ahora las
  familias de Office se leen por su letra y su color: **X** blanca sobre verde,
  **W** sobre azul, **P** sobre naranja, **PDF** sobre rojo.
- Rehechos también correo (sobre lleno), base de datos (cilindro) y certificado
  (escudo con tilde).
- **No se copian los logos de Microsoft ni de Adobe**: son marcas registradas y
  reproducirlas dentro de un producto que se vende es exponerse a un reclamo. Se
  usa el lenguaje visual —letra y color— que es lo que hacen Dropbox y Google
  Drive.

## 0.9.2

**Ahora se pueden elegir ARCHIVOS sueltos, no solo carpetas**
- El selector listaba únicamente carpetas (`.filter(e => e.isDirectory())`). Para
  respaldar un archivo suelto —el PST, una planilla, el certificado de AFIP— había
  que agregar la carpeta entera y después excluir todo lo demás a mano. Un
  contador que solo quiere su libro IVA no tiene por qué respaldar Documentos
  completo.
- El selector ahora muestra carpetas y archivos, con su ícono por tipo y su
  tamaño, para que el cliente vea cuánto pesa antes de elegirlo. En un archivo el
  clic sobre el nombre lo marca: no hay dónde entrar.

**Y un problema más grave que estaba detrás**
- Aunque se lograra poner un archivo como origen, `walkDir` da por sentado que
  recibe una carpeta: con un archivo no devolvía nada. El archivo elegido **no se
  respaldaba, y el respaldo terminaba diciendo que salió bien.**
- Es el peor modo de falla posible en este producto: el cliente cree que su
  archivo está guardado y no lo está. Corregido, con prueba que verifica el conteo
  real de lo subido y no el mensaje de "terminado".
- Un archivo que está excluido ahora se saltea **con aviso**, no en silencio. Uno
  que ya no existe deja constancia en lugar de pasar desapercibido.

**Etiquetas del selector traducidas**
- "Browse…", "User Profile", "Selected:" y "My Computer" quedaban en inglés. La
  auditoría no las agarraba porque no matcheaban el patrón de detección.

## 0.9.1

**Íconos por tipo de archivo al restaurar**
- Antes todos los archivos mostraban la misma hoja genérica: con mil archivos en
  la lista, encontrar "el Excel del balance" obligaba a leer cada nombre.
- Ahora cada familia tiene su ícono y su color: documentos, planillas, PDF,
  imágenes, video, audio, comprimidos, planos, código, fuentes y ejecutables.
- Con atención especial a lo que importa en un estudio contable: **correo**
  (.pst, .ost, .msg), **bases de datos** (.mdb, .accdb, .dbf, .bak — el sistema
  de gestión) y **certificados** (.pfx, .p12, .kdbx — facturación electrónica).
- Los temporales de Outlook (`~correo.pst.tmp`) se reconocen como correo, no como
  archivo desconocido.

**El mismo módulo en el programa y en el portal**
- `electron/iconos-archivo.js` y `js/iconos-archivo.js` son el mismo archivo. Si
  cada lado tuviera su tabla, con el tiempo un .pst se vería distinto en cada uno
  y habría que arreglar el mismo detalle dos veces. Hay una prueba que compara
  los dos archivos y falla si divergen.
- El portal tenía cuatro emojis y todo lo demás genérico; ahora usa el módulo.

**Decisiones de implementación**
- Son SVG dibujados, no imágenes ni una librería de íconos: el programa tiene que
  funcionar sin conexión y sin agregar peso al instalador, y el portal no
  debería pedirle nada a un servidor de terceros para mostrar una lista.
- Cada familia se distingue por **silueta**, no solo por color. Importa en listas
  largas y para quien no distingue bien los colores. Hay una prueba que falla si
  dos familias comparten forma.
- El ícono nunca incluye el nombre del archivo, así un nombre con comillas o
  `<script>` no puede inyectar nada. Probado con nombres hostiles.

## 0.9.0

**El agente ya puede entrar con email y contraseña**
- El programa llamaba a `POST /api/agent-auth/login` desde hacía tiempo y **el
  servidor no tenía esa ruta**. Cualquiera que bajara el agente recibía un 404 y
  tenía que configurar endpoint, bucket y claves a mano: lo contrario de lo que
  promete el sitio.
- Ahora entra con las mismas credenciales del portal, el equipo se da de alta
  solo y el espacio del cliente se crea si todavía no existe.
- **El equipo no recibe claves del almacenamiento.** Una notebook robada no da
  acceso a nada, y rotar la credencial maestra no obliga a tocar los equipos
  instalados. Hay una prueba que falla si alguna clave se cuela en la respuesta.
- Cuenta suspendida: 403 aclarando que los archivos siguen guardados. Es lo
  primero que va a preguntar el cliente.
- Token de 365 días: el equipo respalda solo, no hay nadie para reescribir la
  contraseña cuando venza.

**Espacio del plan: un solo número, en el programa y en el portal**
- UNA función calcula el consumo y la usan el agente, el portal y el panel. Si
  cada uno hiciera su cuenta los números diferirían —un cliente tiene varios
  equipos que suman al mismo cupo— y quien ve 340 GB en el programa y 355 GB en
  la web deja de creerle a los dos.
- Se mide el tamaño **lógico**: archivos más versiones, como si no existiera la
  deduplicación. El cliente entiende ese número y lo puede verificar mirando sus
  carpetas; "lo que ocupa realmente" cambia solo según cuánto se repitan los
  datos y no se puede defender por teléfono ni poner en una factura.
- La diferencia entre lo lógico y lo real queda como margen del negocio: en el
  PST de 651 MB fue del 97%. Permite ofrecer más espacio nominal que la
  competencia por el mismo costo real.
- El equipo informa su total **absoluto**, no la diferencia: con diferencias, un
  aviso perdido o repetido desajusta la cuenta para siempre.

**Tres estados, no dos**
- Hasta el 80%, nada. Desde el 80%, aviso. Pasado el 100%, se avisa **pero se
  sigue respaldando** (10% de gracia, para que el cliente tenga tiempo de
  decidir). Recién pasada la gracia se frenan las subidas.
- **Las restauraciones nunca se frenan**, aunque esté excedido. Frenar una
  restauración por una cuestión de facturación es el peor momento posible y va
  contra la razón de ser del producto. Hay una prueba dedicada a eso.
- Cuando el respaldo queda frenado, salta un aviso de Windows: es lo único que
  evita que el cliente se entere el día que necesita restaurar algo que nunca se
  subió.

**Indicador de espacio en el programa**
- Tarjeta con barra, porcentaje y color según el estado, arriba de todo en la
  pestaña de respaldo. Con botón "Consultar" para verificar en el momento.
- Se actualiza solo después de cada respaldo.

## 0.8.5

**Abrir el programa disparaba un respaldo, ignorando el horario configurado**
- `start()` corría un respaldo inmediato SIEMPRE, y el motor llama a `start()` en
  cada arranque. Con la programación en "cada 12 horas", abrir la ventana
  respaldaba igual: el horario no se respetaba y el usuario perdía el control
  sobre cuándo se usa su conexión. En una notebook con datos móviles eso se paga.
- Ahora se respalda al arrancar **solo si ya correspondía**: si nunca se respaldó
  en ese equipo, o si desde el último pasó más tiempo del que dice la
  programación. Si está al día, se espera al horario y se explica en el registro.
- No se puede simplemente esperar: si la máquina estuvo apagada tres días el
  momento programado ya pasó, y esperar al siguiente dejaría al cliente sin
  respaldo por más tiempo del que eligió. Por eso la regla es "ponerse al día", no
  "no correr nunca al arrancar".
- Funciona en los dos modos: cada X minutos, y días y hora concretos.

**Un respaldo interrumpido no cuenta como hecho**
- La fecha del último respaldo se anota solo si el respaldo TERMINÓ. Si el usuario
  apretó Detener, se cerró el programa o se cortó la luz, los archivos no quedaron
  a salvo: contarlo como "al día" dejaría al cliente esperando al próximo horario
  justo después de una corrida que no se completó.
- Lo detectó `pruebas/detener.cjs`, que ya cubría el reinicio después de detener.

**`hasState()` ignora las claves internas**
- La fecha del último respaldo se guarda en el mismo registro que los archivos.
  Sin excluirla, un equipo que nunca respaldó nada parecería tener estado y el
  primer respaldo se habría tratado como incremental: no habría subido nada.

**La programación se leía en inglés**
- "every 12 hours", "Mon, Tue at 03:00" en el registro de actividad de un programa
  en castellano. Ahora: "cada 12 horas", "lunes, martes y viernes a las 03:00",
  "todos los días a las 03:00".

**Prueba nueva: `pruebas/arranque-respeta-horario.cjs`**
- Cubre los dos modos de programación, el equipo recién instalado, la máquina que
  estuvo días apagada y los límites del intervalo.
- Comprobado que falla (6 fallas) si se reintroduce el respaldo incondicional al
  arrancar.

## 0.8.4

**El cartel de las instantáneas decía algo falso**
- Decía "los archivos abiertos pueden quedar afuera" siempre que el programa no
  corriera elevado. Es falso: la lectura directa funciona para casi todo,
  incluido el PST de Outlook, como quedó comprobado al arreglar la doble lectura.
- Los únicos archivos que realmente pueden necesitar una instantánea son las
  bases de datos que se estén escribiendo en ese momento (SQL Server, Access, un
  sistema de gestión). Word, Excel, PDF, fotos y planos se respaldan abiertos sin
  problema: Office bloquea el archivo pero permite leerlo.
- Ahora es una línea informativa en gris —"Leyendo los archivos directamente, sin
  instantánea"— y en el registro sale como dato, no como advertencia. Un respaldo
  que salió bien no se pinta de naranja.
- El cartel de Configuración que empujaba a reinstalar ya no aparece por defecto.
  Asustar al cliente con un problema que no tiene es peor que no decir nada.

**La barra no avanzaba en el camino por bloques**
- `marcarAvance` comparaba el avance contra la actualización anterior en lugar de
  contra el último valor EMITIDO. Con bloques de ~1 MB el salto nunca alcanzaba el
  umbral, así que después del primer aviso no se emitía ninguno más y la barra
  quedaba clavada.
- Ahora se compara contra lo último emitido, así que el avance se informa cada
  2 MB reales sin importar cuán rápido vaya la conexión.
- Lo encontró `pruebas/progreso-archivo-grande.cjs`, que ya cubría este caso.

## 0.8.3

**El PST se abría DOS veces. Esa era la causa del EBUSY, y viene de varias versiones atrás.**

- La secuencia real para un archivo grande era:
  1. el motor llamaba a `hashFile`, que abría el archivo y lo leía completo
     —651 MB— solo para calcular la huella, **sin reintentos**;
  2. después `subirPorBloques` lo abría **otra vez** para recorrerlo y cortarlo,
     esa sí con `abrirConReintentos`.
- Dos aperturas de un archivo que Outlook tiene tomado, y la primera —la que
  revienta— era justo la única sin protección.
- El arreglo de la 0.6.4 le sacó una lectura a `bloques.cjs` reutilizando la
  huella del motor, y quedó ahí: seguían siendo dos aperturas y la que fallaba
  seguía en pie. **Por eso el error "volvía": nunca se había ido del todo.**
- Ahora el motor NO lee los archivos que van por bloques: `recorrerBloques` ya
  calcula la huella total en su única pasada. Una apertura por archivo, en todo
  el respaldo.

**El intercambio que esto implica, explícito**
- La huella del archivo completo iba en el metadato de CADA bloque, y se necesita
  antes de subir el primero — de ahí venía la obligación de leer el archivo de
  antemano.
- Ahora los bloques se suben sin ese campo y la huella queda en el índice, que se
  guarda en dos copias.
- Lo que se pierde: si se pierden las DOS copias del índice y hay que
  reconstruirlo desde los bloques, el índice reconstruido no podrá verificar
  integridad. El archivo se rearma igual, porque cada bloque conserva `archivo`,
  `desde` y `bytes`.
- Leer el archivo una sola vez vale más que un campo redundante con el índice.

**Prueba nueva: `pruebas/una-sola-lectura.cjs`**
- Cuenta las aperturas reales del archivo durante un respaldo completo. Si
  alguien vuelve a agregar una lectura previa, falla acá y no contra el bucket del
  cliente.
- Verifica además que el índice conserve la huella correcta, que el archivo
  restaurado sea idéntico al original y que la deduplicación siga funcionando
  (98% de ahorro en el segundo respaldo).
- Comprobado que la prueba FALLA si se reintroduce la doble lectura. Una prueba
  que no falla con el bug presente no sirve para nada.

**Nota sobre VSS**
- Sigue siendo la solución correcta para archivos que otro programa mantiene
  abiertos, y queda enchufada desde la 0.8.0. Pero ya no es lo único que se
  interpone entre el PST y el respaldo: la doble lectura era un problema aparte, y
  este arreglo no depende de permisos de administrador.

## 0.8.2

**El arranque automático ahora corre con privilegios (esto es lo que hacía falta
para que VSS sirva en la máquina de un cliente)**

- El problema: VSS es la única forma de copiar un archivo que otro programa tiene
  abierto, y Windows exige permisos de administrador para crear la instantánea.
  El arranque automático se registraba en `HKCU\...\Run`, que arranca el programa
  SIN elevación. Resultado: en la máquina de un cliente el PST de Outlook no se
  respaldaba nunca, y el cliente no se enteraba hasta el día que lo necesitaba.
- Confiar en que el usuario haga clic derecho → "Ejecutar como administrador" no
  es una solución: no lo va a hacer, y no tiene por qué saber que hace falta.
- Ahora el arranque automático es una **tarea programada con `/RL HIGHEST`**,
  disparada al iniciar sesión. Arranca el programa elevado y —a diferencia de la
  entrada Run— sin mostrar el cartel de UAC en cada arranque.
- **La crea el instalador**, que ya corre elevado, así que el usuario no ve
  ningún pedido de permisos extra. El desinstalador la borra: si no, quedaría una
  tarea disparándose contra un .exe que ya no existe.
- Nunca la tarea y la entrada de Run a la vez, o el programa se abriría dos
  veces. Si la tarea no se puede crear, se cae al registro para que al menos
  arranque, y se avisa que va sin privilegios.
- Nuevo módulo `electron/tarea-programada.cjs`.

**Dos avisos distintos en Configuración, porque son dos problemas distintos**
- "No arranca solo" → no se hacen respaldos automáticos.
- "Arranca sin privilegios" → los respaldos SÍ corren, pero los archivos
  abiertos quedan afuera. Este es el más peligroso: todo parece funcionar y el
  archivo más importante del cliente no se está respaldando. Antes no se
  distinguía de ninguna forma.
- Y si está todo bien, se confirma en pantalla: "los archivos abiertos también se
  respaldan".

**Un falso positivo que habría dejado el problema invisible**
- La detección de privilegios buscaba "más altos" en la salida de `schtasks`,
  pero esa frase está en la ETIQUETA del campo ("Ejecutar con los privilegios más
  altos: LIMITED") y aparece igual cuando la tarea NO es privilegiada. En Windows
  en español habría dado por buena una configuración sin permisos.
- Ahora se mira el VALOR, no la etiqueta. `HIGHEST` y `LIMITED` son las dos únicas
  posibilidades y `schtasks` no las traduce, así que funciona en cualquier idioma.
- Lo encontró la prueba nueva, no una corrida en Windows.

**Aviso de instantánea: salía dos veces y no decía qué hacer**
- El módulo de VSS ya avisa por su cuenta; el motor lo repetía. Dos renglones
  seguidos diciendo lo mismo hacen parecer que hay dos problemas.
- Ahora sale una vez y explica la salida.

**Nota sobre lo que no se puede probar acá**
- Que Windows cree la tarea y que arranque elevada solo se verifica en Windows.
  `pruebas/arranque-privilegiado.cjs` cubre el armado del comando, la lectura del
  estado y el cableado —incluida la parte del instalador—, que es donde los
  errores se pagan en silencio.

## 0.8.1

**El encabezado decía "Respaldo" en lugar de "BackupPrime" (error mío en la 0.8.0)**
- Al pasar los textos fijos al diccionario tomé el `<span>` del logo como texto
  traducible. El logo es "Backup" + "Prime" en dos partes, así que en castellano
  el encabezado quedó como "Respaldo". El nombre del producto es BackupPrime en
  todos los idiomas y no se traduce nunca.
- Revertido, y con dos guardas para que no pueda repetirse: la auditoría marca
  cualquier clave donde la traducción pierda la palabra "Prime" que tenía el
  inglés, y `pruebas/idioma-pantalla.cjs` comprueba que el encabezado diga
  BackupPrime en los tres idiomas.
- El sitio y el portal no fueron tocados en ningún momento: verificado con un
  diff completo contra la versión de referencia.

**El aviso de "sin instantánea" salía dos veces y no decía qué hacer**
- El módulo de VSS ya avisa por su cuenta; el motor lo repetía. Dos renglones
  seguidos diciendo lo mismo hacen parecer que hay dos problemas distintos.
- Ahora sale una sola vez y, cuando el motivo es falta de permisos, explica cómo
  resolverlo: abrir el programa como administrador, o activar el arranque
  automático, que lo hace solo.

## 0.8.0

**VSS conectado al motor: el PST se respalda con Outlook abierto**
- La instantánea de volumen estaba construida y probada desde hace tiempo, pero
  nunca se había enchufado al motor. Ahora se crea antes de recorrer las
  carpetas y cada archivo se LEE desde la copia sombra.
- Es lo único que resuelve el caso real: los reintentos de `hashFile` sirven para
  bloqueos pasajeros, pero Outlook mantiene el PST tomado toda la sesión. Sin
  instantánea, el archivo más importante de un estudio contable quedaba afuera.
- Punto crítico del cableado: la clave en el destino y el estado incremental se
  siguen armando con `sourcePath`, la ruta original. Si se hubieran armado con la
  ruta de la instantánea —que incluye un número de ShadowCopy distinto en cada
  corrida— se habría resubido todo el respaldo bajo rutas nuevas y el historial
  de versiones habría quedado partido. Hay una prueba específica para eso.
- Si la instantánea no se puede crear (sin permisos de administrador, volumen que
  no es NTFS, servicio VSS caído), el respaldo SIGUE sin instantánea y se avisa
  en pantalla. Un respaldo degradado con aviso es mejor que ninguno; lo que no se
  hace es fingir que salió bien.
- Se libera en un `finally`: un respaldo que falla a mitad de camino ya no deja
  una copia sombra colgada comiéndole disco al cliente. Y al arrancar se limpian
  las que hayan quedado de una corrida anterior que se cerró mal.
- Nuevo aviso en la pantalla de progreso: si la instantánea no está activa, el
  usuario ve que sus archivos abiertos pueden haber quedado afuera.
- `pruebas/instantaneas.cjs` cubre la traducción de rutas, el fallback y el
  cableado. Lo que NO cubre —que Windows cree la instantánea y que el PST copiado
  sea íntegro— solo se puede verificar en Windows, con Outlook abierto y
  `scanpst.exe`.

**Idioma: la pantalla ya cambia completa**
- `applyLang()` alcanzaba solo a los elementos con id "lbl-…" que además
  existieran en el diccionario. Todo el resto quedaba fijo en el HTML, en inglés
  o en castellano según cuándo se hubiera escrito. La auditoría midió 77
  problemas; ahora son 0.
- Siete elementos tenían DOS atributos id (`id="addDest" id="lbl-dest-add"`). El
  navegador se queda con el primero, así que esas etiquetas no podían traducirse
  ni queriendo. Pasaron a `data-i18n`.
- 23 ids "lbl-" no tenían clave en el diccionario: todos los campos de S3, FTP y
  SFTP. Quedaban en inglés siempre.
- 35 textos fijos —incluido el castellano que se fue agregando en las últimas
  versiones— pasaron al diccionario en los tres idiomas.
- Las fases del respaldo ("Buscando archivos…", "Copiando archivos…") también
  salen del diccionario. Antes eran constantes en castellano.
- `<html lang>` se actualiza al cambiar de idioma. Antes quedaba en "en" siempre.
- Los nombres de los idiomas en el selector NO se traducen, a propósito: un
  brasileño busca "Português", no "Portugués".
- `pruebas/auditoria-idioma.cjs` lista cualquier texto que quede sin traducir y
  con `--estricto` falla; `pruebas/idioma-pantalla.cjs` cambia el idioma en un
  navegador simulado y comprueba que el texto efectivamente cambie.

**"Copiando archivos… 0 B copiados" se contradecía**
- Con un incremental donde nada cambió, la pantalla mostraba una barra casi llena
  y cero bytes: parecía una falla. Ahora dice cuántos archivos se están revisando
  y que todavía no cambió nada.

**ReferenceError al restaurar una selección que ya no existe**
- `inventario` solo existe dentro de la rama "restaurar todo", pero se usaba en el
  mensaje de error de las dos ramas. Al restaurar una selección que ya no estaba
  en el destino, el usuario recibía "Cannot access 'inventario'" en lugar de una
  explicación.

**La prueba de SFTP fallaba al azar**
- `generateKeyPairSync('ed25519')` de ssh2 devuelve de vez en cuando una clave
  que su propio `Server` rechaza como malformada, y hacía fallar el suite entero
  una corrida de cada varias. Ahora se genera y se valida hasta obtener una
  usable. Una prueba que falla sola es peor que no tenerla: enseña a ignorar los
  resultados.

## 0.7.5

**El panel "Versiones anteriores" no se abría al hacer clic en el archivo**
- El `<span>` con el nombre llevaba `data-toggle` también en los archivos, y el
  handler de `data-toggle` hacía `ev.stopPropagation()` ANTES de comprobar si el
  nodo era una carpeta. El evento moría ahí y nunca llegaba al handler de la
  fila: hacer clic en un archivo —que es literalmente lo que pide el panel— era
  lo único que no funcionaba. Andaba el botón del reloj y el área vacía de la
  fila, que es lo que nadie clickea.
- Ahora `data-toggle` va solo en las carpetas, y el handler comprueba primero y
  corta el evento después.
- Tildar la casilla de un archivo también trae sus versiones. Tildar una carpeta
  no: sería una consulta por cada archivo de la rama.

**Primeras pruebas de interfaz del cliente**
- No había ninguna: las 200+ pruebas del cliente son todas del motor, así que un
  clic que no hacía nada no tenía forma de ser detectado.
- `pruebas/arbol-restauracion.cjs` abre `renderer.html` en un navegador simulado
  (jsdom) y hace los clics de verdad: en el nombre, en el reloj, en la casilla y
  en las carpetas.
- Verificado que la prueba falla si se reintroduce el error, que es la única
  manera de saber que una prueba sirve para algo.
- `renderer.html` expone `window.__pruebasRestore` para cargar un árbol de prueba
  sin levantar Electron.

## 0.7.4

**La causa de fondo: las pruebas no verificaban la firma**
- El servidor de pruebas decía, textualmente: "No valida la firma (eso lo prueba
  el servidor real)". Por eso cualquier error de firma pasaba las 200+ pruebas y
  aparecía recién contra el bucket real como un 403 imposible de rastrear.
- Ahora valida SigV4 con una implementación independiente
  (`pruebas/firma-sigv4.cjs`), escrita desde la especificación y NO copiada de
  `s3Firmar`. Si se copiara el cliente, los dos errores se cancelarían y la
  validación no detectaría nada.
- El listado de versiones tampoco paginaba nunca en las pruebas: el servidor
  contestaba siempre `IsTruncated=false`. Con 1177 objetos en el bucket real, la
  paginación es justamente el camino que corre, y no tenía ni una prueba.

**EBUSY en el PST: el arreglo anterior cubría la mitad del recorrido**
- `bloques.cjs` ya tenía `abrirConReintentos`, y el problema figuraba como
  resuelto. Pero el motor llama PRIMERO a `hashFile` para saber si el archivo
  cambió, y `hashFile` abría el archivo de una sola vez, sin reintentos.
- Con Outlook abierto, el PST falla ahí y se cuenta como error, así que NUNCA
  llega al camino por bloques, que era el único que sabía reintentar. El error no
  había vuelto: nunca se había ido.
- `hashFile` ahora reintenta con espera creciente ante EBUSY/EPERM/EACCES, y si
  se rinde da un mensaje que dice qué hacer. Un error que no es un bloqueo sigue
  fallando enseguida, sin reintentos inútiles.
- Sigue en pie el límite real: un PST que Outlook mantiene abierto toda la
  sesión no se libera con reintentos. Eso lo resuelve VSS, que está construido y
  todavía sin conectar al motor.

**Firma: tres errores reales encontrados por la validación nueva**
- `host` firmado sin el puerto. Node manda `Host: host:puerto` cuando el puerto
  no es el estándar, así que la firma no coincidía contra cualquier endpoint con
  puerto explícito (MinIO en :9000, un proxy interno, el servidor de pruebas).
  Contra iDrive e2 no se notaba porque va por el 443.
- Valores de la query firmados con `encodeURIComponent`, que deja sin codificar
  `! ' ( ) *`. AWS los exige codificados. Un prefijo con paréntesis —"Copia (1)",
  que en Windows aparece solo— daba 403.
- Los parámetros se ordenaban por la cadena "nombre=valor" completa en lugar de
  por nombre. Con los parámetros de hoy da el mismo resultado, pero por
  casualidad: basta un valor que empiece con un carácter menor que "=" para que
  el orden cambie y la firma deje de coincidir.

**Paginación de versiones: se perdían versiones en silencio**
- `NextKeyMarker` y `NextVersionIdMarker` se usaban sin desescapar el XML. Una
  clave con "&" volvía como "&amp;" y la página siguiente se pedía sobre una
  clave que no existe: a partir de ahí se perdían versiones sin ningún aviso.

**Un 403 ahora se puede diagnosticar**
- El mensaje de error incluye la query firmada y la petición canónica completa.
  Sin eso, un 403 contra el bucket real no da ninguna pista de qué revisar.

## 0.7.3

**La barra no se movía al respaldar un archivo grande**
- `progreso.bytesSubidos` se actualizaba únicamente al TERMINAR cada archivo.
  Con un PST de 651 MB eso significa que durante todo el proceso la pantalla
  mostraba "Copiando archivos… 0 B copiados", la velocidad en "—" y el tiempo
  restante en "—". Indistinguible de un programa colgado, y justo en el archivo
  donde el usuario más necesita ver que algo pasa.
- Tres agujeros, los tres tapados:
  · `hashFile` leía el archivo entero para saber si cambió sin informar nada.
  · `streamRequest` (subida entera a S3) contaba los bytes y no los reportaba.
  · el respaldo por bloques ni siquiera recibía el callback `alAvanzar`, que ya
    existía en `bloques.cjs` desde el principio.
- Ahora el motor mantiene un registro de los archivos en vuelo y publica
  `bytesEnVuelo` más el detalle de los archivos de más de 8 MB, con su nombre,
  su total, cuánto lleva hecho y en qué fase está (revisando si cambió,
  partiendo por bloques, o subiendo).
- La velocidad ya no se calcula solo con los archivos terminados, así que en un
  archivo grande deja de mostrar "—".
- En pantalla, cada archivo grande tiene su propia barra con porcentaje real:
  ahí sí se conoce el total, así que no es una barra de actividad.
- El registro en vuelo se libera en un `finally`: un archivo que falla a mitad
  de camino ya no queda contado para siempre.
- `pruebas/progreso-archivo-grande.cjs` respalda un archivo de 40 MB por los dos
  caminos (entero y por bloques) y verifica que el avance llegue, crezca, no
  supere el total del archivo y quede en cero al terminar.

**`acorn` y `acorn-walk` pasaron a devDependencies**
- Solo los usa `pruebas/identificadores.cjs`. Estaban en `dependencies`, así que
  se empaquetaban dentro del instalador que se entrega al cliente.

## 0.7.2

**Herramienta nueva: `npm run diagnostico-versiones`**
- Prueba siete formas distintas de pedir `?versions` contra el bucket real y
  dice cuál contesta 200, incluyendo un control con el listado normal para
  separar "problema de credencial" de "problema de esta consulta".
- Si el servidor devuelve su propia canonical request, la compara línea por
  línea con la nuestra y marca en qué difiere.

**Volver a una fecha restauraba los archivos de hoy (grave)**
- `bajarRemoto` llamaba a `s3Descargar` sin pasarle el `versionId`, y S3 sin
  `versionId` devuelve la versión **actual** del objeto. Los archivos guardados
  por bloques sí lo pasaban; los guardados enteros, no.
- Consecuencia: "volver la carpeta a como estaba el lunes" traía los archivos
  chicos tal como están hoy —los que cifró el ransomware— mezclados con los
  grandes correctos, y sin ningún aviso. Es exactamente el caso que el producto
  promete resolver.
- La prueba de `maquina-tiempo.cjs` no lo detectaba porque rehacía el bucle de
  descarga a mano pasando el `versionId` ella misma: comprobaba la lógica de
  elección, no que el programa la usara.
- Se agregó `pruebas/restaurar-version-correcta.cjs`, que baja dos versiones
  reales del mismo archivo y verifica el contenido, más una guarda estática que
  falla si alguna llamada a `s3Descargar` vuelve a omitir el `versionId`.

**La barra no se movía al restaurar una versión suelta**
- `s3Descargar` contaba los bytes pero no los informaba, y el seguidor arrancaba
  sin total: el porcentaje caía en "archivos hechos / archivos totales", que con
  un solo archivo es 0% hasta el final y después 100%.
- Ahora `s3Descargar` acepta un callback de avance, informa el `Content-Length`
  como total y reporta cada bloque de datos. La pantalla además manda el tamaño
  de la versión elegida, así la barra tiene un total desde el primer byte.

**El calendario no decía hasta dónde llega el respaldo**
- `restore:fechas` devuelve `primera`, `ultima` y `totalDias`; el campo de fecha
  usa `min`/`max` y arriba se lee "Se puede restaurar entre el X y el Y".
- Si la fecha que había quedado cae fuera del rango de la carpeta elegida, se
  corrige sola en lugar de fallar al confirmar.
- Un error al consultar las fechas ya no se muestra como "todavía no hay
  versiones guardadas": decirle a alguien que no tiene respaldos porque se cortó
  la red es el peor mensaje posible en un programa de respaldo.

## 0.7.1

**La barra de progreso se quedaba en 0% al restaurar un archivo grande**
- Al rearmar un archivo guardado por bloques no se informaba nada hasta
  terminar: el cartel mostraba 0% durante todo el proceso y de golpe cerraba.
  En un PST de 651 MB eso son minutos mirando un cero.
- Ahora informa a medida que rearma, y funciona con varios archivos bajando a la
  vez: cada uno reporta cuánto avanzó desde la última vez, en lugar de pisar el
  total de los demás.

**Diagnóstico de versiones**
- Cuando el panel dice que no hay versiones anteriores, ahora hay un
  "Ver detalle técnico" que muestra exactamente qué claves se consultaron en el
  almacenamiento y qué contestó cada una.
- Sirve para distinguir dos cosas que se veían igual: que el archivo realmente
  tenga una sola versión, o que estemos preguntando por la clave equivocada.

## 0.7.0

**La máquina del tiempo, ahora sobre carpetas enteras**

Hasta acá las versiones eran archivo por archivo. Eso no sirve para el caso que
de verdad importa: cuando entra un ransomware nadie quiere recuperar UN archivo,
quiere la carpeta como estaba el día antes.

- En Restaurar hay un bloque nuevo: elegís una carpeta, elegís una fecha, y el
  programa trae **de cada archivo la última versión anterior a ese momento**.
- Se puede aplicar a una carpeta o a todo el respaldo.
- **Los archivos que en esa fecha todavía no existían no se traen.** La carpeta
  queda como estaba, no como una mezcla de épocas.
- Muestra qué días tienen algo guardado, con cuántos cambios cada uno, para que
  no haya que adivinar en un calendario vacío.
- Funciona igual con los archivos guardados por bloques: se rearman con el
  contenido que tenían ese día.
- Nada se sobrescribe: se restaura en una carpeta nueva que elegís.

**Once pruebas nuevas** simulan tres días de trabajo con un virus que cifra todo
el tercer día, y verifican que volver al segundo devuelva el contenido de ese
día, que un archivo creado el martes no aparezca en el estado del lunes, y que
el archivo grande vuelva a su versión de cada fecha.

**Restaurar una versión suelta no mostraba nada**
- Se apretaba "Restaurar esta versión" y el botón decía "Restaurando…" sin barra,
  sin velocidad y sin tiempo restante. En un PST de 651 MB eso son minutos a
  ciegas.
- Ahora usa la misma barra de progreso que el resto: porcentaje, archivo en
  curso, megas, velocidad y cuánto falta. Y se puede cancelar.

**Un bug encontrado por las pruebas**
- El catálogo interno de archivos grandes se colaba en el listado como si fuera
  un archivo del cliente, y la restauración a una fecha intentaba recuperar algo
  llamado `_catalogo.json`.

## 0.6.5

**Las versiones anteriores no aparecían, y el cartel mentía**
- Un archivo guardado por bloques **no existe como objeto con su nombre**: vive
  repartido en pedazos y lo que se versiona es su índice. El programa buscaba las
  versiones por el nombre del archivo, no encontraba nada, y mostraba "no hay
  versiones anteriores".
- Era falso, y justamente en los archivos más importantes del cliente: el PST de
  Outlook, la base del sistema de gestión, los planos grandes.
- Ahora se buscan donde están de verdad: en el índice, y si falta, en la copia
  del índice. Restaurar una versión anterior de un archivo grande rearma el
  archivo tal como estaba ese día.

**Y no había forma de encontrar la función**
- Las versiones aparecían solo al hacer clic en la fila del archivo, sin nada que
  lo indicara. Ahora **cada archivo tiene un botón de reloj** a la derecha que
  abre su historial.

**El cartel dice la verdad**
- Con una sola versión ahora dice "una sola versión guardada: este archivo no
  cambió desde el primer respaldo", en lugar de dar a entender que no hay
  historial. Y en los destinos que no guardan versiones —FTP, SFTP, carpetas
  locales— explica que el historial lo guarda el proveedor de almacenamiento.

**Cinco pruebas nuevas** sobre exactamente este caso: que por el nombre del
archivo no haya nada, que en el índice estén todas las versiones, que la copia
del índice también las tenga, y que restaurar una versión anterior devuelva el
contenido de entonces y no el actual.

## 0.6.4

**"EBUSY: resource busy or locked" en el PST con Outlook abierto**
- El respaldo por bloques abría el archivo dos veces: una para recorrerlo y
  calcular los cortes, y otra para leer cada pedazo por posición. Con un archivo
  que otro programa tiene tomado —Outlook con su PST es el caso típico— esa
  segunda apertura falla.
- Ahora **se lee una sola vez**: se corta y se sube en la misma pasada. Además de
  arreglar el error, es la mitad de trabajo de disco.
- Y nunca hay más de un bloque en memoria, aunque el archivo pese 650 MB.

**Si el archivo está tomado un instante, se reintenta**
- Outlook, los sistemas de gestión y los antivirus toman y sueltan archivos todo
  el tiempo. Un bloqueo momentáneo no puede costar el respaldo del archivo más
  importante del cliente: se espera y se vuelve a intentar, hasta cuatro veces.
- Si igual no se puede, el mensaje explica qué pasa y qué hacer, en vez de
  mostrar "EBUSY" y dejar al usuario adivinando.

**Y se lee el archivo una vez menos**
- La huella que el motor ya calculó para detectar si el archivo cambió ahora se
  reutiliza para los bloques. Antes se recalculaba.

## 0.6.3

**Que nunca se pueda perder un archivo grande por perder su índice**

Los archivos grandes se guardan en pedazos, y para rearmarlos hace falta el
índice que dice qué pedazo va en qué posición. Un pedazo solo es anónimo: sin
índice, no hay forma de saber de qué archivo es. Tres capas nuevas para que eso
no ocurra nunca:

- **El índice se guarda en dos lugares**: en `indices/` y una copia junto a donde
  estaría el archivo. Si una regla de ciclo de vida mal puesta barre una carpeta,
  la otra copia salva el día. Y el bucket queda autodescriptivo: se navega a la
  carpeta y el índice está ahí.
- **Cada pedazo lleva anotado de qué archivo es, en qué posición, de qué tamaño
  total y la huella del archivo completo.** Con eso, si se perdieran las dos
  copias del índice, se puede reconstruir desde los pedazos.
- **Y la reconstrucción es verificable, no una apuesta.** Se rearma el archivo,
  se calcula su huella y se compara con la que quedó anotada en los pedazos. Si
  no coincide, no se escribe nada: un índice inventado que produce un archivo
  corrupto es peor que no tener índice, porque el cliente creería que recuperó
  sus datos.

**Revisión de salud, en Configuración**
- *Revisar ahora* comprueba que todos los pedazos de todos los archivos grandes
  estén donde tienen que estar. Es lo que detecta un problema **antes** de que
  haga falta restaurar; sin esto, uno se enteraría el peor día posible.
- *Reconstruir índices* primero simula y muestra qué se puede recuperar y qué no,
  con el motivo. Recién si se confirma, escribe.

**Diez pruebas nuevas para el peor escenario**: se borran los índices y sus
copias, se reconstruye desde los pedazos, y se verifica que el archivo
restaurado sea idéntico al original. Incluye el caso en que la reconstrucción
**no** es posible —cuando al archivo le insertaron contenido y las posiciones
guardadas quedaron viejas— comprobando que se niegue con una explicación en
lugar de escribir un índice que daría un archivo roto.

## 0.6.2

**El mismo archivo aparecía en dos ramas distintas del árbol**
- Había dos convenciones a la vez para nombrar un archivo en el destino:
  guardando por bloques, `C:\Users\…` quedaba como `C/Users/…`; guardando
  entero, como `Users/…`. En la pantalla de restaurar se veía una carpeta `C`
  con el PST adentro y otra `Users` con todo el resto.
- **La consecuencia era grave:** restaurar la carpeta `Documents` no traía los
  archivos grandes que estaban dentro de esa misma carpeta, porque vivían en
  otra rama.
- Ahora hay una sola función que decide la ruta, y la usan los cuatro destinos y
  las dos formas de guardar.

**Dos unidades distintas se pisaban entre sí**
- Al borrar la letra de unidad, `C:\datos\plano.dwg` y `D:\datos\plano.dwg`
  terminaban en la misma clave y uno sobrescribía al otro. Con carpetas de dos
  discos se perdían archivos en silencio.
- La letra de unidad ahora es la primera carpeta, que es lo que ya hacían los
  destinos en disco. Las carpetas de red también quedan bien.
- Once pruebas nuevas sobre la ruta, incluidas las molestas: barras repetidas,
  `..`, rutas de red, acentos y espacios.

**Ojo con el bucket de prueba:** las claves cambiaron, así que lo que subiste
antes queda con la ruta vieja. Conviene vaciar el bucket y volver a respaldar
para no tener las dos convenciones mezcladas.

## 0.6.1

**Los bloques se reutilizaban mal contra servicios reales**
- Para saber si un bloque ya estaba guardado, el programa preguntaba uno por
  uno con HEAD. Varios servicios compatibles con S3 contestan 403 en vez de 404
  cuando el objeto no existe, y con esa respuesta el programa concluía que
  NINGÚN bloque estaba: volvía a subir el archivo entero todos los días, que es
  justamente el problema que los bloques venían a resolver.
- Ahora se pide la lista de bloques guardados **una sola vez por corrida**. Es
  una llamada en lugar de ciento veintiocho para un archivo de 650 MB, y no
  depende de cómo conteste el servidor.
- Prueba nueva con un servidor que contesta mal a propósito: tiene que reutilizar
  los bloques igual y el archivo tiene que restaurarse perfecto.

**No había forma de ver si el ahorro estaba funcionando**
- El resumen solo aparecía cuando ya había bloques reutilizados, así que en el
  primer respaldo no se veía nada y era imposible distinguir "se guardó por
  bloques" de "se subió entero".
- Ahora cada archivo grande deja constancia en Actividad, también la primera vez:
  cuántos bloques tiene, cuántos se subieron, cuántos megas de cuántos y el
  porcentaje de ahorro.
- Y al empezar avisa cuántos bloques ya había guardados en el destino.

## 0.6.0

**Archivos grandes: se sube solo lo que cambió**
- Un PST de 650 MB al que Outlook le agrega dos mails se subía entero, todos los
  días. Con 30 días de versiones eran 19,7 GB de un solo archivo.
- Ahora los archivos de más de 25 MB se parten en pedazos y solo se suben los que
  cambiaron. Medido con ese mismo PST durante 30 días: **de 19,7 GB a 114 MB
  subidos, y de 19,7 GB a 0,75 GB ocupados**.
- El umbral se configura en Configuración → Archivos grandes. 25 MB es lo medido:
  por debajo casi no hay ahorro, porque el archivo tiene pocos pedazos y cambiar
  algo cambia casi todo. A 25 MB entran los PST, los planos de CAD y los archivos
  de los sistemas de gestión.
- Los cortes se deciden mirando el contenido, no cada X megas. Si fueran fijos,
  insertar algo al principio correría todo y habría que volver a subir el archivo
  entero.

**Y para el usuario no cambia nada**
- En la pantalla de restaurar sigue viendo `Outlook.pst` con su tamaño real. Los
  pedazos y los índices no aparecen por ningún lado.
- Al restaurarlo, el programa lo rearma y **verifica que el resultado sea idéntico
  al original antes de entregarlo**. Si un pedazo llegara alterado, falla con un
  mensaje claro en lugar de dar un archivo roto que parece entero.
- Las versiones anteriores funcionan igual que con cualquier archivo.
- El listado vive en el destino, no en la computadora: un cliente que reinstala
  Windows ve su respaldo igual.

**Restaurar una selección era eterno**
- Para bajar tres archivos, el programa volvía a recorrer el destino completo
  —148.000 objetos— buscando cuáles eran. El cartel de "Restaurando…" quedaba
  girando varios minutos sin que pasara nada visible. Ahora usa lo que la
  pantalla ya sabe y arranca en el acto.

## 0.5.21

**La máquina del tiempo: versiones anteriores desde el programa**
- Con el versionado activado en el bucket, el proveedor guarda cada versión de
  cada archivo. Hasta ahora eso existía en el proveedor pero era invisible desde
  el programa, que para el usuario es lo mismo que no existir.
- En la pestaña Restaurar, al hacer clic en un archivo aparecen sus versiones al
  costado, con fecha y tamaño, de la más nueva a la más vieja y con la actual
  marcada.
- Se elige una y se restaura. **Se guarda al lado del archivo actual, con la
  fecha en el nombre, y no lo reemplaza**: nadie quiere descubrir que "restauré
  la de ayer" borró la de hoy.
- Trece pruebas nuevas simulan tres días de trabajo sobre el mismo archivo —
  incluido el día en que un virus lo cifra— y verifican que se pueda volver a la
  versión sana.
- En carpetas locales, FTP y SFTP el panel explica que ese destino no guarda
  versiones, en lugar de aparecer vacío sin motivo. El historial lo guarda el
  proveedor de almacenamiento.

## 0.5.20

**Faltaban archivos en la restauración: había un tope de 50.000**
- El listado del destino cortaba a los 50.000 archivos. Un escritorio común
  tiene 150.000, así que **se mostraba un tercio del respaldo como si fuera
  todo**, y refrescar no cambiaba nada porque el tope era fijo. Los archivos
  estaban en el destino; lo que fallaba era la pantalla.
- **El tope se eliminó por completo**, en S3, FTP, SFTP y carpetas locales. Un
  programa de backup no puede tener un límite de archivos.
- Mientras recorre el destino se informa cuántos archivos va encontrando, porque
  con cientos de miles ya no es instantáneo.
- Si por cualquier motivo el listado quedara incompleto, ahora se avisa en rojo y
  se recomienda no restaurar hasta resolverlo, en lugar de un texto gris al final
  de un renglón.

**Se quedaba varios minutos en un mismo archivo**
- El recorrido de carpetas y los trabajadores compartían la misma cola, y esa
  cola se atiende de a uno. Si el recorrido se trababa en un archivo que el
  antivirus estaba revisando, **todos** los trabajadores quedaban esperando ese
  archivo: parecía congelado.
- Ahora el recorrido llena una reserva por su cuenta y los trabajadores comen de
  ahí. Un archivo trabado frena solo al que lo tocó.

## 0.5.19

**Herramienta para saber cuánto va a tardar el primer respaldo**
- `npm run estimar -- "C:\\Users\\usuario\\Desktop"` escanea la carpeta y estima
  el tiempo. No es una regla de tres sobre los gigabytes: con archivos chicos
  manda la cantidad de idas y vueltas al servidor y con archivos grandes manda
  el ancho de banda, así que el modelo tiene las dos cosas.
- Está calibrado contra las mediciones del banco de pruebas: con 120 archivos de
  50 KB y 6 simultáneas predice 10,3 s y la medición dio 10,4 s.
- Muestra cómo se reparten los archivos por tamaño, el tiempo estimado para 6,
  12, 16, 24 y 32 transferencias simultáneas, y dice si conviene subir ese
  número o si ya estás usando todo el ancho de banda.

## 0.5.18

**"Detener" ahora detiene**
- Marcaba una bandera que se miraba entre archivo y archivo. Con seis
  transferencias simultáneas y archivos grandes contra un servidor lento, eso
  tardaba minutos y parecía que el botón no hacía nada.
- Ahora se cortan las conexiones y las lecturas abiertas: deja de copiar en
  menos de cinco segundos. Ocho pruebas nuevas lo verifican, incluida la de
  volver a arrancar después.

**Un archivo que el antivirus está revisando ya no cuelga el respaldo**
- Leer un archivo no tenía límite de tiempo. Si el antivirus lo estaba
  revisando, o si otro programa lo tenía tomado, la corrida entera quedaba
  esperando ahí.
- Ahora se corta a los dos minutos sin recibir datos, se anota qué archivo fue y
  con qué explicación, y se sigue con el resto.

**La tarjeta de velocidad explica el compromiso real**
- Con muchos archivos chicos, el límite es la cantidad de idas y vueltas al
  servidor, no el ancho de banda. Medido contra un servidor con 150 ms de
  latencia y archivos de 50 KB: 6 simultáneos dan 4,7 Mbps; 16 dan 10,1; 32 dan
  15,8 — con la misma conexión. Con archivos de 4 MB el mismo caso da 144 Mbps
  con solo 6. Ahora la pantalla lo dice, con los números.

## 0.5.17

**No conectaba con iDrive e2 por el https:// que falta**
- La consola de e2 muestra la dirección del servicio como
  `s3.us-southeast-1.idrivee2.com`, sin `https://` adelante. Sin el esquema, la
  dirección no es válida y todo fallaba con "Invalid URL".
- Ahora se completa sola, y también se aceptan espacios alrededor y la barra
  final, que es como queda al copiar y pegar.

**El mensaje de error mandaba a revisar lo que no era**
- Con una dirección mal escrita, el programa decía "las credenciales no son
  válidas o la suscripción no está al día". El usuario se iba a revisar la clave
  y el problema estaba tres campos más arriba. Ahora dice que la dirección está
  mal escrita.
- Y los mensajes nombran al destino en lugar de decir "undefined", que es lo que
  pasaba con los destinos S3 sin etiqueta.

**No se podían guardar cambios en un destino S3**
- Error mío de la versión anterior: al editar, la clave secreta se mostraba
  vacía a propósito, pero la validación seguía exigiéndola. No se podía guardar
  ningún cambio sin volver a tipear la clave entera. Ahora, en blanco significa
  "dejá la que estaba".

**Se pueden revisar las claves guardadas**
- Al editar un destino, las claves y contraseñas se cargan en el formulario y
  hay un botón de ojo para verlas. Ya están guardadas en esa misma computadora,
  así que mostrarlas no expone nada nuevo — y sin eso no había forma de
  verificar si una clave de cuarenta caracteres estaba bien copiada.

## 0.5.16

**Los destinos se pueden editar**
- Antes solo se podían agregar y borrar. Para corregir un dato —un endpoint mal
  copiado, una región equivocada— había que borrar el destino y cargarlo de
  nuevo entero, incluida la clave secreta.
- Ahora cada destino tiene un botón de editar. El tipo no se puede cambiar,
  porque eso sería otro destino.
- **Las contraseñas y claves se dejan en blanco al editar.** Si no escribís
  nada, se conserva la que ya estaba. Así podés arreglar un endpoint sin volver
  a tipear una clave secreta de cuarenta caracteres y arriesgarte a equivocarla.
- Probar la conexión desde la edición usa la clave guardada, así que sirve para
  verificar el cambio antes de aplicarlo.
- Quitar un destino ahora pide confirmación y aclara que los archivos que ya
  están ahí no se borran, solo dejan de actualizarse.

## 0.5.15

**S3: los nombres de archivo con espacios o acentos**
- Al subir, el nombre iba sin codificar en la dirección; al bajar, codificado.
  Con un archivo llamado "Balance Ferretería Ruiz (final).xlsx" —o sea, el
  primer archivo real de cualquier estudio— la firma no coincidía, o el archivo
  quedaba guardado con un nombre y buscado con otro.
- Ahora se codifica igual de los dos lados, siguiendo la regla que exige la
  firma de Amazon, que además de lo habitual pide codificar ! ' ( ) *.
- Tres pruebas nuevas con un archivo de nombre difícil: que suba, que aparezca
  entero en el listado y que vuelva idéntico.

**Herramienta para probar iDrive e2 antes de configurarlo**
- `npm run probar-e2` conecta con tus credenciales reales y va paso por paso:
  listar los buckets de la cuenta, crear el bucket si falta (con
  `--crear-bucket`), subir tres archivos, verificar los nombres y bajarlos
  comparando el contenido.
- Cuando algo falla dice qué probar en vez de un error genérico. La mayoría de
  los problemas con e2 son la región equivocada en la firma, y el mensaje que
  devuelve el servidor no lo dice.

## 0.5.14

**Se colgaba en "Contando archivos…" y no había forma de salir**
- El canal de datos del FTP no tenía ningún límite de tiempo. Si el servidor
  daba una dirección a la que no se podía llegar, la espera era eterna.
- Y esa dirección suele ser mentira: muchísimos servidores FTP están detrás de
  un router y contestan con su IP interna (192.168.x.x, 10.x.x.x), imposible de
  alcanzar desde afuera. Ahora, cuando la dirección que contesta el servidor es
  interna, se usa la del servidor al que ya estamos conectados — que es lo que
  hacen los clientes FTP de escritorio desde hace décadas.
- Todo el canal de datos tiene límite de tiempo: conectar, y quedarse sin
  recibir nada. Antes cualquiera de las dos cosas colgaba el programa.

**Se puede cancelar una restauración**
- Antes la única salida era cerrar el programa, que deja archivos a medio bajar.
  Ahora hay un botón en el cartel de progreso: termina el archivo que está en
  curso y frena. Vale para carpetas locales, FTP, SFTP, S3 y la nube.

**La X de los carteles de error no cerraba nada**
- El cartel entero tenía `pointer-events: none`, así que ignoraba el mouse. El
  botón estaba, se veía, y el clic nunca le llegaba.

**Contar los archivos del destino remoto es mucho más rápido**
- El recorrido de carpetas iba de a una, y cada carpeta cuesta varios viajes de
  ida y vuelta. Ahora se reparte entre varias conexiones, como las subidas y las
  bajadas.

**Pruebas**
- Tres casos nuevos contra un servidor que contesta con una dirección interna:
  que no se cuelgue, que el proceso siga vivo y que el error explique qué pasó.

## 0.5.13

**"Respaldar ahora" no hacía nada si ya había un respaldo en curso**
- El motor descartaba el pedido y solo escribía una línea en el registro, que
  nadie mira. Con destino local el respaldo termina en segundos y el botón
  siempre parecía andar; con FTP tarda, así que al apretarlo todavía estaba
  corriendo el anterior y no pasaba nada. Se veía como "el FTP no respalda las
  carpetas nuevas".
- Ahora el pedido **queda anotado** y arranca apenas termina el que está
  corriendo, y la pantalla lo dice en vez de quedarse callada.

**Las carpetas agregadas durante un respaldo se perdían hasta la próxima corrida**
- Al agregar carpetas mientras el respaldo trabajaba, el cambio se guardaba
  pero el trabajo en curso lo ignoraba, y con un intervalo de una hora eso es
  una eternidad. Ahora al terminar vuelve a correr con la configuración nueva.
- No hace falta ningún botón de guardar: los cambios ya se guardaban al
  instante. Lo que faltaba era que el trabajo en curso se enterara.

**Se ve qué está pasando sin cambiar de pestaña**
- La barra de progreso estaba en Actividad. Se movió a la pantalla principal,
  arriba de todo.
- Y en la cabecera hay un indicador chico que se ve desde cualquier pestaña,
  con cuánto se copió hasta el momento.

**Se entiende en qué estado está el agente**
- Antes había dos botones iguales y ninguna indicación de si estaba vigilando o
  detenido. Ahora hay una etiqueta que dice *Vigilancia activada*, *Detenido* o
  *Respaldando ahora*; el botón que no corresponde queda deshabilitado; y abajo
  se explica en una línea qué significa y qué conviene hacer.

## 0.5.12

- El dominio del proyecto quedó en `backupprime.com`. El programa ya viene
  apuntando ahí: el cliente solo escribe su email y su contraseña, un campo
  menos donde equivocarse. Se puede cambiar desde Configuración avanzada para
  pruebas o instalaciones a medida.
- Datos de contacto del instalador actualizados al dominio definitivo.

## 0.5.11

**"reply was never sent": ahora se ve el error de verdad**
- Ese mensaje aparece cuando la pantalla le pide algo al programa y ese pedido
  no contesta nunca. No dice nada del problema real y deja el cartel de
  progreso girando para siempre.
- Pasaba por tres motivos, y los tres están tapados: que se lanzara algo que no
  es un error y no se pudiera transmitir, que la respuesta tuviera adentro algo
  que no se puede serializar, o que algo reventara fuera de un try y la promesa
  quedara colgada. Ahora todo pedido contesta siempre.
- **El error real queda escrito en la pestaña Actividad.** Si vuelve a pasar,
  ahí va a estar la causa en lugar del mensaje genérico de Electron.

**Un error suelto ya no mata el programa**
- Este programa está prendido todo el día. Si algo reventaba fuera de un try
  —un socket que emite un error tarde, una promesa que nadie atendió— Node
  terminaba el proceso y el usuario se quedaba sin respaldo sin enterarse.
  Ahora queda registrado y el programa sigue andando.

**Pruebas contra un servidor FTP que se porta mal**
- Ocho pruebas nuevas con un servidor que corta la conexión al saludar, al
  listar y a mitad de un archivo; que rechaza las conexiones de más; y que se
  queda mudo. En los ocho casos el programa tiene que sobrevivir y avisar.
- Con un servidor que anda bien, estos casos no se reproducen nunca, que es por
  qué el problema llegó hasta acá.

## 0.5.10

**La restauración era mucho más lenta de lo que debía**
- Bajaba de a un archivo por vez, por una sola conexión. El respaldo se
  paralelizó en la 0.5.5 y la restauración quedó atrás sin que nadie lo midiera:
  contra un servidor remoto, casi todo el tiempo era espera.
- Ahora usa la misma cantidad de transferencias simultáneas que el respaldo, que
  se configura en Configuración → Velocidad de transferencia.
- Medido contra un servidor de prueba con 40 ms de latencia y 30 archivos:
  de 1.976 KB/s a 9.446 KB/s. Casi cinco veces más rápido con el valor por
  defecto.
- Aplica a FTP, SFTP y S3. Si el servidor no acepta tantas conexiones, los
  trabajadores que sobran se retiran y los demás siguen: baja más lento, pero
  no falla.

**El logo**
- La ventana del programa seguía mostrando una "B" sobre un cuadrado oscuro, de
  antes de que tuviéramos el logo. Ahora es el mismo de las tres barras que usa
  el ícono y el sitio.

## 0.5.9

**La restauración muestra qué está pasando**
- Antes solo giraba un cartel. Restaurar puede tardar horas y el usuario no
  sabía si iba bien, cuánto faltaba o si se había colgado, así que terminaba
  cerrando el programa por las dudas.
- Ahora hay barra de progreso, porcentaje, archivo en curso, cuántos van de
  cuántos, cuántos megas de cuántos, velocidad y tiempo restante.
- La velocidad se calcula sobre los últimos diez segundos, no sobre el promedio
  total: si la conexión se frena, la estimación lo refleja en vez de quedarse
  pegada en un número optimista.
- En archivos grandes la barra se mueve mientras se copia el archivo. Antes se
  hubiera quedado quieta media hora en uno de 4 GB.
- Funciona igual restaurando de una carpeta local, de FTP, de SFTP, de S3 y de
  la nube.
- Para poder mostrar el total, primero se cuenta todo lo que hay que traer.

## 0.5.8

**Se caía la aplicación entera durante la restauración por FTP**
- El socket de control quedaba sin nadie escuchando los errores después de
  conectar. Cuando el servidor FTP cortaba la conexión —cosa que hacen por
  inactividad, por límite de conexiones o por un hipo de red— Node emitía el
  error sobre un socket sin escucha, y eso mata el proceso entero. Desde la
  pantalla se veía como "reply was never sent" y el cartel de restauración
  quedaba girando para siempre.

**Los avisos de Windows ya no se apilan**
- Antes avisaba de cada respaldo terminado. Si respalda cada hora y dejás la
  máquina prendida el fin de semana, el lunes te esperan treinta carteles para
  cerrar de a uno. Un aviso que aparece siempre deja de ser un aviso.
- Tres modos, en Configuración → Avisos de Windows: solo cuando algo falla
  (viene puesto así), cada respaldo, o nunca.
- Horas de silencio configurables, incluso cruzando la medianoche.
- El mismo problema no se repite más de una vez cada seis horas. Si el disco
  externo está desenchufado y el respaldo corre cada hora, alcanza con avisar
  una vez, no veinticuatro.
- Los avisos comunes ya no hacen ruido; los de error sí.

**Los carteles de error se pueden cerrar**
- Tenían una X invisible: había que adivinar que se cerraban haciéndoles clic
  encima. Ahora la cruz se ve, funciona la tecla Escape, y como último recurso
  se van solos al minuto.

## 0.5.7

Revisión de todos los tipos de destino, uno por uno. El resultado fue que la
mitad no se podía recuperar.

**Ahora se puede restaurar desde todos lados**
- **La nube no restauraba nada desde el programa.** Al elegirla en la pestaña
  Restaurar aparecía un cartel y ninguna lista de archivos: no había forma de
  bajar nada. El servidor sí tenía todo. Ahora se explora en el mismo árbol que
  los demás destinos.
- **S3 y SFTP ni siquiera figuraban** entre los orígenes para restaurar. El
  respaldo subía bien y no había manera de recuperarlo. Ahora aparecen, se
  exploran y se bajan archivos sueltos, carpetas o todo.
- Las descargas de SFTP van todas por una sola conexión y las de S3 en paralelo.
- Todo lo que se baja se escribe de forma atómica: si se corta la descarga a
  mitad de camino no queda un archivo truncado haciéndose pasar por bueno.

**Pruebas de lo que antes no tenía ninguna**
- Servidores de prueba propios de FTP, SFTP y S3, incluidos en el proyecto. Las
  pruebas respaldan contra cada uno, listan lo que quedó y lo vuelven a bajar
  comprobando que el contenido esté intacto.
- Un chequeo automático busca funciones que se llaman pero no existen — el error
  que hizo que los destinos locales nunca copiaran un solo archivo. Corre antes
  que el resto de las pruebas.
- 90 pruebas en total, con `npm run pruebas`.

## 0.5.6

**Restaurar desde FTP no restauraba nada**
- Al elegir archivos y darle a restaurar, el programa respondía "no se encontró
  ningún archivo para restaurar" aunque estuvieran ahí listados. La pantalla
  mandaba la selección identificando cada archivo de una forma y la parte que
  los busca en el servidor los esperaba de otra, así que no coincidía nunca
  nada. El motor y la pantalla andaban bien por separado; el error estaba en el
  medio. Esa parte ahora vive en un archivo propio y tiene sus pruebas.

**Elegir carpetas enteras**
- Tildar una carpeta ahora arrastra todo lo que tiene adentro. Antes había que
  ir archivo por archivo, impracticable en un backup real.
- Una carpeta con parte de su contenido elegido se muestra a medias, para
  distinguirla de una vacía o una completa.
- Botón "Elegir todo" para seleccionar el respaldo entero de una.

## 0.5.5

**Mucho más rápido contra cualquier servidor**
- El programa transfería un archivo por vez: mandaba uno, esperaba la
  confirmación y recién ahí empezaba el siguiente. Contra un servidor remoto
  cada archivo cuesta varios viajes de ida y vuelta, así que con archivos
  chicos más del 90% del tiempo era espera pura. Por eso tener 400 Mbps no
  cambiaba nada: el cuello de botella nunca fue el ancho de banda.
- Ahora se transfieren varios archivos al mismo tiempo. La cantidad se
  configura en Configuración → Velocidad de transferencia (6 por defecto).
- Medido contra un servidor de prueba con 40 ms de latencia y 60 archivos:
  de 8,0 s a 1,6 s con el valor por defecto, y a 1,0 s con 12 simultáneos.
- Aplica a todos los destinos: nube, S3, FTP, SFTP, carpetas locales y de red.

**FTP en particular**
- Se dejó de entrar carpeta por carpeta con CWD para cada archivo. Ahora la
  ruta va completa en el comando de subida y las carpetas se crean una sola
  vez, compartido entre todas las conexiones. Si un servidor no acepta rutas
  completas, el programa lo detecta y vuelve al método anterior solo.
- Cada transferencia simultánea usa su propia conexión, como hacen los
  clientes FTP de escritorio.

**El registro de estado frenaba los respaldos grandes**
- Se reescribía el archivo entero después de cada archivo respaldado. Con
  50.000 archivos eran 50.000 escrituras de un archivo cada vez más grande, así
  que el respaldo se iba frenando solo a medida que avanzaba. Ahora se agrupa,
  y la escritura es atómica: un corte de luz ya no puede dejar el registro
  corrupto y obligar a subir todo de nuevo.

**Restaurar desde FTP**
- Un respaldo hecho contra un servidor FTP se subía bien, pero el destino no
  aparecía en la pestaña Restaurar y no había forma de recuperarlo desde el
  programa. Ahora aparece, se explora igual que una carpeta local y se pueden
  bajar archivos sueltos, carpetas enteras o el respaldo completo.

## 0.5.4

**Los destinos locales y de red ahora funcionan**
- La función que copiaba el archivo a una carpeta local o de red no existía en
  el programa. Cada archivo fallaba con un error interno, así que ningún
  destino local, de red o en disco externo recibió jamás un solo archivo, y
  agregar un segundo destino no copiaba nada. Los destinos en la nube y S3 no
  estaban afectados.
- Al agregar un destino nuevo, los archivos que ya estaban respaldados en los
  otros se copian al nuevo. Antes el chequeo incremental los daba por hechos.
- Se verifica en el disco si el archivo está realmente en el destino, en vez de
  confiar solo en el registro interno. Si alguien borró la carpeta, formateó el
  disco o cambió el pendrive, el archivo se vuelve a copiar. Es el peor error
  posible en un backup: creer que hay copia donde no hay nada.
- Los archivos se escriben de forma atómica: primero a un temporal y recién ahí
  se renombran. Si se corta la luz o se desenchufa el disco a mitad de la copia,
  la versión anterior queda intacta en vez de quedar truncada.
- Un destino que no está disponible (disco desenchufado, carpeta de red caída)
  se avisa una sola vez y se omite en esa corrida, en vez de generar un error
  por cada archivo. Cuando vuelve, recibe todo lo que quedó pendiente.
- Se conserva la fecha de modificación de cada archivo copiado.

**Excluir carpetas**
- El botón para agregar una exclusión abría un cuadro de diálogo que el entorno
  del programa no soporta: en vez de pedir la ruta, tiraba el error
  "prompt() is not supported" y no se podía excluir nada. Ahora abre una
  ventana propia, y se puede elegir la carpeta con el explorador en vez de
  escribir la ruta a mano.

**Arranque automático**
- La tilde se destildaba sola. El programa guardaba el arranque automático con
  un argumento y después lo leía sin ese argumento, así que Windows respondía
  que no estaba configurado aunque sí lo estuviera. Se leía y se escribía de
  forma distinta.

**Cambios de configuración durante un respaldo**
- Al cambiar los destinos o el horario mientras había un respaldo corriendo,
  arrancaba un segundo respaldo en paralelo sobre el mismo registro. El viejo
  terminaba pisando lo que anotaba el nuevo y algunos archivos quedaban
  marcados como respaldados en destinos donde nunca habían llegado. Ahora el
  cambio se aplica cuando termina el que está en curso.
- Al detener la vigilancia, el respaldo en curso se corta en el archivo
  siguiente en vez de seguir hasta el final.

**Menor**
- Una ruta con caracteres especiales podía romper la lista de exclusiones.

## 0.5.3

**FTP muchísimo más rápido**
- Se reutiliza la conexión durante toda la corrida. Antes se abría una
  conexión nueva por cada archivo: conectar, autenticar, crear carpetas y
  negociar el canal de datos. Con muchos archivos chicos, la mayor parte
  del tiempo se iba en eso.
- Corregida una espera de 30 segundos entre archivo y archivo: el canal de
  datos no se cerraba al terminar la transferencia y quedaba esperando a
  que lo cortara el control de inactividad.
- Se recuerdan las carpetas ya creadas, para no repetir el mismo trabajo.
- Corregida una acumulación de detectores de eventos que degradaba el
  rendimiento y consumía memoria en respaldos largos.

En una prueba con 25 archivos sobre una conexión con 40 ms de latencia, el
tiempo pasó de más de 12 minutos a menos de 3 segundos.

## 0.5.2

**Ahora se ve qué está pasando**
- Barra de actividad durante el respaldo, con el archivo que se está copiando,
  cuántos van, cuántos se saltearon, cuántos fallaron, la velocidad y el
  tiempo transcurrido. Antes la pantalla quedaba quieta y no había forma de
  saber si estaba funcionando.
- Los errores se resaltan en rojo mientras corre, no solo al final.

**Probar un destino antes de usarlo**
- Botón "Probar conexión" al agregar un destino. Escribe un archivo de prueba,
  lo verifica y lo borra: comprobar que conecta no alcanza, porque puede
  faltar permiso de escritura o espacio.
- Muestra datos útiles según el tipo: espacio libre en carpetas locales,
  usuario y carpeta en FTP y SFTP, servidor y región en S3.
- Avisa explícitamente que FTP no cifra la conexión.
- Los errores se explican en castellano, con el detalle técnico aparte.

## 0.5.1

**Almacenamiento legible**
- Los archivos ahora se guardan con su nombre y su estructura de carpetas
  real. Antes se guardaban con un nombre derivado del contenido, ilegible.
  El cambio permite recuperar los datos de un cliente entrando directamente
  a la consola del proveedor de almacenamiento, sin depender de la base de
  datos ni de ninguna herramienta.
- Las versiones anteriores van a una carpeta separada, así la carpeta
  principal refleja siempre el estado actual del equipo.

**Versiones anteriores**
- Ahora se conservan 10 versiones por archivo por defecto (antes 5), con un
  máximo de 30. La pantalla advierte cuánto espacio implica.

**Correcciones importantes**
- Las versiones viejas nunca se borraban: el programa las pedía, pero el
  servidor devolvía siempre una sola, así que el límite configurado no se
  aplicaba y el espacio crecía sin freno.
- Al borrar una versión se eliminaba solo su registro, no el archivo. El
  archivo quedaba ocupando espacio de forma permanente e invisible.
- La poda ahora la ejecuta el servidor por su cuenta, para que el límite se
  respete aunque el programa falle.

## 0.5.0

Primera versión con la identidad visual definitiva y correcciones importantes
de comportamiento.

**Arranque automático**
- El programa ahora se inicia solo con Windows, minimizado en la bandeja.
  Antes, si el usuario no lo abría a mano, no se respaldaba nada — y la
  persona creía que sí. Se puede desactivar desde Configuración.

**Icono de la bandeja**
- Ahora se ve. El archivo del icono directamente no existía en el paquete,
  por eso no aparecía nada al lado del reloj.
- El icono se adapta al tema claro u oscuro de Windows, así queda visible
  en ambos casos.
- El menú de la bandeja muestra el estado y permite respaldar al instante.

**Restauración**
- Explorador en árbol: carpetas que se abren con los archivos adentro, en vez
  de dos listas separadas de archivos y carpetas.
- Búsqueda que filtra el árbol y resalta las coincidencias.
- Selección múltiple: archivos y carpetas mezclados, se restauran juntos.
- Se puede restaurar desde destinos locales y de red, no solo desde la nube.

**Actividad**
- La pestaña mostraba texto técnico en inglés. Ahora es una lista legible en
  castellano, con hora e ícono por tipo de evento.
- Los errores explican la causa y qué hacer, en vez del mensaje técnico crudo.
- Filtros por tipo, y una opción para ver el detalle técnico si hace falta
  diagnosticar a fondo.

**Cuenta**
- Se entra con el email y la contraseña del portal. El equipo se registra solo.
  Antes había que copiar y pegar un token a mano.

**Correcciones**
- Al cambiar de destino, los archivos ya respaldados no se copiaban al destino
  nuevo: el programa los daba por hechos sin fijarse a dónde habían ido.
- El programa informaba al servidor un estado que el servidor no reconocía,
  así que ningún respaldo quedaba registrado como exitoso.
- Un archivo podía quedar marcado como respaldado por el éxito de otro archivo
  distinto de la misma corrida.
- Los archivos se cargaban enteros en memoria antes de subirse. Con archivos
  grandes eso podía agotar la memoria; ahora se transmiten mientras se leen.
- Se podían abrir dos instancias del programa a la vez, pisándose entre sí.
- El escaneo no salteaba carpetas de sistema de Windows, generando errores
  de permisos y basura en el respaldo.
- La configuración se escribía de forma que un corte de luz podía dejarla
  corrupta. Ahora la escritura es atómica.
- Al cerrar la ventana, el programa liberaba menos memoria de la que podía.
  En reposo ahora consume bastante menos.

**Seguridad**
- El token del equipo se guarda cifrado con el sistema de Windows (DPAPI).
  Antes quedaba legible en un archivo de texto.

## 0.4.0

Versión inicial: respaldo incremental, programación, destinos en la nube,
S3, FTP, SFTP y carpetas locales o de red.
