'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Auditoría de idioma de la pantalla del cliente.

   El problema: `applyLang()` traduce SOLO los elementos cuyo id empieza con
   "lbl-" y que además existen como clave en el diccionario. Todo el resto del
   texto queda tal como está escrito en el HTML, y ahí hay frases en inglés y en
   castellano mezcladas. Al cambiar de idioma, parte de la pantalla cambia y
   parte no.

   Esta herramienta no adivina: lista exactamente qué queda afuera.

     node pruebas/auditoria-idioma.cjs            # informe
     node pruebas/auditoria-idioma.cjs --estricto # falla si hay problemas
   ═══════════════════════════════════════════════════════════════════════════ */

const fs = require('node:fs');
const path = require('node:path');

const RENDERER = path.join(__dirname, '..', 'electron', 'renderer.html');
const html = fs.readFileSync(RENDERER, 'utf8');
const estricto = process.argv.includes('--estricto');

// ── El diccionario, tal como lo ve el programa ──
const bloque = html.match(/const LANGS\s*=\s*\{[\s\S]*?\n    \};/);
if (!bloque) { console.error('No se encontró el diccionario LANGS.'); process.exit(1); }
let LANGS;
try {
  LANGS = new Function(bloque[0].replace(/^const LANGS\s*=/, 'return') + ';')();
} catch (e) {
  console.error('El diccionario no se pudo leer:', e.message); process.exit(1);
}

const idiomas = Object.keys(LANGS);
const clavesEn = new Set(Object.keys(LANGS.en || {}));

// ── Los ids que hay en el HTML ──
const idsHtml = [...html.matchAll(/\bid="([^"]+)"/g)].map((m) => m[1]);
const idsLbl = idsHtml.filter((i) => i.startsWith('lbl-'));

// Elementos con DOS atributos id: el navegador se queda con el primero, así que
// el segundo no existe y su traducción nunca se aplica.
const idsDuplicados = [...html.matchAll(/<[^>]*\bid="([^"]+)"[^>]*\bid="([^"]+)"[^>]*>/g)]
  .map((m) => ({ usado: m[1], ignorado: m[2] }));

const marcas = [...html.matchAll(/\bdata-i18n(?:-html)?="([^"]+)"/g)].map((m) => m[1]);
const sinTraduccion = [...new Set([...idsLbl, ...marcas])].filter((i) => !clavesEn.has(i));
const clavesLblSinElemento = [...clavesEn]
  .filter((k) => k.startsWith('lbl-') && !idsHtml.includes(k));

// ── Traducciones incompletas entre idiomas ──
const faltantesPorIdioma = {};
for (const l of idiomas) {
  if (l === 'en') continue;
  faltantesPorIdioma[l] = [...clavesEn].filter((k) => !(k in (LANGS[l] || {})));
}

// ── Texto visible sin ninguna posibilidad de traducirse ──
// Se busca dentro del <body>, en elementos de texto que no tengan un id "lbl-".
const cuerpo = html.slice(html.indexOf('<body'), html.indexOf('</body>'));
const sinCuerposDeCodigo = cuerpo.replace(/<script[\s\S]*?<\/script>/g, '')
                                 .replace(/<style[\s\S]*?<\/style>/g, '');

// Elementos cuyo texto lo reescribe el propio código con t() cada vez que se
// dibuja la pantalla. Su contenido en el HTML es solo el estado inicial.
const DINAMICOS = new Set(['schedInfo', 'mtCarpeta', 'pvAyuda', 'autoStartWarn',
  'lbl-src-empty', 'lbl-dest-empty', 'lbl-excludes-empty']);

const ACENTOS = /[áéíóúñÁÉÍÓÚÑ¿¡]/;
const PALABRAS_ES = /\b(el|la|los|las|de|del|que|para|con|sin|una|por|más|cada|desde|hasta|todo|todos|se|no|hay|está|ya|acá|querés|podés|vas|tenés)\b/i;
const PALABRAS_EN = /\b(the|and|for|with|without|your|you|this|that|all|every|from|until|are|is|not|click|select|backup|folder|drive|schedule|settings|apply|add|run)\b/i;

const textos = [];
for (const m of sinCuerposDeCodigo.matchAll(/<(span|div|label|button|p|strong|h[1-6]|option|summary|td|th)\b([^>]*)>([^<]{3,})</g)) {
  const [, etiqueta, atributos, texto] = m;
  const limpio = texto.replace(/\s+/g, ' ').trim();
  if (!limpio || /^[\d\s.,:%·—–\-+()[\]{}<>/\\|]*$/.test(limpio)) continue;
  if (/\$\{/.test(limpio)) continue;              // plantilla de JS, no texto fijo
  const id = (atributos.match(/\bid="([^"]+)"/) || [])[1] || '';
  const marca = (atributos.match(/\bdata-i18n(?:-html)?="([^"]+)"/) || [])[1] || '';
  // Un elemento se considera cubierto si lo alcanza applyLang(): por su id
  // "lbl-", por data-i18n, porque es una pestaña, o porque el propio código lo
  // reescribe con t() en tiempo de ejecución.
  const traducible =
    (id.startsWith('lbl-') && clavesEn.has(id)) ||
    (marca && clavesEn.has(marca)) ||
    (id.startsWith('tab-') && clavesEn.has(id)) ||
    DINAMICOS.has(id);
  if (traducible) continue;
  const esEs = ACENTOS.test(limpio) || PALABRAS_ES.test(limpio);
  const esEn = !esEs && PALABRAS_EN.test(limpio);
  if (!esEs && !esEn) continue;
  // Los nombres de los idiomas en el selector se escriben en su propio idioma,
  // a propósito: un brasileño busca "Português", no "Portugués".
  if (etiqueta === 'option' && /^(English|Español|Português)$/.test(limpio)) continue;
  // El nombre del producto no es texto traducible: es un nombre propio. El logo
  // lo parte en dos <span> ("Backup" + "Prime"), así que el trozo suelto aparece
  // acá y hay que dejarlo en paz.
  if (/\bhdr-title\b/.test(atributos)) continue;
  textos.push({ etiqueta, id, texto: limpio.slice(0, 72), idioma: esEs ? 'es' : 'en' });
}


// ── El nombre del producto no se traduce nunca ──
// Esto está acá por un error real: al pasar los textos fijos al diccionario, el
// <span> del logo —que es "Backup" + "Prime" en dos partes— se tomó como texto
// traducible y en castellano el encabezado pasó a decir "Respaldo". El nombre
// del producto es BackupPrime en todos los idiomas.
// Ojo con el criterio: "Backup" como palabra suelta SÍ se traduce cuando es la
// pestaña o una acción ("Copia de Seguridad"). Lo que no se traduce nunca es el
// nombre propio, y eso se reconoce por dos cosas: que aparezca "BackupPrime"
// junto, o que el valor traducido pierda la palabra "Prime" que tenía el inglés.
const marcaTraducida = [];
for (const [idioma, dicc] of Object.entries(LANGS)) {
  if (idioma === 'en') continue;
  for (const [clave, valor] of Object.entries(dicc)) {
    if (typeof valor !== 'string') continue;
    const enIngles = String((LANGS.en || {})[clave] || '');
    const mencionaMarca = /BackupPrime/i.test(enIngles) || /\bPrime\b/.test(enIngles);
    if (!mencionaMarca) continue;
    const conservaMarca = /BackupPrime/i.test(valor) || /\bPrime\b/.test(valor);
    if (!conservaMarca) {
      marcaTraducida.push({ idioma, clave, de: enIngles, a: valor });
    }
  }
}
// Y el encabezado con el logo no debe estar marcado para traducir.
const logoMarcado = /<span class="hdr-title"[^>]*data-i18n/.test(html);

const langDinamico = /document\.documentElement\.lang\s*=/.test(html);
const problemas = idsDuplicados.length + sinTraduccion.length +
  Object.values(faltantesPorIdioma).reduce((n, f) => n + f.length, 0) + textos.length +
  (langDinamico ? 0 : 1) + marcaTraducida.length + (logoMarcado ? 1 : 0);

// ── Informe ──
const sep = (t) => console.log('\n' + t + '\n' + '─'.repeat(t.length));
console.log('BackupPrime — auditoría de idioma de la pantalla del cliente');
console.log(`\nIdiomas en el diccionario: ${idiomas.join(', ')}`);
console.log(`Claves en inglés (referencia): ${clavesEn.size}`);
console.log(`Ids "lbl-" en el HTML: ${new Set(idsLbl).size}`);

sep(`1. Elementos con dos atributos id (${idsDuplicados.length})`);
if (!idsDuplicados.length) console.log('  Ninguno.');
for (const d of idsDuplicados) {
  console.log(`  · se usa "${d.usado}" y se IGNORA "${d.ignorado}"` +
    (d.ignorado.startsWith('lbl-') ? '  ← esta etiqueta nunca se traduce' : ''));
}

sep(`2. Ids "lbl-" en el HTML sin clave en el diccionario (${sinTraduccion.length})`);
if (!sinTraduccion.length) console.log('  Ninguno.');
sinTraduccion.forEach((i) => console.log('  · ' + i));

sep(`3. Claves "lbl-" del diccionario sin elemento en el HTML (${clavesLblSinElemento.length})`);
if (!clavesLblSinElemento.length) console.log('  Ninguna.');
clavesLblSinElemento.forEach((k) => console.log('  · ' + k));

sep('4. Traducciones incompletas');
for (const [l, faltan] of Object.entries(faltantesPorIdioma)) {
  console.log(`  ${l}: faltan ${faltan.length} de ${clavesEn.size}` +
    (faltan.length ? ` → ${faltan.slice(0, 6).join(', ')}${faltan.length > 6 ? '…' : ''}` : ''));
}

const fijosEs = textos.filter((t) => t.idioma === 'es');
const fijosEn = textos.filter((t) => t.idioma === 'en');
sep(`5. Texto fijo que NO cambia al cambiar de idioma (${textos.length})`);
console.log(`  En castellano: ${fijosEs.length}   ·   En inglés: ${fijosEn.length}`);
console.log('\n  Esto es lo que produce la pantalla mezclada: conviva el idioma que');
console.log('  elija el usuario, estas frases quedan siempre igual.\n');
for (const grupo of [['inglés', fijosEn], ['castellano', fijosEs]]) {
  console.log(`  ── Fijos en ${grupo[0]} ──`);
  grupo[1].slice(0, 25).forEach((t) =>
    console.log(`     <${t.etiqueta}${t.id ? ' id=' + t.id : ''}> ${t.texto}`));
  if (grupo[1].length > 25) console.log(`     … y ${grupo[1].length - 25} más`);
}



sep(`6. El nombre del producto traducido (${marcaTraducida.length + (logoMarcado ? 1 : 0)})`);
if (!marcaTraducida.length && !logoMarcado) console.log('  Ninguno. BackupPrime es BackupPrime en todos los idiomas.');
if (logoMarcado) console.log('  · el encabezado con el logo está marcado con data-i18n: NO debe estarlo');
for (const m of marcaTraducida) {
  console.log(`  · ${m.idioma}/${m.clave}: "${m.de}" → "${m.a}"`);
}

sep('Resumen');
console.log(`  Total de problemas: ${problemas}`);

console.log(`  El <html lang> se actualiza al cambiar de idioma: ${langDinamico ? 'sí' : 'NO'}`);

if (estricto && problemas) process.exit(1);
