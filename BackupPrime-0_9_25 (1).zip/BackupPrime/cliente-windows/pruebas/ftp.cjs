'use strict';
// Prueba el destino FTP de punta a punta: respalda, lista lo que quedó en el
// servidor y lo descarga de vuelta. Usa un servidor FTP de prueba propio, así
// que no necesita nada instalado ni salir a internet.
//
//   node pruebas/ftp.cjs

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { crearServidorFtp } = require('./servidor-ftp-prueba.cjs');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-ftp-'));
process.env.BACKUPPRIME_CONFIG_DIR = path.join(TEMP, 'config');
fs.mkdirSync(process.env.BACKUPPRIME_CONFIG_DIR, { recursive: true });

const { BackupEngine, SesionFtp } = require('../electron/backup-engine.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
function comprobar(nombre, condicion, detalle = '') {
  if (condicion) { pasadas++; console.log(`  ok   ${nombre}`); }
  else { falladas++; fallos.push(nombre); console.log(`  FALLA ${nombre}${detalle ? ' — ' + detalle : ''}`); }
}
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — pruebas de FTP');

(async () => {
  const raizFtp = path.join(TEMP, 'servidor');
  const srv = crearServidorFtp({ raiz: raizFtp, latenciaMs: 2 });
  const puerto = await srv.escuchar();

  const origen = path.join(TEMP, 'origen');
  fs.mkdirSync(path.join(origen, 'Documentos'), { recursive: true });
  fs.writeFileSync(path.join(origen, 'Documentos', 'balance.xlsx'), 'planilla contable');
  fs.writeFileSync(path.join(origen, 'Documentos', 'contrato.pdf'), 'contrato firmado');
  fs.writeFileSync(path.join(origen, 'notas.txt'), 'notas varias');

  const dest = {
    type: 'ftp', host: '127.0.0.1', port: puerto,
    user: 'u', pass: 'p', remotePath: '/backup', label: 'FTP de prueba',
  };

  const engine = new BackupEngine();
  const registro = [];
  engine.on('log', (l) => registro.push(l.trim()));

  const cfg = {
    server: '', token: '',
    localPaths: [origen], excludedPaths: [],
    destinations: [dest], maxVersions: 10,
    systemBackup: false, forceFullBackup: false,
  };

  // ── Respaldo ──────────────────────────────────────────────────────────────
  titulo('Respaldo');
  await engine.runOnce(cfg);

  comprobar('1. Sube los 3 archivos', srv.stats.archivos === 3,
    `recibidos: ${srv.stats.archivos}`);
  comprobar('2. No informa errores', !registro.some((l) => l.includes('[error]')),
    registro.filter((l) => l.includes('[error]'))[0] || '');
  comprobar('3. Abre varias conexiones para transferir en paralelo',
    srv.stats.conexiones > 1, `conexiones: ${srv.stats.conexiones}`);

  const antes = srv.stats.archivos;
  await engine.runOnce(cfg);
  comprobar('4. La segunda corrida no vuelve a subir nada',
    srv.stats.archivos === antes, `subidos de más: ${srv.stats.archivos - antes}`);

  // ── Listado ───────────────────────────────────────────────────────────────
  titulo('Listado para restaurar');

  const sesion = new SesionFtp(dest);
  await sesion.conectar();
  const { archivos } = await sesion.listarTodo('/backup');

  comprobar('5. Encuentra los 3 archivos en el servidor', archivos.length === 3,
    `encontrados: ${archivos.length}`);
  comprobar('6. Conserva la estructura de carpetas',
    archivos.some((a) => a.ruta.includes('/Documentos/balance.xlsx')),
    archivos.map((a) => a.ruta).join(' | '));
  comprobar('7. Informa el tamaño de cada archivo',
    archivos.every((a) => a.size > 0));

  // ── Descarga ──────────────────────────────────────────────────────────────
  titulo('Descarga');

  const uno = archivos.find((a) => a.ruta.endsWith('balance.xlsx'));
  const salida = path.join(TEMP, 'recuperado', 'balance.xlsx');
  await sesion.descargar(uno.ruta, salida);

  comprobar('8. Descarga el archivo', fs.existsSync(salida));
  comprobar('9. El contenido vuelve intacto',
    fs.readFileSync(salida, 'utf8') === 'planilla contable');
  comprobar('10. No deja temporales', !fs.existsSync(salida + '.bp-tmp'));

  let fallo = null;
  try { await sesion.descargar('/backup/no-existe.txt', path.join(TEMP, 'x')); }
  catch (e) { fallo = e; }
  comprobar('11. Avisa si el archivo no está en el servidor', !!fallo);

  // ── Lo que manda la pantalla ──────────────────────────────────────────────
  titulo('Selección desde la pantalla');

  const { armarArbol, rutasElegidas, filtrarSeleccion } =
    require('../electron/restore-remoto.cjs');

  const base = '/backup';
  const planos = archivos.map((a) => ({
    ruta: a.ruta, size: a.size,
    rel: a.ruta.slice(base.length).replace(/^\/+/, ''),
  }));
  const arbol = armarArbol(planos);

  comprobar('12. El árbol arranca en la letra de disco o la primera carpeta',
    arbol.length > 0);
  comprobar('13. Cuenta los archivos de cada carpeta',
    arbol.reduce((n, c) => n + (c.fileCount || 0), 0) === planos.length);

  // La pantalla guarda cada nodo elegido con su ruta relativa.
  const comoLaPantalla = (nodo) => ({
    relPath: nodo.relPath, fullPath: nodo.fullPath, type: nodo.type, name: nodo.name,
  });
  const buscarNodo = (nodos, pred) => {
    for (const n of nodos) {
      if (pred(n)) return n;
      if (n.children) { const f = buscarNodo(n.children, pred); if (f) return f; }
    }
    return null;
  };

  const carpetaDocs = buscarNodo(arbol, (n) => n.type === 'folder' && n.name === 'Documentos');
  comprobar('14. Existe la carpeta en el árbol', !!carpetaDocs);

  const porCarpeta = filtrarSeleccion(planos, rutasElegidas([comoLaPantalla(carpetaDocs)], base));
  comprobar('15. Elegir una carpeta baja todo lo que tiene adentro',
    porCarpeta.length === 2, `bajaría ${porCarpeta.length}`);

  const unArchivo = buscarNodo(arbol, (n) => n.type === 'file' && n.name === 'notas.txt');
  const porArchivo = filtrarSeleccion(planos, rutasElegidas([comoLaPantalla(unArchivo)], base));
  comprobar('16. Elegir un archivo suelto baja solo ese', porArchivo.length === 1);

  const mezcla = filtrarSeleccion(planos,
    rutasElegidas([comoLaPantalla(carpetaDocs), comoLaPantalla(unArchivo)], base));
  comprobar('17. Carpeta y archivo juntos, sin duplicados', mezcla.length === 3);

  // Este es el caso que fallaba: la pantalla mandaba la selección sin la ruta
  // relativa y no coincidía con nada.
  const sinRelPath = [{ fullPath: unArchivo.fullPath, type: 'file', name: unArchivo.name }];
  comprobar('18. Funciona aunque falte la ruta relativa',
    filtrarSeleccion(planos, rutasElegidas(sinRelPath, base)).length === 1);

  comprobar('19. Una selección vacía no baja todo por error',
    filtrarSeleccion(planos, rutasElegidas([], base)).length === 0);

  const raiz = arbol[0];
  comprobar('20. Elegir la raíz baja el backup entero',
    filtrarSeleccion(planos, rutasElegidas([comoLaPantalla(raiz)], base)).length === planos.length);

  // ── Rutas que vienen de la nube ───────────────────────────────────────────
  titulo('Rutas de la nube');

  const { relDesdeRutaOriginal } = require('../electron/restore-remoto.cjs');

  comprobar('21. Una ruta de Windows entra al mismo árbol que los demás destinos',
    relDesdeRutaOriginal('C:\\Users\\ana\\Documentos\\balance.xlsx')
      === 'C/Users/ana/Documentos/balance.xlsx');
  comprobar('22. La letra de disco se normaliza a mayúscula',
    relDesdeRutaOriginal('d:\\Datos\\x.txt') === 'D/Datos/x.txt');
  comprobar('23. Una ruta sin letra de disco no se rompe',
    relDesdeRutaOriginal('/home/ana/x.txt') === 'home/ana/x.txt');
  comprobar('24. Y el árbol de la nube se arma igual que el de los otros',
    armarArbol([{ ruta: '42', size: 10, rel: relDesdeRutaOriginal('C:\\Users\\ana\\x.txt') }])[0].name === 'C');

  // ── Bajar varios a la vez ─────────────────────────────────────────────────
  titulo('Descarga en paralelo');

  const antesConexiones = srv.stats.conexiones;
  const cola = [...archivos];
  let bajados = 0;
  await Promise.all(Array.from({ length: 3 }, async () => {
    const s = new SesionFtp(dest);
    await s.conectar();
    try {
      for (;;) {
        const a = cola.shift();
        if (!a) return;
        await s.descargar(a.ruta, path.join(TEMP, 'paralelo', path.basename(a.ruta)));
        bajados++;
      }
    } finally { await s.cerrar().catch(() => {}); }
  }));

  comprobar('25. Se pueden bajar varios archivos a la vez', bajados === 3, `bajados ${bajados}`);
  comprobar('26. Cada descarga simultánea usa su propia conexión',
    srv.stats.conexiones - antesConexiones === 3,
    `abrió ${srv.stats.conexiones - antesConexiones}`);
  comprobar('27. Y todos llegan enteros',
    fs.readFileSync(path.join(TEMP, 'paralelo', 'balance.xlsx'), 'utf8') === 'planilla contable');

  await sesion.cerrar();
  await srv.cerrar();

  console.log('\n──────────────────────────────────────────────────────');
  console.log(`  ${pasadas} de ${pasadas + falladas} pruebas pasadas`);
  if (falladas) { console.log('\n  Fallaron:'); for (const f of fallos) console.log(`    · ${f}`); }
  console.log('──────────────────────────────────────────────────────\n');

  try { fs.rmSync(TEMP, { recursive: true, force: true }); } catch {}
  process.exit(falladas ? 1 : 0);
})();
