'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Subir bloques en paralelo, sin romper nada.

   Por qué se hizo: el bucle de bloques era estrictamente secuencial. Por cada
   bloque se esperaba un `existe()` —un pedido a la red— y después la subida, y
   mientras tanto LA LECTURA DEL ARCHIVO SE FRENABA.

   Con un archivo de 300 MB son unos 75 bloques. A 80 ms de ida y vuelta contra
   el almacenamiento, son varios segundos gastados solo en preguntar si cada
   bloque ya está. Y se pagan igual en el respaldo incremental, donde no se sube
   nada: es la razón por la que un cliente con archivos de 150 a 300 MB ve
   demoras aunque "no haya cambiado nada".

   Medido con 200 MB y 80 ms de latencia: 12,6 s → 4,0 s en el primer respaldo.

   Lo que hay que asegurar al paralelizar, y es lo que se prueba acá:
     · que los bloques del índice queden en ORDEN, sin importar en qué orden
       terminen las subidas;
     · que un bloque que falla haga fallar el archivo entero, en lugar de dejar
       un índice que apunta a algo que no se subió;
     · que el índice se escriba DESPUÉS de que todos los bloques llegaron;
     · que no haya más de N bloques en memoria a la vez.

     node pruebas/bloques-en-paralelo.cjs
   ═══════════════════════════════════════════════════════════════════════════ */

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');

const Bloques = require('../electron/bloques.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);
const dormir = (ms) => new Promise((r) => setTimeout(r, ms));

console.log('BackupPrime — subir bloques en paralelo\n');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-par-'));

function archivo(destino, megas) {
  const partes = [];
  let h = crypto.createHash('sha256').update('paralelo').digest();
  for (let i = 0; i < megas * 1048576 / 32; i++) {
    h = crypto.createHash('sha256').update(h).digest();
    partes.push(h);
  }
  fs.writeFileSync(destino, Buffer.concat(partes));
  return destino;
}

/** Almacén de mentira que registra todo y puede tardar o fallar a pedido. */
function almacenFalso({ latencia = 0, fallaEn = null, existentes = new Set() } = {}) {
  const guardado = new Map();
  const textos = new Map();
  let enVueloAhora = 0, picoEnVuelo = 0;
  const ordenDeLlegada = [];
  let n = 0;

  return {
    guardado, textos, ordenDeLlegada,
    get picoEnVuelo() { return picoEnVuelo; },
    async existe(clave) {
      enVueloAhora++; picoEnVuelo = Math.max(picoEnVuelo, enVueloAhora);
      if (latencia) await dormir(latencia);
      enVueloAhora--;
      return existentes.has(clave);
    },
    async subirDatos(clave, datos) {
      enVueloAhora++; picoEnVuelo = Math.max(picoEnVuelo, enVueloAhora);
      n++;
      if (fallaEn && n === fallaEn) {
        enVueloAhora--;
        throw new Error('El almacenamiento rechazó el bloque');
      }
      // Tiempos desparejos a propósito: así las subidas terminan en un orden
      // distinto al que salieron, que es lo que puede desordenar el índice.
      if (latencia) await dormir(latencia * (1 + (n % 3)));
      guardado.set(clave, Buffer.from(datos));
      ordenDeLlegada.push(clave);
      enVueloAhora--;
    },
    async subirTexto(clave, texto) {
      textos.set(clave, texto);
    },
  };
}

(async () => {
  const f = archivo(path.join(TEMP, 'grande.bin'), 40);

  titulo('El índice queda en orden aunque las subidas terminen desordenadas');
  {
    const a = almacenFalso({ latencia: 6 });
    const r = await Bloques.subirPorBloques(a, {
      rutaArchivo: f, rutaRelativa: 'x.bin', prefijo: 'p/', paralelo: 4,
      yaSubidos: new Set(),
    });

    // En el índice cada bloque es { h: huella, n: bytes }, en orden de lectura.
    const indice = JSON.parse([...a.textos.values()][0]);
    const clavesEnOrden = indice.bloques.map((b) => 'p/bloques/' + b.h.slice(0, 2) + '/' + b.h);

    // Que las subidas terminaron desordenadas: si no, lo de abajo no prueba nada.
    // Con latencias desparejas las subidas suelen terminar desordenadas, pero
    // no está garantizado en cada corrida: si terminaran en orden, la prueba de
    // abajo sigue siendo válida, solo que menos exigente. Se informa cuál fue el
    // caso en lugar de fallar por algo que depende del azar.
    const soloSubidos = clavesEnOrden.filter((c) => a.ordenDeLlegada.includes(c));
    const huboDesorden = JSON.stringify(a.ordenDeLlegada) !== JSON.stringify(soloSubidos);
    console.log(`       (las subidas terminaron ${huboDesorden ? 'DESORDENADAS' : 'en orden'} en esta corrida)`);

    // Y aun así el índice quedó en el orden de lectura del archivo, que es lo
    // que permite rearmarlo. Se verifica rearmando de verdad.
    const rearmado = Buffer.concat(clavesEnOrden.map((c) => a.guardado.get(c)));
    comprobar('el índice rearma el archivo original exacto',
      rearmado.equals(fs.readFileSync(f)),
      'un índice desordenado rearma el archivo mal, y eso no se nota hasta abrirlo');

    comprobar('los tamaños suman el archivo entero',
      indice.bloques.reduce((s, b) => s + b.n, 0) === fs.statSync(f).size);
    comprobar('se subieron bloques', r.nuevos > 0, JSON.stringify(r));
  }

  titulo('No hay más bloques en vuelo que el tope');
  {
    for (const tope of [1, 2, 4]) {
      const a = almacenFalso({ latencia: 4 });
      await Bloques.subirPorBloques(a, {
        rutaArchivo: f, rutaRelativa: 'x.bin', prefijo: 'p/', paralelo: tope,
        yaSubidos: new Set(),
      });
      comprobar(`con tope ${tope}, el pico no lo supera`, a.picoEnVuelo <= tope,
        `pico ${a.picoEnVuelo} — cada bloque en vuelo son hasta 16 MB de memoria`);
    }
  }

  titulo('Si un bloque falla, falla el archivo entero');
  {
    const a = almacenFalso({ latencia: 3, fallaEn: 3 });
    let err = null;
    try {
      await Bloques.subirPorBloques(a, {
        rutaArchivo: f, rutaRelativa: 'x.bin', prefijo: 'p/', paralelo: 4,
        yaSubidos: new Set(),
      });
    } catch (e) { err = e; }

    comprobar('propaga el error', !!err, err ? '' : 'seguir sería mentirle al cliente');
    comprobar('NO escribe el índice', a.textos.size === 0,
      'un índice que apunta a bloques que no llegaron es un archivo irrecuperable');
  }

  titulo('El índice se escribe recién cuando llegaron todos los bloques');
  {
    const a = almacenFalso({ latencia: 5 });
    const original = a.subirTexto.bind(a);
    let bloquesAlEscribirIndice = null;
    a.subirTexto = async (clave, texto) => {
      if (bloquesAlEscribirIndice === null) bloquesAlEscribirIndice = a.guardado.size;
      return original(clave, texto);
    };
    await Bloques.subirPorBloques(a, {
      rutaArchivo: f, rutaRelativa: 'x.bin', prefijo: 'p/', paralelo: 4,
      yaSubidos: new Set(),
    });
    const indice = JSON.parse([...a.textos.values()][0]);
    comprobar('todos los bloques estaban guardados antes del índice',
      bloquesAlEscribirIndice === indice.bloques.length,
      `había ${bloquesAlEscribirIndice} de ${indice.bloques.length}`);
  }

  titulo('El resultado es el mismo con 1 que con 8 en paralelo');
  {
    const uno = almacenFalso();
    const ocho = almacenFalso();
    await Bloques.subirPorBloques(uno, {
      rutaArchivo: f, rutaRelativa: 'x.bin', prefijo: 'p/', paralelo: 1, yaSubidos: new Set(),
    });
    await Bloques.subirPorBloques(ocho, {
      rutaArchivo: f, rutaRelativa: 'x.bin', prefijo: 'p/', paralelo: 8, yaSubidos: new Set(),
    });
    comprobar('se guardan los mismos bloques',
      JSON.stringify([...uno.guardado.keys()].sort()) ===
      JSON.stringify([...ocho.guardado.keys()].sort()));
    // Se compara todo menos `creado`, que es la hora de escritura y obviamente
    // difiere entre dos corridas.
    const sinFecha = (t) => { const j = JSON.parse(t); delete j.creado; return JSON.stringify(j); };
    comprobar('el índice es idéntico',
      sinFecha([...uno.textos.values()][0]) === sinFecha([...ocho.textos.values()][0]),
      'el paralelismo no puede cambiar lo que queda guardado');
  }

  titulo('Un bloque repetido dentro del archivo no se pregunta dos veces');
  {
    // Un archivo con contenido repetido: los bloques iguales no deberían
    // generar pedidos de más.
    //
    // El trozo tiene que ser bastante más grande que el bloque promedio (5 MB) y
    // el contenido determinista. Con datos al azar y trozos chicos, los cortes
    // caen en lugares distintos en cada repetición y la prueba fallaba una de
    // cada tres corridas — una prueba que falla sola enseña a ignorar los
    // resultados.
    const rep = path.join(TEMP, 'repetido.bin');
    const unidad = fs.readFileSync(archivo(path.join(TEMP, 'unidad.bin'), 25));
    fs.writeFileSync(rep, Buffer.concat([unidad, unidad, unidad]));

    const a = almacenFalso();
    const r = await Bloques.subirPorBloques(a, {
      rutaArchivo: rep, rutaRelativa: 'r.bin', prefijo: 'p/', paralelo: 4,
      yaSubidos: new Set(),
    });
    comprobar('reutilizó los repetidos', r.reutilizados > 0, JSON.stringify(r));
    comprobar('no guardó el mismo bloque dos veces',
      a.guardado.size === new Set(a.guardado.keys()).size);
  }

  try { fs.rmSync(TEMP, { recursive: true, force: true }); } catch {}

  console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
  if (falladas) { console.log('Fallaron:'); fallos.forEach((f) => console.log('  · ' + f)); }
  process.exit(falladas ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
