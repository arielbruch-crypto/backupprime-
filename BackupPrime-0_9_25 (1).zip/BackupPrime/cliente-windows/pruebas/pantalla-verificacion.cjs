'use strict';
/* La franja que le dice al cliente si su respaldo está de verdad.

   Es la tercera regla del producto: el cliente tiene que poder verificar. La
   tranquilidad no viene de que el programa ande, viene de poder ver qué se
   respaldó y cuándo se comprobó.

   Lo que se controla acá, y por qué:

     · Que el número que se muestre sea el del archivo MÁS OLVIDADO, no solo la
       fecha de la última revisión. "Verificado el martes" puede ser cierto y
       engañoso a la vez: se puede haber verificado el martes y tener archivos
       que nadie mira desde hace dos meses. Mostrar solo la fecha sería dar una
       tranquilidad que los datos no respaldan.
     · Que cuando faltaron archivos en el destino se vea, y no quede escondido
       en el registro de actividad que nadie lee.
     · Que "nunca se comprobó" se diga con esas palabras y no como un número
       inventado.

     node pruebas/pantalla-verificacion.cjs                                   */

const fs = require('node:fs');
const path = require('node:path');

let JSDOM;
try { ({ JSDOM } = require('jsdom')); }
catch { console.log('Falta jsdom. Instalalo con: npm install'); process.exit(1); }

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — la franja de verificación en pantalla\n');

const RENDERER = path.join(__dirname, '..', 'electron', 'renderer.html');
const html = fs.readFileSync(RENDERER, 'utf8');

// Se guarda el manejador que la pantalla registra con `onVerificacion`, que es
// por donde le llega el dato real desde el proceso principal. Llamarlo es
// ejercitar el mismo camino que corre en producción; pintar el HTML a mano
// sería probar la prueba.
let alRecibirVerificacion = null;

const dom = new JSDOM(html, {
  runScripts: 'dangerously',
  pretendToBeVisual: true,
  beforeParse(win) {
    win.backupprime = new Proxy({}, {
      get: (_t, p) => {
        const nombre = String(p);
        if (nombre === 'onVerificacion') return (fn) => { alRecibirVerificacion = fn; };
        if (nombre.startsWith('on')) return () => {};
        return async () => ({});
      },
    });
  },
});
const win = dom.window;

const DIA = 86400000;

new Promise((r) => {
  if (win.document.readyState === 'complete') return r();
  win.addEventListener('load', r);
}).then(() => {
  const doc = win.document;
  const caja = doc.getElementById('verifBanner');
  const titulo_ = () => doc.getElementById('verifTitulo').textContent;
  const detalle = () => doc.getElementById('verifDetalle').textContent;

  comprobar('La franja existe en la pantalla', !!caja);
  comprobar('La pantalla se suscribe al estado de verificación',
    typeof alRecibirVerificacion === 'function',
    'sin esto el dato llega del motor y no lo ve nadie');
  if (!caja || !alRecibirVerificacion) throw new Error('sin punto de entrada');

  comprobar('Arranca oculta, antes del primer respaldo',
    caja.style.display === 'none',
    'un dato incompleto no puede pintar "todo comprobado" en verde');

  // Se fija el idioma: la pantalla arranca en inglés y los textos que se
  // comprueban abajo son los castellanos. Sin esto la prueba mediría el
  // diccionario equivocado.
  const fijarIdioma = win.__pruebasIdioma;
  if (typeof fijarIdioma === 'function') fijarIdioma('es');

  titulo('Todo comprobado hoy');

  alRecibirVerificacion({
    modo: 'programada', ultima: Date.now(), revisados: 120, faltantes: 0,
    sinComprobar: 0, comprobados: 120,
    diasSinVerificarElPeor: 0, proximaProgramada: Date.now() + 7 * DIA,
  });
  comprobar('Se muestra', caja.style.display !== 'none');
  comprobar('En verde', caja.className.includes('ok'), caja.className);
  comprobar('Dice que está comprobado', /comprobado/i.test(titulo_()), titulo_());
  comprobar('Y muestra la fecha de la última revisión completa',
    /Última revisión completa/i.test(detalle()), detalle());

  titulo('Hay archivos que nadie mira desde hace dos meses');

  // El caso engañoso: la última revisión es RECIENTE, pero quedaron archivos
  // afuera. Si la pantalla mirara solo `ultima`, diría "todo bien" y estaría
  // mintiendo. Este control es el que impide esa mentira.
  alRecibirVerificacion({
    modo: 'rotativa', ultima: Date.now() - 2 * DIA, revisados: 40, faltantes: 0,
    sinComprobar: 0, comprobados: 400,
    diasSinVerificarElPeor: 63, proximaProgramada: Date.now() + 5 * DIA,
  });
  // El control decisivo. Si la pantalla mirara solo `ultima`, acá diría
  // "comprobado hoy" y sería mentira: hay archivos de hace 63 días sin mirar.
  comprobar('NO dice que está todo bien',
    !/comprobado/i.test(titulo_()) && !/Todos tus archivos/i.test(titulo_()),
    titulo_());
  comprobar('Avisa, en ámbar', caja.className.includes('aviso'), caja.className);
  comprobar('Y dice cuántos días lleva el más olvidado',
    titulo_().includes('63'), titulo_());

  titulo('Faltaban archivos en el destino');

  alRecibirVerificacion({
    modo: 'programada', ultima: Date.now(), revisados: 120, faltantes: 3,
    sinComprobar: 0, comprobados: 120,
    diasSinVerificarElPeor: 0, proximaProgramada: Date.now() + 7 * DIA,
  });
  comprobar('Se marca como problema', caja.className.includes('mal'), caja.className);
  comprobar('Dice cuántos faltaban', titulo_().includes('3'), titulo_());
  comprobar('Y aclara que el respaldo quedó completo',
    /complet/i.test(detalle()), detalle());

  titulo('Primer respaldo: todavía no se comprobó nada');

  alRecibirVerificacion({
    modo: 'ninguna', ultima: null, revisados: 0, faltantes: 0,
    sinComprobar: 500, comprobados: 0,
    diasSinVerificarElPeor: null, proximaProgramada: 0,
  });
  comprobar('Lo dice con palabras, no con un número inventado',
    /todavía sin comprobar/i.test(titulo_()) && !/\d/.test(titulo_()), titulo_());
  comprobar('Y aclara que se resuelve solo',
    /sola en los próximos respaldos/i.test(detalle()), detalle());
  // ── El control que faltaba ──
  // No es una advertencia: es el estado normal del primer respaldo y el
  // programa lo resuelve solo. Antes salía en ÁMBAR diciendo "cuidado" y
  // "no hace falta hacer nada" en la misma franja — una contradicción que
  // además no se apagaba nunca, ni recién terminada una verificación completa.
  comprobar('NO se pinta como advertencia, porque no hay nada que hacer',
    !caja.className.includes('aviso') && !caja.className.includes('mal'),
    caja.className);

  titulo('Verificado, pero quedan algunos por revisar');

  alRecibirVerificacion({
    modo: 'rotativa', ultima: Date.now(), revisados: 300, faltantes: 0,
    sinComprobar: 42, comprobados: 1200,
    diasSinVerificarElPeor: 2, proximaProgramada: Date.now() + 5 * DIA,
  });
  comprobar('Sigue siendo buena noticia, no alarma',
    !caja.className.includes('aviso') && !caja.className.includes('mal'),
    caja.className);
  comprobar('Y los que faltan se mencionan como parte del detalle',
    detalle().includes('42'), detalle());

  titulo('Los textos están en los tres idiomas');

  const cambiar = win.__pruebasIdioma;
  if (typeof cambiar === 'function') {
    const vistos = {};
    for (const idioma of ['en', 'es', 'pt']) {
      cambiar(idioma);
      alRecibirVerificacion({
        modo: 'programada', ultima: Date.now(), revisados: 10, faltantes: 0,
        diasSinVerificarElPeor: 0, proximaProgramada: Date.now() + 7 * DIA,
      });
      vistos[idioma] = titulo_();
    }
    comprobar('El texto cambia con el idioma',
      new Set(Object.values(vistos)).size === 3, JSON.stringify(vistos));
    comprobar('Y ninguno quedó vacío',
      Object.values(vistos).every((t) => t && t.length > 5), JSON.stringify(vistos));
  } else {
    comprobar('la pantalla permite cambiar de idioma para probar', false,
      'falta window.__pruebasIdioma');
  }

  console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
  if (falladas) { console.log(fallos.map((f) => ` · ${f}`).join('\n')); process.exit(1); }
}).catch((e) => { console.error(e); process.exit(1); });
