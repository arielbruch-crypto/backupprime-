'use strict';
/* La caché de los navegadores no se respalda. Ni se recorre.

   ── De dónde salió esto ──

   En un cliente real apareció en pantalla un archivo llamado
   `8d26b1f1032e8a48_0`. Ese nombre —dieciséis caracteres hexadecimales y `_0`—
   es una entrada de caché de Chrome, Edge o Firefox.

   Respaldar esa caché es lo peor de los dos mundos:

     · **Cambia todo el tiempo**, así que se sube en cada respaldo y consume
       cuota que el cliente paga.
     · **No le sirve a nadie.** Nadie restauró jamás la caché de su navegador:
       son páginas e imágenes que el navegador vuelve a bajar solo.

   En un equipo normal son decenas de miles de archivos, la mitad del perfil de
   usuario, y cada uno cuesta una consulta al disco en cada recorrido — con un
   antivirus de por medio, mucho más.

   ── Y algo peor que se encontró buscando esto ──

   El SELECTOR de carpetas escondía la basura del sistema, pero el MOTOR la
   respaldaba igual: eran dos listas distintas y la del motor era mucho más
   corta. El cliente elegía una carpeta que la pantalla le mostraba limpia y
   terminaba con archivos que nunca vio.

   Medido: perfil con 2.000 documentos y 24.000 archivos de caché.
   Antes 20,8 s y 20.000 archivos subidos. Ahora 2,1 s y 2.000.

     node pruebas/sin-cache-navegadores.cjs                                   */

const fs = require('node:fs');
const fsp = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-cache-'));
process.env.BACKUPPRIME_CONFIG_DIR = path.join(TEMP, 'config');
fs.mkdirSync(process.env.BACKUPPRIME_CONFIG_DIR, { recursive: true });

const { crearServidorS3 } = require('./servidor-s3-prueba.cjs');
const { BackupEngine } = require('../electron/backup-engine.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — la caché de los navegadores no se respalda\n');

(async () => {
  const srv = crearServidorS3();
  const puerto = await srv.escuchar();
  const dest = {
    type: 's3', endpoint: `http://127.0.0.1:${puerto}`, region: 'us-east-1',
    bucket: 'respaldos', prefix: 'c/', accessKey: 'AKIA', secretKey: 'secreta',
    label: 'e2',
  };

  const perfil = path.join(TEMP, 'Usuario');

  // Lo que el cliente SÍ quiere: sus documentos.
  const docs = path.join(perfil, 'Documents');
  await fsp.mkdir(docs, { recursive: true });
  const suyos = [];
  for (let i = 0; i < 40; i++) {
    const n = `Balance-${i}.xlsx`;
    await fsp.writeFile(path.join(docs, n), Buffer.alloc(4096, 1));
    suyos.push(n);
  }
  // Un archivo con NOMBRE de caché pero fuera de una carpeta de caché: es un
  // archivo del cliente y tiene que respaldarse. El filtro es por carpeta, no
  // por nombre, justamente para no confundirse acá.
  await fsp.writeFile(path.join(docs, '8d26b1f1032e8a48_0'), Buffer.alloc(2048, 9));

  // Lo que NO: la caché, con los nombres y las rutas reales.
  const cachés = [
    'AppData/Local/Google/Chrome/User Data/Default/Cache/Cache_Data',
    'AppData/Local/Google/Chrome/User Data/Default/Code Cache/js',
    'AppData/Local/Google/Chrome/User Data/Default/GPUCache',
    'AppData/Local/Microsoft/Edge/User Data/Default/Service Worker/CacheStorage',
    'AppData/Local/Mozilla/Firefox/Profiles/abc.default/cache2/entries',
    'AppData/Local/Microsoft/Windows/INetCache',
  ];
  let deCache = 0;
  for (const rel of cachés) {
    const d = path.join(perfil, ...rel.split('/'));
    await fsp.mkdir(d, { recursive: true });
    for (let i = 0; i < 50; i++) {
      await fsp.writeFile(
        path.join(d, `${(i * 2654435761 >>> 0).toString(16).padStart(16, '0')}_0`),
        Buffer.alloc(1024, 2));
      deCache++;
    }
  }

  // Y basura del sistema que el selector ya escondía pero el motor subía.
  await fsp.writeFile(path.join(docs, 'Thumbs.db'), Buffer.alloc(512, 3));
  await fsp.writeFile(path.join(docs, 'desktop.ini'), Buffer.alloc(256, 3));
  const nm = path.join(docs, 'proyecto', 'node_modules', 'algo');
  await fsp.mkdir(nm, { recursive: true });
  for (let i = 0; i < 30; i++) {
    await fsp.writeFile(path.join(nm, `mod-${i}.js`), Buffer.alloc(512, 4));
  }

  const cfg = {
    server: '', token: '', localPaths: [perfil], excludedPaths: [],
    destinations: [dest], maxVersions: 10, systemBackup: false,
    forceFullBackup: false, umbralBloquesMB: 25,
  };

  const motor = new BackupEngine();
  let resumen = null;
  motor.on('done', (d) => { resumen = d; });
  await motor.runOnce(cfg);

  const claves = [...srv.objetos.keys()];
  const guardado = (frag) => claves.some((k) => k.includes(frag));

  titulo('Lo que el cliente quiere, se respalda');

  comprobar('Están sus documentos',
    suyos.every((n) => guardado(n)),
    `faltan ${suyos.filter((n) => !guardado(n)).slice(0, 3).join(', ')}`);

  comprobar('Se subieron 41 archivos, ni uno más',
    resumen.uploaded === 41,
    `${resumen.uploaded} subidos — de más significa que se coló basura`);

  titulo('La caché de los navegadores, no');

  comprobar('Ni un archivo de Cache_Data', !guardado('Cache_Data'));
  comprobar('Ni de Code Cache', !guardado('Code%20Cache') && !guardado('Code Cache'));
  comprobar('Ni de GPUCache', !guardado('GPUCache'));
  comprobar('Ni de CacheStorage', !guardado('CacheStorage'));
  comprobar('Ni el cache2 de Firefox', !guardado('cache2'));
  comprobar('Ni el INetCache de Windows', !guardado('INetCache'));
  comprobar(`Los ${deCache} archivos de caché quedaron todos afuera`,
    !claves.some((k) => /_0$/.test(k) && k.includes('AppData')),
    'cambian todo el día y consumen cuota que el cliente paga, para nada');

  titulo('Pero un archivo del cliente con ese nombre SÍ se respalda');

  // El filtro es por CARPETA, no por nombre. Un archivo que se llame parecido,
  // guardado en Documentos, es del cliente y no se toca.
  comprobar('Se respaldó el archivo con nombre de caché que está en Documentos',
    claves.some((k) => k.includes('8d26b1f1032e8a48_0') && k.includes('Documents')),
    'filtrar por nombre en vez de por carpeta le borraría archivos propios');

  titulo('Y la basura del sistema tampoco, igual que en el selector');

  comprobar('Sin Thumbs.db', !guardado('Thumbs.db'));
  comprobar('Sin desktop.ini', !guardado('desktop.ini'));
  comprobar('Sin node_modules', !guardado('node_modules'),
    'el selector ya lo escondía; el motor lo subía igual');

  await srv.cerrar();
  fs.rmSync(TEMP, { recursive: true, force: true });

  console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
  if (falladas) { console.log(fallos.map((f) => ` · ${f}`).join('\n')); process.exit(1); }
})().catch((e) => { console.error(e); process.exit(1); });
