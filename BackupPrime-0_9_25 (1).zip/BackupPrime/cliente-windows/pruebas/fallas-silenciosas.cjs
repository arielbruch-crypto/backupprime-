'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Fallas silenciosas: que nada parezca haber funcionado cuando no funcionó.

   En un producto de backup, el peor modo de falla no es que algo falle: es que
   PAREZCA haber funcionado. Un archivo restaurado a medias que se abre y está
   roto, cuando el original ya no existe, es la situación que el producto
   entero está para evitar.

   Lo que se prueba acá:

   · Una descarga cortada a la mitad tiene que FALLAR, no dejar un archivo
     truncado con su nombre definitivo. `s3Descargar` escribía a un temporal y lo
     renombraba en cuanto el flujo cerraba, sin comparar contra el
     `Content-Length`. Un corte de red producía un PST truncado que parece entero.

   · Un bloque incompleto tiene que FALLAR. `s3BajarDatos` devolvía lo que
     hubiera llegado, y con eso se rearmaba el archivo.

   · Rearmar por bloques tiene que verificar la huella antes de entregar el
     archivo.

     node pruebas/fallas-silenciosas.cjs
   ═══════════════════════════════════════════════════════════════════════════ */

const fs = require('node:fs');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-silencio-'));
process.env.BACKUPPRIME_CONFIG_DIR = path.join(TEMP, 'config');
fs.mkdirSync(process.env.BACKUPPRIME_CONFIG_DIR, { recursive: true });

const { s3Descargar, s3BajarDatos, s3SubirDatos } = require('../electron/backup-engine.cjs');
const Bloques = require('../electron/bloques.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — fallas silenciosas\n');

/**
 * Un servidor que anuncia un tamaño y manda menos: simula exactamente lo que
 * pasa cuando se corta la conexión a mitad de una descarga.
 */
function servidorMentiroso({ anuncia, manda, cortar = true }) {
  const srv = http.createServer((req, res) => {
    res.writeHead(200, {
      'Content-Type': 'application/octet-stream',
      'Content-Length': String(anuncia),
    });
    res.write(Buffer.alloc(manda, 7));
    if (cortar) {
      // Se corta la conexión sin terminar la respuesta, como una red que se cae.
      res.socket.destroy();
    } else {
      res.end();
    }
  });
  return {
    escuchar: () => new Promise((r) => srv.listen(0, '127.0.0.1', () => r(srv.address().port))),
    cerrar: () => new Promise((r) => srv.close(r)),
  };
}

(async () => {
  titulo('Una descarga cortada a la mitad falla, no deja un archivo truncado');
  {
    const srv = servidorMentiroso({ anuncia: 10 * 1024 * 1024, manda: 512 * 1024 });
    const puerto = await srv.escuchar();
    const dest = {
      type: 's3', endpoint: `http://127.0.0.1:${puerto}`, region: 'us-east-1',
      bucket: 'respaldos', prefix: '', accessKey: 'AKIA', secretKey: 'secreta',
    };
    const destino = path.join(TEMP, 'correo-restaurado.pst');

    let error = null;
    try { await s3Descargar(dest, 'correo.pst', destino); } catch (e) { error = e; }

    comprobar('la descarga incompleta lanza un error', !!error,
      'sin esto el cliente restaura un PST truncado que parece entero');
    comprobar('el mensaje explica qué pasó y qué hacer',
      error && /incompleta|cortó/i.test(error.message) && /de nuevo/i.test(error.message),
      error ? error.message : '');

    // Lo más importante de esta prueba: que NO quede el archivo a medias con su
    // nombre definitivo. Si quedara, el cliente lo abre creyendo que está bien.
    comprobar('NO quedó ningún archivo con el nombre definitivo',
      !fs.existsSync(destino),
      'un archivo a medias con el nombre real es peor que ningún archivo');

    const sobrantes = fs.readdirSync(TEMP).filter((f) => /\.tmp|\.part|correo-restaurado/.test(f));
    comprobar('tampoco quedaron temporales sueltos', sobrantes.length === 0,
      JSON.stringify(sobrantes));

    await srv.cerrar();
  }

  titulo('Una lectura de bloque incompleta falla');
  {
    const srv = servidorMentiroso({ anuncia: 1048576, manda: 4096 });
    const puerto = await srv.escuchar();
    const dest = {
      type: 's3', endpoint: `http://127.0.0.1:${puerto}`, region: 'us-east-1',
      bucket: 'respaldos', prefix: '', accessKey: 'AKIA', secretKey: 'secreta',
    };

    let error = null;
    try { await s3BajarDatos(dest, 'bloques/ab/abcdef'); } catch (e) { error = e; }

    comprobar('lanza un error en lugar de devolver el pedazo', !!error,
      'con un bloque truncado se rearma un archivo roto que parece correcto');
    comprobar('el mensaje dice qué faltó',
      error && /incompleta|cortó/i.test(error.message), error ? error.message : '');

    await srv.cerrar();
  }

  titulo('Una descarga completa sigue funcionando');
  {
    // Guarda de la guarda: si la verificación fuera demasiado estricta y
    // rechazara descargas buenas, el producto quedaría inservible.
    const contenido = Buffer.alloc(256 * 1024, 3);
    const srv = servidorMentiroso({ anuncia: contenido.length, manda: contenido.length, cortar: false });
    const puerto = await srv.escuchar();
    const dest = {
      type: 's3', endpoint: `http://127.0.0.1:${puerto}`, region: 'us-east-1',
      bucket: 'respaldos', prefix: '', accessKey: 'AKIA', secretKey: 'secreta',
    };
    const destino = path.join(TEMP, 'bien.bin');

    let error = null;
    try { await s3Descargar(dest, 'bien.bin', destino); } catch (e) { error = e; }
    comprobar('una descarga entera no da error', !error, error ? error.message : '');
    comprobar('el archivo quedó con el tamaño correcto',
      fs.existsSync(destino) && fs.statSync(destino).size === contenido.length,
      fs.existsSync(destino) ? String(fs.statSync(destino).size) : 'no existe');

    let datos = null;
    try { datos = await s3BajarDatos(dest, 'bien.bin'); } catch (e) { error = e; }
    comprobar('la lectura de datos entera tampoco da error',
      datos && datos.length === contenido.length,
      datos ? String(datos.length) : String(error && error.message));

    await srv.cerrar();
  }

  titulo('Las DOS defensas están puestas, no solo una');
  {
    // Honestidad sobre lo que cubre esta prueba: en la simulación de arriba, el
    // socket se destruye y salta la defensa de "conexión cortada". La comparación
    // contra el Content-Length cubre un caso distinto y más difícil de simular:
    // que el flujo cierre LIMPIAMENTE pero con menos bytes de los anunciados,
    // que es lo que hace un proxy o un balanceador que corta la respuesta.
    //
    // Las dos hacen falta. Se comprueba que ninguna se haya sacado.
    const src = fs.readFileSync(
      path.join(__dirname, '..', 'electron', 'backup-engine.cjs'), 'utf8');

    comprobar('al bajar a un archivo se compara contra el Content-Length',
      /n !== total[\s\S]{0,200}La descarga quedó incompleta/.test(src),
      'sin esto, un flujo que cierra limpio pero corto deja un archivo truncado');
    comprobar('al bajar a un archivo se detecta la conexión cortada',
      /res\.on\("aborted"/.test(src));
    comprobar('al leer datos se compara el tamaño recibido',
      /datos\.length !== total[\s\S]{0,160}Lectura incompleta/.test(src));
    comprobar('al leer datos se detecta la conexión cortada',
      /res\.on\("aborted"[\s\S]{0,200}Se cortó la conexión al leer/.test(src));
    comprobar('el archivo se escribe a un temporal y se renombra al final',
      /rename\(tmp, destinoLocal\)/.test(src),
      'es lo que evita que quede un archivo a medias con el nombre definitivo');
  }

  titulo('Rearmar por bloques verifica la huella antes de entregar el archivo');
  {
    const bloquesSrc = fs.readFileSync(
      path.join(__dirname, '..', 'electron', 'bloques.cjs'), 'utf8');
    comprobar('compara la huella obtenida contra la del índice',
      /obtenida !== indice\.huella/.test(bloquesSrc),
      'si faltara un bloque, es mejor fallar que entregar un archivo roto');
    comprobar('el archivo se rearma en un temporal y se renombra al final',
      /rename\(temporal, destinoLocal\)/.test(bloquesSrc),
      'así un rearmado que falla no deja un archivo a medias con el nombre real');
    comprobar('si el índice no trae huella, se avisa en vez de fingir que se verificó',
      /!indice\.huella/.test(bloquesSrc));
  }

  titulo('El índice se guarda en dos lugares');
  {
    const bloquesSrc = fs.readFileSync(
      path.join(__dirname, '..', 'electron', 'bloques.cjs'), 'utf8');
    const copias = (bloquesSrc.match(/subirTexto\(/g) || []).length;
    comprobar('hay más de una copia del índice', copias >= 2,
      'sin índice los bloques son pedazos anónimos: el archivo no se rearma');
  }

  titulo('Un archivo subido se puede volver a bajar idéntico');
  {
    // Prueba de extremo a extremo contra el servidor S3 de prueba, para que la
    // verificación nueva no rompa el camino feliz.
    const { crearServidorS3 } = require('./servidor-s3-prueba.cjs');
    const srv = crearServidorS3();
    const puerto = await srv.escuchar();
    const dest = {
      type: 's3', endpoint: `http://127.0.0.1:${puerto}`, region: 'us-east-1',
      bucket: 'respaldos', prefix: 'cliente/', accessKey: 'AKIA', secretKey: 'secreta',
    };
    const contenido = crypto.randomBytes(2 * 1024 * 1024);
    await s3SubirDatos(dest, 'cliente/prueba.bin', contenido, 'application/octet-stream');

    const destino = path.join(TEMP, 'vuelta.bin');
    await s3Descargar(dest, 'cliente/prueba.bin', destino);
    const leido = fs.readFileSync(destino);
    comprobar('el archivo que vuelve es idéntico al que se subió',
      Buffer.compare(leido, contenido) === 0,
      `${leido.length} vs ${contenido.length}`);

    await srv.cerrar();
  }

  try { fs.rmSync(TEMP, { recursive: true, force: true }); } catch {}

  console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
  if (falladas) { console.log('Fallaron:'); fallos.forEach((f) => console.log('  · ' + f)); }
  process.exit(falladas ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
