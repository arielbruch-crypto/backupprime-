'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Que al volver a una fecha se baje LA VERSIÓN DE ESA FECHA.

   Esta prueba existe por un error real: `bajarRemoto` llamaba a `s3Descargar`
   sin pasarle el `versionId`, y S3 sin versionId devuelve la versión ACTUAL del
   objeto. Los archivos guardados por bloques sí lo pasaban, los guardados
   enteros no. Resultado: alguien restauraba "la carpeta como estaba el lunes",
   recibía los archivos chicos de hoy —los que cifró el ransomware— y no había
   ningún aviso de que eso había pasado.

   La prueba de `maquina-tiempo.cjs` no lo detectó porque rehacía el bucle de
   descarga a mano, pasando el versionId ella misma. Comprobaba que la LÓGICA de
   elección estuviera bien, no que el programa la usara. De ahí la lección:
   cuando una prueba reimplementa el camino en vez de llamarlo, deja de cubrirlo.

   Se comprueba también que la descarga informe el avance: sin eso, restaurar un
   solo archivo grande dejaba la barra en 0% hasta el final.

     node pruebas/restaurar-version-correcta.cjs
   ═══════════════════════════════════════════════════════════════════════════ */

const fs = require('node:fs');
const fsp = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-ver-'));
process.env.BACKUPPRIME_CONFIG_DIR = path.join(TEMP, 'config');
fs.mkdirSync(process.env.BACKUPPRIME_CONFIG_DIR, { recursive: true });

const { crearServidorS3 } = require('./servidor-s3-prueba.cjs');
const { s3SubirDatos, s3Versiones, s3Descargar } = require('../electron/backup-engine.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);
const esperar = (ms) => new Promise((r) => setTimeout(r, ms));

console.log('BackupPrime — se restaura la versión pedida, no la actual\n');

(async () => {
  const srv = crearServidorS3();
  const puerto = await srv.escuchar();
  const dest = {
    type: 's3', endpoint: `http://127.0.0.1:${puerto}`, region: 'us-east-1',
    bucket: 'respaldos', prefix: 'cliente/', accessKey: 'AKIA', secretKey: 'secreta',
    label: 'e2',
  };

  const clave = 'cliente/C/Clientes/balance.xlsx';
  const SANO = 'balance real del cliente';
  const CIFRADO = 'AAAA-cifrado-por-ransomware-AAAA';

  titulo('Dos versiones del mismo archivo');
  await s3SubirDatos(dest, clave, Buffer.from(SANO), 'application/octet-stream');
  await esperar(1100);          // que las fechas de versión sean distintas
  const corte = new Date();
  await esperar(1100);
  await s3SubirDatos(dest, clave, Buffer.from(CIFRADO), 'application/octet-stream');

  const versiones = await s3Versiones(dest, clave);
  const lista = versiones.get(clave) || [];
  comprobar('el bucket guardó las dos versiones', lista.length === 2,
    `hay ${lista.length}`);

  const vSana = lista
    .filter((v) => !v.borrado && v.fecha && new Date(v.fecha) <= corte)
    .sort((a, b) => new Date(b.fecha) - new Date(a.fecha))[0];
  comprobar('se identifica la versión anterior al corte', !!vSana);

  titulo('Bajar esa versión trae el contenido de esa fecha');
  const conVersion = path.join(TEMP, 'con-version.xlsx');
  await s3Descargar(dest, clave, conVersion, vSana.versionId);
  const leido = await fsp.readFile(conVersion, 'utf8');
  comprobar('el archivo restaurado es el sano, no el cifrado', leido === SANO,
    `se recibió: ${JSON.stringify(leido.slice(0, 40))}`);

  titulo('Sin versionId se recibe la versión actual (la trampa del error)');
  const sinVersion = path.join(TEMP, 'sin-version.xlsx');
  await s3Descargar(dest, clave, sinVersion);
  const leido2 = await fsp.readFile(sinVersion, 'utf8');
  comprobar('sin versionId llega la versión actual', leido2 === CIFRADO);
  comprobar('las dos descargas dan contenidos distintos', leido !== leido2,
    'si dieran lo mismo, la prueba anterior no probaría nada');

  titulo('La descarga informa el avance');
  const grande = 'cliente/C/Clientes/archivo-grande.bin';
  const relleno = Buffer.alloc(3 * 1024 * 1024, 7);
  await s3SubirDatos(dest, grande, relleno, 'application/octet-stream');
  const avisos = [];
  const destinoGrande = path.join(TEMP, 'grande.bin');
  await s3Descargar(dest, grande, destinoGrande, undefined,
    (p) => avisos.push(p));

  comprobar('se informó el avance al menos una vez', avisos.length > 0,
    `avisos: ${avisos.length}`);
  comprobar('el primer aviso trae el total del archivo',
    avisos.length > 0 && avisos[0].total === relleno.length,
    `total informado: ${avisos.length ? avisos[0].total : '—'}`);
  const bytesFinales = avisos.length ? avisos[avisos.length - 1].bytes : 0;
  comprobar('el último aviso llega al total', bytesFinales === relleno.length,
    `${bytesFinales} de ${relleno.length}`);
  const creciente = avisos.every((p, i) => i === 0 || p.bytes >= avisos[i - 1].bytes);
  comprobar('los bytes informados nunca retroceden', creciente);
  comprobar('la suma de los deltas coincide con el total',
    avisos.reduce((n, p) => n + (p.delta || 0), 0) === relleno.length);

  titulo('El programa pasa el versionId donde hay que pasarlo');
  // Guarda estática: la prueba no puede llamar a `bajarRemoto` porque vive en
  // main.cjs y eso arrastra Electron entero. Se revisa el punto exacto donde
  // estaba el error, para que no vuelva sin que nadie se dé cuenta.
  const main = await fsp.readFile(path.join(__dirname, '..', 'electron', 'main.cjs'), 'utf8');
  // Los argumentos traen paréntesis adentro —`destinoDe(a)`— así que hay que
  // contar la apertura y el cierre, no cortar en el primer `)`.
  const argumentosDe = (texto, desde) => {
    let nivel = 0, i = desde;
    for (; i < texto.length; i++) {
      if (texto[i] === '(') nivel++;
      else if (texto[i] === ')') { nivel--; if (nivel === 0) break; }
    }
    return texto.slice(desde + 1, i);
  };
  // Se parten los argumentos de primer nivel: una coma dentro de `f(a, b)` o de
  // una función anónima no separa argumentos de la llamada externa.
  const partirNivelUno = (args) => {
    const partes = []; let actual = '', nivel = 0;
    for (const ch of args) {
      if ('([{'.includes(ch)) nivel++;
      else if (')]}'.includes(ch)) nivel--;
      if (ch === ',' && nivel === 0) { partes.push(actual); actual = ''; continue; }
      actual += ch;
    }
    partes.push(actual);
    return partes;
  };

  const llamadas = [];
  let pos = 0;
  for (;;) {
    const i = main.indexOf('s3Descargar(', pos);
    if (i < 0) break;
    llamadas.push(argumentosDe(main, i + 's3Descargar'.length));
    pos = i + 1;
  }
  const sinVersionEnMain = llamadas.filter((args) => {
    const partes = partirNivelUno(args);
    return partes.length < 4 || !/version/i.test(partes[3]);
  });
  comprobar('ninguna llamada a s3Descargar en main.cjs omite el versionId',
    sinVersionEnMain.length === 0,
    sinVersionEnMain.map((a) => a.replace(/\s+/g, ' ').slice(0, 90)).join(' | '));

  await srv.cerrar();
  try { fs.rmSync(TEMP, { recursive: true, force: true }); } catch {}

  console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
  if (falladas) { console.log('Fallaron:'); fallos.forEach((f) => console.log('  · ' + f)); }
  process.exit(falladas ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
