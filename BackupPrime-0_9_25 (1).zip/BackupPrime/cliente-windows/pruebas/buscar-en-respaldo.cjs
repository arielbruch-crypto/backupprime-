'use strict';
/* Buscar dentro de un respaldo.

   ── De dónde salió ──

   Un cliente escribió `*.pst` en el buscador de Restaurar y el programa dijo
   **"0 archivos"**, teniendo su PST de 651 MB ahí adentro.

   La búsqueda era `ruta.includes(texto)`, a secas. Escribir `*.pst` pedía rutas
   que CONTUVIERAN los caracteres `*.pst`, y ningún archivo se llama así.

   Eso no es un detalle de comodidad. Si alguien busca su correo en el respaldo
   y el programa contesta que no está, la conclusión es que **el respaldo no lo
   tiene**. Puede llegar a rehacer el trabajo, o pagar una recuperación de
   datos, teniendo el archivo guardado. Un producto de respaldo no puede
   hacerle creer eso.

     node pruebas/buscar-en-respaldo.cjs                                      */

const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — buscar dentro de un respaldo\n');

// Se saca `armarBusqueda` del propio `main.cjs`, sin copiarla: si se copiara,
// la prueba quedaría verde con la pantalla rota.
const fuente = fs.readFileSync(
  path.join(__dirname, '..', 'electron', 'main.cjs'), 'utf8');
const desde = fuente.indexOf('function armarBusqueda');
const hasta = fuente.indexOf('\n}\n', desde) + 3;
comprobar('Se encontró la función de búsqueda en main.cjs', desde > 0 && hasta > desde);
const armarBusqueda = new Function(
  fuente.slice(desde, hasta) + '\nreturn armarBusqueda;')();

// Un respaldo con las rutas como quedan de verdad en el destino.
const ARCHIVOS = [
  'C/Users/usuario/Documents/Outlook Files/ariel.bruch@itstandard.org.pst',
  'C/Users/usuario/Documents/archivo viejo.PST',
  'C/Users/usuario/Documents/Balance 2026.xlsx',
  'C/Users/usuario/Documents/Balance 2025.xlsx',
  'C/Users/usuario/Documents/balance borrador.docx',
  'C/Users/usuario/Desktop/backup ASSOFT 2026-08-13 (Completo).zip',
  'C/Users/usuario/Desktop/EMAIL-6.1.0.iso',
  'C/Users/usuario/Desktop/notas.txt',
  'C/pst/una carpeta que se llama pst/cualquiera.docx',
  // Nombres con caracteres que significan otra cosa en una expresión regular.
  // Son comunes de verdad: Windows los permite y la gente los usa.
  'C/Users/usuario/Documents/informe [final] v1+2.docx',
];

const buscar = (q) => {
  const coincide = armarBusqueda(q);
  return coincide ? ARCHIVOS.filter(coincide) : ARCHIVOS.slice();
};

titulo('La búsqueda que hacía cualquiera y no andaba');

const pst = buscar('*.pst');
comprobar('`*.pst` encuentra los archivos de correo',
  pst.length === 2,
  `encontró ${pst.length}: ${pst.join(' | ') || 'nada'} — decirle "0 archivos" a ` +
  `alguien que tiene su PST guardado es hacerle creer que perdió el correo`);

comprobar('Y no distingue mayúsculas: encuentra el .PST también',
  pst.some((r) => r.endsWith('.PST')));

comprobar('`.pst` sin asterisco también funciona',
  buscar('.pst').length === 2, `${buscar('.pst').length}`);

comprobar('No se cuela la carpeta que se LLAMA pst',
  !pst.some((r) => r.includes('cualquiera.docx')),
  'buscar una extensión tiene que mirar el final del nombre, no la ruta entera');

titulo('Buscar por texto sigue funcionando como antes');

comprobar('`balance` encuentra los tres, sin importar mayúsculas',
  buscar('balance').length === 3, `${buscar('balance').length}`);

comprobar('`ASSOFT` encuentra el zip',
  buscar('ASSOFT').length === 1);

comprobar('Un texto que no está no encuentra nada',
  buscar('facturacion').length === 0);

titulo('Comodines en cualquier posición');

comprobar('`Balance*.xlsx` encuentra los dos Excel',
  buscar('Balance*.xlsx').length === 2, `${buscar('Balance*.xlsx').length}`);

comprobar('`*2026*` encuentra lo del año',
  buscar('*2026*').length >= 2, `${buscar('*2026*').length}`);

comprobar('`EMAIL-?.?.?.iso` encuentra la imagen',
  buscar('EMAIL-?.?.?.iso').length === 1, `${buscar('EMAIL-?.?.?.iso').length}`);

titulo('Los nombres con caracteres especiales no rompen la búsqueda');

// `backup ASSOFT 2026-08-13 (Completo).zip` tiene paréntesis, que en una
// expresión regular significan otra cosa. Sin escaparlos, la búsqueda falla o
// tira un error y el cliente ve una pantalla vacía.
comprobar('`*(Completo)*` encuentra el archivo con paréntesis',
  buscar('*(Completo)*').length === 1,
  `${buscar('*(Completo)*').length} — sin escapar, los paréntesis rompen la búsqueda`);

comprobar('Un comodín suelto no hace explotar nada',
  Array.isArray(buscar('*')) && buscar('*').length === ARCHIVOS.length);

// Estos son los que de verdad exigen escapar: sin escapar, `[final]` se
// interpreta como "cualquiera de las letras f,i,n,a,l" y encuentra medio
// respaldo; y `v1+2` pide "uno o más unos". El cliente ve resultados que no
// pidió, o ninguno.
comprobar('`*[final]*` encuentra SOLO el archivo que dice [final]',
  buscar('*[final]*').length === 1,
  `${buscar('*[final]*').length} resultados — sin escapar, los corchetes se ` +
  `interpretan como "cualquiera de esas letras" y aparece medio respaldo`);

comprobar('`*v1+2*` encuentra el que tiene el signo más',
  buscar('*v1+2*').length === 1,
  `${buscar('*v1+2*').length} — sin escapar, el + significa "repetido" y no encuentra nada`);

comprobar('Corchetes sin cerrar no tiran un error',
  Array.isArray(buscar('bal[ance')),
  'una búsqueda mal escrita tiene que dar pocos resultados, no una pantalla en blanco');

titulo('Sin texto, se muestra todo');

comprobar('Búsqueda vacía devuelve el respaldo completo',
  buscar('').length === ARCHIVOS.length);
comprobar('Y solo espacios también',
  buscar('   ').length === ARCHIVOS.length);

console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
if (falladas) { console.log(fallos.map((f) => ` · ${f}`).join('\n')); process.exit(1); }
