'use strict';
// ---------------------------------------------------------------------------
// El cliente tiene que mostrar SU información sin depender de la web.
//
// Tres cosas que no se veían en el programa y sí en el portal:
//
//   1. La tarjeta de espacio quedaba oculta hasta que corriera un respaldo,
//      porque la cuota solo se llenaba al informar el uso. Un cliente abría el
//      programa y no sabía cuánto espacio usaba.
//   2. El plan contratado venía en la respuesta del login y se descartaba.
//   3. La papelera se dibujaba DENTRO del cargado del árbol: si el servidor no
//      respondía, no había dónde ver lo borrado ni cómo recuperarlo.
//
//   node pruebas/cliente-muestra-su-plan.cjs
// ---------------------------------------------------------------------------

const fs = require('node:fs');
const path = require('node:path');
const { JSDOM, VirtualConsole } = require('jsdom');

let pasadas = 0, falladas = 0;
const fallos = [];
function comprobar(nombre, condicion, detalle = '') {
  if (condicion) { pasadas++; console.log(`  ok   ${nombre}`); }
  else { falladas++; fallos.push(nombre); console.log(`  FALLA ${nombre}${detalle ? ' — ' + detalle : ''}`); }
}
const titulo = (t) => console.log(`\n${t}`);
const esperar = (ms) => new Promise((r) => setTimeout(r, ms));

const HTML = path.join(__dirname, '..', 'electron', 'renderer.html');
const MAIN = fs.readFileSync(path.join(__dirname, '..', 'electron', 'main.cjs'), 'utf8');

/* Doble del puente. Cualquier método que no esté definido devuelve [], para que
   falte uno y no se caiga toda la pantalla. */
function puenteFalso(extra) {
  return new Proxy(Object.assign({
    ultimaCuota: async () => ({
      usadoBytes: 442381045862, limiteBytes: 1073741824000,
      porcentaje: 41, estado: 'ok', plan: 'Estudio', planEspacioGB: 1000,
    }),
    papeleraListar: async () => ({
      total: 2, bytes: 1048576, diasRetencion: 30,
      archivos: [
        { id: 'a', nombre: 'viejo.pst', bytes: 3145728, diasRestantes: 27 },
        { id: 'b', nombre: 'IVA 2024.pdf', bytes: 184320, diasRestantes: 12 },
      ],
    }),
  }, extra || {}), {
    get(o, k) { return k in o ? o[k] : (typeof k === 'string' ? async () => [] : undefined); },
  });
}

async function abrir(extra) {
  const errores = [];
  const vc = new VirtualConsole();
  vc.on('jsdomError', (e) => errores.push(e.message));
  const dom = new JSDOM(fs.readFileSync(HTML, 'utf8'), {
    runScripts: 'dangerously', virtualConsole: vc, url: 'file:///r.html',
    beforeParse(w) { w.backupprime = puenteFalso(extra); },
  });
  await esperar(800);
  return { dom, doc: dom.window.document, errores };
}

(async () => {
  titulo('Espacio y plan, al abrir el programa');
  let { doc, errores } = await abrir();
  comprobar('La pantalla arranca sin errores',
    errores.filter((e) => !/fonts|css/i.test(e)).length === 0,
    errores.slice(0, 1).join(''));

  const tarjeta = doc.getElementById('cuotaCard');
  comprobar('La tarjeta de espacio se ve SIN haber corrido un respaldo',
    tarjeta && tarjeta.style.display !== 'none', tarjeta && tarjeta.style.display);
  comprobar('Dice cuánto se usa y de cuánto',
    /412.*de.*1000/.test(doc.getElementById('cuotaTexto').textContent),
    doc.getElementById('cuotaTexto').textContent);
  comprobar('Y dice QUÉ plan tiene contratado',
    /Estudio/.test(doc.getElementById('cuotaPlan').textContent),
    doc.getElementById('cuotaPlan').textContent);

  titulo('El plan se guarda al entrar');
  comprobar('El login guarda el plan que informa el servidor',
    /plan:\s*account\?\.plan/.test(MAIN), 'no se guarda');
  comprobar('Y la cuota se consulta al arrancar, no solo tras un respaldo',
    /function refrescarCuota/.test(MAIN) && /cuota:ultima.*refrescarCuota/s.test(MAIN),
    'sigue esperando al respaldo');

  titulo('La papelera se ve en el programa');
  ({ doc } = await abrir());
  doc.getElementById('tab-restore').click();
  await esperar(400);
  const caja = doc.getElementById('papeleraCliente');
  comprobar('Aparece al entrar a Restaurar', !!caja && /Papelera/.test(caja.textContent),
    caja && caja.textContent.slice(0, 80));
  comprobar('Con los archivos y los días que les quedan',
    /viejo\.pst/.test(caja.textContent) && /27 días/.test(caja.textContent));
  comprobar('Y cada uno se puede recuperar',
    doc.querySelectorAll('[data-recuperar]').length === 2,
    `${doc.querySelectorAll('[data-recuperar]').length} botones`);

  titulo('Vacía, lo dice; y no se esconde');
  ({ doc } = await abrir({
    papeleraListar: async () => ({ total: 0, bytes: 0, diasRetencion: 30, archivos: [] }),
  }));
  doc.getElementById('tab-restore').click();
  await esperar(400);
  const vacia = doc.getElementById('papeleraCliente');
  comprobar('Dice que está vacía en vez de desaparecer',
    /vacía/.test(vacia.textContent), vacia.textContent.slice(0, 80));
  comprobar('Y explica cuántos días se guarda lo borrado',
    /30 días/.test(vacia.textContent));

  titulo('Sin servidor, la papelera igual dice algo');
  // Era el caso real: con un certificado vencido el árbol no cargaba y la
  // papelera no se dibujaba nunca.
  ({ doc } = await abrir({
    papeleraListar: async () => ({ error: 'no se pudo conectar' }),
  }));
  doc.getElementById('tab-restore').click();
  await esperar(400);
  const sinRed = doc.getElementById('papeleraCliente');
  comprobar('Avisa que no se pudo consultar, en vez de quedar en blanco',
    /No se pudo consultar la papelera/.test(sinRed.textContent),
    sinRed.textContent.slice(0, 90));

  titulo('Se puede borrar una CARPETA, no solo archivos sueltos');
  // Solo los archivos tenían botón: para vaciar una carpeta había que ir uno
  // por uno. Y sin el tamaño de cada uno, la papelera decía "40 archivos" y
  // cero espacio.
  let enviado = null;
  ({ doc } = await abrir({
    papeleraMandar: async (archivos, carpeta) => {
      enviado = { archivos, carpeta };
      return { ok: true, movidos: archivos.length };
    },
    restoreRemotoTree: async () => ({
      totalFiles: 2,
      tree: [{ name: 'Datos', relPath: 'C/Datos', type: 'folder', fileCount: 2, children: [
        { name: 'a.pst', relPath: 'C/Datos/a.pst', type: 'file', size: 3000 },
        { name: 'b.xlsx', relPath: 'C/Datos/b.xlsx', type: 'file', size: 2000 },
      ] }],
    }),
    restoreSources: async () => [{ id: 'd1', kind: 'remoto', tipo: 's3', name: 'Nube' }],
  }));

  const marcado = fs.readFileSync(HTML, 'utf8');
  comprobar('El botón de papelera no está limitado a los archivos',
    !/node\.type === 'file' \? `<button class="small" data-borrar/.test(marcado),
    'sigue solo en archivos');
  comprobar('Y una carpeta junta lo que tiene adentro, con el tamaño de cada uno',
    /archivos\.push\(\{ ruta: n\.relPath, bytes: n\.size \|\| 0 \}\)/.test(marcado));
  comprobar('El aviso dice cuánto espacio son antes de confirmar',
    /Son ' \+ fmtSize\(total\)/.test(marcado));

  titulo('La papelera muestra el espacio, no solo la cantidad');
  ({ doc } = await abrir());
  doc.getElementById('tab-restore').click();
  await esperar(400);
  const conTam = doc.getElementById('papeleraCliente').textContent;
  comprobar('Cada archivo dice cuánto ocupa', /MB|KB|GB/.test(conTam), conTam.slice(0, 110));

  console.log('\n──────────────────────────────');
  console.log(`${pasadas} pasadas, ${falladas} falladas`);
  if (falladas) { console.log('Fallaron:'); fallos.forEach((f) => console.log('  · ' + f)); }
  process.exit(falladas ? 1 : 0);
})().catch((e) => { console.error('error inesperado:', e); process.exit(1); });
