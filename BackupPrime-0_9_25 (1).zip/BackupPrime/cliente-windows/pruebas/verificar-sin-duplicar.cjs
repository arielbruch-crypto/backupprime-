'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Verificar un respaldo SIN duplicar los datos.

   El problema que resuelve: cuando un respaldo se corta a mitad de camino —se
   colgó la máquina, se cortó la luz, se cayó la red— queda la duda de si lo que
   figura como subido está realmente en el destino y está entero.

   La respuesta fácil sería "forzá un respaldo completo", y es la respuesta
   equivocada: `forceFullBackup` borra el registro y vuelve a subir TODO. Con
   versionado activo, cada archivo se guarda otra vez como versión nueva. Para un
   cliente con 134 GB respaldados, eso son 134 GB más de su cuota sin ningún
   beneficio.

   El modo verificar comprueba contra el destino y sube ÚNICAMENTE lo que falta.

   Esta prueba mide lo que importa: cuántos objetos hay en el destino antes y
   después. Si verificar duplicara, el número subiría.

     node pruebas/verificar-sin-duplicar.cjs
   ═══════════════════════════════════════════════════════════════════════════ */

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-verif-'));
process.env.BACKUPPRIME_CONFIG_DIR = path.join(TEMP, 'config');
fs.mkdirSync(process.env.BACKUPPRIME_CONFIG_DIR, { recursive: true });

const { crearServidorS3 } = require('./servidor-s3-prueba.cjs');
const { BackupEngine, s3Listar, s3Versiones, s3Borrar, rutaEnDestino } =
  require('../electron/backup-engine.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — verificar sin duplicar\n');

(async () => {
  const srv = crearServidorS3();
  const puerto = await srv.escuchar();
  const dest = {
    type: 's3', enabled: true, label: 'e2',
    endpoint: `http://127.0.0.1:${puerto}`, region: 'us-east-1',
    bucket: 'respaldos', prefix: 'cliente/', accessKey: 'AKIA', secretKey: 'secreta',
  };

  const origen = path.join(TEMP, 'origen');
  fs.mkdirSync(origen, { recursive: true });
  for (let i = 1; i <= 6; i++) {
    fs.writeFileSync(path.join(origen, `archivo-${i}.txt`), crypto.randomBytes(4096));
  }

  const cfg = {
    server: '', token: '', localPaths: [origen], excludedPaths: [],
    destinations: [dest], maxVersions: 30, systemBackup: false,
    umbralBloquesMB: 500,   // que ninguno vaya por bloques, para contar objetos
  };

  /** Cuántas VERSIONES hay en total en el destino. Es lo que consume la cuota. */
  async function versionesTotales() {
    const mapa = await s3Versiones(dest, dest.prefix);
    let n = 0;
    for (const [, lista] of mapa) n += lista.filter((v) => !v.borrado).length;
    return n;
  }

  const correr = async (extra = {}) => {
    const motor = new BackupEngine();
    const registro = [];
    motor.on('log', (l) => registro.push(String(l)));
    await motor.runOnce({ ...cfg, ...extra });
    return registro.join('\n');
  };

  titulo('Primer respaldo');
  await correr();
  const trasPrimero = await versionesTotales();
  comprobar('se subieron los 6 archivos', trasPrimero === 6, `hay ${trasPrimero} versiones`);

  titulo('Verificar con todo en orden: no sube nada');
  {
    const registro = await correr({ verificar: true });
    const despues = await versionesTotales();
    comprobar('la cantidad de versiones NO cambió', despues === trasPrimero,
      `antes ${trasPrimero}, después ${despues} — verificar no puede consumir cuota`);
    comprobar('informa que está todo en orden', /Todo en orden/i.test(registro),
      registro.split('\n').filter((l) => /verificar/i.test(l)).join(' | ').slice(0, 160));
  }

  titulo('Falta un archivo en el destino: lo sube, y solo ese');
  {
    // Se borra del destino a mano, como si el respaldo se hubiera cortado justo
    // antes de subirlo.
    const clave = `${dest.prefix}${rutaEnDestino(path.join(origen, 'archivo-3.txt'))}`;
    await s3Borrar(dest, clave);
    const antes = await versionesTotales();

    const registro = await correr({ verificar: true });
    const despues = await versionesTotales();

    comprobar('detectó el que faltaba', /Falta en el destino/i.test(registro),
      registro.split('\n').filter((l) => /verificar/i.test(l)).join(' | ').slice(0, 200));
    comprobar('subió exactamente uno', despues === antes + 1,
      `antes ${antes}, después ${despues}`);
    comprobar('el resumen dice cuántos faltaban', /Faltaban 1 archivo/i.test(registro),
      registro.split('\n').filter((l) => /verificar/i.test(l)).join(' | ').slice(0, 200));
  }

  titulo('Un archivo cortado por la mitad también se detecta');
  {
    // El peor caso: la clave existe pero el contenido está incompleto. Figura
    // como respaldado y no sirve.
    const rel = rutaEnDestino(path.join(origen, 'archivo-5.txt'));
    const { s3SubirDatos } = require('../electron/backup-engine.cjs');
    await s3SubirDatos(dest, `${dest.prefix}${rel}`, Buffer.alloc(100), 'application/octet-stream');
    const antes = await versionesTotales();

    const registro = await correr({ verificar: true });
    const despues = await versionesTotales();

    comprobar('detecta que el tamaño no coincide',
      new RegExp(rel.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).test(registro),
      'un archivo incompleto en el destino es peor que uno ausente: parece estar');
    comprobar('lo vuelve a subir', despues > antes, `antes ${antes}, después ${despues}`);
  }

  titulo('La comparación con "respaldo completo"');
  {
    const antes = await versionesTotales();
    await correr({ forceFullBackup: true });
    const despues = await versionesTotales();

    // Esto NO es un error: es lo que forceFullBackup hace, a propósito. Se
    // documenta acá para que quede claro por qué no sirve como verificación y
    // por qué la pantalla lo advierte.
    comprobar('forzar un completo SÍ duplica las versiones', despues > antes,
      `antes ${antes}, después ${despues} — por eso no se recomienda para verificar`);

    const registro = await correr({ verificar: true });
    const trasVerificar = await versionesTotales();
    comprobar('verificar después de eso tampoco suma nada',
      trasVerificar === despues, `${despues} → ${trasVerificar}`);
  }

  titulo('Verificar no borra el registro local');
  {
    const antes = fs.readFileSync(
      path.join(process.env.BACKUPPRIME_CONFIG_DIR, 'state.json'), 'utf8');
    await correr({ verificar: true });
    const despues = fs.readFileSync(
      path.join(process.env.BACKUPPRIME_CONFIG_DIR, 'state.json'), 'utf8');
    const a = Object.keys(JSON.parse(antes)).length;
    const b = Object.keys(JSON.parse(despues)).length;
    comprobar('el registro sigue completo', b >= a, `${a} → ${b}`);
  }

  titulo('La pantalla advierte el costo del respaldo completo');
  {
    const html = fs.readFileSync(
      path.join(__dirname, '..', 'electron', 'renderer.html'), 'utf8');
    comprobar('hay un botón para verificar', html.includes('id="verificar2"'));
    comprobar('el texto de ayuda avisa que el completo consume cuota',
      /consume espacio de tu plan otra vez/i.test(html),
      'sin ese aviso, alguien puede duplicarle el consumo a un cliente sin querer');
  }

  await srv.cerrar();
  try { fs.rmSync(TEMP, { recursive: true, force: true }); } catch {}

  console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
  if (falladas) { console.log('Fallaron:'); fallos.forEach((f) => console.log('  · ' + f)); }
  process.exit(falladas ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
