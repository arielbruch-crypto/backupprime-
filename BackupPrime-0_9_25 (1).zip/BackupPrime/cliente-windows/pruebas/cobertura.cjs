'use strict';
// ---------------------------------------------------------------------------
// Marcar lo que quedó fuera del respaldo actual.
//
//   node pruebas/cobertura.cjs
// ---------------------------------------------------------------------------

const { marcarCatalogo, estaCubierto, estaDentroDe, explicarResumen } =
  require('../electron/cobertura.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
function comprobar(nombre, condicion, detalle = '') {
  if (condicion) { pasadas++; console.log(`  ok   ${nombre}`); }
  else { falladas++; fallos.push(nombre); console.log(`  FALLA ${nombre}${detalle ? ' — ' + detalle : ''}`); }
}
const titulo = (t) => console.log(`\n${t}`);

titulo('Comparar por segmentos, no por texto');
comprobar('Un archivo adentro de la carpeta está cubierto',
  estaDentroDe('C/Datos/balance.xlsx', 'C/Datos'));
comprobar('"C/Datos2" NO está dentro de "C/Datos"',
  !estaDentroDe('C/Datos2/x.xlsx', 'C/Datos'),
  'como texto empieza igual, y ese error saca de la lista cosas que sí se respaldan');
comprobar('La carpeta es ella misma', estaDentroDe('C/Datos', 'C/Datos'));
comprobar('Las barras invertidas se normalizan',
  estaDentroDe('C\\Datos\\x.xlsx', 'C/Datos'));
comprobar('Las barras repetidas también', estaDentroDe('C//Datos///x.xlsx', 'C/Datos'));

titulo('Exclusiones');
comprobar('Lo excluido no está cubierto aunque esté adentro',
  !estaCubierto('C/Datos/temp/x.tmp', ['C/Datos'], ['C/Datos/temp']));
comprobar('Y lo de al lado sí',
  estaCubierto('C/Datos/balance.xlsx', ['C/Datos'], ['C/Datos/temp']));

titulo('Marcar el catálogo');
const AHORA = new Date('2026-08-21T12:00:00Z').getTime();
let cat = {
  'C/Datos/balance.xlsx': { bytes: 1000 },
  'C/Datos/iva.pdf': { bytes: 2000 },
  'D/Viejo/carpeta-que-saque/x.pst': { bytes: 5000 },
};
let r = marcarCatalogo(cat, { carpetas: ['C/Datos'], ahora: AHORA });
comprobar('Marca cubierto lo que el trabajo cubre',
  r.catalogo['C/Datos/balance.xlsx'].cubierto === true);
comprobar('Y marca fuera lo que ya no',
  r.catalogo['D/Viejo/carpeta-que-saque/x.pst'].cubierto === false);
comprobar('Anota desde cuándo quedó fuera',
  r.catalogo['D/Viejo/carpeta-que-saque/x.pst'].fueraDesde === AHORA);
comprobar('El resumen cuenta bien', r.resumen.cubiertos === 2 && r.resumen.fuera === 1,
  JSON.stringify(r.resumen));
comprobar('Y suma los bytes de cada lado',
  r.resumen.bytesCubiertos === 3000 && r.resumen.bytesFuera === 5000,
  JSON.stringify(r.resumen));

titulo('La fecha de "fuera desde" no se pisa en cada corrida');
const DESPUES = AHORA + 90 * 86400000;
r = marcarCatalogo(r.catalogo, { carpetas: ['C/Datos'], ahora: DESPUES });
comprobar('Sigue diciendo cuándo se notó, no hoy',
  r.catalogo['D/Viejo/carpeta-que-saque/x.pst'].fueraDesde === AHORA,
  new Date(r.catalogo['D/Viejo/carpeta-que-saque/x.pst'].fueraDesde).toISOString());
comprobar('Así se puede decir "hace 3 meses que no se respalda"',
  r.resumen.masViejoFueraMs === AHORA);

titulo('Si la carpeta vuelve al respaldo, se limpia la marca');
r = marcarCatalogo(r.catalogo, { carpetas: ['C/Datos', 'D/Viejo'], ahora: DESPUES });
comprobar('Vuelve a estar cubierto',
  r.catalogo['D/Viejo/carpeta-que-saque/x.pst'].cubierto === true);
comprobar('Y no queda la fecha vieja colgada',
  r.catalogo['D/Viejo/carpeta-que-saque/x.pst'].fueraDesde === undefined);
comprobar('El resumen ya no reporta nada fuera', r.resumen.fuera === 0);

titulo('BARANDA: un trabajo sin carpetas no marca todo como fuera');
// Es el caso peligroso: la configuración no cargó, o el disco externo no montó.
// Marcar todo como fuera del respaldo asusta al cliente con un problema que no
// existe, y encima le ofrecería borrar TODO.
const marcado = marcarCatalogo({
  'C/Datos/a.xlsx': { bytes: 10, cubierto: true },
  'C/Datos/b.xlsx': { bytes: 20, cubierto: true },
}, { carpetas: [], ahora: AHORA });
comprobar('No marca nada como fuera', marcado.resumen.fuera === 0, JSON.stringify(marcado.resumen));
comprobar('Y avisa que el trabajo no declaró carpetas', marcado.resumen.sinCarpetas === true);
comprobar('Sin pisar las marcas anteriores',
  marcado.catalogo['C/Datos/a.xlsx'].cubierto === true);

titulo('Casos borde');
comprobar('Catálogo vacío no rompe', marcarCatalogo({}, { carpetas: ['C/x'] }).resumen.total === 0);
comprobar('Catálogo nulo no rompe', marcarCatalogo(null, { carpetas: ['C/x'] }).resumen.total === 0);
comprobar('Una entrada sin bytes cuenta como 0, no como NaN',
  marcarCatalogo({ 'C/x/a': {} }, { carpetas: ['C/x'], ahora: AHORA })
    .resumen.bytesCubiertos === 0);

titulo('El texto para la pantalla');
const linea = explicarResumen({ fuera: 12, bytesFuera: 5000 }, (b) => `${b / 1000} KB`);
comprobar('Dice cuántos y cuánto', /12 archivo/.test(linea) && /5 KB/.test(linea), linea);
comprobar('Aclara que SE PUEDEN restaurar', /podés restaurar/.test(linea), linea);
comprobar('Y que no se están actualizando', /no se están actualizando/.test(linea), linea);
comprobar('Sin archivos fuera, no hay cartel', explicarResumen({ fuera: 0 }) === null);

console.log('\n──────────────────────────────');
console.log(`${pasadas} pasadas, ${falladas} falladas`);
if (falladas) { console.log('Fallaron:'); fallos.forEach((f) => console.log('  · ' + f)); }
process.exit(falladas ? 1 : 0);
