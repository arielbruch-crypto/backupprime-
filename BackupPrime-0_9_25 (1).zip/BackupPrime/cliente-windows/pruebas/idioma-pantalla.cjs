'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Que al cambiar de idioma cambie TODA la pantalla.

   El problema que había: `applyLang()` solo alcanzaba a los elementos con id
   "lbl-…" que además existieran como clave en el diccionario. Todo lo demás
   quedaba escrito fijo en el HTML, en inglés o en castellano según cuándo se
   hubiera agregado. Resultado: al cambiar de idioma, parte de la pantalla
   cambiaba y parte no.

   Había además siete elementos con DOS atributos id —`id="addDest" id="lbl-dest-add"`—
   donde el navegador se queda con el primero e ignora el segundo, así que esas
   etiquetas no podían traducirse ni queriendo.

   Esta prueba abre la pantalla en un navegador simulado, cambia el idioma y
   comprueba que el texto efectivamente cambie.

   Complemento: `node pruebas/auditoria-idioma.cjs --estricto` revisa lo mismo de
   forma estática y lista cualquier texto nuevo que quede sin traducir.

     node pruebas/idioma-pantalla.cjs
   ═══════════════════════════════════════════════════════════════════════════ */

const fs = require('node:fs');
const path = require('node:path');

let JSDOM;
try { ({ JSDOM } = require('jsdom')); }
catch { console.log('Falta jsdom. Instalalo con: npm install'); process.exit(1); }

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — cambio de idioma en la pantalla\n');

const RENDERER = path.join(__dirname, '..', 'electron', 'renderer.html');
const html = fs.readFileSync(RENDERER, 'utf8');

const dom = new JSDOM(html, {
  runScripts: 'dangerously',
  pretendToBeVisual: true,
  beforeParse(win) {
    win.backupprime = new Proxy({}, {
      get: (_t, p) => (String(p).startsWith('on') ? () => {} : async () => ({})),
    });
  },
});
const win = dom.window;

new Promise((r) => {
  if (win.document.readyState === 'complete') return r();
  win.addEventListener('load', r);
}).then(() => {
  const doc = win.document;
  const cambiar = win.__pruebasIdioma;

  comprobar('la pantalla permite cambiar de idioma para probar', typeof cambiar === 'function',
    'falta `window.__pruebasIdioma` en renderer.html');
  if (typeof cambiar !== 'function') { throw new Error('sin punto de entrada'); }

  // Un elemento por cada mecanismo de traducción, para que si se rompe uno se
  // sepa cuál.
  const MUESTRAS = [
    ['lbl-restore-pick-title', 'título con id lbl-'],
    ['lbl-dest-add',           'botón que antes tenía dos atributos id'],
    ['lbl-test-connection',    'botón marcado con data-i18n'],
    ['lbl-password',           'etiqueta de formulario'],
    ['lbl-s3-endpoint',        'campo de configuración de S3'],
    ['lbl-notif-info',         'párrafo largo de ayuda'],
  ];
  const buscar = (clave) =>
    doc.getElementById(clave) || doc.querySelector(`[data-i18n="${clave}"]`);

  titulo('Cada mecanismo de traducción alcanza a su elemento');
  const textos = {};
  for (const idioma of ['en', 'es', 'pt']) {
    cambiar(idioma);
    textos[idioma] = {};
    for (const [clave] of MUESTRAS) {
      const el = buscar(clave);
      textos[idioma][clave] = el ? el.textContent.trim() : null;
    }
    comprobar(`el atributo lang del documento queda en "${idioma}"`,
      doc.documentElement.lang === idioma, doc.documentElement.lang);
  }

  for (const [clave, descripcion] of MUESTRAS) {
    const en = textos.en[clave], es = textos.es[clave], pt = textos.pt[clave];
    comprobar(`${descripcion} existe`, !!en, clave);
    comprobar(`${descripcion} cambia entre inglés y castellano`, !!en && en !== es,
      `en: ${JSON.stringify(en)} · es: ${JSON.stringify(es)}`);
    comprobar(`${descripcion} tiene su versión en portugués`, !!pt && pt !== en,
      `pt: ${JSON.stringify(pt)}`);
  }

  titulo('El nombre del producto no se traduce');
  {
    // Está acá por un error real: el <span> del logo es "Backup" + "Prime" en
    // dos partes, se tomó como texto traducible y en castellano el encabezado
    // pasó a decir "Respaldo". El nombre del producto es BackupPrime siempre.
    const logo = doc.querySelector('.hdr-title');
    comprobar('el encabezado con el logo existe', !!logo);
    for (const idioma of ['en', 'es', 'pt']) {
      cambiar(idioma);
      const texto = logo ? logo.textContent.replace(/\s+/g, '') : '';
      comprobar(`en "${idioma}" el encabezado dice BackupPrime`, texto === 'BackupPrime',
        JSON.stringify(texto));
    }
    comprobar('el logo no está marcado para traducir',
      !!logo && !logo.hasAttribute('data-i18n'));
    cambiar('es');
  }

  titulo('Ningún elemento con dos atributos id');
  {
    // La raíz de aquel error: el segundo id no existe para el navegador.
    const dobles = [...html.matchAll(/<[^>]*\bid="[^"]+"[^>]*\bid="[^"]+"[^>]*>/g)];
    comprobar('no quedan elementos con id repetido', dobles.length === 0,
      dobles.slice(0, 3).map((m) => m[0].slice(0, 80)).join(' | '));
  }

  titulo('Volver al castellano deja todo en castellano');
  {
    cambiar('en');
    cambiar('es');
    const enIngles = MUESTRAS
      .map(([c]) => [c, buscar(c)])
      .filter(([c, el]) => el && el.textContent.trim() === textos.en[c]);
    comprobar('no queda ningún texto en inglés después de volver', enIngles.length === 0,
      enIngles.map(([c]) => c).join(', '));
  }

  console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
  if (falladas) { console.log('Fallaron:'); fallos.forEach((f) => console.log('  · ' + f)); }
  process.exit(falladas ? 1 : 0);
}).catch((e) => { console.error(e); process.exit(1); });
