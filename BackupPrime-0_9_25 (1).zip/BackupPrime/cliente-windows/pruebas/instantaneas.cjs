'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Instantáneas de volumen: traducción de rutas y modo degradado.

   Qué NO prueba esto: que Windows cree la instantánea. Eso es API de Windows y
   solo se puede verificar en Windows, con Outlook abierto y `scanpst.exe`
   revisando el PST copiado. Esta prueba cubre la lógica que rodea a esa llamada,
   que es donde están los errores que uno puede cometer:

     · traducir C:\\...\\correo.pst a la ruta de la copia sombra;
     · no tocar las rutas de otros volúmenes;
     · devolver la ruta ORIGINAL cuando no hay instantánea, para que el respaldo
       siga funcionando en lugar de fallar entero;
     · que la clave en el destino se siga armando con la ruta original, y no con
       la de la instantánea — si no, al activar VSS todo el respaldo se resubiría
       bajo rutas nuevas tipo "GLOBALROOT/Device/..." y el histórico se perdería.

   Ese último punto es el que más caro sale y el más fácil de pasar por alto.

     node pruebas/instantaneas.cjs
   ═══════════════════════════════════════════════════════════════════════════ */

const path = require('node:path');
const Vss = require('../electron/vss.cjs');
const { rutaEnDestino } = require('../electron/backup-engine.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — instantáneas de volumen (lógica, sin Windows)\n');

// Una instantánea como la que devuelve Windows.
const INST_C = {
  id: '{11111111-2222-3333-4444-555555555555}',
  dispositivo: '\\\\?\\GLOBALROOT\\Device\\HarddiskVolumeShadowCopy7',
  volumen: 'C',
};
const estadoActivo = {
  activas: [INST_C],
  porVolumen: new Map([['C', INST_C]]),
  degradado: false, motivo: null,
};
const estadoDegradado = {
  activas: [], porVolumen: new Map(),
  degradado: true, motivo: 'Hacen falta permisos de administrador.',
};

const PST = 'C:\\Users\\usuario\\Desktop\\Backup\\Documents\\Outlook Files\\correo.pst';

titulo('Traducción de rutas');
{
  const t = Vss.traducirRuta(PST, INST_C);
  comprobar('la ruta traducida apunta al dispositivo sombra',
    t && t.includes('HarddiskVolumeShadowCopy7'), String(t));
  comprobar('conserva el resto del camino, sin la letra de unidad',
    t && t.includes('Outlook Files') && t.includes('correo.pst') && !/^C:/i.test(t),
    String(t));
  comprobar('un volumen distinto no se traduce',
    Vss.traducirRuta('D:\\Datos\\base.mdb', INST_C) === null);
  comprobar('la letra en minúscula también se reconoce',
    !!Vss.traducirRuta('c:\\Users\\a.txt', INST_C));
}

titulo('De dónde se lee cada archivo');
{
  comprobar('con instantánea activa se lee de la copia sombra',
    Vss.rutaDeLectura(PST, estadoActivo).includes('ShadowCopy7'));
  comprobar('un archivo de otro volumen se lee de su ruta original',
    Vss.rutaDeLectura('E:\\respaldo\\x.txt', estadoActivo) === 'E:\\respaldo\\x.txt');

  // Esto es el fallback: sin instantánea el respaldo sigue, degradado pero
  // andando. Devolver null o vacío acá dejaría al motor sin nada que leer.
  comprobar('sin instantánea se devuelve la ruta original',
    Vss.rutaDeLectura(PST, estadoDegradado) === PST);
  comprobar('sin estado alguno se devuelve la ruta original',
    Vss.rutaDeLectura(PST, null) === PST);
}

titulo('Volúmenes involucrados: una instantánea por volumen, no una por carpeta');
{
  const v = Vss.volumenesDe([
    'C:\\Users\\usuario\\Documents',
    'C:\\Users\\usuario\\Desktop',
    'D:\\Contabilidad',
    'd:\\Otra',
  ]);
  comprobar('agrupa por letra sin repetir', v.length === 2 && v.includes('C') && v.includes('D'),
    JSON.stringify(v));
}

titulo('La clave en el destino NO cambia al activar la instantánea');
{
  // El punto más caro de todos. `rutaEnDestino` tiene que recibir siempre la
  // ruta ORIGINAL. Si recibiera la de la instantánea, cada respaldo con VSS
  // guardaría los archivos bajo un camino nuevo —y distinto en cada corrida,
  // porque el número de ShadowCopy cambia— así que se resubiría todo y el
  // historial de versiones quedaría partido en pedazos.
  const claveOriginal = rutaEnDestino(PST);
  const claveSombra = rutaEnDestino(Vss.rutaDeLectura(PST, estadoActivo));

  comprobar('la clave desde la ruta original es limpia',
    claveOriginal.includes('Outlook Files') && !claveOriginal.includes('GLOBALROOT'),
    claveOriginal);
  comprobar('usar la ruta de la instantánea daría una clave distinta (por eso no se usa)',
    claveSombra !== claveOriginal,
    `original: ${claveOriginal} · sombra: ${claveSombra}`);

  // Y la comprobación que importa de verdad: el motor usa `sourcePath` para la
  // clave y `rutaLectura` para leer. Se verifica sobre el código.
  const fs = require('node:fs');
  const motor = fs.readFileSync(path.join(__dirname, '..', 'electron', 'backup-engine.cjs'), 'utf8');
  comprobar('el motor arma la clave con sourcePath, no con la ruta de lectura',
    motor.includes('rutaEnDestino(file.sourcePath)') &&
    !motor.includes('rutaEnDestino(file.rutaLectura)'));
  comprobar('el motor guarda el estado incremental por sourcePath',
    motor.includes('state.set(file.sourcePath') && !motor.includes('state.set(file.rutaLectura'));
  comprobar('el motor lee el archivo por la ruta de lectura',
    motor.includes('hashFile(file.rutaLectura'));
  comprobar('la instantánea se libera en un finally',
    /\} finally \{\s*\n\s*Vss\.liberar/.test(motor),
    'si no, un respaldo que falla deja la copia sombra colgada comiendo disco');
  comprobar('se limpian instantáneas huérfanas de corridas anteriores',
    motor.includes('Vss.limpiarHuerfanas()'));
}

titulo('Fuera de Windows no se intenta nada');
{
  const d = Vss.disponible();
  comprobar('en Linux informa que no está disponible, sin explotar',
    d && d.ok === false && /Windows/i.test(d.motivo), JSON.stringify(d));
  comprobar('esAdministrador devuelve false sin lanzar', Vss.esAdministrador() === false);
  comprobar('limpiarHuerfanas devuelve 0 sin lanzar', Vss.limpiarHuerfanas() === 0);
  comprobar('liberar sin estado no lanza', (() => {
    try { Vss.liberar(null); Vss.liberar({ activas: [], porVolumen: new Map() }); return true; }
    catch { return false; }
  })());
}

titulo('Modo degradado: se avisa, no se falla');
{
  const mensajes = [];
  const estado = Vss.crearParaCarpetas(['C:\\Users\\usuario\\Documents'],
    (m, tipo) => mensajes.push({ m, tipo }));
  comprobar('devuelve un estado usable aunque no haya instantánea',
    estado && Array.isArray(estado.activas) && estado.activas.length === 0);
  comprobar('queda marcado como degradado', estado.degradado === true);
  comprobar('explica el motivo', typeof estado.motivo === 'string' && estado.motivo.length > 10,
    String(estado.motivo));
  // Se informa, pero como 'info', NO como 'aviso'. La distinción importa: el
  // respaldo funciona sin instantáneas —la lectura directa sirve para casi todo,
  // incluido el PST de Outlook— así que teñir de naranja un respaldo correcto
  // asusta al cliente con un problema que no tiene.
  comprobar('informa por el log', mensajes.length > 0);
  comprobar('lo informa como dato, no como advertencia',
    mensajes[0] && mensajes[0].tipo !== 'aviso',
    `tipo: ${mensajes[0] && mensajes[0].tipo}`);
  comprobar('el mensaje no dice que los archivos queden afuera',
    mensajes.every((m) => !/queda\w* afuera|se van a saltear/i.test(m.m)),
    mensajes.map((m) => m.m).join(' | ').slice(0, 160));
}

console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
if (falladas) { console.log('Fallaron:'); fallos.forEach((f) => console.log('  · ' + f)); }
console.log('\nNota: que Windows cree la instantánea y que el PST copiado sea íntegro');
console.log('se verifica solo en Windows, con Outlook abierto y scanpst.exe.');
process.exit(falladas ? 1 : 0);
