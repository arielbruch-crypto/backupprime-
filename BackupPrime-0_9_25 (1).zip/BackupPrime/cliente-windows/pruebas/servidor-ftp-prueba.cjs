'use strict';
// Servidor FTP mínimo para medir el cliente de BackupPrime.
// Soporta USER/PASS/TYPE/PASV/MKD/CWD/STOR/LIST/QUIT, que es lo que usa el motor.
// `latenciaMs` retrasa cada respuesta del canal de control: así se reproduce
// una conexión real a un servidor remoto sin salir de la máquina.

const net = require('node:net');
const fs = require('node:fs');
const path = require('node:path');

function crearServidorFtp({ raiz, latenciaMs = 0, host = '127.0.0.1' }) {
  fs.mkdirSync(raiz, { recursive: true });
  const stats = { conexiones: 0, comandos: 0, archivos: 0, bytes: 0 };

  const servidor = net.createServer((ctrl) => {
    stats.conexiones++;
    let cwd = '/';
    let pasvServer = null;
    let pendiente = null;      // socket de datos aceptado
    let esperando = null;      // resolver cuando llegue

    const responder = (txt) => {
      if (latenciaMs) setTimeout(() => { try { ctrl.write(txt + '\r\n'); } catch {} }, latenciaMs);
      else { try { ctrl.write(txt + '\r\n'); } catch {} }
    };

    const rutaReal = (p) => {
      const limpio = path.posix.normalize(p).replace(/^(\.\.[/])+/, '');
      return path.join(raiz, limpio);
    };

    responder('220 Servidor de prueba');

    let buffer = '';
    ctrl.on('data', async (chunk) => {
      buffer += chunk.toString('ascii');
      let i;
      while ((i = buffer.indexOf('\r\n')) >= 0) {
        const linea = buffer.slice(0, i);
        buffer = buffer.slice(i + 2);
        stats.comandos++;
        const [cmd, ...resto] = linea.split(' ');
        const arg = resto.join(' ');

        switch (cmd.toUpperCase()) {
          case 'USER': responder('331 Falta la contraseña'); break;
          case 'PASS': responder('230 Sesión iniciada'); break;
          case 'TYPE': responder('200 Modo binario'); break;
          case 'SYST': responder('215 UNIX Type: L8'); break;
          case 'PWD':  responder(`257 "${cwd}"`); break;
          case 'CWD': {
            const destino = arg.startsWith('/') ? arg : path.posix.join(cwd, arg);
            if (fs.existsSync(rutaReal(destino))) { cwd = destino; responder('250 Carpeta cambiada'); }
            else responder('550 No existe');
            break;
          }
          case 'MKD': {
            const destino = arg.startsWith('/') ? arg : path.posix.join(cwd, arg);
            try { fs.mkdirSync(rutaReal(destino)); responder(`257 "${destino}" creada`); }
            catch { responder('550 Ya existe'); }
            break;
          }
          case 'PASV': {
            if (pasvServer) { try { pasvServer.close(); } catch {} }
            pendiente = null;
            pasvServer = net.createServer((sock) => {
              if (esperando) { const f = esperando; esperando = null; f(sock); }
              else pendiente = sock;
            });
            await new Promise((r) => pasvServer.listen(0, host, r));
            const puerto = pasvServer.address().port;
            const p1 = puerto >> 8, p2 = puerto & 255;
            responder(`227 Modo pasivo (127,0,0,1,${p1},${p2})`);
            break;
          }
          case 'STOR': {
            const destino = arg.startsWith('/') ? arg : path.posix.join(cwd, arg);
            const obtenerSock = () => pendiente
              ? Promise.resolve(pendiente)
              : new Promise((r) => { esperando = r; });
            responder('150 Abriendo canal de datos');
            (async () => {
              const sock = await obtenerSock();
              pendiente = null;
              const ws = fs.createWriteStream(rutaReal(destino));
              let n = 0;
              sock.on('data', (b) => { n += b.length; });
              sock.pipe(ws);
              ws.on('close', () => {
                stats.archivos++; stats.bytes += n;
                responder('226 Transferencia completa');
                try { pasvServer.close(); } catch {}
                pasvServer = null;
              });
            })();
            break;
          }
          case 'LIST': case 'NLST': {
            const obtenerSock = () => pendiente
              ? Promise.resolve(pendiente)
              : new Promise((r) => { esperando = r; });
            responder('150 Listado');
            (async () => {
              const sock = await obtenerSock();
              pendiente = null;
              let salida = '';
              try {
                const dirList = arg && arg.startsWith('/') ? arg : cwd;
                for (const e of fs.readdirSync(rutaReal(dirList), { withFileTypes: true })) {
                  const st = fs.statSync(path.join(rutaReal(dirList), e.name));
                  const tipo = e.isDirectory() ? 'd' : '-';
                  salida += `${tipo}rw-r--r-- 1 u g ${String(st.size).padStart(12)} Jan 01 00:00 ${e.name}\r\n`;
                }
              } catch {}
              sock.end(salida);
              responder('226 Listado completo');
              try { pasvServer.close(); } catch {}
              pasvServer = null;
            })();
            break;
          }
          case 'RETR': {
            const destino = arg.startsWith('/') ? arg : path.posix.join(cwd, arg);
            const obtenerSock = () => pendiente
              ? Promise.resolve(pendiente)
              : new Promise((r) => { esperando = r; });
            if (!fs.existsSync(rutaReal(destino))) { responder('550 No existe'); break; }
            responder('150 Enviando');
            (async () => {
              const sock = await obtenerSock();
              pendiente = null;
              fs.createReadStream(rutaReal(destino)).pipe(sock);
              sock.on('close', () => {
                responder('226 Transferencia completa');
                try { pasvServer.close(); } catch {}
                pasvServer = null;
              });
            })();
            break;
          }
          case 'QUIT': responder('221 Chau'); ctrl.end(); break;
          default: responder('502 No implementado');
        }
      }
    });
    ctrl.on('error', () => {});
  });

  return {
    stats,
    escuchar: () => new Promise((r) => servidor.listen(0, host, () => r(servidor.address().port))),
    cerrar: () => new Promise((r) => servidor.close(r)),
  };
}

module.exports = { crearServidorFtp };
