'use strict';
/* Un archivo tomado por otro programa, como el PST con Outlook abierto.
   El respaldo tiene que reintentar y, si igual no puede, explicarlo bien. */
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const B = require('../electron/bloques.cjs');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-lock-'));
let ok = 0, mal = 0;
const c = (n, v, d = '') => { if (v) { ok++; console.log('  ok   ' + n); } else { mal++; console.log('  FALLA ' + n + (d ? ' — ' + d : '')); } };

(async () => {
  const f = path.join(TEMP, 'correo.pst');
  fs.writeFileSync(f, Buffer.alloc(3 * 1048576, 7));

  console.log('\nUn archivo que se libera al segundo intento');
  // Se simula el bloqueo interceptando la apertura las primeras dos veces.
  const real = fs.createReadStream;
  let intentos = 0;
  fs.createReadStream = function (...args) {
    intentos++;
    if (intentos <= 2) {
      const falso = new (require('node:stream').Readable)({ read() {} });
      setImmediate(() => {
        const e = new Error('EBUSY: resource busy or locked, read');
        e.code = 'EBUSY';
        falso.emit('error', e);
      });
      return falso;
    }
    return real.apply(fs, args);
  };

  let resultado = null, error = null;
  try {
    resultado = await B.partir(f);
  } catch (e) { error = e; }
  fs.createReadStream = real;

  c('1. Reintenta en lugar de rendirse al primer EBUSY', intentos > 1, `${intentos} intentos`);
  c('2. Y termina leyendo el archivo', !!resultado && !error, error ? error.message.slice(0, 60) : '');

  console.log('\nUn archivo que nunca se libera');
  let intentos2 = 0;
  fs.createReadStream = function () {
    intentos2++;
    const falso = new (require('node:stream').Readable)({ read() {} });
    setImmediate(() => {
      const e = new Error('EBUSY: resource busy or locked, read');
      e.code = 'EBUSY';
      falso.emit('error', e);
    });
    return falso;
  };
  let err2 = null;
  try { await B.partir(f); } catch (e) { err2 = e; }
  fs.createReadStream = real;

  c('3. Después de varios intentos se rinde', !!err2);
  c('4. Y el mensaje explica qué hacer, no solo "EBUSY"',
    !!err2 && /tomado por otro programa/.test(err2.message) && /cerrar ese programa/.test(err2.message),
    err2 ? err2.message.slice(0, 90) : '');
  c('5. Nombra el archivo', !!err2 && err2.message.includes('correo.pst'));

  console.log(`\n  ${ok} de ${ok + mal} pruebas pasadas\n`);
  fs.rmSync(TEMP, { recursive: true, force: true });
  process.exit(mal ? 1 : 0);
})();
