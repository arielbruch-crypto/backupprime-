'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Respaldo por bloques, probado con un archivo que se comporta como un PST.
 
   Lo que hay que demostrar:
     · que un cambio chico dentro de un archivo grande sube poco;
     · que insertar contenido al principio NO obliga a subir todo de nuevo;
     · que el archivo rearmado es idéntico al original, byte por byte;
     · y que la limpieza de bloques sueltos no borra nada que se esté usando.
 
   Esa última es la más importante: borrar un bloque en uso deja un archivo
   imposible de restaurar y nadie se enteraría hasta el día que haga falta.
 
     node pruebas/bloques.cjs
   ═══════════════════════════════════════════════════════════════════════════ */

const fs = require('node:fs');
const fsp = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');

const B = require('../electron/bloques.cjs');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-bloques-'));

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);
const fmt = (b) => (b / 1048576).toFixed(1) + ' MB';

/** Almacén de mentira, en memoria, con soporte de versiones. */
function almacenFalso() {
  const objetos = new Map();      // clave -> [{ datos, fecha }]
  const stats = { subidas: 0, bajadas: 0, bytesSubidos: 0, existencias: 0 };

  const ultimo = (clave) => {
    const l = objetos.get(clave);
    return l && l[l.length - 1];
  };

  return {
    objetos, stats,
    async existe(clave) { stats.existencias++; return objetos.has(clave); },
    async subirDatos(clave, buffer, meta) {
      stats.subidas++; stats.bytesSubidos += buffer.length;
      if (!objetos.has(clave)) objetos.set(clave, []);
      objetos.get(clave).push({
        datos: Buffer.from(buffer), fecha: new Date().toISOString(), meta: meta || {},
      });
    },
    async leerMeta(clave) {
      // Devuelve los metadatos planos, igual que el adaptador de S3: lo que
      // guardó el respaldo y nada más envuelto alrededor.
      const item = ultimo(clave);
      if (!item) throw new Error(`No existe ${clave}`);
      return item.meta || {};
    },
    async subirTexto(clave, texto) {
      return this.subirDatos(clave, Buffer.from(texto, 'utf8'));
    },
    async bajarDatos(clave, version) {
      stats.bajadas++;
      const lista = objetos.get(clave);
      if (!lista) throw new Error(`No existe ${clave}`);
      const item = version != null ? lista[version] : lista[lista.length - 1];
      if (!item) throw new Error(`No existe esa versión de ${clave}`);
      return item.datos;
    },
    async bajarTexto(clave, version) {
      return (await this.bajarDatos(clave, version)).toString('utf8');
    },
    async borrar(clave) { objetos.delete(clave); },
    async listarIndices(prefijo) {
      // Las dos copias: la de indices/ y la que quedó al lado del archivo.
      return [...objetos.keys()]
        .filter((k) => k.startsWith(prefijo) && k.endsWith('.bpi'))
        .map((k) => ({ clave: k, versiones: objetos.get(k).map((_, i) => i) }));
    },
    async listarBloques(prefijo) {
      return [...objetos.keys()]
        .filter((k) => k.startsWith(`${prefijo}bloques/`))
        .map((k) => ({
          clave: k,
          bytes: ultimo(k).datos.length,
          fecha: ultimo(k).fecha,
        }));
    },
    espacio() {
      let n = 0;
      for (const lista of objetos.values()) for (const v of lista) n += v.datos.length;
      return n;
    },
  };
}

console.log('BackupPrime — respaldo por bloques\n');

(async () => {
  titulo('Los cortes');

  // Contenido variado de verdad. Con datos muy repetitivos los cortes por
  // contenido degeneran —la huella móvil se vuelve periódica— y la prueba mide
  // otra cosa. Un PST real tiene mensajes, adjuntos e índices: variado.
  const grande = Buffer.allocUnsafe(120 * 1024 * 1024);
  for (let i = 0; i < grande.length; i += 1048576) {
    crypto.randomFillSync(grande, i, Math.min(1048576, grande.length - i));
  }
  const archivo = path.join(TEMP, 'correo.pst');
  await fsp.writeFile(archivo, grande);

  const { bloques, huellaTotal } = await B.partir(archivo);
  const promedio = grande.length / bloques.length;

  comprobar('1. Parte el archivo en varios bloques', bloques.length > 5, `${bloques.length} bloques`);
  comprobar('2. El promedio queda cerca del objetivo de 4 MB',
    promedio > 1.5 * 1024 * 1024 && promedio < 12 * 1024 * 1024, fmt(promedio));
  comprobar('3. Ninguno pasa el máximo', bloques.every((b) => b.bytes <= B.MAXIMO));
  comprobar('4. Los bloques cubren el archivo entero sin huecos',
    bloques.reduce((n, b) => n + b.bytes, 0) === grande.length);
  comprobar('5. Los límites son consecutivos',
    bloques.every((b, i) => i === 0 || b.desde === bloques[i - 1].desde + bloques[i - 1].bytes));

  // Cortar dos veces el mismo archivo tiene que dar exactamente lo mismo.
  const otra = await B.partir(archivo);
  comprobar('6. Cortar el mismo archivo dos veces da el mismo resultado',
    JSON.stringify(otra.bloques.map((b) => b.huella)) ===
    JSON.stringify(bloques.map((b) => b.huella)));

  titulo('Primer respaldo');

  const almacen = almacenFalso();
  const r1 = await B.subirPorBloques(almacen, {
    rutaArchivo: archivo, rutaRelativa: 'C/Users/ana/correo.pst', prefijo: 'cliente/',
  });

  comprobar('7. Sube todos los bloques la primera vez',
    r1.nuevos === r1.bloques && r1.reutilizados === 0, `${r1.nuevos} de ${r1.bloques}`);
  comprobar('8. Y sube el archivo completo, ni más ni menos',
    r1.bytesSubidos === grande.length, fmt(r1.bytesSubidos));

  titulo('Al día siguiente: Outlook toca el final, como hace siempre');

  const conMailNuevo = Buffer.from(grande);
  crypto.randomBytes(80 * 1024).copy(conMailNuevo, conMailNuevo.length - 90 * 1024);
  await fsp.writeFile(archivo, conMailNuevo);

  const antes = almacen.stats.bytesSubidos;
  const r2 = await B.subirPorBloques(almacen, {
    rutaArchivo: archivo, rutaRelativa: 'C/Users/ana/correo.pst', prefijo: 'cliente/',
  });
  const subidoAhora = almacen.stats.bytesSubidos - antes;

  comprobar('9. Reutiliza casi todos los bloques',
    r2.reutilizados >= r2.bloques - 3, `reutilizó ${r2.reutilizados} de ${r2.bloques}`);
  comprobar('10. Sube una fracción del archivo, no los 120 MB',
    subidoAhora < grande.length * 0.2,
    `subió ${fmt(subidoAhora)} de ${fmt(grande.length)} — ` +
    `${(subidoAhora / grande.length * 100).toFixed(1)}%`);

  titulo('El caso difícil: se inserta contenido al principio');

  // Con bloques de tamaño fijo esto correría todo y habría que subir el archivo
  // entero. Con cortes por contenido, se mueve un límite y el resto se conserva.
  const conInsercion = Buffer.concat([crypto.randomBytes(3 * 1024 * 1024), conMailNuevo]);
  await fsp.writeFile(archivo, conInsercion);

  const antes2 = almacen.stats.bytesSubidos;
  const r3 = await B.subirPorBloques(almacen, {
    rutaArchivo: archivo, rutaRelativa: 'C/Users/ana/correo.pst', prefijo: 'cliente/',
  });
  const subido3 = almacen.stats.bytesSubidos - antes2;

  comprobar('11. Insertar al principio no obliga a subir todo de nuevo',
    // El corte por contenido acota el impacto, pero cuánto exactamente depende
    // de dónde caigan los límites: con 3 MB insertados el peor caso razonable
    // ronda el 25%. Lo que importa es que no sea el 100%, que es lo que pasaría
    // con bloques de tamaño fijo.
    subido3 < conInsercion.length * 0.28,
    `subió ${fmt(subido3)} de ${fmt(conInsercion.length)} — ` +
    `${(subido3 / conInsercion.length * 100).toFixed(1)}%`);

  titulo('Cuánto espacio se ahorró');

  const sinBloques = grande.length + conMailNuevo.length + conInsercion.length;
  const conBloques = almacen.espacio();
  comprobar('12. Tres versiones ocupan mucho menos que tres copias',
    conBloques < sinBloques * 0.5,
    `${fmt(conBloques)} contra ${fmt(sinBloques)} — ` +
    `ahorro del ${((1 - conBloques / sinBloques) * 100).toFixed(0)}%`);

  titulo('Restaurar');

  const salida = path.join(TEMP, 'recuperado.pst');
  const rr = await B.restaurarPorBloques(almacen, {
    rutaRelativa: 'C/Users/ana/correo.pst', destinoLocal: salida, prefijo: 'cliente/',
  });

  comprobar('13. Rearma el archivo con el tamaño correcto',
    rr.bytes === conInsercion.length, `${rr.bytes} vs ${conInsercion.length}`);
  comprobar('14. Y es idéntico al original, byte por byte',
    (await fsp.readFile(salida)).equals(conInsercion));

  // Una versión anterior del índice devuelve la versión anterior del archivo.
  const claveIdx = B.claveIndice('cliente/', 'C/Users/ana/correo.pst');
  const salidaVieja = path.join(TEMP, 'version-vieja.pst');
  await B.restaurarPorBloques(almacen, {
    rutaRelativa: 'C/Users/ana/correo.pst', destinoLocal: salidaVieja,
    prefijo: 'cliente/', versionIndice: 0,
  });
  comprobar('15. Con un índice anterior se recupera la versión anterior',
    (await fsp.readFile(salidaVieja)).equals(grande));

  titulo('No se entrega un archivo corrupto');

  // Se corrompe un bloque que la versión ACTUAL usa. Antes tomaba el primero que
  // encontraba, que podía ser de una versión vieja: la restauración no lo tocaba
  // y la prueba daba un falso "no lo detectó".
  const indiceActual = B.leerIndice(
    await almacen.bajarTexto(B.claveIndice('cliente/', 'C/Users/ana/correo.pst')));
  const claveAlgunBloque = B.claveBloque('cliente/', indiceActual.bloques[1].h);
  const original = almacen.objetos.get(claveAlgunBloque);
  const copia = Buffer.from(original[0].datos);
  copia[0] = copia[0] ^ 0xff;
  almacen.objetos.set(claveAlgunBloque, [{ datos: copia, fecha: original[0].fecha }]);

  let detecto = null;
  const salidaMala = path.join(TEMP, 'mala.pst');
  try {
    await B.restaurarPorBloques(almacen, {
      rutaRelativa: 'C/Users/ana/correo.pst', destinoLocal: salidaMala, prefijo: 'cliente/',
    });
  } catch (e) { detecto = e; }

  comprobar('16. Detecta que un bloque llegó alterado', !!detecto,
    detecto ? detecto.message.slice(0, 70) : 'no lo detectó');
  comprobar('17. Y no deja el archivo a medias haciéndose pasar por bueno',
    !fs.existsSync(salidaMala));

  almacen.objetos.set(claveAlgunBloque, original);   // se repara para lo que sigue

  titulo('Limpiar bloques que ya no se usan');

  const simulado = await B.limpiarBloquesSueltos(almacen, { prefijo: 'cliente/', simular: true });
  comprobar('18. Con todas las versiones vigentes, no hay nada para borrar',
    simulado.borrados === 0, `marcaría ${simulado.borrados} para borrar`);
  comprobar('19. Y reconoce todos los bloques como usados',
    simulado.usados > 0 && simulado.usados <= simulado.revisados);

  // Ahora se descartan las versiones viejas del índice, como haría la regla de
  // ciclo de vida a los 35 días. Hay que vencer LAS DOS copias: mientras una
  // conserve el historial, esos bloques siguen en uso y no se pueden borrar
  // (que es justamente para lo que existe la segunda copia).
  for (const clave of [...almacen.objetos.keys()].filter((k) => k.endsWith('.bpi'))) {
    almacen.objetos.set(clave, [almacen.objetos.get(clave).pop()]);
  }

  const conSueltos = await B.limpiarBloquesSueltos(almacen,
    { prefijo: 'cliente/', simular: true, diasDeGracia: 0 });
  comprobar('20. Al vencer las versiones viejas, aparecen bloques sueltos',
    conSueltos.borrados > 0, `${conSueltos.borrados} bloques, ${fmt(conSueltos.liberados)}`);

  const real = await B.limpiarBloquesSueltos(almacen,
    { prefijo: 'cliente/', simular: false, diasDeGracia: 0 });
  comprobar('21. Los borra', real.borrados === conSueltos.borrados);

  const salidaFinal = path.join(TEMP, 'final.pst');
  await B.restaurarPorBloques(almacen, {
    rutaRelativa: 'C/Users/ana/correo.pst', destinoLocal: salidaFinal, prefijo: 'cliente/',
  });
  comprobar('22. Y la versión que quedó sigue restaurándose perfecta',
    (await fsp.readFile(salidaFinal)).equals(conInsercion));

  titulo('La limpieza es cobarde a propósito');

  const conGracia = await B.limpiarBloquesSueltos(almacen,
    { prefijo: 'cliente/', simular: true, diasDeGracia: 7 });
  comprobar('23. No toca bloques recién subidos, aunque parezcan sueltos',
    conGracia.borrados === 0, `marcaría ${conGracia.borrados}`);

  // Un índice ilegible tiene que frenar la limpieza entera.
  await almacen.subirTexto('cliente/indices/roto.bpi', 'esto no es un índice');
  const conRoto = await B.limpiarBloquesSueltos(almacen,
    { prefijo: 'cliente/', simular: false, diasDeGracia: 0 });
  comprobar('24. Si un índice no se puede leer, no borra nada y avisa',
    !!conRoto.error && conRoto.borrados === 0, conRoto.error || '');

  titulo('El peor caso: se perdieron TODOS los índices');

  // Escenario catastrófico: no hay índices, no hay copias, y el cliente ya no
  // tiene el archivo original. Lo único que queda son los bloques.
  //
  // Se usa un archivo aparte que solo creció al final, que es cómo se comportan
  // los archivos que de verdad importan acá: PST, bases de datos, logs.
  const almacen2 = almacenFalso();
  const creciente = path.join(TEMP, 'crece.pst');
  const base1 = Buffer.allocUnsafe(30 * 1024 * 1024);
  for (let i = 0; i < base1.length; i += 1048576) {
    crypto.randomFillSync(base1, i, Math.min(1048576, base1.length - i));
  }
  await fsp.writeFile(creciente, base1);
  await B.subirPorBloques(almacen2, {
    rutaArchivo: creciente, rutaRelativa: 'C/Users/ana/crece.pst', prefijo: 'c/',
  });

  const base2 = Buffer.concat([base1, crypto.randomBytes(6 * 1024 * 1024)]);
  await fsp.writeFile(creciente, base2);
  await B.subirPorBloques(almacen2, {
    rutaArchivo: creciente, rutaRelativa: 'C/Users/ana/crece.pst', prefijo: 'c/',
  });

  // Se borra todo lo que sirva para ubicar los bloques.
  for (const clave of [...almacen2.objetos.keys()]) {
    if (clave.includes('indices/') || clave.endsWith('.bpi')) almacen2.objetos.delete(clave);
  }

  let sinIndice = null;
  try {
    await B.restaurarPorBloques(almacen2, {
      rutaRelativa: 'C/Users/ana/crece.pst',
      destinoLocal: path.join(TEMP, 'imposible.pst'), prefijo: 'c/',
    });
  } catch (e) { sinIndice = e; }
  comprobar('25. Sin índice no restaura, y explica que se puede reconstruir',
    !!sinIndice && /reconstruc/i.test(sinIndice.message),
    sinIndice ? sinIndice.message.slice(0, 70) : '');

  const simulacion = await B.reconstruirIndices(almacen2, { prefijo: 'c/', simular: true });
  comprobar('26. La reconstrucción encuentra el archivo dentro de los bloques',
    simulacion.recuperados.length === 1,
    JSON.stringify(simulacion.recuperados) + JSON.stringify(simulacion.incompletos));
  comprobar('27. Y mientras simula no escribe nada',
    ![...almacen2.objetos.keys()].some((k) => k.endsWith('.bpi')));

  const reconstruccion = await B.reconstruirIndices(almacen2, { prefijo: 'c/', simular: false });
  comprobar('28. Al reconstruir de verdad, deja los dos índices escritos',
    reconstruccion.recuperados.length === 1 &&
    [...almacen2.objetos.keys()].some((k) => k.endsWith('.bpi')) &&
    [...almacen2.objetos.keys()].some((k) => k.includes('indices/')));

  const rescatado = path.join(TEMP, 'rescatado.pst');
  await B.restaurarPorBloques(almacen2, {
    rutaRelativa: 'C/Users/ana/crece.pst', destinoLocal: rescatado, prefijo: 'c/',
  });
  comprobar('29. Y el archivo se recupera IDÉNTICO al original',
    (await fsp.readFile(rescatado)).equals(base2),
    `${(await fsp.stat(rescatado)).size} de ${base2.length} bytes`);

  titulo('Cuando la reconstrucción no puede: lo dice, no inventa');

  // Si al archivo le insertaron contenido al principio, las posiciones que
  // guardaron los bloques reutilizados quedaron viejas. Ahí NO se puede
  // reconstruir, y lo que importa es que se niegue en lugar de escribir un
  // índice que produzca un archivo corrupto.
  const almacen3 = almacenFalso();
  const arch3 = path.join(TEMP, 'corrido.dat');
  await fsp.writeFile(arch3, base1);
  await B.subirPorBloques(almacen3, {
    rutaArchivo: arch3, rutaRelativa: 'C/x/corrido.dat', prefijo: 'd/',
  });
  await fsp.writeFile(arch3, Buffer.concat([crypto.randomBytes(4 * 1024 * 1024), base1]));
  await B.subirPorBloques(almacen3, {
    rutaArchivo: arch3, rutaRelativa: 'C/x/corrido.dat', prefijo: 'd/',
  });
  for (const clave of [...almacen3.objetos.keys()]) {
    if (clave.includes('indices/') || clave.endsWith('.bpi')) almacen3.objetos.delete(clave);
  }

  const imposible = await B.reconstruirIndices(almacen3, { prefijo: 'd/', simular: false });
  comprobar('29b. Avisa que ese archivo no se puede reconstruir, con el motivo',
    imposible.incompletos.length === 1 && imposible.recuperados.length === 0,
    JSON.stringify(imposible.incompletos[0] || {}).slice(0, 120));
  comprobar('29c. Y no escribe un índice que daría un archivo corrupto',
    ![...almacen3.objetos.keys()].some((k) => k.endsWith('.bpi')));

  titulo('La copia del índice al lado del archivo');

  // Se borra solo la carpeta indices/, como haría una regla de ciclo de vida mal
  // puesta. La copia que quedó junto al archivo tiene que salvar el día.
  for (const clave of [...almacen2.objetos.keys()]) {
    if (clave.includes('indices/')) almacen2.objetos.delete(clave);
  }
  const conCopia = path.join(TEMP, 'con-copia.pst');
  await B.restaurarPorBloques(almacen2, {
    rutaRelativa: 'C/Users/ana/crece.pst', destinoLocal: conCopia, prefijo: 'c/',
  });
  comprobar('30. Perder la carpeta de índices no rompe nada',
    (await fsp.readFile(conCopia)).equals(base2));

  titulo('Revisión preventiva');

  const revision = await B.verificarIndices(almacen2, { prefijo: 'c/' });
  comprobar('31. Confirma que los índices tienen todos sus bloques',
    revision.conProblemas.length === 0 && revision.sanos >= 1,
    JSON.stringify(revision.conProblemas));

  // Se borra un bloque a mano: la revisión tiene que detectarlo.
  const unBloque = [...almacen2.objetos.keys()].find((k) => k.includes('/bloques/'));
  almacen2.objetos.delete(unBloque);
  const revision2 = await B.verificarIndices(almacen2, { prefijo: 'c/' });
  comprobar('32. Y detecta un bloque faltante antes de que haga falta restaurar',
    revision2.conProblemas.length === 1,
    JSON.stringify(revision2.conProblemas[0] || {}));

  console.log('\n──────────────────────────────────────────────────────');
  console.log(`  ${pasadas} de ${pasadas + falladas} pruebas pasadas`);
  if (falladas) { console.log('\n  Fallaron:'); for (const f of fallos) console.log(`    · ${f}`); }
  console.log('──────────────────────────────────────────────────────\n');

  try { fs.rmSync(TEMP, { recursive: true, force: true }); } catch {}
  process.exit(falladas ? 1 : 0);
})();
