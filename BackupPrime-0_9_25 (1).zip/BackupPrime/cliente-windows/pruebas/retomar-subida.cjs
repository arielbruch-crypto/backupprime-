'use strict';
/* Una subida cortada tiene que retomar, no empezar de cero.

   Por qué esto es crítico y no una optimización:

   Un cliente con 25 GB de imágenes ISO y 14,5 MB/s de subida necesita unas
   OCHO HORAS para el primer respaldo. En una máquina de estudio contable eso no
   entra en una jornada: se apaga a la noche, se reinicia por una actualización,
   se corta internet.

   Si cada corte hiciera empezar de cero, **esos archivos no se respaldarían
   nunca**. Y lo peor no es la lentitud: es que el cliente no se entera. La
   pantalla dice "115.204 sin cambios" y parece que está todo bien, mientras sus
   tres archivos más grandes no están en el destino.

   Por eso los archivos grandes van por bloques: no es para deduplicar una ISO
   —que no cambia nunca— sino para que lo ya subido quede subido.

     node pruebas/retomar-subida.cjs                                          */

const fs = require('node:fs');
const fsp = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-retomar-'));
process.env.BACKUPPRIME_CONFIG_DIR = path.join(TEMP, 'config');
fs.mkdirSync(process.env.BACKUPPRIME_CONFIG_DIR, { recursive: true });

const { crearServidorS3 } = require('./servidor-s3-prueba.cjs');
const { BackupEngine } = require('../electron/backup-engine.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — una subida cortada retoma donde quedó\n');

const RUTA_ESTADO = path.join(process.env.BACKUPPRIME_CONFIG_DIR, 'state.json');

/** Datos deterministas: con `randomBytes` los cortes caen distinto cada vez. */
function generar(mb) {
  const partes = [];
  let x = 99 >>> 0;
  for (let m = 0; m < mb; m++) {
    const b = Buffer.alloc(1048576);
    for (let j = 0; j < b.length; j++) {
      x ^= x << 13; x >>>= 0; x ^= x >>> 17; x ^= x << 5; x >>>= 0; b[j] = x & 0xff;
    }
    partes.push(b);
  }
  return Buffer.concat(partes);
}

(async () => {
  const srv = crearServidorS3();
  const puerto = await srv.escuchar();
  const dest = {
    type: 's3', endpoint: `http://127.0.0.1:${puerto}`, region: 'us-east-1',
    bucket: 'respaldos', prefix: 'c/', accessKey: 'AKIA', secretKey: 'secreta',
    label: 'e2',
  };

  const origen = path.join(TEMP, 'origen');
  await fsp.mkdir(origen, { recursive: true });
  const iso = path.join(origen, 'EMAIL-6.1.0.iso');
  const datos = generar(200);
  await fsp.writeFile(iso, datos);

  const cfg = {
    server: '', token: '', localPaths: [origen], excludedPaths: [],
    destinations: [dest], maxVersions: 10, systemBackup: false,
    forceFullBackup: false, umbralBloquesMB: 25,
  };

  titulo('Primer respaldo, completo');

  const motor = new BackupEngine();
  const registro = [];
  motor.on('log', (l) => registro.push(l.trim()));
  await motor.runOnce(cfg);

  comprobar('Sin errores', !registro.some((l) => l.includes('[error]')),
    registro.filter((l) => l.includes('[error]'))[0] || '');

  const bloquesDe = () => [...srv.objetos.keys()].filter((k) => k.includes('/bloques/'));
  const subidos = bloquesDe().length;
  comprobar('La imagen se guardó partida en bloques', subidos > 5, `${subidos} bloques`);

  titulo('El proceso se muere y el registro local se pierde');

  // El caso real: la máquina se apaga, Windows reinicia por una actualización,
  // o el cliente mata el proceso porque "parecía colgado". `state.json` queda
  // sin la anotación del archivo, así que el chequeo rápido no puede saltearlo.
  await fsp.writeFile(RUTA_ESTADO, '{}');

  const antes = { ...srv.stats };
  let leidos = 0;
  const crearReal = fs.createReadStream;
  fs.createReadStream = function (p, ...resto) {
    const s = crearReal.call(fs, p, ...resto);
    if (String(p).endsWith('.iso')) s.on('data', (b) => { leidos += b.length; });
    return s;
  };

  const motor2 = new BackupEngine();
  await motor2.runOnce(cfg);
  fs.createReadStream = crearReal;

  const nuevos = srv.stats.puts - antes.puts;

  comprobar('NO se vuelven a subir los bloques que ya estaban',
    nuevos <= 3,
    `subió ${nuevos} objetos de ${subidos} bloques — con 14,5 MB/s, resubir 25 GB ` +
    `son ocho horas, y esos archivos no se terminarían de respaldar nunca`);

  comprobar('No aparecen bloques duplicados en el destino',
    bloquesDe().length === subidos, `${bloquesDe().length} contra ${subidos}`);

  // ── Y con POCAS operaciones, no una por bloque ──
  //
  // Que no se resuban los bloques no alcanza. Hay dos redes de contención: la
  // lista completa de bloques (una sola operación) y, si esa falla, preguntar
  // bloque por bloque si existe. La segunda salva los datos pero es justo el
  // camino que da 403 en varios servicios compatibles con S3 — y con un 403 el
  // programa concluye que el bloque no está y lo sube igual.
  //
  // Medido con este archivo: 4 operaciones con la lista, 46 sin ella. En una
  // ISO de 13 GB serían miles.
  const operaciones = srv.stats.firmados - antes.firmados;
  comprobar('Y lo resuelve con pocas operaciones, no una por bloque',
    operaciones < subidos / 2,
    `${operaciones} operaciones para ${subidos} bloques — preguntar de a uno es ` +
    `el camino que devuelve 403 en varios servicios y hace resubir todo`);

  // Releer el archivo es inevitable: sin leerlo no hay forma de saber qué
  // bloques tiene. Lo que importa es que no VIAJE de nuevo. El troceo va a
  // ~85 MB/s contra los ~14 MB/s de una subida real, así que releer cuesta seis
  // veces menos que resubir.
  comprobar('Se relee el archivo para trocearlo, que es inevitable',
    leidos >= datos.length, `${(leidos / 1048576).toFixed(0)} MB leídos`);

  titulo('La corrida siguiente NO vuelve a trocear el archivo entero');

  // ── El caso de las imágenes ISO grandes ──
  //
  // El respaldo se corta a mitad de una ISO de 13 GB. El archivo no queda
  // anotado, así que el chequeo rápido no puede saltearlo. Antes, la corrida de
  // mañana volvía a LEER Y TROCEAR los 13 GB para descubrir exactamente los
  // mismos cortes: a ~85 MB/s son unos cinco minutos de disco y CPU quemados
  // todos los días para no aprender nada.
  //
  // Ahora el plan de corte se guarda apenas se conoce, aunque la subida no haya
  // terminado. Medido con esta imagen: 4,05 s leyendo 300 MB contra 0,10 s
  // leyendo 0 MB.
  {
    const est = JSON.parse(await fsp.readFile(RUTA_ESTADO, 'utf8'));
    const planes = Object.keys(est).filter((k) => k.startsWith('__plan:'));
    comprobar('El plan de corte queda guardado', planes.length >= 1,
      'sin el plan, mañana hay que trocear los 13 GB de nuevo');

    // Se borra la anotación del archivo —como si el respaldo se hubiera
    // cortado— pero se conserva el plan.
    for (const k of Object.keys(est)) if (!k.startsWith('__')) delete est[k];
    await fsp.writeFile(RUTA_ESTADO, JSON.stringify(est));

    let leidosPlan = 0;
    const abrirReal = fsp.open;
    fsp.open = async function (p, ...resto) {
      const h = await abrirReal.call(fsp, p, ...resto);
      if (String(p).endsWith('.iso')) {
        const leer = h.read.bind(h);
        h.read = async (...a) => { const x = await leer(...a); leidosPlan += x.bytesRead; return x; };
      }
      return h;
    };
    const crear2 = fs.createReadStream;
    fs.createReadStream = function (p, ...resto) {
      const st2 = crear2.call(fs, p, ...resto);
      if (String(p).endsWith('.iso')) st2.on('data', (b) => { leidosPlan += b.length; });
      return st2;
    };

    await new BackupEngine().runOnce(cfg);
    fsp.open = abrirReal;
    fs.createReadStream = crear2;

    comprobar('No se relee el archivo para volver a trocearlo',
      leidosPlan < datos.length / 4,
      `${(leidosPlan / 1048576).toFixed(0)} MB leídos de ${(datos.length / 1048576).toFixed(0)} — ` +
      `en una ISO de 13 GB, releerla son cinco minutos por corrida`);
  }

  titulo('Si el archivo cambió de verdad, el plan se descarta');

  // ── Hasta dónde se confía en el plan, dicho con precisión ──
  //
  // El atajo se apoya en tamaño y fecha. Es EXACTAMENTE el mismo nivel de
  // confianza que ya usa el chequeo rápido para saltear un archivo entero sin
  // abrirlo: si alguien cambia el contenido dejando tamaño y fecha idénticos,
  // el respaldo incremental completo se equivoca, no solo este atajo. No se
  // agrega ningún riesgo nuevo.
  //
  // Lo que sí hay que garantizar es que un cambio NORMAL —el que mueve la
  // fecha, que es lo que hace cualquier programa al escribir— descarte el plan
  // y obligue a recorrer el archivo. Eso es lo que se prueba acá.
  //
  // Y como red adicional: cada bloque que el atajo lee del disco se verifica
  // contra la huella del plan antes de subirse. Si no coincide, el atajo se
  // abandona sin subir nada.
  {
    const distinto = Buffer.from(datos);
    distinto.fill(0xAB, 10 * 1048576, 12 * 1048576);
    await fsp.writeFile(iso, distinto);   // escribir mueve la fecha, como siempre

    const est = JSON.parse(await fsp.readFile(RUTA_ESTADO, 'utf8'));
    const planViejo = Object.keys(est).find((k) => k.startsWith('__plan:'));
    comprobar('El plan viejo sigue guardado', !!planViejo);
    for (const k of Object.keys(est)) if (!k.startsWith('__')) delete est[k];
    await fsp.writeFile(RUTA_ESTADO, JSON.stringify(est));

    const motorX = new BackupEngine();
    const errores = [];
    motorX.on('log', (l) => { if (l.includes('[error]')) errores.push(l); });
    await motorX.runOnce(cfg);
    comprobar('Se respalda sin errores', errores.length === 0, errores[0] || '');

    // La prueba de fuego: que lo guardado permita rearmar el contenido NUEVO.
    const Bloques = require('../electron/bloques.cjs');
    const { almacenDeBloques } = require('../electron/backup-engine.cjs');
    const relIso = [...srv.objetos.keys()]
      .find((k) => k.includes('indices/') && k.endsWith('.iso.bpi'))
      .split('/').slice(1).join('/')
      .replace(/^c\//, '').replace(/^indices\//, '').replace(/\.bpi$/, '');
    const vuelta = path.join(TEMP, 'vuelta.iso');
    await Bloques.restaurarPorBloques(almacenDeBloques(dest), {
      rutaRelativa: relIso, destinoLocal: vuelta, prefijo: 'c/',
    });
    comprobar('Lo restaurado es el contenido NUEVO, byte por byte',
      (await fsp.readFile(vuelta)).equals(distinto),
      'el atajo confió en un plan viejo y armó un archivo que ya no existe');
  }

  titulo('Y con el registro intacto, ni se abre');

  // Una corrida más para que el archivo actual quede anotado en el registro.
  await new BackupEngine().runOnce(cfg);

  const antes2 = { ...srv.stats };
  leidos = 0;
  fs.createReadStream = function (p, ...resto) {
    const s = crearReal.call(fs, p, ...resto);
    if (String(p).endsWith('.iso')) s.on('data', (b) => { leidos += b.length; });
    return s;
  };
  const motor3 = new BackupEngine();
  await motor3.runOnce(cfg);
  fs.createReadStream = crearReal;

  comprobar('La imagen no se abre siquiera', leidos === 0,
    `${(leidos / 1048576).toFixed(0)} MB leídos`);
  comprobar('Y no se toca la red', srv.stats.puts === antes2.puts,
    `${srv.stats.puts - antes2.puts} objetos`);

  await srv.cerrar();
  fs.rmSync(TEMP, { recursive: true, force: true });

  console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
  if (falladas) { console.log(fallos.map((f) => ` · ${f}`).join('\n')); process.exit(1); }
})().catch((e) => { console.error(e); process.exit(1); });
