'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Firma SigV4 y archivos bloqueados.

   Estas pruebas existen por dos errores que llegaron al bucket real después de
   pasar las 200+ pruebas del proyecto:

   1) 403 SignatureDoesNotMatch al pedir las versiones. Nunca se había detectado
      porque el servidor de pruebas decía, textualmente, "no valida la firma (eso
      lo prueba el servidor real)". Una prueba que no verifica lo que importa no
      es una prueba. Ahora el servidor valida SigV4 con una implementación
      independiente (`firma-sigv4.cjs`), escrita desde la especificación y no
      copiada del cliente: si copiara el cliente, los dos errores se cancelarían.

   2) EBUSY en el PST con Outlook abierto, "arreglado" antes y vuelto a aparecer.
      El arreglo estaba en `bloques.cjs` (`abrirConReintentos`), pero el motor
      llama PRIMERO a `hashFile` para saber si el archivo cambió, y esa función
      no reintentaba. El archivo fallaba antes de llegar al código que sabía
      reintentar: el arreglo cubría la segunda mitad del recorrido, no la primera.

     node pruebas/firma-y-bloqueos.cjs
   ═══════════════════════════════════════════════════════════════════════════ */

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-firma-'));
process.env.BACKUPPRIME_CONFIG_DIR = path.join(TEMP, 'config');
fs.mkdirSync(process.env.BACKUPPRIME_CONFIG_DIR, { recursive: true });

const { crearServidorS3 } = require('./servidor-s3-prueba.cjs');
const { queryCanonica } = require('./firma-sigv4.cjs');
const motor = require('../electron/backup-engine.cjs');
const { s3SubirDatos, s3Listar, s3Versiones, s3Descargar, hashFile } = motor;

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — firma SigV4 y archivos bloqueados\n');

(async () => {
  // ═══ Parte 1: la firma se verifica de verdad ═══
  const srv = crearServidorS3({ validarFirma: { AKIA: 'secreta' } });
  const puerto = await srv.escuchar();
  const dest = {
    type: 's3', endpoint: `http://127.0.0.1:${puerto}`, region: 'us-east-1',
    bucket: 'bucket2test', prefix: 'cliente/', accessKey: 'AKIA', secretKey: 'secreta',
  };

  titulo('El servidor de pruebas ahora rechaza firmas mal armadas');
  {
    // Guarda de la guarda: si el validador aceptara cualquier cosa, todo lo que
    // viene después no probaría nada.
    const malo = { ...dest, secretKey: 'la-que-no-es' };
    let rechazado = false;
    try { await s3Listar(malo); } catch (e) { rechazado = /403/.test(e.message); }
    comprobar('una clave secreta incorrecta da 403', rechazado,
      'el validador acepta firmas inválidas: el resto de las pruebas no vale');
  }

  titulo('Las operaciones contra S3 firman bien');
  const casos = [
    ['subir un objeto', () => s3SubirDatos(dest, 'cliente/C/Users/a.txt', Buffer.from('x'), 'text/plain')],
    ['listar el bucket', () => s3Listar(dest)],
    ['listar versiones sin prefijo', () => s3Versiones(dest, '')],
    ['listar versiones con prefijo', () => s3Versiones(dest, 'cliente/C/Users/')],
  ];
  for (const [nombre, fn] of casos) {
    let err = null;
    try { await fn(); } catch (e) { err = e; }
    comprobar(nombre, !err, err && String(err.message).slice(0, 120));
  }

  titulo('Nombres con caracteres que rompían la firma');
  // encodeURIComponent NO codifica ! ' ( ) * y AWS los exige codificados. En
  // Windows los paréntesis aparecen en cuanto alguien copia un archivo.
  const nombresBravos = [
    'cliente/C/Users/Copia (1).docx',
    "cliente/C/Users/Balance 'final'.xlsx",
    'cliente/C/Users/Informe !urgente!.pdf',
    'cliente/C/Users/Notas *borrador*.txt',
    'cliente/C/Users/Presupuesto (rev 2) & anexo.xlsx',
    'cliente/C/Users/acentuado ñandú áéí.txt',
  ];
  for (const clave of nombresBravos) {
    let err = null;
    try {
      await s3SubirDatos(dest, clave, Buffer.from('contenido'), 'application/octet-stream');
      await s3Versiones(dest, clave);
      const bajado = path.join(TEMP, 'bajado.bin');
      await s3Descargar(dest, clave, bajado);
    } catch (e) { err = e; }
    comprobar(`funciona con "${path.basename(clave)}"`, !err,
      err && String(err.message).slice(0, 120));
  }

  titulo('El prefijo con esos caracteres se firma bien al pedir versiones');
  {
    let err = null;
    try { await s3Versiones(dest, "cliente/C/Users/Copia (1)"); } catch (e) { err = e; }
    comprobar('prefijo con paréntesis', !err, err && String(err.message).slice(0, 120));
  }

  titulo('Paginación de versiones (más de 1000 objetos)');
  {
    // Este camino no se ejecutaba en ninguna prueba: el servidor contestaba
    // siempre IsTruncated=false. Con 1177 objetos en el bucket real, es el
    // camino que corre.
    const d2 = { ...dest, prefix: 'muchos/' };
    for (let i = 0; i < 1150; i++) {
      await s3SubirDatos(d2, `muchos/archivo-${String(i).padStart(5, '0')}.txt`,
        Buffer.from('x'), 'application/octet-stream');
    }
    let err = null, mapa = null;
    try { mapa = await s3Versiones(d2, 'muchos/'); } catch (e) { err = e; }
    comprobar('la paginación no rompe la firma', !err, err && String(err.message).slice(0, 160));
    comprobar('la paginación trae TODAS las claves, no solo la primera página',
      mapa && mapa.size === 1150, mapa ? `trajo ${mapa.size} de 1150` : '—');
  }

  titulo('El error 403 explica qué se firmó');
  {
    const malo = { ...dest, secretKey: 'la-que-no-es' };
    let mensaje = '';
    try { await s3Versiones(malo, 'cliente/'); } catch (e) { mensaje = e.message; }
    comprobar('el mensaje incluye la petición canónica para diagnosticar',
      /petición canónica/.test(mensaje) && /query firmada/.test(mensaje),
      'sin esto, un 403 contra el bucket real no se puede rastrear');
  }

  await srv.cerrar();

  // ═══ Parte 2: la query canónica se ordena por nombre ═══
  titulo('Orden de los parámetros de la query');
  {
    // Ordenar las cadenas "nombre=valor" completas da el mismo resultado que
    // ordenar por nombre solo por casualidad, con los parámetros que se usan
    // hoy. Este caso muestra la diferencia.
    const porCadena = ['b=1', 'a-x=2', 'a=3'].sort().join('&');
    const canonica = queryCanonica('b=1&a-x=2&a=3');
    comprobar('ordenar por nombre no es lo mismo que ordenar la cadena entera',
      porCadena !== canonica, `cadena: ${porCadena} · canónica: ${canonica}`);
  }

  // ═══ Parte 3: archivos bloqueados ═══
  titulo('Un archivo tomado por otro programa se reintenta');
  {
    const archivo = path.join(TEMP, 'correo.pst');
    fs.writeFileSync(archivo, crypto.randomBytes(64 * 1024));
    const esperado = crypto.createHash('sha256')
      .update(fs.readFileSync(archivo)).digest('hex');

    // Se simula lo que hace Windows con Outlook abierto: los primeros intentos
    // de abrir fallan con EBUSY, después el archivo se suelta.
    const original = fs.createReadStream;
    let intentos = 0;
    fs.createReadStream = function (ruta, ...resto) {
      if (ruta === archivo && intentos++ < 2) {
        const flujo = original.call(fs, ruta, ...resto);
        process.nextTick(() => {
          const e = new Error('EBUSY: resource busy or locked, read');
          e.code = 'EBUSY';
          flujo.destroy(e);
        });
        return flujo;
      }
      return original.call(fs, ruta, ...resto);
    };

    let hash = null, err = null;
    try { hash = await hashFile(archivo, 5000); } catch (e) { err = e; }
    fs.createReadStream = original;

    comprobar('se reintenta y termina leyendo el archivo', hash === esperado,
      err ? String(err.message).slice(0, 140) : `hash: ${String(hash).slice(0, 16)}…`);
    comprobar('hubo más de un intento', intentos > 1, `intentos: ${intentos}`);
  }

  titulo('Un archivo bloqueado de forma permanente falla con un mensaje claro');
  {
    const archivo = path.join(TEMP, 'trabado.pst');
    fs.writeFileSync(archivo, Buffer.from('x'));
    const original = fs.createReadStream;
    let intentos = 0;
    fs.createReadStream = function (ruta, ...resto) {
      if (ruta === archivo) {
        intentos++;
        const flujo = original.call(fs, ruta, ...resto);
        process.nextTick(() => {
          const e = new Error('EBUSY: resource busy or locked, read');
          e.code = 'EBUSY';
          flujo.destroy(e);
        });
        return flujo;
      }
      return original.call(fs, ruta, ...resto);
    };
    let err = null;
    try { await hashFile(archivo, 5000, null, 3); } catch (e) { err = e; }
    fs.createReadStream = original;

    comprobar('reintenta las veces pedidas antes de rendirse', intentos === 3,
      `intentos: ${intentos}`);
    comprobar('el mensaje dice qué hacer, no solo "EBUSY"',
      err && /tomado por otro programa/.test(err.message) &&
      /cerrar ese programa/.test(err.message),
      err ? err.message.slice(0, 140) : 'no falló');
    comprobar('el error queda marcado como bloqueo', err && err.bloqueado === true);
  }

  titulo('Un error que NO es un bloqueo no se reintenta');
  {
    let err = null;
    const antes = Date.now();
    try { await hashFile(path.join(TEMP, 'no-existe-nunca.txt'), 5000); } catch (e) { err = e; }
    const tardo = Date.now() - antes;
    comprobar('un archivo inexistente falla enseguida', err && tardo < 400,
      `tardó ${tardo} ms`);
    comprobar('no se disfraza de bloqueo', err && !err.bloqueado);
  }

  try { fs.rmSync(TEMP, { recursive: true, force: true }); } catch {}

  console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
  if (falladas) { console.log('Fallaron:'); fallos.forEach((f) => console.log('  · ' + f)); }
  process.exit(falladas ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
