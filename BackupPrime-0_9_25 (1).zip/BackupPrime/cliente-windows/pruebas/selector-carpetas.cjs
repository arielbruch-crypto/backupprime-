'use strict';
/* El selector de carpetas.

   Es la primera pantalla que toca un cliente nuevo, y la que decide si su
   respaldo va a servir. Un selector malo no da un error: da un respaldo
   incompleto, que es lo que nadie descubre hasta el día del desastre.

   Lo que se controla:

     · Que la basura del sistema no aparezca. En el selector salían cosas como
       `snx_rhive{…}.TMContainer0000…0001.regtrans-ms` —transacciones del
       registro de Windows— mezcladas con los documentos del cliente. No son
       datos suyos, están siempre abiertas, y si las elige generan errores de
       archivo bloqueado en cada respaldo.
     · Que haya accesos rápidos, y sobre todo el correo de Outlook. Nadie que no
       sea técnico sabe que sus mails están en
       `AppData\Local\Microsoft\Outlook`. Obligarlo a navegar hasta ahí es
       garantizar que su PST no se respalde nunca: justo el archivo que más le
       va a doler perder.
     · La casilla INTERMEDIA. Sin ella, el cliente que eligió tres subcarpetas
       de Documentos ve la casilla de Documentos vacía y no tiene forma de
       saber que ahí adentro hay algo elegido. Termina marcando la carpeta
       entera "por las dudas" y respaldando 80 GB que no quería.
     · El total en vivo. Sin el número, elegir es a ciegas.

     node pruebas/selector-carpetas.cjs                                       */

const fs = require('node:fs');
const path = require('node:path');

let JSDOM;
try { ({ JSDOM } = require('jsdom')); }
catch { console.log('Falta jsdom. Instalalo con: npm install'); process.exit(1); }

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);
const esperar = (ms) => new Promise((r) => setTimeout(r, ms));

console.log('BackupPrime — el selector de carpetas\n');

const html = fs.readFileSync(path.join(__dirname, '..', 'electron', 'renderer.html'), 'utf8');
const preload = fs.readFileSync(path.join(__dirname, '..', 'electron', 'preload.cjs'), 'utf8');
const main = fs.readFileSync(path.join(__dirname, '..', 'electron', 'main.cjs'), 'utf8');

/**
 * Todo puente que la pantalla usa tiene que tener a alguien del otro lado.
 *
 * ── Por qué esto no existía y tenía que existir ──
 *
 * Los controles de más abajo simulan `window.backupprime`, y eso está bien para
 * probar la pantalla. Pero tiene un costo que se pagó caro: **el control "se
 * pidió la medición" pasaba en verde mientras el handler NO EXISTÍA**.
 * `medirRutas` estaba declarado en `preload.cjs`, la pantalla lo llamaba, y en
 * `main.cjs` no había ningún `ipcMain.handle("fs:medir")`. El pedido quedaba
 * colgado para siempre, el `catch` de la pantalla lo tragaba sin decir nada, y
 * el total de lo elegido aparecía en blanco. El cliente marcaba "Descargas" sin
 * enterarse de que eran 80 GB.
 *
 * Una prueba que simula el otro lado no puede detectar que el otro lado falta.
 * Este control mira los tres archivos de verdad y cierra ese agujero para todos
 * los puentes, no solo para este.
 */
function puentesHuerfanos() {
  const puentes = [];
  for (const m of preload.matchAll(
      /(\w+)\s*:\s*\([^)]*\)\s*=>\s*ipcRenderer\.invoke\(\s*["'`]([^"'`]+)["'`]/g)) {
    puentes.push({ nombre: m[1], canal: m[2] });
  }
  const usados = puentes.filter((p) =>
    new RegExp('backupprime\\s*\\.\\s*' + p.nombre + '\\s*\\(').test(html));
  const escapar = (c) => c.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const huerfanos = usados.filter((p) =>
    !new RegExp('ipcMain\\s*\\.\\s*handle\\(\\s*["\'`]' + escapar(p.canal) + '["\'`]').test(main));
  return { total: puentes.length, usados: usados.length, huerfanos };
}

// Un disco de mentira que se parece al de un estudio contable de verdad:
// documentos, el correo de Outlook donde Windows lo esconde, y basura del
// sistema mezclada.
const DISCO = {
  'C:\\Users\\usuario': {
    dirs: [{ name: 'Documents', full: 'C:\\Users\\usuario\\Documents' },
           { name: 'Desktop', full: 'C:\\Users\\usuario\\Desktop' }],
    files: [],
  },
  'C:\\Users\\usuario\\Documents': {
    dirs: [{ name: 'Balances', full: 'C:\\Users\\usuario\\Documents\\Balances' },
           { name: 'Clientes', full: 'C:\\Users\\usuario\\Documents\\Clientes' },
           { name: 'Liquidaciones', full: 'C:\\Users\\usuario\\Documents\\Liquidaciones' }],
    files: [{ name: 'Libro IVA.xlsx', full: 'C:\\Users\\usuario\\Documents\\Libro IVA.xlsx', size: 240000 }],
  },
};

let medicionesPedidas = [];

const dom = new JSDOM(html, {
  runScripts: 'dangerously',
  pretendToBeVisual: true,
  beforeParse(win) {
    win.backupprime = new Proxy({}, {
      get: (_t, p) => {
        const n = String(p);
        if (n.startsWith('on')) return () => {};
        if (n === 'listDir') return async (dir) => {
          const d = DISCO[dir];
          return d ? { ok: true, ...d, ocultos: 2, parent: path.win32.dirname(dir) }
                   : { ok: false, error: 'no existe', dirs: [], files: [], parent: '' };
        };
        if (n === 'systemDrives') return async () => ({ drives: ['C:\\'] });
        if (n === 'accesosRapidos') return async () => ({ accesos: [
          { clave: 'documentos', icono: '📄', ruta: 'C:\\Users\\usuario\\Documents' },
          { clave: 'escritorio', icono: '🖥️', ruta: 'C:\\Users\\usuario\\Desktop' },
          { clave: 'outlook', icono: '📧',
            ruta: 'C:\\Users\\usuario\\AppData\\Local\\Microsoft\\Outlook' },
        ] });
        if (n === 'medirRutas') return async (rutas) => {
          medicionesPedidas.push(rutas.slice());
          return { bytes: 1024 * 1024 * 1536, archivos: 4210, incompleto: false };
        };
        if (n === 'getPaths') return async () => [];
        return async () => ({});
      },
    });
  },
});
const win = dom.window;

new Promise((r) => {
  if (win.document.readyState === 'complete') return r();
  win.addEventListener('load', r);
}).then(async () => {
  const doc = win.document;
  const fijar = win.__pruebasIdioma;
  if (typeof fijar === 'function') fijar('es');

  titulo('Todo puente que la pantalla usa tiene alguien del otro lado');

  const puentes = puentesHuerfanos();
  comprobar('Se leyeron los puentes del preload', puentes.total > 20,
    `${puentes.total} puentes declarados`);
  comprobar('La pantalla usa varios de ellos', puentes.usados > 10,
    `${puentes.usados} usados`);
  comprobar('Ninguno queda colgado sin handler en main.cjs',
    puentes.huerfanos.length === 0,
    puentes.huerfanos.map((h) => `${h.nombre} → "${h.canal}"`).join(' | ') +
    ' · el pedido queda colgado y el catch de la pantalla lo traga en silencio');

  titulo('El selector se abre con accesos rápidos');

  doc.getElementById('addFoldersTree').onclick();
  await esperar(60);

  const atajos = doc.getElementById('treeAtajos');
  comprobar('Hay accesos rápidos', atajos && atajos.children.length >= 3,
    `${atajos ? atajos.children.length : 0} atajos`);

  // El control que importa de esta sección.
  comprobar('Y uno lleva directo al correo de Outlook',
    /Outlook/i.test(atajos.textContent),
    'sin esto el PST no se respalda nunca, porque nadie sabe dónde está');

  titulo('Se navega y se ve el contenido');

  const irA = (ruta) => {
    const el = [...atajos.querySelectorAll('.tree-atajo')]
      .find((x) => x.dataset.ruta === ruta);
    if (el) el.onclick();
  };
  irA('C:\\Users\\usuario\\Documents');
  await esperar(60);

  const lista = doc.getElementById('treeList');
  comprobar('Se ven las carpetas', /Balances/.test(lista.textContent));
  comprobar('Y también los archivos sueltos', /Libro IVA/.test(lista.textContent),
    'sin esto, para respaldar un archivo hay que agregar la carpeta entera');

  titulo('Las migas de pan permiten volver');

  const migas = doc.getElementById('treeBreadcrumb');
  comprobar('Cada tramo de la ruta es un enlace',
    migas.querySelectorAll('[data-ir]').length >= 2,
    `${migas.querySelectorAll('[data-ir]').length} enlaces`);

  titulo('El buscador filtra lo que se está viendo');

  const buscar = doc.getElementById('treeBuscar');
  buscar.value = 'liquid';
  buscar.oninput();
  await esperar(30);
  comprobar('Muestra lo que coincide', /Liquidaciones/.test(lista.textContent));
  comprobar('Y esconde lo que no', !/Balances/.test(lista.textContent),
    'buscar sin filtrar no sirve de nada');

  buscar.value = 'zzzz';
  buscar.oninput();
  await esperar(30);
  comprobar('Y si no hay nada, lo dice', /No hay nada con ese nombre/i.test(lista.textContent),
    lista.textContent.slice(0, 60));

  buscar.value = '';
  buscar.oninput();
  await esperar(30);

  titulo('La casilla intermedia');

  // Se eligen DOS subcarpetas de Documentos, no Documentos entera.
  const marcar = (ruta) => {
    const cb = lista.querySelector(`input[data-full="${win.CSS.escape(ruta)}"]`);
    cb.checked = true;
    cb.onchange();
  };
  marcar('C:\\Users\\usuario\\Documents\\Balances');
  marcar('C:\\Users\\usuario\\Documents\\Clientes');
  await esperar(30);

  // Se sube un nivel: la carpeta Documents tiene que mostrarse como parcial.
  irA('C:\\Users\\usuario\\Documents');
  await esperar(60);
  doc.getElementById('treeUp').onclick();
  await esperar(80);

  const cbDocs = lista.querySelector(
    `input[data-full="${win.CSS.escape('C:\\Users\\usuario\\Documents')}"]`);
  comprobar('La carpeta padre NO figura como elegida entera',
    cbDocs && !cbDocs.checked,
    'marcarla llena sería mentir: solo hay dos subcarpetas elegidas');
  comprobar('Pero SÍ se marca que hay algo elegido adentro',
    cbDocs && cbDocs.dataset.estado === 'parcial',
    `estado: ${cbDocs && cbDocs.dataset.estado} — sin esto el cliente marca la carpeta entera por las dudas`);
  comprobar('Y se dice con palabras, no solo con un color',
    /algo elegido adentro/i.test(lista.textContent),
    'un color solo no lo ve alguien que no sabe qué significa');

  titulo('Elegir la carpeta entera limpia lo redundante');

  cbDocs.checked = true;
  cbDocs.onchange();
  await esperar(30);

  const elegidos = doc.getElementById('treeSelectedList').textContent;
  comprobar('Ya no figuran las subcarpetas por separado',
    !/Balances/.test(elegidos) && !/Clientes/.test(elegidos),
    elegidos.slice(0, 120));
  comprobar('Y sí figura la carpeta padre', /Documents/.test(elegidos), elegidos.slice(0, 120));

  titulo('El total en vivo');

  await esperar(500);
  const total = doc.getElementById('treeTotal');
  comprobar('Se pidió la medición', medicionesPedidas.length > 0);
  comprobar('Se muestra la cantidad de archivos', /4\.210|4210/.test(total.textContent),
    total.textContent);
  comprobar('Y cuánto pesa', /GB|MB/.test(total.textContent), total.textContent);

  titulo('Hay forma de agregar una ruta de red');

  comprobar('Existe el botón', !!doc.getElementById('treeAddRed'),
    'un estudio con servidor tiene los datos en el servidor y eso no se navega');

  // Electron NO implementa prompt(): usarlo tira "prompt() is not supported" y
  // no pasa absolutamente nada. Ya nos pasó una vez con las exclusiones, y es
  // el tipo de falla que no se ve leyendo el código.
  // Se miran solo las líneas de CÓDIGO: los comentarios nombran `prompt()`
  // justamente para explicar por qué no se usa, y contarlos sería una falla
  // falsa. Una prueba que da rojo por un comentario enseña a ignorar el rojo.
  const codigo = html.split('\n')
    .filter((l) => !/^\s*(\/\/|\*|<!--)/.test(l))
    .join('\n');
  comprobar('Y NO usa prompt(), que en Electron no existe',
    !/[^.\w'"`]prompt\s*\(/.test(codigo),
    'usar prompt() deja el botón muerto sin ningún error visible');

  doc.getElementById('treeAddRed').onclick();
  await esperar(20);
  comprobar('El botón abre un campo propio dentro del selector',
    doc.getElementById('treeRedBox').style.display !== 'none');

  doc.getElementById('treeRedInput').value = 'X:\\no-existe';
  await doc.getElementById('treeRedIr').onclick();
  await esperar(40);
  comprobar('Si la ruta no anda, el error se muestra al lado del campo',
    doc.getElementById('treeRedErr').style.display !== 'none',
    'un aviso que se va solo no le sirve a alguien que escribió mal la ruta');

  console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
  if (falladas) { console.log(fallos.map((f) => ` · ${f}`).join('\n')); process.exit(1); }
}).catch((e) => { console.error(e); process.exit(1); });
