'use strict';
/* La pantalla de cifrado.

   Acá lo que se controla no es que "funcione": es que **no prometa nada que no
   pueda cumplir**, porque en este punto una promesa incumplida no la descubre
   nadie hasta que ya es tarde.

   Concretamente:

     · Que el modo privado avise, con esas palabras, que si se pierde la frase
       se pierden los archivos. Es la única función del programa que es
       irreversible por matemática, no por decisión nuestra.
     · Que el modo gestionado NO se pueda activar mientras el servidor no exista.
       Activarlo a medias sería decirle al cliente "tus archivos están cifrados y
       te los podemos devolver" cuando no hay quién guarde esa clave.
     · Que cambiar la frase con respaldos ya hechos se rechace con una
       explicación, en vez de dejar el respaldo anterior ilegible en silencio.

     node pruebas/pantalla-cifrado.cjs                                        */

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

let JSDOM;
try { ({ JSDOM } = require('jsdom')); }
catch { console.log('Falta jsdom. Instalalo con: npm install'); process.exit(1); }

const Cifrado = require('../electron/cifrado.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — la pantalla de cifrado\n');

const RENDERER = path.join(__dirname, '..', 'electron', 'renderer.html');
const html = fs.readFileSync(RENDERER, 'utf8');

const llamadas = [];
const dom = new JSDOM(html, {
  runScripts: 'dangerously',
  pretendToBeVisual: true,
  beforeParse(win) {
    win.backupprime = new Proxy({}, {
      get: (_t, p) => {
        const n = String(p);
        if (n.startsWith('on')) return () => {};
        if (n === 'getCifrado') return async () => ({ modo: null, configurado: false });
        if (n === 'setCifrado') return async (modo, frase) => {
          llamadas.push({ modo, frase });
          return { ok: true, modo };
        };
        return async () => ({});
      },
    });
  },
});
const win = dom.window;

new Promise((r) => {
  if (win.document.readyState === 'complete') return r();
  win.addEventListener('load', r);
}).then(async () => {
  const doc = win.document;
  const fijar = win.__pruebasIdioma;
  if (typeof fijar === 'function') fijar('es');

  const texto = doc.body.textContent;

  titulo('Los dos modos están, y se explican');

  comprobar('Existe la opción de clave administrada', !!doc.getElementById('cifGestionada'));
  comprobar('Existe la opción de frase propia', !!doc.getElementById('cifPrivada'));

  comprobar('Se dice que la frase NUNCA sale de la computadora',
    /nunca sale de esta computadora/i.test(texto));

  // Este es el control importante. Si el cliente elige frase propia y pierde la
  // frase, pierde todo, y no hay nada que se pueda hacer. Si la pantalla no lo
  // dice con todas las letras, el producto le está escondiendo lo único
  // irreversible que tiene.
  comprobar('Se advierte que perder la frase es perder los archivos',
    /si perdés la frase, perdés los archivos/i.test(texto), texto.slice(0, 0));
  comprobar('Y que no es una limitación que podamos sortear',
    /no hay forma de recuperarlos|no es una limitación que podamos sortear/i.test(texto));
  comprobar('Se pide anotar la frase fuera de la computadora',
    /anotá esta frase en un lugar seguro/i.test(texto));

  comprobar('Del modo administrado se dice que BackupPrime puede leer los archivos',
    /puede técnicamente leerlos/i.test(texto),
    'sin esto el cliente elige el modo por defecto creyendo que nadie puede leer sus datos');

  titulo('La frase se pide dos veces');

  comprobar('Hay dos campos de frase',
    !!doc.getElementById('cifFrase') && !!doc.getElementById('cifFrase2'));
  comprobar('Y son campos de contraseña, no de texto a la vista',
    doc.getElementById('cifFrase').type === 'password' &&
    doc.getElementById('cifFrase2').type === 'password');

  titulo('Si las dos frases no coinciden, no se guarda nada');

  doc.getElementById('cifPrivada').checked = true;
  doc.getElementById('cifFrase').value = 'frase larga del estudio';
  doc.getElementById('cifFrase2').value = 'frase larga del estudioo';
  llamadas.length = 0;
  doc.getElementById('cifGuardar').onclick();
  await new Promise((r) => setTimeout(r, 30));
  comprobar('No se llamó a guardar', llamadas.length === 0,
    `se llamó ${llamadas.length} vez/veces`);

  titulo('Si coinciden, se guarda con el modo correcto');

  doc.getElementById('cifFrase2').value = 'frase larga del estudio';
  llamadas.length = 0;
  doc.getElementById('cifGuardar').onclick();
  await new Promise((r) => setTimeout(r, 30));
  comprobar('Se llamó a guardar una vez', llamadas.length === 1);
  comprobar('Con el modo privado', llamadas[0] && llamadas[0].modo === 'privada',
    JSON.stringify(llamadas[0] || null));
  comprobar('Y con la frase que escribió el cliente',
    llamadas[0] && llamadas[0].frase === 'frase larga del estudio');

  titulo('La frase escrita no queda a la vista después de guardar');

  comprobar('Los campos se limpian',
    doc.getElementById('cifFrase').value === '' &&
    doc.getElementById('cifFrase2').value === '');

  titulo('El comprobante permite avisar antes de bajar nada');

  const sal = Cifrado.salNueva();
  const clave = Cifrado.claveDesdeFrase('frase larga del estudio', sal);
  const otra = Cifrado.claveDesdeFrase('otra frase distinta larga', sal);
  const comprobante = Cifrado.crearComprobante(clave);
  comprobar('La frase correcta valida', Cifrado.comprobanteValido(comprobante, clave));
  comprobar('Y una frase equivocada NO valida',
    !Cifrado.comprobanteValido(comprobante, otra),
    'sin esto el cliente se entera de que se equivocó después de bajar gigabytes');

  console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
  if (falladas) { console.log(fallos.map((f) => ` · ${f}`).join('\n')); process.exit(1); }
}).catch((e) => { console.error(e); process.exit(1); });
