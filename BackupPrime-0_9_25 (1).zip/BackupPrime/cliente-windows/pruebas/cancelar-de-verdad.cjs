'use strict';
/* Cancelar tiene que cancelar.

   ── El problema ──

   La bandera de cancelación existía, pero solo se miraba DENTRO del bucle de
   subida y del de bajada. Las fases largas no la consultaban nunca:

     · el recorrido de carpetas — con 165.000 archivos, decenas de segundos;
     · el inventario del destino — con 115.000 objetos, más de cien viajes;
     · la búsqueda de versiones — con 148.000 archivos, cientos de viajes.

   O sea que apretar "Detener" o "Cancelar" durante todo ese rato **no hacía
   absolutamente nada**. El botón no responde, el cliente concluye que el
   programa está colgado, y termina matando el proceso — que deja archivos a
   medio subir. Un botón que no responde es peor que no tener botón.

   ── Y un bug de los que no se ven ──

   La bandera se limpiaba al crear el seguidor de la bajada, o sea DESPUÉS de la
   búsqueda. Un cancelar de una operación anterior dejaba la bandera prendida y
   cortaba la búsqueda siguiente antes de empezar: el cliente apretaba
   "Restaurar" y no pasaba nada, sin ninguna explicación.

     node pruebas/cancelar-de-verdad.cjs                                      */

const fs = require('node:fs');
const fsp = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-cancel-'));
process.env.BACKUPPRIME_CONFIG_DIR = path.join(TEMP, 'config');
fs.mkdirSync(process.env.BACKUPPRIME_CONFIG_DIR, { recursive: true });

const { crearServidorS3 } = require('./servidor-s3-prueba.cjs');
const { BackupEngine, s3Versiones } = require('../electron/backup-engine.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — cancelar cancela\n');

(async () => {
  const srv = crearServidorS3();
  const puerto = await srv.escuchar();
  const dest = {
    type: 's3', endpoint: `http://127.0.0.1:${puerto}`, region: 'us-east-1',
    bucket: 'respaldos', prefix: 'c/', accessKey: 'AKIA', secretKey: 'secreta',
    label: 'e2',
  };

  // Muchas carpetas con muchos archivos: el recorrido tarda lo suficiente para
  // poder cancelarlo en el medio, que es el caso real.
  const origen = path.join(TEMP, 'origen');
  for (let d = 0; d < 40; d++) {
    const carpeta = path.join(origen, `carpeta-${d}`, 'sub', 'otra');
    await fsp.mkdir(carpeta, { recursive: true });
    for (let i = 0; i < 150; i++) {
      await fsp.writeFile(path.join(carpeta, `a${i}.docx`), Buffer.alloc(2048, 1));
    }
  }

  const cfg = {
    server: '', token: '', localPaths: [origen], excludedPaths: [],
    destinations: [dest], maxVersions: 10, systemBackup: false,
    forceFullBackup: false, umbralBloquesMB: 25,
  };

  titulo('Detener durante el recorrido de carpetas');

  const motor = new BackupEngine();
  const registro = [];
  motor.on('log', (l) => registro.push(l.trim()));

  const corriendo = motor.runOnce(cfg);
  // Se corta apenas arrancó: acá el programa está recorriendo carpetas, todavía
  // no subiendo. Es el momento en que antes el botón no hacía nada.
  await new Promise((r) => setTimeout(r, 150));
  const arranque = Date.now();
  motor.stop();
  await corriendo;
  const tardo = Date.now() - arranque;

  comprobar('El respaldo se detiene en menos de tres segundos',
    tardo < 3000,
    `tardó ${tardo} ms desde el pedido — con 165.000 archivos el recorrido son ` +
    `decenas de segundos y el botón parecía roto`);

  comprobar('Y lo dice en el registro',
    registro.some((l) => l.includes('[stop]')),
    registro.slice(-2).join(' | '));

  const subidos = [...srv.objetos.keys()].length;
  comprobar('No subió los 6.000 archivos: cortó antes',
    subidos < 6000, `subió ${subidos} objetos`);

  titulo('Y después de cancelar, el siguiente respaldo funciona');

  // Si la bandera quedara prendida, el respaldo siguiente no haría nada y el
  // cliente no tendría forma de saber por qué.
  const motor2 = new BackupEngine();
  let resumen = null;
  motor2.on('done', (d) => { resumen = d; });
  await motor2.runOnce(cfg);
  comprobar('El respaldo siguiente sube todo',
    resumen && (resumen.uploaded + resumen.skipped) === 6000,
    `${resumen ? resumen.uploaded + resumen.skipped : 0} de 6000 — una bandera que ` +
    `queda prendida deja el respaldo siguiente sin hacer nada`);

  titulo('Cancelar durante la búsqueda de versiones');

  // Esta es la fase que el cliente ve como "buscando": cientos de páginas
  // pedidas al servidor, una por una.
  let paginas = 0;
  const antes = srv.stats.lists;
  let cancelado = false;

  const mapa = await s3Versiones(dest, 'c/', () => { paginas++; },
    // Se cancela después de la primera página.
    () => { const c = cancelado; cancelado = true; return c; });

  const pedidas = srv.stats.lists - antes;
  comprobar('Corta después de la primera página, no sigue hasta el final',
    pedidas <= 2, `pidió ${pedidas} páginas`);
  comprobar('Y devuelve lo que alcanzó a juntar, sin tirar un error',
    mapa instanceof Map,
    'devolver un error haría que la pantalla muestre una falla donde hubo una ' +
    'cancelación pedida por el cliente');

  titulo('Sin cancelar, la búsqueda completa sigue funcionando');

  const antes2 = srv.stats.lists;
  const completo = await s3Versiones(dest, 'c/', null, () => false);
  comprobar('Encuentra los objetos del destino',
    completo.size > 0, `${completo.size} claves`);
  comprobar('Y pidió al menos una página',
    srv.stats.lists > antes2);

  await srv.cerrar();
  fs.rmSync(TEMP, { recursive: true, force: true });

  console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
  if (falladas) { console.log(fallos.map((f) => ` · ${f}`).join('\n')); process.exit(1); }
})().catch((e) => { console.error(e); process.exit(1); });
