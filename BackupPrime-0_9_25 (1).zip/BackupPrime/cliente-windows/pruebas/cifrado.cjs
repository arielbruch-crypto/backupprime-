'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Cifrado de los archivos: los dos modos.

   Hasta la 0.9.5 los archivos se subían SIN cifrar. Estaban protegidos por TLS
   en tránsito y por el cifrado en reposo del proveedor, y nada más: el
   proveedor, o cualquiera que acceda a esa cuenta, podía leerlos.

   Ahora el cliente elige, y la diferencia es quién puede rescatarlo:

   · GESTIONADA (por defecto): la clave la guarda BackupPrime. Si el cliente
     pierde la contraseña, se le puede restablecer el acceso y bajar los
     archivos. También permite restaurar desde la web.

   · PRIVADA: la clave sale de una frase que solo conoce el cliente y no viaja
     nunca al servidor. Nadie más puede leer los archivos. **Si el cliente pierde
     la frase, pierde todo**, y eso no es una limitación que se pueda sortear.

   Lo que más importa probar acá, en orden:
     1. Que lo que llega al almacenamiento NO sea legible.
     2. Que la deduplicación siga funcionando (es el diferencial del producto).
     3. Que los respaldos hechos ANTES del cifrado se sigan pudiendo restaurar.
     4. Que una frase equivocada falle CLARO y antes de bajar nada.

     node pruebas/cifrado.cjs
   ═══════════════════════════════════════════════════════════════════════════ */

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-cifra-'));
process.env.BACKUPPRIME_CONFIG_DIR = path.join(TEMP, 'config');
fs.mkdirSync(process.env.BACKUPPRIME_CONFIG_DIR, { recursive: true });

const C = require('../electron/cifrado.cjs');
const { crearServidorS3 } = require('./servidor-s3-prueba.cjs');
const { BackupEngine, s3Listar, s3BajarDatos, almacenDeBloques, rutaEnDestino } =
  require('../electron/backup-engine.cjs');
const Bloques = require('../electron/bloques.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — cifrado de archivos\n');

(async () => {
  titulo('El módulo, por sí solo');
  {
    const clave = C.claveNueva();
    const secreto = Buffer.from('Balance del estudio: 4.500.000 pesos');
    const cif = C.cifrar(secreto, clave);

    comprobar('el texto original NO aparece en los datos cifrados',
      !cif.includes(Buffer.from('Balance')) && !cif.includes(Buffer.from('4.500.000')),
      'es lo único que importa de un cifrado');
    comprobar('descifra al original exacto', C.descifrar(cif, clave).equals(secreto));
    comprobar('se reconoce como cifrado', C.estaCifrado(cif));
    comprobar('un dato sin cifrar no se confunde', !C.estaCifrado(secreto));

    comprobar('con otra clave falla', (() => {
      try { C.descifrar(cif, C.claveNueva()); return false; } catch { return true; }
    })());

    // Un byte cambiado tiene que detectarse: en un backup, devolver datos
    // alterados que parecen correctos es lo peor que puede pasar.
    const alterado = Buffer.from(cif);
    alterado[alterado.length - 1] ^= 1;
    comprobar('detecta si los datos fueron alterados', (() => {
      try { C.descifrar(alterado, clave); return false; } catch { return true; }
    })());

    // Dos cifrados del mismo dato tienen que dar bytes distintos. Si dieran
    // iguales, se podría confirmar qué archivos guarda un cliente sin tener la
    // clave, comparando contra un archivo conocido.
    comprobar('cifrar dos veces lo mismo da resultados distintos',
      !C.cifrar(secreto, clave).equals(C.cifrar(secreto, clave)),
      'si no, se puede confirmar qué archivos tiene un cliente sin la clave');
  }

  titulo('Derivar la clave de una frase');
  {
    const sal = C.salNueva();
    const a = C.claveDesdeFrase('una-frase-larga-y-secreta', sal);
    const b = C.claveDesdeFrase('una-frase-larga-y-secreta', sal);
    comprobar('la misma frase y sal dan la misma clave', a.equals(b));
    comprobar('otra frase da otra clave',
      !a.equals(C.claveDesdeFrase('otra-frase-distinta', sal)));
    comprobar('otra sal da otra clave',
      !a.equals(C.claveDesdeFrase('una-frase-larga-y-secreta', C.salNueva())));
    comprobar('una frase demasiado corta se rechaza', (() => {
      try { C.claveDesdeFrase('corta', sal); return false; } catch { return true; }
    })());
  }

  titulo('El comprobante avisa de una frase equivocada ANTES de restaurar');
  {
    const sal = C.salNueva();
    const clave = C.claveDesdeFrase('la-frase-del-cliente', sal);
    const comp = C.crearComprobante(clave);

    comprobar('valida la frase correcta', C.comprobanteValido(comp, clave));
    comprobar('rechaza la equivocada',
      !C.comprobanteValido(comp, C.claveDesdeFrase('la-que-no-es-che', sal)));

    let err = null;
    try {
      C.abrirClave({ modo: 'privada', frase: 'equivocada-del-todo',
        salBase64: sal.toString('base64'), comprobante: comp });
    } catch (e) { err = e; }
    comprobar('al abrir con la frase mal, falla con un mensaje claro',
      err && /no coincide/i.test(err.message), err ? err.message.slice(0, 80) : '');
    comprobar('el mensaje avisa que NADIE puede recuperarlos',
      err && /nadie/i.test(err.message) && /BackupPrime/.test(err.message),
      'el cliente tiene que entender que no hay a quién llamar');
  }

  // ═══ De extremo a extremo, contra el almacenamiento ═══
  const srv = crearServidorS3();
  const puerto = await srv.escuchar();
  const dest = {
    type: 's3', enabled: true, label: 'e2',
    endpoint: `http://127.0.0.1:${puerto}`, region: 'us-east-1',
    bucket: 'respaldos', prefix: 'cliente/', accessKey: 'AKIA', secretKey: 'secreta',
  };

  const origen = path.join(TEMP, 'origen');
  fs.mkdirSync(origen, { recursive: true });
  const SECRETO = 'CUIT 20-12345678-9 — Balance confidencial del estudio';
  const grande = path.join(origen, 'balance.dat');
  // Grande para que vaya por bloques, con el texto sensible adentro.
  const relleno = crypto.randomBytes(30 * 1048576);
  Buffer.from(SECRETO).copy(relleno, 1000);
  fs.writeFileSync(grande, relleno);

  const claveCuenta = C.claveNueva();
  const cfgBase = {
    server: '', token: '', localPaths: [origen], excludedPaths: [],
    destinations: [dest], maxVersions: 10, umbralBloquesMB: 25,
  };
  const limpiar = () => {
    try { fs.unlinkSync(path.join(process.env.BACKUPPRIME_CONFIG_DIR, 'state.json')); } catch {}
  };
  const correr = async (extra = {}) => {
    limpiar();
    const motor = new BackupEngine();
    const reg = [];
    motor.on('log', (l) => reg.push(String(l)));
    await motor.runOnce({ ...cfgBase, ...extra });
    return reg.join('\n');
  };

  titulo('Lo que llega al almacenamiento no se puede leer');
  {
    const reg = await correr({
      cifradoModo: 'gestionada', cifradoClave: claveCuenta.toString('base64'),
    });
    comprobar('el respaldo avisa que cifra', /se cifran antes de subirse/i.test(reg),
      reg.split('\n').find((l) => /cifra/i.test(l)) || '');

    const { archivos } = await s3Listar(dest);
    let apareceElSecreto = false;
    for (const a of archivos) {
      const datos = await s3BajarDatos(dest, a.clave);
      if (datos.includes(Buffer.from(SECRETO))) apareceElSecreto = true;
    }
    comprobar('el texto confidencial NO aparece en ningún objeto del bucket',
      !apareceElSecreto,
      'es la prueba que importa: quien acceda al almacenamiento no lee nada');

    // Y el índice tampoco, que lleva nombres y rutas de archivos.
    const indices = archivos.filter((a) => a.clave.endsWith('.bpi'));
    comprobar('hay índices guardados', indices.length > 0);
    let indiceLegible = false;
    for (const i of indices) {
      const d = await s3BajarDatos(dest, i.clave);
      if (d.includes(Buffer.from('balance.dat'))) indiceLegible = true;
    }
    comprobar('el índice tampoco es legible', !indiceLegible,
      'los nombres y rutas de los archivos ya son información sensible');
  }

  titulo('Y se restaura idéntico');
  {
    const destino = path.join(TEMP, 'restaurado.dat');
    await Bloques.restaurarPorBloques(almacenDeBloques(dest, claveCuenta), {
      rutaRelativa: rutaEnDestino(grande), destinoLocal: destino, prefijo: 'cliente/',
    });
    comprobar('el archivo restaurado es idéntico al original',
      crypto.createHash('sha256').update(fs.readFileSync(destino)).digest('hex') ===
      crypto.createHash('sha256').update(fs.readFileSync(grande)).digest('hex'));
  }

  titulo('Sin la clave no se puede restaurar');
  {
    let err = null;
    try {
      await Bloques.restaurarPorBloques(almacenDeBloques(dest, null), {
        rutaRelativa: rutaEnDestino(grande),
        destinoLocal: path.join(TEMP, 'no-deberia.dat'), prefijo: 'cliente/',
      });
    } catch (e) { err = e; }
    comprobar('falla al intentar sin clave', !!err, 'si funcionara, el cifrado no serviría');
    comprobar('no dejó ningún archivo a medias',
      !fs.existsSync(path.join(TEMP, 'no-deberia.dat')));
  }

  titulo('La deduplicación sigue funcionando con cifrado');
  {
    // Es el diferencial del producto: si el cifrado la rompiera, cada respaldo
    // subiría el archivo entero otra vez.
    const antes = (await s3Listar(dest)).archivos.length;

    // Se cambia un pedacito del archivo, como hace Outlook al llegar un mail.
    const fd = fs.openSync(grande, 'r+');
    fs.writeSync(fd, crypto.randomBytes(65536), 0, 65536, 5 * 1048576);
    fs.closeSync(fd);

    const reg = await correr({
      cifradoModo: 'gestionada', cifradoClave: claveCuenta.toString('base64'),
    });
    const despues = (await s3Listar(dest)).archivos.length;
    // El motor informa la reutilización de dos formas distintas según el
    // camino: "reutilizó N" al partir el archivo, o "Ya hay N bloque(s)
    // guardados" cuando los encuentra en el destino. Las dos significan que no
    // se volvió a subir.
    const linea = reg.split('\n').find((l) => /\[bloques\]/.test(l)) || '';
    const reutilizados = Number(
      (linea.match(/reutiliz\S* (\d+)/) || linea.match(/Ya hay (\d+) bloque/) || [])[1] || 0);

    comprobar('reutilizó bloques ya subidos', reutilizados > 0, linea.slice(0, 140));
    comprobar('solo se agregaron unos pocos objetos', despues - antes < 10,
      `pasó de ${antes} a ${despues} objetos`);
  }

  titulo('Modo privada: la frase no viaja, la clave se deriva en el equipo');
  {
    const sal = C.salNueva();
    const clavePrivada = C.claveDesdeFrase('la-frase-del-contador', sal);
    const dest2 = { ...dest, prefix: 'privada/' };

    await correr({
      destinations: [dest2],
      cifradoModo: 'privada', cifradoFrase: 'la-frase-del-contador',
      cifradoSal: sal.toString('base64'),
      cifradoComprobante: C.crearComprobante(clavePrivada),
    });

    const { archivos } = await s3Listar(dest2);
    comprobar('se subió algo', archivos.length > 0);
    let legible = false;
    for (const a of archivos) {
      const d = await s3BajarDatos(dest2, a.clave);
      if (d.includes(Buffer.from(SECRETO))) legible = true;
    }
    comprobar('tampoco es legible en el almacenamiento', !legible);

    // Con la clave gestionada de la otra cuenta NO se puede leer esto.
    let err = null;
    try {
      await Bloques.restaurarPorBloques(almacenDeBloques(dest2, claveCuenta), {
        rutaRelativa: rutaEnDestino(grande),
        destinoLocal: path.join(TEMP, 'cruzado.dat'), prefijo: 'privada/',
      });
    } catch (e) { err = e; }
    comprobar('la clave de otra cuenta no sirve', !!err,
      'cada cuenta tiene que estar aislada de las demás');
  }

  titulo('Una frase equivocada no arranca el respaldo');
  {
    const sal = C.salNueva();
    const buena = C.claveDesdeFrase('la-correcta-de-verdad', sal);
    const reg = await correr({
      cifradoModo: 'privada', cifradoFrase: 'esta-no-es-la-buena',
      cifradoSal: sal.toString('base64'),
      cifradoComprobante: C.crearComprobante(buena),
    });
    comprobar('el respaldo se detiene con un error claro',
      /no coincide/i.test(reg), reg.split('\n').slice(-3).join(' | ').slice(0, 160));
    comprobar('NO sube los archivos sin cifrar como alternativa',
      !/terminado/i.test(reg),
      'subir sin cifrar sería peor que fallar: el cliente creería que están protegidos');
  }

  titulo('Los respaldos hechos ANTES del cifrado se siguen restaurando');
  {
    // Sin esto, activar el cifrado dejaría ilegible todo lo anterior — que es
    // exactamente lo que no puede pasar en un producto de backup.
    const dest3 = { ...dest, prefix: 'viejo/' };
    await correr({ destinations: [dest3] });          // sin cifrado

    const destino = path.join(TEMP, 'viejo.dat');
    let err = null;
    try {
      // Se restaura con una cuenta que YA tiene clave: los datos viejos no
      // llevan la marca de cifrado y tienen que devolverse tal cual.
      await Bloques.restaurarPorBloques(almacenDeBloques(dest3, claveCuenta), {
        rutaRelativa: rutaEnDestino(grande), destinoLocal: destino, prefijo: 'viejo/',
      });
    } catch (e) { err = e; }
    comprobar('un respaldo sin cifrar se restaura aunque la cuenta ya tenga clave',
      !err && fs.existsSync(destino), err ? err.message.slice(0, 120) : '');
  }

  await srv.cerrar();
  try { fs.rmSync(TEMP, { recursive: true, force: true }); } catch {}

  console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
  if (falladas) { console.log('Fallaron:'); fallos.forEach((f) => console.log('  · ' + f)); }
  process.exit(falladas ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
