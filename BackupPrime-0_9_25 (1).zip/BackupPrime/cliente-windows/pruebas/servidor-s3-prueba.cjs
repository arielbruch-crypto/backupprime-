'use strict';
// Servidor compatible con S3, mínimo, para probar el cliente de BackupPrime:
// PUT de objeto, GET de objeto y ListObjectsV2 con paginación.
// Valida que la petición esté bien armada, que los datos vayan y vuelvan
// enteros, y —si se le pasan claves con `validarFirma`— que la firma SigV4 sea
// correcta. Esto último se agregó porque antes NO se validaba la firma, y por eso
// un error de firma pasaba todas las pruebas y aparecía recién contra el bucket
// real como un 403 SignatureDoesNotMatch imposible de rastrear.

const http = require('node:http');
const { verificarFirma } = require('./firma-sigv4.cjs');

function crearServidorS3({ host = '127.0.0.1', validarFirma = null } = {}) {
  const objetos = new Map();   // "bucket/clave" -> Buffer (la versión actual)
  const versiones = new Map(); // "bucket/clave" -> [{ id, dato, fecha }]
  const bucketsCreados = [];
  let contadorVersion = 0;
  const stats = { puts: 0, gets: 0, lists: 0, firmados: 0, firmasRechazadas: 0, ultimoRechazo: null };

  const xmlEscape = (t) => String(t)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');

  const servidor = http.createServer((req, res) => {
    const url = new URL(req.url, `http://${req.headers.host}`);
    const partes = url.pathname.replace(/^\//, '').split('/');
    const bucket = partes.shift();
    const clave = decodeURIComponent(partes.join('/'));

    if (req.headers.authorization && req.headers.authorization.startsWith('AWS4-HMAC-SHA256')) {
      stats.firmados++;
    }

    // ── Validación de firma ──
    // Solo para las peticiones sin cuerpo (listados, HEAD, GET de objeto). Las
    // que traen cuerpo se validan más abajo, cuando ya se leyó.
    if (validarFirma && !['PUT', 'POST'].includes(req.method)) {
      const r = verificarFirma(req, Buffer.alloc(0), { secretas: validarFirma });
      if (!r.ok) {
        stats.firmasRechazadas++;
        stats.ultimoRechazo = r;
        res.writeHead(403, { 'Content-Type': 'application/xml' });
        return res.end('<?xml version="1.0" encoding="UTF-8"?><Error><Code>' + r.codigo +
          '</Code><Message>' + xmlEscape(r.motivo) + '</Message></Error>');
      }
    }

    // ── Listar los buckets de la cuenta (GET /) ──
    if (req.method === 'GET' && !bucket) {
      const nombres = [...new Set([...objetos.keys()].map((k) => k.split('/')[0]))]
        .concat(bucketsCreados).filter((v, i, a) => a.indexOf(v) === i);
      res.writeHead(200, { 'Content-Type': 'application/xml' });
      return res.end('<?xml version="1.0" encoding="UTF-8"?><ListAllMyBucketsResult><Buckets>' +
        nombres.map((n) => `<Bucket><Name>${n}</Name></Bucket>`).join('') +
        '</Buckets></ListAllMyBucketsResult>');
    }

    // ── Crear un bucket (PUT /bucket) ──
    if (req.method === 'PUT' && bucket && !clave) {
      req.resume();
      if (bucketsCreados.includes(bucket)) {
        res.writeHead(409, { 'Content-Type': 'application/xml' });
        return res.end('<Error><Code>BucketAlreadyOwnedByYou</Code></Error>');
      }
      bucketsCreados.push(bucket);
      res.writeHead(200); return res.end();
    }

    // ── Listar versiones (GET /bucket?versions) ──
    //
    // Pagina de verdad, con key-marker y version-id-marker. Antes contestaba
    // siempre IsTruncated=false, así que el camino de paginación de
    // `s3Versiones` NUNCA se ejecutaba en ninguna prueba. Con más de 1000
    // objetos en el bucket real ese es justamente el camino que corre.
    if (req.method === 'GET' && !clave && url.searchParams.has('versions')) {
      stats.lists++;
      const prefijo = url.searchParams.get('prefix') || '';
      const maxKeys = Math.max(1, Number(url.searchParams.get('max-keys')) || 1000);
      const marcadorClave = url.searchParams.get('key-marker') || '';
      const marcadorVersion = url.searchParams.get('version-id-marker') || '';

      // Todas las versiones, ordenadas por clave y después por versión: es el
      // orden en el que S3 las devuelve y sobre el que operan los marcadores.
      const todas = [];
      for (const [k, lista] of versiones) {
        if (!k.startsWith(bucket + '/')) continue;
        const nombre = k.slice(bucket.length + 1);
        if (!nombre.startsWith(prefijo)) continue;
        lista.forEach((v, i) => {
          todas.push({ nombre, v, esUltima: i === lista.length - 1 });
        });
      }
      todas.sort((a, b) => (a.nombre < b.nombre ? -1 : a.nombre > b.nombre ? 1
        : String(a.v.id).localeCompare(String(b.v.id))));

      let desdeIdx = 0;
      if (marcadorClave) {
        desdeIdx = todas.findIndex((x) => x.nombre > marcadorClave ||
          (x.nombre === marcadorClave &&
           (!marcadorVersion || String(x.v.id) > marcadorVersion)));
        if (desdeIdx < 0) desdeIdx = todas.length;
      }
      const pagina = todas.slice(desdeIdx, desdeIdx + maxKeys);
      const truncado = desdeIdx + maxKeys < todas.length;
      const ultima = pagina[pagina.length - 1];

      const filas = pagina.map(({ nombre, v, esUltima }) =>
        `<Version><Key>${xmlEscape(nombre)}</Key>` +
        `<VersionId>${v.id}</VersionId>` +
        `<IsLatest>${esUltima}</IsLatest>` +
        `<LastModified>${v.fecha}</LastModified>` +
        `<Size>${v.dato.length}</Size></Version>`);

      res.writeHead(200, { 'Content-Type': 'application/xml' });
      return res.end('<?xml version="1.0" encoding="UTF-8"?>' +
        `<ListVersionsResult><Name>${bucket}</Name>` +
        `<IsTruncated>${truncado}</IsTruncated>` +
        (truncado && ultima
          ? `<NextKeyMarker>${xmlEscape(ultima.nombre)}</NextKeyMarker>` +
            `<NextVersionIdMarker>${ultima.v.id}</NextVersionIdMarker>`
          : '') +
        filas.join('') + '</ListVersionsResult>');
    }

    // ── ListObjectsV2 ──
    if (req.method === 'GET' && !clave && url.searchParams.get('list-type') === '2') {
      stats.lists++;
      // Destino que no se puede listar: red caída, credencial vencida, permiso
      // sacado. Importa poder probarlo porque el programa NO tiene que anotar
      // que verificó cuando esto pasa.
      if (api.rechazarListados) {
        res.writeHead(503, { 'Content-Type': 'application/xml' });
        return res.end('<?xml version="1.0"?><Error><Code>ServiceUnavailable</Code>' +
                       '<Message>No se pudo listar</Message></Error>');
      }
      const prefijo = url.searchParams.get('prefix') || '';
      const maxKeys = Number(url.searchParams.get('max-keys')) || 1000;
      const desde = url.searchParams.get('continuation-token') || '';

      const todas = [...objetos.keys()]
        .filter((k) => k.startsWith(bucket + '/'))
        .map((k) => k.slice(bucket.length + 1))
        .filter((k) => k.startsWith(prefijo))
        .sort();
      const arranque = desde ? todas.findIndex((k) => k > desde) : 0;
      const pagina = arranque < 0 ? [] : todas.slice(arranque, arranque + maxKeys);
      const truncado = arranque >= 0 && arranque + maxKeys < todas.length;

      const cuerpo =
        `<?xml version="1.0" encoding="UTF-8"?>` +
        `<ListBucketResult><Name>${bucket}</Name>` +
        `<IsTruncated>${truncado}</IsTruncated>` +
        (truncado ? `<NextContinuationToken>${xmlEscape(pagina[pagina.length - 1])}</NextContinuationToken>` : '') +
        pagina.map((k) =>
          `<Contents><Key>${xmlEscape(k)}</Key>` +
          `<Size>${objetos.get(bucket + '/' + k).length}</Size></Contents>`).join('') +
        `</ListBucketResult>`;
      res.writeHead(200, { 'Content-Type': 'application/xml' });
      return res.end(cuerpo);
    }

    // ── PUT de objeto ──
    if (req.method === 'PUT' && clave) {
      stats.puts++;
      const trozos = [];
      req.on('data', (c) => trozos.push(c));
      req.on('end', () => {
        const dato = Buffer.concat(trozos);
        const k = `${bucket}/${clave}`;
        objetos.set(k, dato);
        const id = 'v' + (++contadorVersion).toString().padStart(8, '0');
        if (!versiones.has(k)) versiones.set(k, []);
        versiones.get(k).push({ id, dato, fecha: new Date().toISOString() });
        res.writeHead(200, { 'x-amz-version-id': id }); res.end();
      });
      return;
    }

    // ── HEAD de objeto: ¿existe? ──
    if (req.method === 'HEAD' && clave) {
      // Simula los servicios que contestan 403 en vez de 404 para un objeto que
      // no existe: es lo que rompía la reutilización de bloques.
      if (api.responderMalAHead) { res.writeHead(403); return res.end(); }
      const dato = objetos.get(`${bucket}/${clave}`);
      if (!dato) { res.writeHead(404); return res.end(); }
      res.writeHead(200, { 'Content-Length': dato.length });
      return res.end();
    }

    // ── GET de objeto ──
    if (req.method === 'GET' && clave) {
      stats.gets++;
      const pedida = url.searchParams.get('versionId');
      let dato;
      if (pedida) {
        const lista = versiones.get(`${bucket}/${clave}`) || [];
        const v = lista.find((x) => x.id === pedida);
        dato = v && v.dato;
      } else {
        dato = objetos.get(`${bucket}/${clave}`);
      }
      if (!dato) { res.writeHead(404); return res.end('<Error><Code>NoSuchKey</Code></Error>'); }
      res.writeHead(200, { 'Content-Length': dato.length });
      return res.end(dato);
    }

    if (req.method === 'DELETE' && clave) {
      objetos.delete(`${bucket}/${clave}`);
      res.writeHead(204); return res.end();
    }

    res.writeHead(400); res.end('<Error><Code>BadRequest</Code></Error>');
  });

  const api = {
    objetos, versiones, stats, bucketsCreados,
    responderMalAHead: false,
    // Un destino que falla al listar. Es lo que pasa con la red caída o una
    // credencial vencida, y hay que poder probar que en ese caso el programa
    // NO anota que verificó: anotarlo sería registrar una tranquilidad que
    // nadie comprobó.
    rechazarListados: false,
    /** Las claves guardadas, para poder simular que el destino perdió una. */
    objetosGuardados: () => [...objetos.keys()].map((k) => k.split('/').slice(1).join('/')),
    /**
     * Borra un objeto por atrás, sin que el cliente se entere.
     *
     * Simula lo único que el registro local no puede detectar solo: que el
     * destino perdió un archivo que figura como subido. Es el caso que la
     * revalidación existe para encontrar.
     */
    borrarObjeto: (clave) => {
      for (const k of [...objetos.keys()]) {
        if (k === clave || k.split('/').slice(1).join('/') === clave) objetos.delete(k);
      }
    },
    escuchar: () => new Promise((r) => servidor.listen(0, host, () => r(servidor.address().port))),
    cerrar: () => new Promise((r) => servidor.close(r)),
  };

  return api;
}

module.exports = { crearServidorS3 };
