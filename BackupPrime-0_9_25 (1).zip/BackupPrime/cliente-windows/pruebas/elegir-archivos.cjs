'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Elegir un ARCHIVO suelto para respaldar, no solo carpetas.

   Cómo estaba: el selector listaba únicamente carpetas
   (`.filter(e => e.isDirectory())`), así que para respaldar un archivo suelto
   —el PST, una planilla, el certificado de AFIP— había que agregar la carpeta
   entera y después excluir todo lo demás a mano. Un contador que solo quiere su
   libro IVA no tiene por qué respaldar Documentos completo.

   Y había un segundo problema, peor: aunque se lograra poner un archivo como
   origen, `walkDir` da por sentado que recibe una carpeta. Con un archivo no
   devolvía nada, así que el archivo elegido **no se respaldaba y no había ningún
   aviso**. Un respaldo que dice "terminado" y no copió lo que el cliente eligió
   es el peor modo de falla que puede tener este producto.

     node pruebas/elegir-archivos.cjs
   ═══════════════════════════════════════════════════════════════════════════ */

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-elegir-'));
process.env.BACKUPPRIME_CONFIG_DIR = path.join(TEMP, 'config');
fs.mkdirSync(process.env.BACKUPPRIME_CONFIG_DIR, { recursive: true });

const { crearServidorS3 } = require('./servidor-s3-prueba.cjs');
const { BackupEngine, s3Listar, rutaEnDestino } = require('../electron/backup-engine.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — elegir archivos sueltos\n');

(async () => {
  const srv = crearServidorS3();
  const puerto = await srv.escuchar();
  const dest = {
    type: 's3', enabled: true, label: 'e2',
    endpoint: `http://127.0.0.1:${puerto}`, region: 'us-east-1',
    bucket: 'respaldos', prefix: 'cliente/', accessKey: 'AKIA', secretKey: 'secreta',
  };

  // Una carpeta Documentos con varias cosas. El cliente solo quiere UNA.
  const docs = path.join(TEMP, 'Documentos');
  fs.mkdirSync(docs, { recursive: true });
  const libroIva = path.join(docs, 'Libro IVA 2026.xlsx');
  fs.writeFileSync(libroIva, crypto.randomBytes(120 * 1024));
  fs.writeFileSync(path.join(docs, 'fotos-asado.jpg'), crypto.randomBytes(3 * 1024 * 1024));
  fs.writeFileSync(path.join(docs, 'apuntes.txt'), 'nada importante');
  fs.mkdirSync(path.join(docs, 'Subcarpeta'), { recursive: true });
  fs.writeFileSync(path.join(docs, 'Subcarpeta', 'otro.docx'), 'tampoco');

  const cfgBase = {
    server: '', token: '', excludedPaths: [],
    destinations: [dest], maxVersions: 10, systemBackup: false, forceFullBackup: false,
    concurrencia: 2, umbralBloquesMB: 25,
  };
  const limpiar = () => {
    try { fs.unlinkSync(path.join(process.env.BACKUPPRIME_CONFIG_DIR, 'state.json')); } catch {}
  };

  titulo('Un solo archivo como origen');
  limpiar();
  {
    const motor = new BackupEngine();
    const registro = [];
    motor.on('log', (l) => registro.push(String(l)));
    await motor.runOnce({ ...cfgBase, localPaths: [libroIva] });

    const { archivos } = await s3Listar(dest);
    const claves = archivos.map((a) => a.clave);

    comprobar('el archivo elegido se respaldó', archivos.length >= 1,
      `se subieron ${archivos.length} — antes no se subía nada y no había aviso`);
    comprobar('es el archivo correcto',
      claves.some((c) => c.includes('Libro IVA 2026.xlsx')),
      JSON.stringify(claves));
    comprobar('NO se respaldó el resto de la carpeta',
      !claves.some((c) => /fotos-asado|apuntes|otro\.docx/.test(c)),
      JSON.stringify(claves));
    comprobar('sin errores', !registro.some((l) => l.includes('[error]')),
      registro.filter((l) => l.includes('[error]'))[0] || '');
  }

  titulo('Varios archivos sueltos, de carpetas distintas');
  limpiar();
  {
    const otra = path.join(TEMP, 'Certificados');
    fs.mkdirSync(otra, { recursive: true });
    const cert = path.join(otra, 'afip.pfx');
    fs.writeFileSync(cert, crypto.randomBytes(8 * 1024));

    const motor = new BackupEngine();
    motor.on('log', () => {});
    await motor.runOnce({ ...cfgBase, localPaths: [libroIva, cert] });

    const { archivos } = await s3Listar(dest);
    const claves = archivos.map((a) => a.clave);
    comprobar('se respaldaron los dos',
      claves.some((c) => c.includes('Libro IVA')) && claves.some((c) => c.includes('afip.pfx')),
      JSON.stringify(claves));
  }

  titulo('Mezclar un archivo y una carpeta');
  limpiar();
  {
    const sola = path.join(TEMP, 'Balances');
    fs.mkdirSync(sola, { recursive: true });
    fs.writeFileSync(path.join(sola, 'balance-2025.xlsx'), 'x');
    fs.writeFileSync(path.join(sola, 'balance-2026.xlsx'), 'y');

    const motor = new BackupEngine();
    motor.on('log', () => {});
    await motor.runOnce({ ...cfgBase, localPaths: [libroIva, sola] });

    const { archivos } = await s3Listar(dest);
    const claves = archivos.map((a) => a.clave);
    comprobar('entra el archivo suelto', claves.some((c) => c.includes('Libro IVA')));
    comprobar('y toda la carpeta',
      claves.some((c) => c.includes('balance-2025')) && claves.some((c) => c.includes('balance-2026')),
      JSON.stringify(claves));
  }

  titulo('Un archivo excluido se saltea con aviso, no en silencio');
  limpiar();
  {
    const motor = new BackupEngine();
    const registro = [];
    motor.on('log', (l) => registro.push(String(l)));
    await motor.runOnce({ ...cfgBase, localPaths: [libroIva], excludedPaths: ['Libro IVA'] });

    comprobar('avisa que lo salteó por una exclusión',
      registro.some((l) => /exclusiones/i.test(l)),
      registro.join(' | ').slice(0, 160));
  }

  titulo('Un archivo que ya no existe avisa');
  limpiar();
  {
    const motor = new BackupEngine();
    const registro = [];
    motor.on('log', (l) => registro.push(String(l)));
    await motor.runOnce({ ...cfgBase, localPaths: [path.join(TEMP, 'no-existe.xlsx')] });
    comprobar('no se cae y deja constancia',
      registro.some((l) => /No se encontró/i.test(l)),
      registro.join(' | ').slice(0, 140));
  }

  titulo('El selector de la pantalla lista archivos, no solo carpetas');
  {
    const main = fs.readFileSync(
      path.join(__dirname, '..', 'electron', 'main.cjs'), 'utf8');
    const bloque = main.slice(main.indexOf('ipcMain.handle("fs:list-dir"'),
                              main.indexOf('ipcMain.handle("fs:system-drives"'));
    comprobar('fs:list-dir devuelve también los archivos',
      /files\.push\(/.test(bloque) && /files,/.test(bloque),
      'antes filtraba con isDirectory() y descartaba todo lo demás');
    comprobar('informa el tamaño de cada archivo', /size/.test(bloque),
      'para que el cliente vea cuánto pesa antes de elegirlo');

    const html = fs.readFileSync(
      path.join(__dirname, '..', 'electron', 'renderer.html'), 'utf8');
    comprobar('la pantalla dibuja las filas de archivo', html.includes('data-archivo="1"'));
    comprobar('el archivo se marca al hacer clic en el nombre',
      /row\.dataset\.archivo/.test(html),
      'en un archivo no hay dónde entrar: el clic tiene que marcarlo');
  }

  await srv.cerrar();
  try { fs.rmSync(TEMP, { recursive: true, force: true }); } catch {}

  console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
  if (falladas) { console.log('Fallaron:'); fallos.forEach((f) => console.log('  · ' + f)); }
  process.exit(falladas ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
