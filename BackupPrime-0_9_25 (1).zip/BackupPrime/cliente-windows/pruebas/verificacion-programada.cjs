'use strict';
/* Verificación programada y revalidación rotativa.

   Por qué existe esto:

   Saltear un archivo sin tocar la red es rápido y es lo correcto, pero deja a
   `state.json` como ÚNICA verdad sobre lo que hay en el destino. Si el destino
   perdió un objeto, el cliente no se entera nunca: cada corrida dice "sin
   cambios" y el archivo no está. Un respaldo que parece estar y no está es peor
   que no tener respaldo, porque el cliente no toma ninguna otra precaución.

   Dos redes, y son distintas:
     · la VERIFICACIÓN PROGRAMADA revisa todo, cada `verificacionCadaDias`;
     · la REVALIDACIÓN ROTATIVA revisa en cada corrida la tajada que hace más de
       `revalidarMaxDias` que nadie mira. Existe porque la programada depende de
       que la máquina esté prendida ese día, y en un estudio contable el domingo
       está apagada.

     node pruebas/verificacion-programada.cjs                                 */

const fs = require('node:fs');
const fsp = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-verif-'));
process.env.BACKUPPRIME_CONFIG_DIR = path.join(TEMP, 'config');
fs.mkdirSync(process.env.BACKUPPRIME_CONFIG_DIR, { recursive: true });

const { crearServidorS3 } = require('./servidor-s3-prueba.cjs');
const { BackupEngine } = require('../electron/backup-engine.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);
const DIAS = 86400000;

const rutaEstado = () => path.join(process.env.BACKUPPRIME_CONFIG_DIR, 'state.json');
const leerEstado = () => JSON.parse(fs.readFileSync(rutaEstado(), 'utf8'));
const escribirEstado = (d) => fs.writeFileSync(rutaEstado(), JSON.stringify(d));

/** Envejece el registro: como si hubieran pasado N días desde todo. */
function envejecer(dias) {
  const d = leerEstado();
  for (const [k, v] of Object.entries(d)) {
    if (k === '__ultimoRespaldo' || k === '__ultimaVerificacion') {
      d[k] = Number(v) - dias * DIAS;
    } else if (v && typeof v === 'object' && v.verificadoEn) {
      v.verificadoEn = Number(v.verificadoEn) - dias * DIAS;
    }
  }
  escribirEstado(d);
}

/**
 * Envejece SOLO los archivos, dejando la fecha de la verificación completa
 * donde está. Es la única forma de probar la rotativa de verdad: si se envejece
 * todo, salta la programada y la prueba estaría midiendo el otro camino —
 * verde, y sin haber ejecutado una línea de lo que dice probar.
 */
function envejecerSoloArchivos(dias) {
  const d = leerEstado();
  for (const [k, v] of Object.entries(d)) {
    if (k.startsWith('__')) continue;
    if (v && typeof v === 'object' && v.verificadoEn) {
      v.verificadoEn = Number(v.verificadoEn) - dias * DIAS;
    }
  }
  escribirEstado(d);
}

console.log('BackupPrime — verificación programada y rotativa\n');

(async () => {
  const srv = crearServidorS3();
  const puerto = await srv.escuchar();
  const prefijo = 'cliente/';
  const dest = {
    type: 's3', endpoint: `http://127.0.0.1:${puerto}`, region: 'us-east-1',
    bucket: 'respaldos', prefix: prefijo, accessKey: 'AKIA', secretKey: 'secreta',
    label: 'e2',
  };

  const origen = path.join(TEMP, 'origen', 'Documentos');
  await fsp.mkdir(origen, { recursive: true });
  const nombres = [];
  for (let i = 0; i < 6; i++) {
    const n = `Balance-${i}.xlsx`;
    await fsp.writeFile(path.join(origen, n), crypto.randomBytes(120 * 1024));
    nombres.push(n);
  }

  const cfg = {
    server: '', token: '', localPaths: [path.join(TEMP, 'origen')], excludedPaths: [],
    destinations: [dest], maxVersions: 10, systemBackup: false, forceFullBackup: false,
    umbralBloquesMB: 25, verificacionCadaDias: 7, revalidarMaxDias: 14,
  };

  const motor = new BackupEngine();
  const registro = [];
  let ultimoDone = null;
  motor.on('log', (l) => registro.push(l.trim()));
  motor.on('done', (d) => { ultimoDone = d; });

  titulo('Primer respaldo');
  await motor.runOnce(cfg);
  comprobar('Sin errores', !registro.some((l) => l.includes('[error]')),
    registro.filter((l) => l.includes('[error]'))[0] || '');

  const est1 = leerEstado();
  const archivo0 = path.join(origen, nombres[0]);
  comprobar('Cada archivo subido queda anotado con su fecha de comprobación',
    nombres.every((n) => Number(est1[path.join(origen, n)].verificadoEn) > 0),
    'sin esta marca la rotativa elegiría siempre los mismos archivos');

  titulo('Al otro día, sin que pase nada, no se revisa nada');

  const antes = { ...srv.stats };
  registro.length = 0;
  await motor.runOnce(cfg);
  comprobar('No hay listados de más: la revalidación no es todos los días',
    srv.stats.lists === antes.lists, `${srv.stats.lists - antes.lists} listado(s)`);
  comprobar('Y el resumen dice que esta corrida no verificó',
    ultimoDone.verificacion.modo === 'ninguna', ultimoDone.verificacion.modo);

  titulo('Pasan 10 días: la rotativa NO, pero la programada sí (son 7)');

  envejecer(10);
  registro.length = 0;
  const antes2 = { ...srv.stats };
  await motor.runOnce(cfg);

  comprobar('Se revisó contra el destino',
    srv.stats.lists > antes2.lists);
  comprobar('El registro dice cuántos días pasaron',
    registro.some((l) => l.includes('[verificar]') && l.includes('días')),
    registro.filter((l) => l.includes('[verificar]')).join(' | ').slice(0, 160) || '(nada)');
  comprobar('Como estaba todo, no resubió nada',
    (ultimoDone.faltantesVerificados || 0) === 0);
  comprobar('Y no gastó cuota subiendo archivos que ya estaban',
    srv.stats.puts === antes2.puts, `${srv.stats.puts - antes2.puts} objetos subidos`);

  const est2 = leerEstado();
  comprobar('La marca de comprobación se renovó en los archivos revisados',
    Date.now() - Number(est2[archivo0].verificadoEn) < 60000,
    'si no se renueva, cada corrida revisa lo mismo y el resto nunca');

  titulo('Falta un archivo en el destino: la rotativa tiene que encontrarlo');

  // Se borra del destino por atrás, como si el proveedor lo hubiera perdido.
  // El registro local sigue diciendo que está: eso es lo que hace grave el caso.
  const claveBorrada = [...srv.objetosGuardados()]
    .find((k) => k.endsWith(`${nombres[1]}`));
  srv.borrarObjeto(claveBorrada);

  // Solo los archivos envejecen: la verificación completa sigue siendo reciente,
  // así que lo que corre acá es la rotativa y nada más.
  envejecerSoloArchivos(15);
  registro.length = 0;
  const antes3 = { ...srv.stats };
  await motor.runOnce(cfg);

  comprobar('Es la rotativa la que corre, no la programada',
    ultimoDone.verificacion.modo === 'rotativa', ultimoDone.verificacion.modo);
  comprobar('Lo detecta y lo dice por su nombre',
    registro.some((l) => l.includes('[verificar]') && l.includes(nombres[1])),
    registro.filter((l) => l.includes('[verificar]')).join(' | ').slice(0, 200) || '(nada)');
  comprobar('Y lo vuelve a subir',
    srv.stats.puts > antes3.puts && ultimoDone.faltantesVerificados >= 1,
    `faltantes: ${ultimoDone.faltantesVerificados}`);
  comprobar('Sube SOLO el que faltaba, no los seis',
    srv.stats.puts - antes3.puts <= 2, `${srv.stats.puts - antes3.puts} objetos`);

  titulo('La verificación programada: pasa una semana y revisa todo');

  envejecer(8);
  registro.length = 0;
  await motor.runOnce(cfg);

  comprobar('Arranca sola, sin que nadie apriete nada',
    ultimoDone.verificacion.modo === 'programada', ultimoDone.verificacion.modo);
  comprobar('Dice cuántos días pasaron desde la anterior',
    registro.some((l) => l.includes('[verificar]') && l.includes('días')),
    registro.filter((l) => l.includes('[verificar]'))[0] || '(nada)');
  comprobar('Revisa TODOS los archivos, no una tajada',
    ultimoDone.verificacion.revisados >= 6, `${ultimoDone.verificacion.revisados} revisados`);
  comprobar('Y queda anotada la fecha, para saber cuándo toca la próxima',
    Number(leerEstado().__ultimaVerificacion) > 0);

  titulo('Lo que se le muestra al cliente');

  comprobar('Se informa la fecha de la última verificación',
    Number(ultimoDone.verificacion.ultima) > 0);
  comprobar('Y cuánto hace que no se revisa el archivo más olvidado',
    ultimoDone.verificacion.diasSinVerificarElPeor === 0,
    `dice ${ultimoDone.verificacion.diasSinVerificarElPeor}`);
  comprobar('Se informa cuándo toca la próxima programada',
    Number(ultimoDone.verificacion.proximaProgramada) > Date.now());

  titulo('Un archivo BORRADO no puede dejar la pantalla en ámbar para siempre');

  // Este es el caso real que se vio en producción con 165.600 archivos.
  //
  // `state.json` guarda también archivos que YA NO EXISTEN: borrados,
  // renombrados, o sacados de la selección. Esos nunca se procesan en una
  // corrida, así que nunca reciben la marca de comprobado. Calcular "el archivo
  // más olvidado" recorriendo el registro entero hacía que SIEMPRE hubiera
  // alguno sin marca, y la franja quedaba avisando "todavía hay archivos sin
  // comprobar" para siempre — incluso recién terminada una verificación
  // completa que había revisado todo. Un aviso que no se puede apagar deja de
  // leerse, y el día que avise algo de verdad tampoco lo van a leer.
  // Se reproduce el caso EXACTO: el archivo ya no existe Y su entrada no tiene
  // la marca de comprobado, como pasa al venir de una versión anterior donde
  // esa marca no existía. Borrar un archivo que YA estaba marcado no reproduce
  // nada: la entrada conserva su fecha y el cálculo viejo daba un número igual.
  await fsp.unlink(path.join(origen, nombres[3]));
  {
    const d = leerEstado();
    delete d[path.join(origen, nombres[3])].verificadoEn;
    escribirEstado(d);
  }
  registro.length = 0;
  await motor.runOnce(cfg);

  comprobar('Después de borrar un archivo, la verificación sigue dando un número',
    ultimoDone.verificacion.diasSinVerificarElPeor !== null,
    'con null la pantalla avisa "sin comprobar" y no se apaga nunca');
  comprobar('Y ese número es reciente',
    ultimoDone.verificacion.diasSinVerificarElPeor === 0,
    `dice ${ultimoDone.verificacion.diasSinVerificarElPeor}`);
  comprobar('No quedan archivos de esta corrida sin comprobar',
    ultimoDone.verificacion.sinComprobar === 0,
    `${ultimoDone.verificacion.sinComprobar} sin comprobar`);
  comprobar('El registro todavía tiene la entrada del archivo borrado',
    !!leerEstado()[path.join(origen, nombres[3])],
    'la entrada vieja tiene que seguir ahí: lo que cambia es que ya no se cuenta');

  titulo('Si el destino no se puede leer, NO se anota como verificado');

  envejecer(8);
  const ultimaAntes = Number(leerEstado().__ultimaVerificacion);
  srv.rechazarListados = true;
  registro.length = 0;
  await motor.runOnce(cfg);
  srv.rechazarListados = false;

  comprobar('Avisa que no verificó nada',
    registro.some((l) => l.includes('NO se verificó')),
    registro.filter((l) => l.includes('[aviso]')).join(' | ').slice(0, 160) || '(nada)');
  comprobar('Y no mueve la fecha de la última verificación',
    Number(leerEstado().__ultimaVerificacion) === ultimaAntes,
    'moverla haría que la próxima recién sea en una semana, sin haber comprobado nada');

  await srv.cerrar();
  fs.rmSync(TEMP, { recursive: true, force: true });

  console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
  if (falladas) { console.log(fallos.map((f) => ` · ${f}`).join('\n')); process.exit(1); }
})().catch((e) => { console.error(e); process.exit(1); });
