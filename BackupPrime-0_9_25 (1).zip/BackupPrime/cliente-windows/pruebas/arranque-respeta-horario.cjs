'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Abrir el programa NO dispara un respaldo si no corresponde.

   El error: `start()` corría un respaldo inmediato siempre. Con el programa
   configurado para respaldar cada 12 horas, abrir la ventana disparaba uno igual
   —el horario configurado no se respetaba y el usuario perdía el control sobre
   cuándo se usa su conexión—. En una notebook con datos móviles eso es caro de
   verdad.

   Pero tampoco se puede esperar sin más: si la máquina estuvo apagada tres días,
   el momento programado ya pasó y esperar al siguiente dejaría al cliente sin
   respaldo por más tiempo del que él eligió.

   La regla que se prueba acá: se respalda al arrancar solo si YA CORRESPONDÍA.

     node pruebas/arranque-respeta-horario.cjs
   ═══════════════════════════════════════════════════════════════════════════ */

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-horario-'));
process.env.BACKUPPRIME_CONFIG_DIR = path.join(TEMP, 'config');
fs.mkdirSync(process.env.BACKUPPRIME_CONFIG_DIR, { recursive: true });

const { crearServidorS3 } = require('./servidor-s3-prueba.cjs');
const { BackupEngine } = require('../electron/backup-engine.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);
const esperar = (ms) => new Promise((r) => setTimeout(r, ms));

console.log('BackupPrime — abrir el programa respeta el horario\n');

const ESTADO = path.join(process.env.BACKUPPRIME_CONFIG_DIR, 'state.json');

/** Escribe el registro como si el último respaldo hubiera sido hace tanto. */
function ultimoRespaldoHace(ms, conArchivos = true) {
  const datos = { __ultimoRespaldo: Date.now() - ms };
  if (conArchivos) {
    datos['C:\\Users\\usuario\\algo.txt'] = { size: 10, mtimeMs: 1, hash: 'abc' };
  }
  fs.writeFileSync(ESTADO, JSON.stringify(datos));
}

(async () => {
  const srv = crearServidorS3();
  const puerto = await srv.escuchar();

  const origen = path.join(TEMP, 'origen');
  fs.mkdirSync(origen, { recursive: true });
  fs.writeFileSync(path.join(origen, 'a.txt'), 'hola');

  const cfgBase = {
    server: '', token: '',
    localPaths: [origen], excludedPaths: [],
    destinations: [{
      type: 's3', enabled: true, label: 'e2',
      endpoint: `http://127.0.0.1:${puerto}`, region: 'us-east-1',
      bucket: 'respaldos', prefix: 'cliente/', accessKey: 'AKIA', secretKey: 'secreta',
    }],
    maxVersions: 10, systemBackup: false, forceFullBackup: false,
  };

  /** Arranca el motor y devuelve si empezó a respaldar, más el registro. */
  async function arrancar(schedule) {
    const motor = new BackupEngine();
    const registro = [];
    // Sondear `estaRespaldando` no sirve: con pocos archivos el respaldo termina
    // en milisegundos y para cuando se mira ya volvió a false. Se detecta por
    // evento, que es lo que de verdad indica si arrancó.
    let arranco = false;
    motor.on('log', (l) => registro.push(String(l)));
    motor.on('progreso', () => { arranco = true; });
    motor.on('done', () => { arranco = true; });
    motor.start({ ...cfgBase, schedule });
    await esperar(500);
    motor.stop();
    await esperar(400);
    return { corrio: arranco, registro: registro.join('\n') };
  }

  titulo('Sin respaldos previos: se respalda al arrancar');
  {
    try { fs.unlinkSync(ESTADO); } catch {}
    const { corrio, registro } = await arrancar({ mode: 'interval', intervalMins: 720 });
    comprobar('el primer respaldo del equipo empieza enseguida', corrio === true,
      'un equipo recién instalado no puede quedarse 12 horas sin respaldo');
    comprobar('el registro explica por qué', /primer respaldo/i.test(registro),
      registro.split('\n')[0]);
  }

  titulo('Respaldo reciente: NO se respalda al abrir el programa');
  {
    // Configurado cada 12 horas, y el último fue hace 10 minutos.
    ultimoRespaldoHace(10 * 60 * 1000);
    const { corrio, registro } = await arrancar({ mode: 'interval', intervalMins: 720 });
    comprobar('abrir el programa no dispara un respaldo', corrio === false,
      'este era el error: se respaldaba siempre al abrir, ignorando el horario');
    comprobar('el registro dice que se espera al horario',
      /espera al horario|al día/i.test(registro), registro.split('\n')[0]);
  }

  titulo('Máquina apagada varios días: se pone al día');
  {
    ultimoRespaldoHace(3 * 24 * 60 * 60 * 1000);
    const { corrio, registro } = await arrancar({ mode: 'interval', intervalMins: 720 });
    comprobar('se respalda al arrancar porque ya correspondía', corrio === true);
    comprobar('el registro dice cuánto pasó', /d[íi]as?/.test(registro),
      registro.split('\n')[0]);
  }

  titulo('Justo en el límite del intervalo');
  {
    ultimoRespaldoHace(61 * 60 * 1000);   // 61 min, con intervalo de 60
    const { corrio } = await arrancar({ mode: 'interval', intervalMins: 60 });
    comprobar('pasado el intervalo, se respalda', corrio === true);

    ultimoRespaldoHace(59 * 60 * 1000);   // 59 min
    const { corrio: c2 } = await arrancar({ mode: 'interval', intervalMins: 60 });
    comprobar('antes del intervalo, no', c2 === false);
  }

  titulo('Modo días y hora');
  {
    const ahora = new Date();
    const todosLosDias = [0, 1, 2, 3, 4, 5, 6];

    // La hora de hoy ya pasó y no se respaldó desde entonces.
    const haceDosHoras = new Date(ahora.getTime() - 2 * 3600 * 1000);
    ultimoRespaldoHace(26 * 3600 * 1000);
    const { corrio } = await arrancar({
      mode: 'cron', days: todosLosDias,
      hour: haceDosHoras.getHours(), minute: haceDosHoras.getMinutes(),
    });
    comprobar('si el horario de hoy ya pasó y no se respaldó, se pone al día',
      corrio === true);

    // La hora de hoy ya pasó pero YA se respaldó después.
    ultimoRespaldoHace(30 * 60 * 1000);
    const { corrio: c2 } = await arrancar({
      mode: 'cron', days: todosLosDias,
      hour: haceDosHoras.getHours(), minute: haceDosHoras.getMinutes(),
    });
    comprobar('si ya se respaldó después del horario, se espera al próximo',
      c2 === false);

    // La hora de hoy todavía no llegó.
    const enDosHoras = new Date(ahora.getTime() + 2 * 3600 * 1000);
    ultimoRespaldoHace(30 * 60 * 1000);
    const { corrio: c3 } = await arrancar({
      mode: 'cron', days: todosLosDias,
      hour: enDosHoras.getHours(), minute: enDosHoras.getMinutes(),
    });
    comprobar('si el horario todavía no llegó, no se respalda', c3 === false);
  }

  titulo('Un respaldo interrumpido no cuenta como hecho');
  {
    // Es importante: si contara, al volver a abrir el programa se esperaría al
    // próximo horario y el cliente quedaría sin respaldo justo después de una
    // corrida que no llegó a completarse.
    const motorSrc = fs.readFileSync(
      path.join(__dirname, '..', 'electron', 'backup-engine.cjs'), 'utf8');
    comprobar('solo se anota la fecha si el respaldo terminó',
      /if \(!this\._cancelado\) state\.set\("__ultimoRespaldo"/.test(motorSrc));
  }

  titulo('La fecha del último respaldo no rompe el incremental');
  {
    // `hasState()` decide si se puede hacer incremental contando las claves del
    // registro. Sin excluir las claves internas, un equipo que nunca respaldó
    // nada parecería tener estado y el primer respaldo no subiría nada.
    fs.writeFileSync(ESTADO, JSON.stringify({ __ultimoRespaldo: Date.now() }));
    const motor = new BackupEngine();
    const registro = [];
    motor.on('log', (l) => registro.push(String(l)));
    await motor.runOnce({ ...cfgBase, schedule: { mode: 'interval', intervalMins: 60 } });
    comprobar('con solo la fecha guardada, el respaldo sigue siendo completo',
      /completo/i.test(registro.join('\n')),
      registro.filter((l) => /respaldo/i.test(l))[0] || '');
  }

  await srv.cerrar();
  try { fs.rmSync(TEMP, { recursive: true, force: true }); } catch {}

  console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
  if (falladas) { console.log('Fallaron:'); fallos.forEach((f) => console.log('  · ' + f)); }
  process.exit(falladas ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
