'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Un archivo grande se abre UNA sola vez en todo el respaldo.

   Esta prueba existe por el EBUSY del PST, que se arrastró varias versiones.

   La secuencia real era:
     1) el motor llamaba a `hashFile`, que abría el archivo y lo leía completo
        —651 MB— solo para calcular la huella;
     2) después `subirPorBloques` lo abría OTRA VEZ para recorrerlo y cortarlo.

   Dos aperturas de un archivo que Outlook tiene tomado. Y la primera, la que
   revienta, era justo la única sin reintentos.

   Un arreglo anterior le sacó una lectura a `bloques.cjs` reutilizando la huella
   del motor, y quedó ahí: seguían siendo dos aperturas, y la que fallaba seguía
   en pie. Por eso el error "volvía".

   Ahora `recorrerBloques` calcula la huella en su única pasada y el motor no lee
   el archivo. Esta prueba cuenta las aperturas: si alguien vuelve a agregar una
   lectura previa, falla acá y no contra el bucket del cliente.

     node pruebas/una-sola-lectura.cjs
   ═══════════════════════════════════════════════════════════════════════════ */

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-1lect-'));
process.env.BACKUPPRIME_CONFIG_DIR = path.join(TEMP, 'config');
fs.mkdirSync(process.env.BACKUPPRIME_CONFIG_DIR, { recursive: true });

const { crearServidorS3 } = require('./servidor-s3-prueba.cjs');
const { BackupEngine, s3Listar } = require('../electron/backup-engine.cjs');
const Bloques = require('../electron/bloques.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — un archivo grande se lee una sola vez\n');

/** Cuenta cuántas veces se abre cada ruta durante una operación. */
function contandoAperturas(fn) {
  const original = fs.createReadStream;
  const cuenta = new Map();
  fs.createReadStream = function (ruta, ...resto) {
    const k = String(ruta);
    cuenta.set(k, (cuenta.get(k) || 0) + 1);
    return original.call(fs, ruta, ...resto);
  };
  return Promise.resolve()
    .then(fn)
    .finally(() => { fs.createReadStream = original; })
    .then((r) => ({ resultado: r, cuenta }));
}

(async () => {
  const srv = crearServidorS3();
  const puerto = await srv.escuchar();
  const dest = {
    type: 's3', enabled: true, label: 'e2',
    endpoint: `http://127.0.0.1:${puerto}`, region: 'us-east-1',
    bucket: 'respaldos', prefix: 'cliente/', accessKey: 'AKIA', secretKey: 'secreta',
  };

  // Un archivo "PST": grande para el umbral y con contenido poco compresible.
  const origen = path.join(TEMP, 'origen');
  fs.mkdirSync(origen, { recursive: true });
  const pst = path.join(origen, 'correo.pst');
  // ── Datos DETERMINISTAS, no al azar ──
  //
  // Con `crypto.randomBytes` el contenido cambiaba en cada corrida, y como los
  // cortes por contenido dependen del contenido, los bloques caían en lugares
  // distintos cada vez. El control de deduplicación de más abajo pasaba casi
  // siempre y fallaba solo una de cada tantas corridas — que es la peor clase
  // de prueba: enseña a ignorar los resultados en rojo.
  //
  // Con una semilla fija, esta prueba da lo mismo hoy y dentro de un año.
  const pseudoAzar = (semilla, largo) => {
    const salida = Buffer.alloc(largo);
    let x = semilla >>> 0;
    for (let i = 0; i < largo; i++) {
      x ^= x << 13; x >>>= 0;
      x ^= x >>> 17;
      x ^= x << 5; x >>>= 0;
      salida[i] = x & 0xff;
    }
    return salida;
  };
  {
    const fd = fs.openSync(pst, 'w');
    // Cada mega distinto del anterior: si fueran 40 copias del mismo bloque, la
    // deduplicación reutilizaría todo por casualidad y el control no probaría
    // nada.
    for (let i = 0; i < 40; i++) fs.writeSync(fd, pseudoAzar(0x9e3779b9 + i, 1048576));
    fs.closeSync(fd);
  }
  const chico = path.join(origen, 'Balance.xlsx');
  fs.writeFileSync(chico, crypto.randomBytes(300 * 1024));

  const cfg = {
    server: '', token: '',
    localPaths: [origen], excludedPaths: [],
    destinations: [dest],
    maxVersions: 10, systemBackup: false, forceFullBackup: false,
    concurrencia: 2, umbralBloquesMB: 25,
  };
  const limpiarEstado = () => {
    try { fs.unlinkSync(path.join(process.env.BACKUPPRIME_CONFIG_DIR, 'state.json')); } catch {}
  };

  titulo('Primer respaldo: el archivo grande se abre una vez');
  limpiarEstado();
  {
    const motor = new BackupEngine();
    const registro = [];
    motor.on('log', (l) => registro.push(String(l)));
    const { cuenta } = await contandoAperturas(() => motor.runOnce(cfg));

    const aperturasPst = cuenta.get(pst) || 0;
    comprobar('el archivo grande se abrió exactamente una vez', aperturasPst === 1,
      `se abrió ${aperturasPst} vez/veces — con Outlook tomando el archivo, cada ` +
      `apertura de más es una chance de EBUSY`);

    comprobar('no hubo errores', !registro.some((l) => l.includes('[error]')),
      registro.filter((l) => l.includes('[error]'))[0] || '');
    comprobar('el archivo se guardó por bloques',
      registro.some((l) => l.includes('[bloques]') && l.includes('correo.pst')),
      registro.filter((l) => l.includes('[bloques]')).join(' | ').slice(0, 160));
  }

  titulo('El archivo chico sí se lee para calcular su huella');
  {
    // No va por bloques, así que la huella se calcula leyéndolo. Una vez.
    limpiarEstado();
    const motor = new BackupEngine();
    motor.on('log', () => {});
    const { cuenta } = await contandoAperturas(() => motor.runOnce(cfg));
    const n = cuenta.get(chico) || 0;
    comprobar('el archivo chico se abre una vez para la huella y otra para subir',
      n >= 1 && n <= 2, `se abrió ${n} veces`);
  }

  titulo('El índice conserva la huella del archivo completo');
  {
    const { archivos } = await s3Listar({ ...dest, prefix: 'cliente/indices/' });
    const bpi = archivos.find((a) => a.clave.endsWith('.bpi'));
    comprobar('se guardó el índice', !!bpi, JSON.stringify(archivos.map((a) => a.clave)));

    if (bpi) {
      const { s3BajarDatos } = require('../electron/backup-engine.cjs');
      const datos = await s3BajarDatos(dest, bpi.clave);
      const indice = JSON.parse(datos.toString('utf8'));
      const esperada = crypto.createHash('sha256')
        .update(fs.readFileSync(pst)).digest('hex');
      // En el índice el campo se llama `huella`, no `huellaTotal`.
      comprobar('la huella del índice es la del archivo real',
        indice.huella === esperada,
        `índice: ${String(indice.huella).slice(0, 16)}… · real: ${esperada.slice(0, 16)}…`);
      comprobar('el índice lista todos los bloques',
        Array.isArray(indice.bloques) && indice.bloques.length > 0,
        `bloques: ${indice.bloques && indice.bloques.length}`);
    }
  }

  titulo('Restaurar rearma el archivo idéntico');
  {
    const destino = path.join(TEMP, 'restaurado.pst');
    await Bloques.restaurarPorBloques(
      require('../electron/backup-engine.cjs').almacenDeBloques(dest),
      { rutaRelativa: require('../electron/backup-engine.cjs').rutaEnDestino(pst),
        destinoLocal: destino, prefijo: 'cliente/' });
    const a = crypto.createHash('sha256').update(fs.readFileSync(pst)).digest('hex');
    const b = crypto.createHash('sha256').update(fs.readFileSync(destino)).digest('hex');
    comprobar('el archivo restaurado es idéntico al original', a === b,
      'de nada sirve leer una sola vez si lo que se guarda no se rearma bien');
  }

  titulo('Segundo respaldo: la deduplicación sigue funcionando');
  {
    // Se cambia solo un pedazo del archivo, como hace Outlook al llegar un mail.
    const fd = fs.openSync(pst, 'r+');
    fs.writeSync(fd, pseudoAzar(0xdeadbeef, 65536), 0, 65536, 5 * 1048576);
    fs.closeSync(fd);

    const motor = new BackupEngine();
    const registro = [];
    motor.on('log', (l) => registro.push(String(l)));
    const { cuenta } = await contandoAperturas(() => motor.runOnce(cfg));

    comprobar('sigue abriéndose una sola vez', (cuenta.get(pst) || 0) === 1,
      `se abrió ${cuenta.get(pst) || 0} veces`);

    const linea = registro.find((l) => l.includes('[bloques]') && l.includes('correo.pst')) || '';
    // Ojo: \w no incluye la "ó" de "reutilizó" sin la bandera unicode.
    const reutilizados = Number((linea.match(/reutiliz\S* (\d+)/) || [])[1] || 0);
    comprobar('reutilizó bloques en lugar de subir todo de nuevo', reutilizados > 0,
      linea.slice(0, 160) || 'no hubo línea de bloques');
  }

  titulo('El motor no lee el archivo grande antes de subirlo');
  {
    // Guarda estática, para que el arreglo no se deshaga en un cambio futuro.
    const motorSrc = fs.readFileSync(
      path.join(__dirname, '..', 'electron', 'backup-engine.cjs'), 'utf8');
    comprobar('existe la decisión explícita de no leerlo',
      motorSrc.includes('vaPorBloques(file)'),
      'el motor tiene que saltear hashFile para los archivos que van por bloques');
    const bloquesSrc = fs.readFileSync(
      path.join(__dirname, '..', 'electron', 'bloques.cjs'), 'utf8');
    comprobar('bloques.cjs ya no fuerza una segunda lectura',
      !/huella \|\| await huellaDeArchivo/.test(bloquesSrc),
      'esa línea era la segunda apertura del archivo');
  }

  await srv.cerrar();
  try { fs.rmSync(TEMP, { recursive: true, force: true }); } catch {}

  console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
  if (falladas) { console.log('Fallaron:'); fallos.forEach((f) => console.log('  · ' + f)); }
  process.exit(falladas ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
