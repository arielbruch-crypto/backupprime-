'use strict';
/* Silencio y agrupación de avisos.
   La lógica se prueba aparte porque depende de la hora del sistema y de cuánto
   pasó desde el último aviso: dos cosas que a mano se prueban mal.

     node pruebas/avisos.cjs                                                   */

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

// Misma lógica que main.cjs, con la hora inyectada para poder probarla.
function enSilencio(cfg, ahora) {
  const { silencioDesde: desde, silencioHasta: hasta } = cfg;
  if (!desde || !hasta) return false;
  const minutos = ahora.getHours() * 60 + ahora.getMinutes();
  const aMin = (t) => {
    const [h, m] = String(t).split(':').map(Number);
    return (h || 0) * 60 + (m || 0);
  };
  const d = aMin(desde), h = aMin(hasta);
  return d <= h ? (minutos >= d && minutos < h) : (minutos >= d || minutos < h);
}

const alas = (h, m = 0) => new Date(2026, 7, 5, h, m);

console.log('BackupPrime — avisos\n');

titulo('Horas de silencio');
const noche = { silencioDesde: '22:00', silencioHasta: '08:00' };
comprobar('1. A las 23 está en silencio', enSilencio(noche, alas(23)));
comprobar('2. A las 3 de la mañana también', enSilencio(noche, alas(3)));
comprobar('3. A las 7:59 todavía', enSilencio(noche, alas(7, 59)));
comprobar('4. A las 8 en punto ya avisa', !enSilencio(noche, alas(8)));
comprobar('5. Al mediodía avisa', !enSilencio(noche, alas(12)));

const jornada = { silencioDesde: '09:00', silencioHasta: '18:00' };
comprobar('6. Un rango que no cruza medianoche también funciona',
  enSilencio(jornada, alas(12)) && !enSilencio(jornada, alas(20)));

comprobar('7. Sin horario configurado nunca calla', !enSilencio({}, alas(3)));
comprobar('8. Con solo una de las dos horas tampoco',
  !enSilencio({ silencioDesde: '22:00' }, alas(23)));

titulo('Qué se avisa según el modo');
function corresponde(modo, urgente) {
  if (modo === 'ninguno') return false;
  if (modo === 'problemas' && !urgente) return false;
  return true;
}
comprobar('9. En "solo problemas" no avisa los respaldos que salieron bien',
  !corresponde('problemas', false));
comprobar('10. Pero sí los que fallaron', corresponde('problemas', true));
comprobar('11. En "todos" avisa siempre', corresponde('todos', false) && corresponde('todos', true));
comprobar('12. En "ninguno" no avisa ni los errores', !corresponde('ninguno', true));

titulo('El mismo problema no se repite');
const HORAS = 6;
const recientes = new Map();
function repetir(clave, ahora) {
  const ultimo = recientes.get(clave) || 0;
  if (ahora - ultimo < HORAS * 3600e3) return false;
  recientes.set(clave, ahora);
  return true;
}
const t0 = Date.now();
comprobar('13. La primera vez avisa', repetir('disco-desenchufado', t0));
comprobar('14. Una hora después, no', !repetir('disco-desenchufado', t0 + 3600e3));
comprobar('15. Cinco horas después, tampoco', !repetir('disco-desenchufado', t0 + 5 * 3600e3));
comprobar('16. A las siete horas vuelve a avisar', repetir('disco-desenchufado', t0 + 7 * 3600e3));
comprobar('17. Un problema distinto avisa igual', repetir('otro-problema', t0 + 7 * 3600e3));

console.log('\n──────────────────────────────────────────────────────');
console.log(`  ${pasadas} de ${pasadas + falladas} pruebas pasadas`);
if (falladas) { console.log('\n  Fallaron:'); for (const f of fallos) console.log(`    · ${f}`); }
console.log('──────────────────────────────────────────────────────\n');
process.exit(falladas ? 1 : 0);
