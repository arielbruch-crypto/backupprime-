'use strict';
/* Nada sale de la máquina del cliente en claro.

   Esta es la prueba que no se puede falsear leyendo el código: mira los BYTES
   que efectivamente llegaron al destino y busca ahí el contenido original. Si
   aparece, el archivo viajó legible, sin importar lo que diga cualquier
   comentario o cualquier documento.

   Lo que estaba roto hasta la 0.9.9:

     · Los archivos que van por BLOQUES sí se cifraban. Los que van ENTEROS —o
       sea todo lo que está por debajo del umbral de 25 MB: los Excel, los Word,
       los PDF, que son la mayoría de los archivos de un estudio contable— se
       subían TAL CUAL. Estaba anotado como pendiente en lugar de estar cerrado.
     · Y la restauración nunca le pasaba la clave al almacén: `almacenDeBloques(dest)`
       sin segundo argumento, en los cuatro caminos. O sea que un respaldo
       cifrado se guardaba bien y NO SE PODÍA RESTAURAR. Guardar bien y no
       devolver es la peor combinación posible en un producto de backup.

     node pruebas/nada-en-claro.cjs                                           */

const fs = require('node:fs');
const fsp = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-claro-'));
process.env.BACKUPPRIME_CONFIG_DIR = path.join(TEMP, 'config');
fs.mkdirSync(process.env.BACKUPPRIME_CONFIG_DIR, { recursive: true });

const { crearServidorS3 } = require('./servidor-s3-prueba.cjs');
const { BackupEngine, s3Descargar, almacenDeBloques } = require('../electron/backup-engine.cjs');
const Bloques = require('../electron/bloques.cjs');
const Cifrado = require('../electron/cifrado.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — nada sale de la máquina en claro\n');

// Un texto que solo puede estar en el destino si el archivo viajó legible.
const SECRETO = 'CUIT 20-12345678-9 · Balance ejercicio 2026 · Honorarios 4.850.000';

(async () => {
  const srv = crearServidorS3();
  const puerto = await srv.escuchar();
  const prefijo = 'cliente/';
  const dest = {
    type: 's3', endpoint: `http://127.0.0.1:${puerto}`, region: 'us-east-1',
    bucket: 'respaldos', prefix: prefijo, accessKey: 'AKIA', secretKey: 'secreta',
    label: 'e2',
  };

  const origen = path.join(TEMP, 'origen', 'Documentos');
  await fsp.mkdir(origen, { recursive: true });

  // Un archivo CHICO, que va entero: el camino que estaba sin cifrar.
  const chico = path.join(origen, 'Balance 2026.xlsx');
  const datosChico = Buffer.concat([
    crypto.randomBytes(50 * 1024),
    Buffer.from(SECRETO, 'utf8'),
    crypto.randomBytes(50 * 1024),
  ]);
  await fsp.writeFile(chico, datosChico);

  // Y uno GRANDE, que va por bloques: el camino que ya estaba bien.
  const grande = path.join(origen, 'Outlook.pst');
  const partes = [];
  let x = 987654321 >>> 0;
  for (let i = 0; i < 30; i++) {
    const b = Buffer.alloc(1048576);
    for (let j = 0; j < b.length; j++) {
      x ^= x << 13; x >>>= 0; x ^= x >>> 17; x ^= x << 5; x >>>= 0; b[j] = x & 0xff;
    }
    partes.push(b);
  }
  const datosGrande = Buffer.concat(partes);
  Buffer.from(SECRETO, 'utf8').copy(datosGrande, 15 * 1048576);
  await fsp.writeFile(grande, datosGrande);

  const sal = Cifrado.salNueva();
  const frase = 'una frase larga del estudio contable';
  const clave = Cifrado.claveDesdeFrase(frase, sal);

  const cfg = {
    server: '', token: '', localPaths: [path.join(TEMP, 'origen')], excludedPaths: [],
    destinations: [dest], maxVersions: 10, systemBackup: false, forceFullBackup: false,
    umbralBloquesMB: 25,
    cifradoModo: 'privada',
    cifradoFrase: frase,
    cifradoSal: sal.toString('base64'),
    cifradoComprobante: Cifrado.crearComprobante(clave),
  };

  const motor = new BackupEngine();
  const registro = [];
  motor.on('log', (l) => registro.push(l.trim()));
  await motor.runOnce(cfg);

  comprobar('El respaldo termina sin errores',
    !registro.some((l) => l.includes('[error]')),
    registro.filter((l) => l.includes('[error]'))[0] || '');

  titulo('Los bytes que llegaron al destino');

  // Todo lo que el servidor recibió, sin interpretar: los bytes crudos.
  const todos = [...srv.objetos.entries()];
  comprobar('Llegaron objetos al destino', todos.length > 0, `${todos.length} objetos`);

  const secreto = Buffer.from(SECRETO, 'utf8');
  const enClaro = todos.filter(([, datos]) => datos.includes(secreto));
  comprobar('NINGÚN objeto contiene el contenido original',
    enClaro.length === 0,
    enClaro.map(([k]) => k).slice(0, 3).join(' | '));

  // Que ADEMÁS estén marcados como cifrados: sin esto, un objeto vacío o
  // corrupto pasaría el control anterior sin estar cifrado.
  const marca = Buffer.from('BPE1');
  const sinMarca = todos.filter(([k, datos]) =>
    !k.endsWith('/') && datos.length > 0 && !datos.subarray(0, 4).equals(marca));
  comprobar('Todos los objetos llevan la marca de cifrado',
    sinMarca.length === 0, sinMarca.map(([k]) => k).slice(0, 3).join(' | '));

  titulo('El archivo chico, el camino que subía en claro');

  const claveChico = todos.map(([k]) => k).find((k) => k.includes('Balance 2026.xlsx'));
  comprobar('Está en el destino', !!claveChico, todos.map(([k]) => k).join(' | ').slice(0, 200));
  if (claveChico) {
    const bytes = srv.objetos.get(claveChico);
    comprobar('No es el archivo original tal cual',
      !bytes.equals(datosChico),
      'los bytes del destino son idénticos al archivo del cliente');
    comprobar('Está cifrado', bytes.subarray(0, 4).equals(marca));
    comprobar('Y ocupa más que el original, por la cabecera de cifrado',
      bytes.length === datosChico.length + Cifrado.LARGO_CABECERA,
      `${bytes.length} contra ${datosChico.length}`);
  }

  titulo('Y se puede restaurar: guardar bien y no devolver es peor que no guardar');

  const vueltaChico = path.join(TEMP, 'restaurado', 'Balance 2026.xlsx');
  const claveChicoSinBucket = claveChico.split('/').slice(1).join('/');
  await s3Descargar(dest, claveChicoSinBucket, vueltaChico, undefined, null, clave);
  comprobar('El archivo chico vuelve idéntico, byte por byte',
    (await fsp.readFile(vueltaChico)).equals(datosChico));

  const almacen = almacenDeBloques(dest, clave);
  // Las claves del servidor de prueba vienen como "bucket/prefijo/...".
  // Se saca el bucket, después el prefijo, y después la rama `indices/`.
  const relGrande = todos.map(([k]) => k)
    .find((k) => k.includes('indices/') && k.endsWith('Outlook.pst.bpi'))
    .split('/').slice(1).join('/')
    .replace(new RegExp(`^${prefijo}`), '')
    .replace(/^indices\//, '').replace(/\.bpi$/, '');
  const vueltaGrande = path.join(TEMP, 'restaurado', 'Outlook.pst');
  await Bloques.restaurarPorBloques(almacen, {
    rutaRelativa: relGrande, destinoLocal: vueltaGrande, prefijo,
  });
  comprobar('El archivo grande, por bloques, también vuelve idéntico',
    (await fsp.readFile(vueltaGrande)).equals(datosGrande));

  titulo('Con la frase equivocada NO se entrega un archivo');

  const otraClave = Cifrado.claveDesdeFrase('otra frase completamente distinta', sal);
  const fallido = path.join(TEMP, 'fallido', 'Balance 2026.xlsx');
  let huboError = false, mensaje = '';
  try {
    await s3Descargar(dest, claveChicoSinBucket, fallido, undefined, null, otraClave);
  } catch (e) { huboError = true; mensaje = e.message; }

  comprobar('Falla en lugar de entregar basura', huboError, 'devolvió un archivo igual');
  comprobar('Y el archivo con su nombre definitivo NO llega a existir',
    !fs.existsSync(fallido),
    'un archivo ilegible con nombre definitivo es lo peor: parece restaurado');
  comprobar('El mensaje explica qué pasó, en castellano',
    /frase|clave|alterados/i.test(mensaje), mensaje);

  titulo('Los respaldos viejos, sin cifrar, se siguen restaurando');

  // Se guarda un objeto SIN cifrar, como los que hay hoy en el bucket del
  // cliente. Tiene que volver tal cual: activar el cifrado no puede dejar
  // ilegible todo lo anterior.
  const viejo = Buffer.from('Un archivo de antes del cifrado');
  srv.objetos.set(`respaldos/${prefijo}viejo.txt`, viejo);
  const vueltaViejo = path.join(TEMP, 'restaurado', 'viejo.txt');
  await s3Descargar(dest, `${prefijo}viejo.txt`, vueltaViejo, undefined, null, clave);
  comprobar('Un archivo sin cifrar vuelve tal cual',
    (await fsp.readFile(vueltaViejo)).equals(viejo));

  await srv.cerrar();
  fs.rmSync(TEMP, { recursive: true, force: true });

  console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
  if (falladas) { console.log(fallos.map((f) => ` · ${f}`).join('\n')); process.exit(1); }
})().catch((e) => { console.error(e); process.exit(1); });
