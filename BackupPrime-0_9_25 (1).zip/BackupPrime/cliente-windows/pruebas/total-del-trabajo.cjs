'use strict';
/* El total del trabajo y el tiempo que falta.

   ── El problema ──

   La barra mostraba archivos copiados, bytes copiados y velocidad. Ninguno de
   los tres dice cuánto FALTA. El cliente que dejó corriendo el primer respaldo
   de 200 GB no tenía forma de saber si eran veinte minutos o toda la noche, y
   la única respuesta honesta que podía dar el programa era ninguna.

   La causa no era pereza: el motor DESCUBRE los archivos mientras los copia.
   El recorrido que alimenta a los trabajadores tiene una reserva de 500 y se
   frena cuando se llena, así que nunca va más de 500 archivos adelante. Como
   total no sirve: siempre diría "los procesados más quinientos".

   ── La solución, y lo que hay que cuidar ──

   Un segundo recorrido, en paralelo, que no lee ni sube nada: solo cuenta
   archivos y suma tamaños. Tres cosas tienen que ser ciertas, y esta prueba
   comprueba las tres corriendo el motor de verdad:

   1. El total tiene que coincidir EXACTO con lo que el respaldo procesa. Si el
      conteo filtrara distinto que el motor, el porcentaje no llegaría a 100 o
      lo pasaría.
   2. El porcentaje y el tiempo restante NO pueden salir mientras el conteo
      corre. Mientras cuenta, el total sube; "12.480 de 40.000" con carpetas sin
      contar es un número parcial mostrado como exacto, que es el error que este
      proyecto ya pagó con la medición de carpetas.
   3. El avance se cuenta sobre lo RECORRIDO, no sobre lo subido. En un
      incremental donde no cambió nada, `bytesSubidos` queda en cero y el
      trabajo igual avanza: si el porcentaje mirara lo subido, se quedaría en
      cero toda la corrida y el tiempo restante sería infinito.

     node pruebas/total-del-trabajo.cjs                                       */

const fs = require('node:fs');
const fsp = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-total-'));
process.env.BACKUPPRIME_CONFIG_DIR = path.join(TEMP, 'config');
fs.mkdirSync(process.env.BACKUPPRIME_CONFIG_DIR, { recursive: true });

const { crearServidorS3 } = require('./servidor-s3-prueba.cjs');
const { BackupEngine } = require('../electron/backup-engine.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — total del trabajo y tiempo restante\n');

(async () => {
  const srv = crearServidorS3();
  const puerto = await srv.escuchar();
  const dest = {
    type: 's3', endpoint: `http://127.0.0.1:${puerto}`, region: 'us-east-1',
    bucket: 'respaldos', prefix: 'c/', accessKey: 'AKIA', secretKey: 'secreta',
    label: 'e2',
  };

  // Datos deterministas a propósito: con `randomBytes` los cortes por contenido
  // caen distinto en cada corrida y la prueba falla sola una de cada tantas.
  // Ya pasó dos veces en este proyecto.
  const origen = path.join(TEMP, 'origen');
  await fsp.mkdir(path.join(origen, 'sub'), { recursive: true });
  let bytesEsperados = 0;
  let archivosEsperados = 0;
  for (let i = 0; i < 60; i++) {
    const tam = 1000 + i * 10;
    await fsp.writeFile(path.join(origen, `a${i}.docx`), Buffer.alloc(tam, 7));
    bytesEsperados += tam; archivosEsperados++;
  }
  for (let i = 0; i < 40; i++) {
    const tam = 500 + i * 25;
    await fsp.writeFile(path.join(origen, 'sub', `b${i}.xlsx`), Buffer.alloc(tam, 9));
    bytesEsperados += tam; archivosEsperados++;
  }
  // Basura del sistema: el conteo tiene que descartarla igual que el motor. Si
  // la contara, el total sería más grande que el trabajo y el porcentaje nunca
  // llegaría a 100.
  await fsp.writeFile(path.join(origen, 'Thumbs.db'), Buffer.alloc(4096, 1));
  await fsp.mkdir(path.join(origen, 'node_modules'), { recursive: true });
  await fsp.writeFile(path.join(origen, 'node_modules', 'x.js'), Buffer.alloc(9999, 1));

  const cfg = {
    localPaths: [origen], excludedPaths: [],
    destinations: [dest], usarVss: false,
  };

  // ── Primera corrida: sube todo ────────────────────────────────────────────
  const avisos = [];
  const motor = new BackupEngine();
  motor.on('progreso', (p) => avisos.push(JSON.parse(JSON.stringify(p))));
  await motor.runOnce(cfg);

  titulo('El total del trabajo llega a la pantalla');

  const conTotal = avisos.filter((p) => p.trabajo && p.trabajo.listo);
  comprobar('El conteo termina y avisa que el total es exacto', conTotal.length > 0,
    'sin `trabajo.listo` la pantalla no puede mostrar porcentaje sin mentir');

  const fin = avisos[avisos.length - 1];
  comprobar('El total de archivos es el real',
    fin.trabajo && fin.trabajo.archivos === archivosEsperados,
    `dice ${fin.trabajo && fin.trabajo.archivos} y son ${archivosEsperados}`);
  comprobar('El total de bytes es el real',
    fin.trabajo && fin.trabajo.bytes === bytesEsperados,
    `dice ${fin.trabajo && fin.trabajo.bytes} y son ${bytesEsperados}`);

  titulo('Y descarta lo mismo que el motor');

  // Este es el control que importa: el motor procesó N archivos, el conteo
  // contó N. Si el conteo usara filtros propios, acá se separan.
  comprobar('Cuenta exactamente los archivos que el respaldo procesa',
    fin.trabajo.archivos === (fin.subidos + fin.salteados + fin.errores),
    `total ${fin.trabajo.archivos}, procesados ` +
    `${fin.subidos + fin.salteados + fin.errores} ` +
    `(${fin.subidos} subidos, ${fin.salteados} salteados, ${fin.errores} con error)`);

  titulo('Antes de terminar de contar no se inventa ningún número');

  // ── Ojo con esta comprobación ──
  //
  // Se escribió primero separada en dos, una para el porcentaje y otra para el
  // tiempo restante, y la del tiempo restante estaba en VERDE sin probar nada:
  // el tiempo restante además espera 3 segundos de corrida para tener una tasa
  // medible, y en un árbol de prueba el conteo termina en milisegundos, así que
  // no existe ningún aviso con el conteo a medias Y tres segundos encima. La
  // condición nunca se ejercitaba.
  //
  // Van juntas porque comprueban la MISMA guarda —`trabajo.listo`— y el
  // porcentaje sí la ejercita: hay avisos con el conteo a medias desde el
  // primer instante. Sacar `trabajo.listo` del cálculo pone esta línea en rojo.
  const parciales = avisos.filter((p) => p.trabajo && !p.trabajo.listo);
  comprobar('Hubo avisos con el conteo todavía a medias', parciales.length > 0,
    'sin ellos la comprobación de abajo no prueba nada');
  comprobar('Mientras cuenta, ni porcentaje ni tiempo restante',
    parciales.every((p) => (p.porcentaje === null || p.porcentaje === undefined) &&
                           (p.restanteSeg === null || p.restanteSeg === undefined)),
    'un total que todavía sube da un porcentaje que después retrocede y un ' +
    'tiempo restante que crece en vez de bajar');

  titulo('El porcentaje cierra en 100 y nunca se pasa');

  const conPorc = avisos.filter((p) => typeof p.porcentaje === 'number');
  comprobar('Se llegó a calcular el porcentaje', conPorc.length > 0);
  comprobar('Nunca pasa de 100', conPorc.every((p) => p.porcentaje <= 100),
    `máximo visto: ${Math.max(...conPorc.map((p) => p.porcentaje)).toFixed(2)}`);
  comprobar('Nunca es negativo', conPorc.every((p) => p.porcentaje >= 0));
  comprobar('El último llega a 100',
    Math.round(fin.porcentaje) === 100,
    `terminó en ${fin.porcentaje} — si no cierra, el cliente cree que faltó algo`);

  titulo('Y el trabajo recorrido incluye lo que NO se subió');

  comprobar('Los bytes recorridos son el total del trabajo',
    fin.bytesRecorridos === bytesEsperados,
    `${fin.bytesRecorridos} de ${bytesEsperados}`);

  // ── Segunda corrida: incremental, no cambió nada ─────────────────────────
  //
  // Acá es donde se ve por qué el avance NO puede medirse sobre lo subido. En
  // esta corrida `bytesSubidos` es cero de punta a punta y el trabajo se hace
  // igual: hay que recorrer y revisar los 100 archivos.
  titulo('En un incremental donde no cambió nada, el avance igual llega a 100');

  const avisos2 = [];
  const motor2 = new BackupEngine();
  motor2.on('progreso', (p) => avisos2.push(JSON.parse(JSON.stringify(p))));
  await motor2.runOnce(cfg);

  const fin2 = avisos2[avisos2.length - 1];
  comprobar('No se subió nada', fin2.bytesSubidos === 0 && fin2.subidos === 0,
    `subidos ${fin2.subidos}, bytes ${fin2.bytesSubidos}`);
  comprobar('Se saltearon todos', fin2.salteados === archivosEsperados,
    `${fin2.salteados} de ${archivosEsperados}`);
  comprobar('Y el porcentaje igual cierra en 100',
    Math.round(fin2.porcentaje) === 100,
    `terminó en ${fin2.porcentaje} — medir el avance sobre lo SUBIDO lo dejaría en 0`);
  comprobar('Los bytes recorridos cuentan lo salteado',
    fin2.bytesRecorridos === bytesEsperados,
    `${fin2.bytesRecorridos} de ${bytesEsperados}`);

  // ── El tiempo restante ────────────────────────────────────────────────────
  //
  // ── Por qué esta parte usa 6.000 archivos y tarda unos segundos ──
  //
  // El tiempo restante necesita una tasa medible, así que no se calcula hasta
  // que la corrida lleva 3 segundos. Con los 100 archivos de arriba la corrida
  // entera dura menos que eso: `restanteSeg` es null SIEMPRE, y cualquier
  // comprobación sobre él pasa en verde sin haber probado nada. Se escribió
  // así la primera vez y estaba vacía.
  //
  // Medido: con 6.000 archivos la corrida tarda ~6,3 s y hay 12 avisos con un
  // tiempo restante calculado de verdad. Ese es el precio de que esta parte
  // pruebe algo.
  titulo('El tiempo restante, con una corrida lo bastante larga');

  const origenLargo = path.join(TEMP, 'largo');
  await fsp.mkdir(origenLargo, { recursive: true });
  for (let i = 0; i < 6000; i++) {
    await fsp.writeFile(path.join(origenLargo, `c${i}.docx`), Buffer.alloc(3000, 3));
  }
  const cfgLargo = {
    localPaths: [origenLargo], excludedPaths: [], usarVss: false,
    destinations: [{ ...dest, prefix: 'largo/' }],
  };
  const avisos3 = [];
  const motorLargo = new BackupEngine();
  const arranque = Date.now();
  motorLargo.on('progreso', (p) => {
    const copia = JSON.parse(JSON.stringify(p));
    copia.__ms = Date.now() - arranque;   // para contrastar contra el reloj
    avisos3.push(copia);
  });
  await motorLargo.runOnce(cfgLargo);
  const duracionReal = Date.now() - arranque;
  const fin3 = avisos3[avisos3.length - 1];

  const conTiempo = avisos3.filter((p) => typeof p.restanteSeg === 'number');
  comprobar('La corrida fue lo bastante larga como para calcular un tiempo',
    conTiempo.length > 0,
    `${avisos3.length} avisos y ninguno con tiempo restante — sin esto, todo lo ` +
    `que sigue pasa en verde sin probar nada`);

  comprobar('Nunca es negativo ni NaN',
    conTiempo.every((p) => Number.isFinite(p.restanteSeg) && p.restanteSeg >= 0),
    'un "faltan -3 s" es peor que no mostrar nada');

  comprobar('Solo sale con el total ya contado',
    conTiempo.every((p) => p.trabajo && p.trabajo.listo),
    'estimar sobre un total que todavía crece da un tiempo que sube en vez de bajar');

  // Un tiempo restante que crece no es un tiempo restante. No se le puede pedir
  // que baje en CADA aviso —es una estimación y el ritmo real varía— pero sí
  // que el final sea menor que el principio.
  //
  // El `length > 0` no es defensivo por las dudas: cuando se reintroduce el bug
  // de no contar lo salteado como avance, no hay NINGÚN aviso con tiempo y esto
  // reventaba con un TypeError en vez de decir qué se rompió. Una prueba que
  // explota informa peor que una que falla.
  comprobar('Baja a medida que avanza',
    conTiempo.length > 0
      && conTiempo[conTiempo.length - 1].restanteSeg <= conTiempo[0].restanteSeg,
    conTiempo.length === 0
      ? 'ningún aviso trajo tiempo restante'
      : `empezó en ${conTiempo[0].restanteSeg} s y terminó en ` +
        `${conTiempo[conTiempo.length - 1].restanteSeg} s`);

  // ── La comprobación que de verdad importa ──
  //
  // Todo lo de arriba mira que el número sea coherente consigo mismo. Esto mira
  // si SIRVE: se conoce cuánto tardó la corrida de verdad, así que para cada
  // aviso se sabe cuánto faltaba realmente en ese instante. Un tiempo restante
  // que no se parece a eso no es un tiempo restante, por más prolijo que sea.
  //
  // Es lo que separa este cálculo del que había antes. El viejo estimaba sobre
  // los bytes ENCOLADOS —los cinco o seis archivos en vuelo—, así que decía
  // "falta menos de un segundo" durante toda la corrida. Ese error no lo
  // detecta ninguna comprobación de coherencia: el número es prolijo, positivo,
  // baja, y está mal.
  //
  // La banda es ancha a propósito: es una estimación, el ritmo real varía, y
  // una prueba que exige precisión falla sola una de cada tantas.
  const primero = conTiempo[0];
  const faltabaDeVerdad = primero ? (duracionReal - primero.__ms) / 1000 : 0;
  comprobar('El tiempo estimado se parece al que faltaba de verdad',
    !!primero &&
    primero.restanteSeg >= faltabaDeVerdad * 0.25 &&
    primero.restanteSeg <= faltabaDeVerdad * 4 + 1,
    !primero
      ? 'ningún aviso trajo tiempo restante'
      : `estimó ${primero.restanteSeg} s cuando faltaban ${faltabaDeVerdad.toFixed(1)} s ` +
        `— estimar sobre los bytes encolados en vez de sobre el trabajo da siempre ` +
        `"falta menos de un segundo"`);

  comprobar('Al terminar no queda un tiempo restante colgado',
    fin3.restanteSeg === null,
    `dice ${fin3.restanteSeg} — "faltan 2 min" en el aviso de terminado ` +
    `contradice al propio aviso`);

  comprobar('Y el porcentaje de la corrida larga también cierra en 100',
    Math.round(fin3.porcentaje) === 100, `terminó en ${fin3.porcentaje}`);

  const todos = [...avisos, ...avisos2, ...avisos3];
  comprobar('En ninguna de las tres corridas hay un tiempo restante sin total',
    todos.every((p) => !(typeof p.restanteSeg === 'number') ||
      (p.trabajo && p.trabajo.listo)));

  // ── Cancelar ──────────────────────────────────────────────────────────────
  //
  // El conteo es una fase larga más, y las fases largas tienen que consultar la
  // cancelación. Si no, "Detener" deja un recorrido dando vueltas por el disco
  // del cliente después de que la pantalla dijo que se detuvo.
  titulo('Cancelar corta también el conteo');

  const motor3 = new BackupEngine();
  const t0 = Date.now();
  const corrida = motor3.runOnce(cfg);
  setTimeout(() => motor3.stop(), 60);
  await corrida;
  comprobar('La corrida cancelada termina rápido', Date.now() - t0 < 20000,
    `tardó ${Date.now() - t0} ms — el conteo quedó dando vueltas`);

  // ── Y ahora la pantalla, CARGADA, no leída ──────────────────────────────
  //
  // Todo lo de arriba prueba el motor. Pero el motor puede estar perfecto y el
  // cliente ver cualquier cosa: la primera versión de esto mandaba los números
  // bien y la pantalla mostraba literalmente `prog-de-total` en vez del texto,
  // porque las claves de idioma no estaban en el diccionario. `t()` devuelve la
  // clave cuando no la encuentra, así que no hay error, no hay excepción, no
  // hay nada raro en el registro: solo un cliente mirando una etiqueta técnica
  // en el cuadro donde tendría que decirle cuánto falta.
  //
  // Y `auditoria-idioma.cjs --estricto` pasó en verde con eso puesto, porque
  // busca texto sin traducir en el HTML, no claves que se usan y no existen.
  // Este control es el que faltaba.
  titulo('La pantalla muestra texto, no claves de idioma');

  const { JSDOM } = require('jsdom');
  const htmlPantalla = fs.readFileSync(
    path.join(__dirname, '..', 'electron', 'renderer.html'), 'utf8');

  // Primero, sin abrir el DOM: toda clave que la pantalla pasa a `t('…')` tiene
  // que existir en los TRES diccionarios. Con que falte en uno, ese idioma
  // muestra la clave cruda.
  //
  // El `[,)]` del final no es cosmético: la pantalla también arma claves
  // concatenando —`t('perfil-' + nombre)`— y ahí el pedazo literal no es una
  // clave. Sin ese cierre, la prueba informaba cuatro claves inexistentes que
  // no eran bugs, y una prueba que grita en falso se termina ignorando.
  const clavesUsadas = [...htmlPantalla.matchAll(/\bt\(\s*'([a-z0-9-]+)'\s*[,)]/g)]
    .map((m) => m[1]);
  const diccionarios = [...htmlPantalla.matchAll(/"([a-z0-9-]+)"\s*:\s*"/g)]
    .reduce((acc, m) => { acc[m[1]] = (acc[m[1]] || 0) + 1; return acc; }, {});
  const huerfanas = [...new Set(clavesUsadas)].filter((k) => !diccionarios[k]);
  const incompletas = [...new Set(clavesUsadas)]
    .filter((k) => diccionarios[k] && diccionarios[k] < 3);

  comprobar('Toda clave que usa la pantalla existe en el diccionario',
    huerfanas.length === 0,
    `faltan: ${huerfanas.join(', ')} — \`t()\` devuelve la clave y el cliente la ve`);
  comprobar('Y está en los tres idiomas',
    incompletas.length === 0,
    `incompletas: ${incompletas.map((k) => `${k} (${diccionarios[k]}/3)`).join(', ')}`);

  // Y ahora sí, la pantalla corriendo. Se le mandan avisos como los que emite
  // el motor y se mira el texto que queda en el cuadro.
  const METODOS = ('start stop status logs runNow runNowFull verificar agentLogin '
    + 'probarDestino onRestoreContando onRestoreProgreso onProgreso getAutoStart '
    + 'consultarCuota ultimaCuota onCuota ultimaVerificacion onVerificacion setAutoStart '
    + 'readConfig saveCredentials setSchedule setMaxVersions setCifrado getCifrado '
    + 'medirCarpeta onMedidaParcial setConcurrencia setAvisos setUmbralBloques setLang '
    + 'setSystemBackup pickFolders pickFolder setPaths setExcludes setDestinations listDir '
    + 'accesosRapidos medirRutas systemDrives userProfilePaths restoreListFiles '
    + 'restorePickFolder restoreFile restoreFromLocal restoreLocalDestinations '
    + 'restoreLocalFiles restoreLocalFolders restoreLocalRun restoreLocalTree '
    + 'restoreLocalSelection restoreRemotoTree restoreAFecha restoreFechas revisarBloques '
    + 'reconstruirIndices restoreVersiones restoreVersion restoreCancelar '
    + 'restoreRemotoSelection onLog onStatus').split(/\s+/);

  const oyentes = {};
  const apiFalsa = {};
  for (const m of METODOS) {
    apiFalsa[m] = (...a) => {
      const f = a.find((x) => typeof x === 'function');
      if (f && m.startsWith('on')) oyentes[m] = f;
      return Promise.resolve({ ok: true, paths: [], excludes: [], destinations: [],
        entradas: [], archivos: [], carpetas: [] });
    };
  }

  const dom = new JSDOM(htmlPantalla, {
    runScripts: 'dangerously', pretendToBeVisual: true, url: 'http://localhost/',
    beforeParse(w) {
      w.requestAnimationFrame = (f) => setTimeout(f, 0);
      w.iconoDeArchivo = () => '';
      w.backupprime = apiFalsa;
      w.alert = () => {}; w.confirm = () => true;
    },
  });
  await new Promise((r) => setTimeout(r, 2000));
  const doc = dom.window.document;
  const texto = (id) => {
    const e = doc.getElementById(id);
    return e ? e.textContent.trim() : '(NO EXISTE)';
  };

  comprobar('La pantalla se enganchó al evento de progreso',
    typeof oyentes.onProgreso === 'function',
    'sin esto todo lo que sigue prueba nada');

  if (typeof oyentes.onProgreso === 'function') {
    const avisar = oyentes.onProgreso;
    const plantilla = {
      archivoActual: 'Balance 2026.xlsx', subidos: 0, salteados: 0, errores: 0,
      bytesSubidos: 0, bytesTotales: 0, velocidad: 0, restanteSeg: null,
      transcurridoSeg: 0, enVuelo: [], bytesEnVuelo: 0, procesados: 0,
      bytesRecorridos: 0, porcentaje: null, vss: null, espacio: null,
      trabajo: { archivos: 0, bytes: 0, listo: false },
    };
    const esClaveCruda = (s) => /^[a-z0-9]+(-[a-z0-9]+)+$/.test(s);

    // Contando todavía: hay que ver que mide, sin porcentaje ni tiempo.
    avisar({ ...plantilla, fase: 'analizando', procesados: 1200, transcurridoSeg: 4,
      bytesRecorridos: 9e8, velocidad: 8e6,
      trabajo: { archivos: 41300, bytes: 38e9, listo: false } });
    const contando = texto('progTotal');
    comprobar('Mientras cuenta, el cuadro del total dice algo legible',
      contando.length > 0 && !esClaveCruda(contando), `dice "${contando}"`);
    comprobar('Y no promete un tiempo restante',
      texto('progRestante') === '—', `dice "${texto('progRestante')}"`);
    comprobar('Y la barra es de actividad, no de porcentaje',
      doc.getElementById('progBarra').className.includes('activa'),
      'con el total todavía subiendo, un porcentaje retrocede');

    // Total ya contado.
    avisar({ ...plantilla, fase: 'subiendo', procesados: 12480, subidos: 900,
      salteados: 11580, bytesSubidos: 3.2e9, bytesRecorridos: 21e9,
      velocidad: 14.5e6, transcurridoSeg: 1500, restanteSeg: 3 * 3600 + 25 * 60,
      porcentaje: 10, trabajo: { archivos: 165320, bytes: 210e9, listo: true } });
    const conTotal = texto('progTotal');
    comprobar('Con el total listo se ven los DOS números y sus totales',
      !esClaveCruda(conTotal)
      && conTotal.includes('165.320') && /165,?58 GB|195,58 GB|GB/.test(conTotal),
      `dice "${conTotal}"`);
    comprobar('Y aparece el tiempo restante del trabajo completo',
      texto('progRestante') === '3 h 25 min', `dice "${texto('progRestante')}"`);
    // El ancho se compara como número: el DOM normaliza "10.0%" a "10%" y
    // comparar el texto hacía fallar una barra que estaba perfecta.
    const anchoBarra = parseFloat(doc.getElementById('progBarra').style.width);
    comprobar('Y la barra pasa a ser porcentaje real',
      !doc.getElementById('progBarra').className.includes('activa')
      && Math.abs(anchoBarra - 10) < 0.2,
      `ancho "${doc.getElementById('progBarra').style.width}"`);

    // Terminado: no puede quedar un tiempo restante colgado.
    avisar({ ...plantilla, fase: 'terminado', subidos: 4210, salteados: 161110,
      bytesSubidos: 18.4e9, bytesRecorridos: 210e9, porcentaje: 100,
      transcurridoSeg: 4 * 3600, restanteSeg: null,
      trabajo: { archivos: 165320, bytes: 210e9, listo: true } });
    comprobar('Al terminar el cuadro del total sigue siendo texto',
      !esClaveCruda(texto('progTotal')), `dice "${texto('progTotal')}"`);
    comprobar('Y no queda un "restante" colgado al lado de "terminado"',
      texto('progRestante') === '—',
      `dice "${texto('progRestante')}" — contradice al propio aviso de terminado`);
  }
  dom.window.close();

  await srv.cerrar();
  fs.rmSync(TEMP, { recursive: true, force: true });

  console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
  if (falladas) { console.log(fallos.map((f) => ` · ${f}`).join('\n')); process.exit(1); }
})().catch((e) => { console.error(e); process.exit(1); });
