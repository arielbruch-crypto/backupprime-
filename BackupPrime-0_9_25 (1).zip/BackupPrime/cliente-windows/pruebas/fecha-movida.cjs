'use strict';
/* El archivo al que solo le movieron la fecha.

   No es un caso raro: es el caso más común del producto. Outlook le toca la
   fecha al PST todos los días sin cambiar el contenido, y lo mismo hace
   cualquier programa que abre y cierra un archivo. Ahí el chequeo rápido por
   tamaño y fecha falla, y hay que recorrer el archivo — eso es inevitable, sin
   leerlo no hay forma de saber que es el mismo.

   Lo que NO es inevitable es lo que venía después:

     · el motor guardaba `hash: null` para TODO archivo que va por bloques,
       aunque `subirPorBloques` ya devolvía la huella calculada en la única
       pasada. Sin huella guardada no hay con qué comparar;
     · y el índice se reescribía igual. Con versionado en el destino eso crea
       una versión nueva por corrida, y como la retención tiene tope, las
       versiones de índice le van corriendo el historial al archivo: el cliente
       pide "volvé al lunes" y encuentra treinta versiones de esta semana y
       ninguna del lunes.

   Un archivo quieto no puede gastar historial.

     node pruebas/fecha-movida.cjs                                            */

const fs = require('node:fs');
const fsp = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-fecha-'));
process.env.BACKUPPRIME_CONFIG_DIR = path.join(TEMP, 'config');
fs.mkdirSync(process.env.BACKUPPRIME_CONFIG_DIR, { recursive: true });

const { crearServidorS3 } = require('./servidor-s3-prueba.cjs');
const { BackupEngine, s3Listar } = require('../electron/backup-engine.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — la fecha se movió, el contenido no\n');

const leerEstado = () =>
  JSON.parse(fs.readFileSync(path.join(process.env.BACKUPPRIME_CONFIG_DIR, 'state.json'), 'utf8'));

(async () => {
  const srv = crearServidorS3();
  const puerto = await srv.escuchar();
  const prefijo = 'cliente/';
  const dest = {
    type: 's3', endpoint: `http://127.0.0.1:${puerto}`, region: 'us-east-1',
    bucket: 'respaldos', prefix: prefijo, accessKey: 'AKIA', secretKey: 'secreta',
    label: 'e2',
  };

  const origen = path.join(TEMP, 'origen', 'Documentos');
  await fsp.mkdir(origen, { recursive: true });

  const pst = path.join(origen, 'Outlook.pst');
  const datos = Buffer.allocUnsafe(40 * 1048576);
  for (let i = 0; i < datos.length; i += 1048576) {
    crypto.randomFillSync(datos, i, Math.min(1048576, datos.length - i));
  }
  await fsp.writeFile(pst, datos);

  const cfg = {
    server: '', token: '', localPaths: [path.join(TEMP, 'origen')], excludedPaths: [],
    destinations: [dest], maxVersions: 10, systemBackup: false, forceFullBackup: false,
    umbralBloquesMB: 25,
  };

  const motor = new BackupEngine();
  const registro = [];
  motor.on('log', (l) => registro.push(l.trim()));

  titulo('Primer respaldo');
  await motor.runOnce(cfg);
  comprobar('Sin errores', !registro.some((l) => l.includes('[error]')),
    registro.filter((l) => l.includes('[error]'))[0] || '');

  const estado1 = leerEstado()[pst];
  comprobar('La huella del archivo grande queda guardada en state.json',
    !!(estado1 && estado1.hash && estado1.hash.length === 64),
    `quedó ${JSON.stringify(estado1 && estado1.hash)} — sin huella no hay con qué comparar mañana`);

  const huellaReal = crypto.createHash('sha256').update(datos).digest('hex');
  comprobar('Y es la huella REAL del archivo, no otra cosa',
    estado1 && estado1.hash === huellaReal);

  titulo('Segundo día: se toca la fecha, no cambia ni un byte');

  const antes = { ...srv.stats };
  const indicesAntes = (await s3Listar(dest)).archivos
    .filter((a) => a.clave.endsWith('.bpi')).length;

  // La fecha se corre cinco minutos a propósito. Poner "ahora" hacía que la
  // prueba fallara sola una de cada tantas corridas: el chequeo rápido tolera
  // hasta un segundo de diferencia, así que si el primer respaldo terminaba en
  // menos de un segundo el archivo se salteaba y no se ejercitaba nada de lo
  // que esta prueba dice probar. Una prueba que falla sola enseña a ignorar los
  // resultados.
  const movida = new Date(Date.now() + 300000);
  await fsp.utimes(pst, movida, movida);
  registro.length = 0;
  const r2 = await motor.runOnce(cfg);

  const puts = srv.stats.puts - antes.puts;
  comprobar('No se sube ni un objeto: ni bloques, ni índice, ni copia',
    puts === 0, `${puts} objetos subidos`);

  comprobar('El registro lo dice con todas las letras',
    registro.some((l) => l.includes('la fecha cambió pero el contenido no')),
    registro.filter((l) => l.includes('[bloques]')).slice(-1)[0] || '(nada)');

  comprobar('No se cuenta como subido, porque no viajó un byte',
    (r2.uploaded || 0) === 0, `dice ${r2.uploaded} subido(s)`);

  const indicesDespues = (await s3Listar(dest)).archivos
    .filter((a) => a.clave.endsWith('.bpi')).length;
  comprobar('No aparecen copias nuevas del índice en el destino',
    indicesDespues === indicesAntes, `${indicesAntes} → ${indicesDespues}`);

  titulo('La fecha nueva sí queda guardada: al tercer día ni se abre el archivo');

  const estado2 = leerEstado()[pst];
  comprobar('state.json tiene la fecha nueva',
    Math.abs(estado2.mtimeMs - fs.statSync(pst).mtimeMs) < 1000,
    'sin esto el archivo se recorrería entero todos los días para siempre');
  comprobar('Y conserva la huella',
    estado2.hash === huellaReal);

  const antes3 = { ...srv.stats };
  let aperturas = 0;
  const crearReal = fs.createReadStream;
  fs.createReadStream = function (p, ...resto) {
    if (String(p).endsWith('Outlook.pst')) aperturas++;
    return crearReal.call(fs, p, ...resto);
  };
  await motor.runOnce(cfg);
  fs.createReadStream = crearReal;

  comprobar('Tercer respaldo: el archivo no se abre',
    aperturas === 0, `se abrió ${aperturas} vez/veces`);
  comprobar('Tercer respaldo: cero pedidos de red',
    srv.stats.puts === antes3.puts && srv.stats.lists === antes3.lists
      && srv.stats.gets === antes3.gets,
    JSON.stringify({ puts: srv.stats.puts - antes3.puts, lists: srv.stats.lists - antes3.lists,
                     gets: srv.stats.gets - antes3.gets }));

  titulo('Y si el contenido cambia DE VERDAD, se respalda igual que siempre');

  const conMails = Buffer.from(datos);
  crypto.randomFillSync(conMails, conMails.length - 2 * 1048576, 2 * 1048576);
  await fsp.writeFile(pst, conMails);
  // La fecha se separa a propósito: si quedara dentro del segundo de la
  // anterior, el chequeo rápido saltearía el archivo y la prueba estaría
  // midiendo otra cosa.
  const masTarde = new Date(Date.now() + 60000);
  await fsp.utimes(pst, masTarde, masTarde);

  const antes4 = { ...srv.stats };
  const indices4 = (await s3Listar(dest)).archivos.filter((a) => a.clave.endsWith('.bpi')).length;
  registro.length = 0;
  await motor.runOnce(cfg);

  comprobar('Sube los bloques que cambiaron',
    srv.stats.puts - antes4.puts > 0);
  comprobar('Y esta vez SÍ escribe el índice, que es lo que crea la versión nueva',
    registro.some((l) => l.includes('[bloques]') && !l.includes('la fecha cambió')),
    registro.filter((l) => l.includes('[bloques]')).slice(-1)[0] || '(nada)');

  const estado4 = leerEstado()[pst];
  comprobar('Y la huella guardada se actualiza al contenido nuevo',
    estado4.hash === crypto.createHash('sha256').update(conMails).digest('hex'));

  await srv.cerrar();
  fs.rmSync(TEMP, { recursive: true, force: true });

  console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
  if (falladas) { console.log(fallos.map((f) => ` · ${f}`).join('\n')); process.exit(1); }
})().catch((e) => { console.error(e); process.exit(1); });
