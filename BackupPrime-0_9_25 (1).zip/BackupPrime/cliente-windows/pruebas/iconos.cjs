'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Íconos por tipo de archivo.

   Se prueban tres cosas:

   1) Que cada extensión caiga en la familia correcta, con foco en las que
      importan en un estudio contable: el correo de Outlook, la base del sistema
      de gestión y los certificados de facturación electrónica.

   2) Que el SVG que sale sea seguro. Los nombres de archivo vienen del disco del
      cliente y pueden contener comillas o `<script>`: si el ícono los insertara
      sin cuidado, un nombre de archivo podría ejecutar código en la pantalla.

   3) Que el programa de escritorio y el portal usen EL MISMO módulo. Si cada uno
      tuviera su tabla, con el tiempo un .pst se vería distinto en cada lado.

     node pruebas/iconos.cjs
   ═══════════════════════════════════════════════════════════════════════════ */

const fs = require('node:fs');
const path = require('node:path');
const { iconoDeArchivo, tipoDeArchivo, colorDeArchivo, FAMILIAS } =
  require('../electron/iconos-archivo.js');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — íconos por tipo de archivo\n');

titulo('Los archivos que importan en un estudio contable');
{
  const casos = [
    ['ariel.bruch@itstandard.org.pst', 'correo'],
    ['~ariel.bruch@itstandard.org.pst.tmp', 'correo'],   // el temporal de Outlook
    ['Balance 2026.xlsx', 'planilla'],
    ['Libro IVA.xls', 'planilla'],
    ['Contrato de alquiler.docx', 'documento'],
    ['Factura A 0001-00001234.pdf', 'pdf'],
    ['certificado-afip.pfx', 'certificado'],
    ['certificado-afip.p12', 'certificado'],
    ['claves.kdbx', 'certificado'],
    ['Tango.mdb', 'base'],
    ['gestion.accdb', 'base'],
    ['respaldo.bak', 'base'],
    ['padron.dbf', 'base'],
  ];
  for (const [nombre, esperado] of casos) {
    comprobar(`${nombre} → ${esperado}`, tipoDeArchivo(nombre) === esperado,
      `dio "${tipoDeArchivo(nombre)}"`);
  }
}

titulo('El resto de las familias');
{
  const casos = [
    ['foto.JPG', 'imagen'], ['video.mp4', 'video'], ['tema.mp3', 'audio'],
    ['respaldo.zip', 'comprimido'], ['plano.dwg', 'plano'],
    ['notas.txt', 'texto'], ['script.py', 'codigo'],
    ['instalador.exe', 'ejecutable'], ['presentacion.pptx', 'presentacion'],
  ];
  for (const [nombre, esperado] of casos) {
    comprobar(`${nombre} → ${esperado}`, tipoDeArchivo(nombre) === esperado,
      `dio "${tipoDeArchivo(nombre)}"`);
  }
}

titulo('Nombres que no siguen las reglas');
{
  comprobar('sin extensión no rompe', tipoDeArchivo('LEEME') === 'otro');
  comprobar('extensión desconocida cae en "otro"', tipoDeArchivo('cosa.zzz') === 'otro');
  comprobar('los ocultos de Unix no cuentan el punto inicial',
    tipoDeArchivo('.gitignore') === 'otro', tipoDeArchivo('.gitignore'));
  comprobar('mayúsculas y minúsculas dan igual',
    tipoDeArchivo('BALANCE.XLSX') === tipoDeArchivo('balance.xlsx'));
  comprobar('nombre vacío no rompe', tipoDeArchivo('') === 'otro');
  comprobar('null no rompe', tipoDeArchivo(null) === 'otro');
  comprobar('el punto en la carpeta no confunde',
    tipoDeArchivo('C:/Mis.Documentos/informe.pdf') === 'pdf');
}

titulo('El SVG que sale');
{
  const svg = iconoDeArchivo('balance.xlsx');
  comprobar('es un SVG', svg.startsWith('<svg') && svg.endsWith('</svg>'));
  comprobar('lleva el color de la familia', svg.includes(FAMILIAS.planilla.color));
  comprobar('no pide nada por la red', !/https?:|<image|url\(/i.test(svg),
    'el programa tiene que funcionar sin conexión');
  comprobar('los lectores de pantalla lo ignoran', svg.includes('aria-hidden="true"'),
    'el nombre del archivo está al lado: leer "imagen" en cada fila sería ruido');

  const carpeta = iconoDeArchivo('Documentos', true);
  comprobar('la carpeta tiene su propio ícono', carpeta !== iconoDeArchivo('Documentos'));
  // Pasa de verdad: una carpeta llamada "Balance.xlsx".
  comprobar('una carpeta con nombre de archivo sigue siendo carpeta',
    iconoDeArchivo('Balance.xlsx', true) === iconoDeArchivo('Otra', true));
}

titulo('Un nombre de archivo no puede inyectar código');
{
  // Los nombres vienen del disco del cliente. Windows no permite < > " en
  // nombres, pero el árbol también muestra rutas de otros orígenes, y confiar en
  // eso es la clase de suposición que después se paga.
  const peligrosos = [
    '"><script>alert(1)</script>.pdf',
    "malo' onload='alert(1)'.xlsx",
    '<img src=x onerror=alert(1)>.docx',
  ];
  for (const nombre of peligrosos) {
    const svg = iconoDeArchivo(nombre);
    comprobar(`no se cuela nada con ${JSON.stringify(nombre.slice(0, 24))}…`,
      !svg.includes('<script') && !svg.includes('onerror') && !svg.includes('onload'),
      svg.slice(0, 100));
  }
  comprobar('el ícono no incluye el nombre del archivo',
    !iconoDeArchivo('secreto-confidencial.pdf').includes('secreto'),
    'el nombre lo pone quien dibuja la fila, con su propio escapado');
}

titulo('Cada familia se distingue por forma, no solo por color');
{
  // Importa para listas largas y para quien no distingue bien los colores.
  const vistos = new Map();
  const repetidos = [];
  for (const familia of Object.keys(FAMILIAS)) {
    const ejemplo = FAMILIAS[familia].ext[0];
    const svg = iconoDeArchivo('x.' + ejemplo);
    // Se compara la silueta: el SVG sin el color.
    const forma = svg.replace(/color:#[0-9a-f]{6}/i, '');
    if (vistos.has(forma)) repetidos.push(`${familia} = ${vistos.get(forma)}`);
    else vistos.set(forma, familia);
  }
  comprobar('ninguna familia comparte silueta con otra', repetidos.length === 0,
    repetidos.join(', '));
  comprobar('cada familia tiene su propio color',
    new Set(Object.values(FAMILIAS).map((f) => f.color)).size ===
    Object.keys(FAMILIAS).length);
}

titulo('El programa y el portal usan el mismo módulo');
{
  const delAgente = fs.readFileSync(
    path.join(__dirname, '..', 'electron', 'iconos-archivo.js'), 'utf8');
  const delPortal = path.join(__dirname, '..', '..', 'servidor-y-portal', 'js', 'iconos-archivo.js');
  comprobar('el portal tiene el módulo', fs.existsSync(delPortal));
  if (fs.existsSync(delPortal)) {
    comprobar('es exactamente el mismo archivo',
      fs.readFileSync(delPortal, 'utf8') === delAgente,
      'si divergen, un .pst se vería distinto en cada lado');
  }

  const html = fs.readFileSync(
    path.join(__dirname, '..', 'electron', 'renderer.html'), 'utf8');
  comprobar('el programa usa el ícono en el árbol de restauración',
    html.includes('iconoDeArchivo(node.name, isFolder)'));

  const portalJs = fs.readFileSync(
    path.join(__dirname, '..', '..', 'servidor-y-portal', 'js', 'portal.js'), 'utf8');
  comprobar('el portal ya no usa la tabla de cuatro emojis',
    !portalJs.includes("xlsx: '📊'"));
  // En 0.9.21 el portal dejó de listar archivos: bajar desde la web no tiene
  // backend, y el árbol que había estaba escrito a mano. La guarda no se borra,
  // se ata a que el portal muestre archivos — el día que vuelva, tiene que usar
  // el módulo compartido y no inventarse íconos propios.
  const portalListaArchivos = /iconoDeArchivo|data-archivo|data-carpeta/.test(portalJs);
  comprobar('si el portal lista archivos, llama al módulo compartido',
    !portalListaArchivos || portalJs.includes('window.IconosArchivo'),
    portalListaArchivos ? 'lista archivos sin usar IconosArchivo' : '');
}

console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
if (falladas) { console.log('Fallaron:'); fallos.forEach((f) => console.log('  · ' + f)); }
process.exit(falladas ? 1 : 0);
