'use strict';
// ---------------------------------------------------------------------------
// Política de retención por ventanas de tiempo.
//
// La prueba que da sentido a todo esto es la del PST: un archivo que cambia
// diez veces por día. Con "las últimas 30 versiones" el historial cubre TRES
// DÍAS, así que un ransomware detectado el lunes siguiente ya se comió todas
// las copias sanas — sin que ningún atacante borre nada.
//
//   node pruebas/retencion.cjs
// ---------------------------------------------------------------------------

const { clasificarVersiones, explicarPolitica, POLITICA_POR_DEFECTO, DIA } =
  require('../electron/retencion.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
function comprobar(nombre, condicion, detalle = '') {
  if (condicion) { pasadas++; console.log(`  ok   ${nombre}`); }
  else { falladas++; fallos.push(nombre); console.log(`  FALLA ${nombre}${detalle ? ' — ' + detalle : ''}`); }
}
const titulo = (t) => console.log(`\n${t}`);

const AHORA = new Date('2026-08-21T15:00:00').getTime();
const hace = (dias, hora = 12) => {
  const d = new Date(AHORA - dias * DIA);
  d.setHours(hora, 0, 0, 0);
  return d.getTime();
};
const armar = (lista) => lista.map((fechaMs, i) => ({ id: 'v' + i, fechaMs }));
const ids = (arr) => arr.map((v) => v.id).sort();

titulo('Ante la duda, no se borra');
let r = clasificarVersiones([], { ahora: AHORA });
comprobar('Sin versiones no rompe', r.conservar.length === 0 && r.sobrantes.length === 0);

r = clasificarVersiones(armar([hace(900)]), { ahora: AHORA });
comprobar('Una sola versión NUNCA se borra, por vieja que sea',
  r.sobrantes.length === 0, JSON.stringify(r.sobrantes));

r = clasificarVersiones([{ id: 'a', fechaMs: null }, { id: 'b', fechaMs: hace(1) },
                         { id: 'c', fechaMs: 'basura' }], { ahora: AHORA });
comprobar('Las versiones sin fecha legible se conservan',
  r.sobrantes.length === 0 && ids(r.conservar).join() === 'a,b,c', JSON.stringify(r));
comprobar('Y se avisa que las hay', r.avisos.some((a) => /sin fecha legible/.test(a)));

r = clasificarVersiones(armar([hace(-5), hace(400), hace(401)]), { ahora: AHORA });
comprobar('Una fecha futura es un reloj mal puesto: se conserva',
  r.conservar.some((v) => v.fechaMs > AHORA), JSON.stringify(r.avisos));

titulo('La más nueva siempre se conserva');
r = clasificarVersiones(armar([hace(1000), hace(1001), hace(1002)]), { ahora: AHORA });
comprobar('Aunque TODAS estén fuera de la política, queda la actual',
  r.conservar.length === 1 && r.sobrantes.length === 2, JSON.stringify(ids(r.conservar)));

titulo('Últimos 7 días: se conservan TODAS');
r = clasificarVersiones(armar([
  hace(0, 9), hace(0, 11), hace(0, 14), hace(0, 17),
  hace(2, 9), hace(2, 10), hace(2, 11),
  hace(6, 8), hace(6, 16),
]), { ahora: AHORA });
comprobar('Nueve versiones de la última semana, ninguna sobra',
  r.sobrantes.length === 0, JSON.stringify(r.sobrantes.length));

titulo('De 7 a 30 días: una por día');
r = clasificarVersiones(armar([
  hace(0),
  hace(10, 8), hace(10, 12), hace(10, 18),   // tres del mismo día
  hace(11, 9),
]), { ahora: AHORA });
comprobar('De tres versiones del mismo día queda una', r.sobrantes.length === 2,
  JSON.stringify(r.sobrantes.length));
comprobar('Y la que queda es la MÁS NUEVA de ese día',
  r.conservar.some((v) => v.fechaMs === hace(10, 18)),
  JSON.stringify(r.conservar.map((v) => new Date(v.fechaMs).toISOString())));

titulo('De 30 días a 6 meses: una por semana');
r = clasificarVersiones(armar([
  hace(0), hace(40), hace(41), hace(42), hace(50),
]), { ahora: AHORA });
const semanas = r.conservar.filter((v) => v.fechaMs !== hace(0)).length;
comprobar('De 40, 41 y 42 días —misma semana— queda una', semanas === 2,
  `quedaron ${semanas}`);

titulo('De 6 meses a 2 años: una por mes');
// Ojo con armar el caso a ojo: 200 días atrás cae en febrero, y 205 y 210 en
// enero. Los que comparten mes son 205 y 210, no los tres.
r = clasificarVersiones(armar([
  hace(0), hace(200), hace(205), hace(210), hace(240),
]), { ahora: AHORA });
comprobar('De DOS del mismo mes (205 y 210 días) queda una',
  r.sobrantes.length === 1, `sobrantes: ${r.sobrantes.length}`);
comprobar('Y se conserva la más nueva de ese mes',
  r.conservar.some((v) => v.fechaMs === hace(205)) &&
  !r.conservar.some((v) => v.fechaMs === hace(210)),
  JSON.stringify(r.conservar.map((v) => new Date(v.fechaMs).toISOString().slice(0, 10))));

// Un mes entero de versiones diarias tiene que colapsar a una sola.
r = clasificarVersiones(armar([hace(0), ...Array.from({ length: 28 }, (_, i) => hace(200 + i))]),
  { ahora: AHORA });
const viejasConservadas = r.conservar.filter((v) => v.fechaMs !== hace(0)).length;
comprobar('28 versiones diarias de hace medio año colapsan a una por mes',
  viejasConservadas <= 2, `quedaron ${viejasConservadas}`);

titulo('Más de 2 años: sobra');
r = clasificarVersiones(armar([hace(0), hace(700), hace(800)]), { ahora: AHORA });
comprobar('Lo anterior a 2 años se marca como sobrante',
  r.sobrantes.length === 1 && r.sobrantes[0].fechaMs === hace(800),
  JSON.stringify(r.sobrantes.length));

titulo('EL CASO QUE MOTIVA TODO: el PST que cambia diez veces por día');
// Un año de versiones, diez por día. Con "las últimas 30" el historial llega a
// tres días. Con ventanas de tiempo llega a un año.
const pst = [];
for (let dia = 0; dia < 365; dia++) {
  for (let n = 0; n < 10; n++) pst.push(hace(dia, 8 + n));
}
r = clasificarVersiones(armar(pst), { ahora: AHORA });

const masVieja = Math.min(...r.conservar.map((v) => v.fechaMs));
const alcanceDias = Math.round((AHORA - masVieja) / DIA);
comprobar('El historial alcanza casi un año, no tres días',
  alcanceDias > 300, `alcance: ${alcanceDias} días`);
comprobar('Y guarda muchas MENOS versiones que las 3650 originales',
  r.conservar.length < 150, `conserva ${r.conservar.length} de ${pst.length}`);

// La comparación con la política vieja, que es el argumento entero.
const ultimas30 = armar(pst).sort((a, b) => b.fechaMs - a.fechaMs).slice(0, 30);
const alcanceViejo = Math.round((AHORA - Math.min(...ultimas30.map((v) => v.fechaMs))) / DIA);
comprobar('Contra "las últimas 30 versiones", que solo llegaban a 3 días',
  alcanceViejo <= 3 && alcanceDias > 300, `viejo ${alcanceViejo} días, nuevo ${alcanceDias} días`);

titulo('Un ransomware detectado a los 12 días todavía encuentra copia sana');
// Doce días de archivos cifrados, diez por día, sobre un año de historia sana.
const conAtaque = [];
for (let dia = 0; dia < 12; dia++) {
  for (let n = 0; n < 10; n++) conAtaque.push({ fechaMs: hace(dia, 8 + n), sano: false });
}
for (let dia = 12; dia < 365; dia++) {
  conAtaque.push({ fechaMs: hace(dia, 12), sano: true });
}
r = clasificarVersiones(
  conAtaque.map((v, i) => ({ id: 'v' + i, fechaMs: v.fechaMs, sano: v.sano })),
  { ahora: AHORA });
comprobar('Quedan versiones ANTERIORES al ataque',
  r.conservar.some((v) => v.sano === true),
  `sanas conservadas: ${r.conservar.filter((v) => v.sano).length}`);

titulo('El orden de entrada no cambia el resultado');
const desordenado = armar([hace(10, 8), hace(0), hace(10, 18), hace(11), hace(10, 12)]);
const a = clasificarVersiones(desordenado, { ahora: AHORA });
const b = clasificarVersiones([...desordenado].reverse(), { ahora: AHORA });
comprobar('Mismo resultado al revés', ids(a.conservar).join() === ids(b.conservar).join(),
  `${ids(a.conservar)} vs ${ids(b.conservar)}`);

titulo('La política se puede explicar en castellano');
const lineas = explicarPolitica();
comprobar('Da cuatro líneas legibles', lineas.length === 4 && /7 días/.test(lineas[0]),
  JSON.stringify(lineas));
comprobar('Y los valores por defecto son los acordados',
  POLITICA_POR_DEFECTO.todasHastaDias === 7 &&
  POLITICA_POR_DEFECTO.unaPorDiaHastaDias === 30 &&
  POLITICA_POR_DEFECTO.unaPorSemanaHastaDias === 180 &&
  POLITICA_POR_DEFECTO.unaPorMesHastaDias === 730,
  JSON.stringify(POLITICA_POR_DEFECTO));

console.log('\n──────────────────────────────');
console.log(`${pasadas} pasadas, ${falladas} falladas`);
if (falladas) { console.log('Fallaron:'); fallos.forEach((f) => console.log('  · ' + f)); }
process.exit(falladas ? 1 : 0);
