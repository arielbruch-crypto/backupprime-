'use strict';
/* El respaldo tiene que dar señal de vida al instante.

   ── El problema ──

   Entre apretar "Respaldar ahora" y ver algo en pantalla pasaban unos treinta
   segundos: se lee el registro (27 MB con 120.000 entradas), se pide el
   inventario del destino y se empiezan a recorrer las carpetas. Durante todo
   ese rato la pantalla no recibía NADA.

   Para el cliente eso es un botón que no funciona, así que lo aprieta otra vez.
   Y otra. En un producto que corre desatendido, un botón que parece muerto es
   la diferencia entre que confíen en él o que lo cierren.

   ── Y el error que esto destapó ──

   La primera versión de esta señal emitía el evento `"progress"`. El motor usa
   `"progreso"`, en castellano. O sea que se estaba avisando a un nombre que no
   escucha nadie: la pantalla seguía igual de muda. Ninguna prueba lo hubiera
   notado mirando el código — solo se ve corriendo el motor y contando qué
   llega.

     node pruebas/senal-de-vida.cjs                                           */

const fs = require('node:fs');
const fsp = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-vida-'));
process.env.BACKUPPRIME_CONFIG_DIR = path.join(TEMP, 'config');
fs.mkdirSync(process.env.BACKUPPRIME_CONFIG_DIR, { recursive: true });

const { crearServidorS3 } = require('./servidor-s3-prueba.cjs');
const { BackupEngine } = require('../electron/backup-engine.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — señal de vida al arrancar\n');

(async () => {
  const srv = crearServidorS3();
  const puerto = await srv.escuchar();
  const dest = {
    type: 's3', endpoint: `http://127.0.0.1:${puerto}`, region: 'us-east-1',
    bucket: 'respaldos', prefix: 'c/', accessKey: 'AKIA', secretKey: 'secreta',
    label: 'e2',
  };

  const origen = path.join(TEMP, 'origen');
  await fsp.mkdir(origen, { recursive: true });
  for (let i = 0; i < 1500; i++) {
    await fsp.writeFile(path.join(origen, `a${i}.docx`), Buffer.alloc(4096, 1));
  }

  const cfg = {
    server: '', token: '', localPaths: [origen], excludedPaths: [],
    destinations: [dest], maxVersions: 10, systemBackup: false,
    forceFullBackup: false, umbralBloquesMB: 25,
  };

  const motor = new BackupEngine();
  const arranque = Date.now();
  let primero = null;
  const fases = [];
  const avisos = [];
  motor.on('progreso', (p) => {
    if (primero === null) primero = Date.now() - arranque;
    if (!fases.includes(p.fase)) fases.push(p.fase);
    avisos.push(p);
  });
  await motor.runOnce(cfg);

  titulo('El primer aviso llega enseguida');

  comprobar('Hay avisos de progreso', avisos.length > 0,
    'el evento se llama "progreso", en castellano: emitirlo como "progress" ' +
    'avisa a un nombre que no escucha nadie y la pantalla queda muda');

  comprobar('El primero llega en menos de un segundo',
    primero !== null && primero < 1000,
    `tardó ${primero} ms — el cliente aprieta el botón de nuevo creyendo que no anda`);

  titulo('Y arranca diciendo que está preparando, no "0 archivos"');

  comprobar('La primera fase es "preparando"',
    avisos[0] && avisos[0].fase === 'preparando',
    `fue "${avisos[0] && avisos[0].fase}"`);

  comprobar('Sin números inventados todavía',
    avisos[0] && avisos[0].procesados === 0 && avisos[0].subidos === 0,
    'mostrar "0 revisados" hace creer que miró y no encontró nada');

  titulo('Después pasa por todas las fases, no se queda en la primera');

  // Este control es el que hubiera detectado el error del nombre del evento.
  // Con el evento mal escrito llegaba UNA sola fase y ninguna más.
  for (const f of ['preparando', 'analizando', 'subiendo', 'terminado']) {
    comprobar(`Se ve la fase "${f}"`, fases.includes(f), `vistas: ${fases.join(' → ')}`);
  }

  titulo('Y el aviso final no se pierde nunca');

  const fin = avisos[avisos.length - 1];
  comprobar('El último aviso es el de terminado', fin.fase === 'terminado',
    `fue "${fin.fase}" — el limitador de frecuencia no puede descartar el cierre`);
  comprobar('Con el total de lo que se copió', fin.subidos === 1500,
    `dice ${fin.subidos} de 1500`);

  await srv.cerrar();
  fs.rmSync(TEMP, { recursive: true, force: true });

  console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
  if (falladas) { console.log(fallos.map((f) => ` · ${f}`).join('\n')); process.exit(1); }
})().catch((e) => { console.error(e); process.exit(1); });
