'use strict';
/* El programa tiene que arrancar entero. Cargado, no leído.

   ── Por qué existe esta prueba, y por qué la anterior no servía ──

   En la 0.9.12 se registró por error un segundo `ipcMain.handle("fs:medir")`.
   Electron NO permite dos handlers para el mismo canal: tira

       Attempted to register a second handler for 'fs:medir'

   y `main.cjs` **se corta ahí**. Todo lo que se registra más abajo en el
   archivo deja de existir. El programa abría, pero la pestaña Restaurar decía
   "Cargando orígenes…" para siempre, y el arranque automático fallaba con
   "No handler registered". En un producto de respaldo eso significa que el
   cliente, el día del desastre, no puede recuperar NADA.

   La prueba que había buscaba el texto `ipcMain.handle("...")` dentro del
   archivo. El texto estaba: un archivo que revienta a mitad tiene todo su texto
   igual. Pasó en verde con la aplicación rota.

   La única forma de detectar esto es CARGAR el módulo y contar lo que se
   registra de verdad. Eso es lo que hace esto.

     node pruebas/arranque-completo.cjs                                       */

const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — el programa arranca entero\n');

const dirElectron = path.join(__dirname, '..', 'electron');

/**
 * Carga `main.cjs` con un Electron de mentira y devuelve qué pasó.
 *
 * El `ipcMain.handle` de acá se comporta como el de Electron de verdad:
 * **explota si el canal ya estaba registrado**. Sin esa regla, esta prueba no
 * detectaría el error que la hizo nacer.
 */
function cargarMain() {
  const registrados = [];
  const duplicados = [];
  let error = null;

  const nada = () => {};
  const ventana = function () {
    return {
      loadFile: nada, on: nada, once: nada, show: nada, hide: nada,
      isVisible: () => false, setMenu: nada, maximize: nada, minimize: nada,
      restore: nada, focus: nada, isMinimized: () => false, close: nada,
      destroy: nada, isDestroyed: () => false, setSkipTaskbar: nada,
      setProgressBar: nada, flashFrame: nada, setAlwaysOnTop: nada,
      webContents: {
        send: nada, on: nada, once: nada, openDevTools: nada,
        setWindowOpenHandler: nada, executeJavaScript: async () => {},
        session: { webRequest: { onHeadersReceived: nada } },
      },
    };
  };

  const electron = {
    app: {
      whenReady: () => Promise.resolve(), on: nada, once: nada, quit: nada,
      exit: nada, relaunch: nada, isPackaged: false, getName: () => 'BackupPrime',
      getVersion: () => '0.0.0-prueba', setAppUserModelId: nada,
      disableHardwareAcceleration: nada, requestSingleInstanceLock: () => true,
      setLoginItemSettings: nada, getLoginItemSettings: () => ({ openAtLogin: false }),
      getPath: (n) => path.join(require('node:os').tmpdir(), 'bp-arranque', String(n)),
    },
    BrowserWindow: Object.assign(ventana, {
      getAllWindows: () => [], fromWebContents: () => null,
    }),
    ipcMain: {
      handle(canal) {
        // Igual que Electron: un segundo handler para el mismo canal es un
        // error, no un reemplazo silencioso.
        if (registrados.includes(canal)) {
          duplicados.push(canal);
          throw new Error(`Attempted to register a second handler for '${canal}'`);
        }
        registrados.push(canal);
      },
      handleOnce(canal) { this.handle(canal); },
      on: nada, removeHandler: nada,
    },
    dialog: {
      showOpenDialog: async () => ({ canceled: true }),
      showSaveDialog: async () => ({ canceled: true }),
      showMessageBox: async () => ({ response: 0 }),
      showErrorBox: nada,
    },
    shell: { openExternal: nada, openPath: nada, showItemInFolder: nada },
    Tray: function () {
      return { setToolTip: nada, setContextMenu: nada, on: nada, destroy: nada,
               setImage: nada };
    },
    Menu: { buildFromTemplate: () => ({}), setApplicationMenu: nada,
            getApplicationMenu: () => null },
    nativeImage: {
      createEmpty: () => ({ isEmpty: () => true, resize: () => ({}) }),
      createFromPath: () => ({ isEmpty: () => true, resize: () => ({}) }),
      createFromDataURL: () => ({ isEmpty: () => true, resize: () => ({}) }),
    },
    safeStorage: {
      isEncryptionAvailable: () => false,
      encryptString: (s) => Buffer.from(String(s)),
      decryptString: (b) => Buffer.from(b).toString(),
    },
    powerSaveBlocker: { start: () => 1, stop: nada, isStarted: () => false },
    session: { defaultSession: { webRequest: { onHeadersReceived: nada } } },
    Notification: Object.assign(function () {
      return { show: nada, on: nada, close: nada };
    }, { isSupported: () => false }),
  };

  const cargarOriginal = Module._load;
  Module._load = function (pedido, ...resto) {
    if (pedido === 'electron') return electron;
    return cargarOriginal.call(this, pedido, ...resto);
  };
  try {
    delete require.cache[require.resolve(path.join(dirElectron, 'main.cjs'))];
    require(path.join(dirElectron, 'main.cjs'));
  } catch (e) {
    error = e;
  } finally {
    Module._load = cargarOriginal;
  }
  return { registrados, duplicados, error };
}

const r = cargarMain();

titulo('El package.json es JSON válido y la suite está completa');

// ── Por qué esto está acá ──
//
// Un `package.json` roto no lo detecta ninguna prueba de código: `npm run` no
// arranca, `npm install` falla, y el cliente recibe un zip que directamente no
// corre. Ya pasó dos veces en esta línea de trabajo por escapes mal puestos al
// editar el archivo con un script — la misma clase de error que la coma faltante
// que dejó el diccionario de idiomas sin cargar.
//
// Es el primer control de la primera prueba de la suite, a propósito.
{
  let paquete = null, error = null;
  try { paquete = JSON.parse(fs.readFileSync(path.join(dirElectron, '..', 'package.json'), 'utf8')); }
  catch (e) { error = e; }
  comprobar('package.json se puede leer', !!paquete, error ? error.message : '');
  if (paquete) {
    const archivos = String(paquete.scripts && paquete.scripts.pruebas || '').split('&&');
    comprobar('La suite tiene todas las pruebas', archivos.length > 40,
      `${archivos.length} archivos en el script`);
    const faltan = archivos
      .map((c) => (c.match(/pruebas\/([\w-]+\.cjs)/) || [])[1])
      .filter(Boolean)
      .filter((f) => !fs.existsSync(path.join(dirElectron, '..', 'pruebas', f)));
    comprobar('Y todas existen en el disco', faltan.length === 0, faltan.join(', '));
  }
}

titulo('main.cjs se carga entero, sin cortarse a mitad');

comprobar('No revienta al cargar', !r.error,
  r.error ? `${r.error.message} · si el módulo se corta, TODO lo que se registra ` +
            `después deja de existir y la pantalla queda con "No handler registered"`
          : '');

comprobar('No registra dos veces el mismo canal',
  r.duplicados.length === 0,
  r.duplicados.join(', ') + ' · Electron explota y el archivo se corta ahí mismo');

comprobar('Se registran todos los puentes, no unos pocos',
  r.registrados.length > 45,
  `${r.registrados.length} registrados — un número bajo significa que se cortó antes de terminar`);

titulo('Todo lo que la pantalla llama existe del otro lado');

const preload = fs.readFileSync(path.join(dirElectron, 'preload.cjs'), 'utf8');
const html = fs.readFileSync(path.join(dirElectron, 'renderer.html'), 'utf8');

const puentes = [];
for (const m of preload.matchAll(
    /(\w+)\s*:\s*\([^)]*\)\s*=>\s*ipcRenderer\.invoke\(\s*["'`]([^"'`]+)["'`]/g)) {
  puentes.push({ nombre: m[1], canal: m[2] });
}
const usados = puentes.filter((p) =>
  new RegExp('backupprime\\s*\\.\\s*' + p.nombre + '\\s*\\(').test(html));

comprobar('Se leyeron los puentes del preload', puentes.length > 30,
  `${puentes.length} declarados`);
// Si esto diera cero, los controles de abajo pasarían sin mirar nada. Ya pasó.
comprobar('Y la pantalla usa varios de ellos', usados.length > 20,
  `${usados.length} usados — con cero, el control de abajo no probaría nada`);

const huerfanos = usados.filter((p) => !r.registrados.includes(p.canal));
comprobar('Ningún puente que la pantalla usa queda sin handler',
  huerfanos.length === 0,
  huerfanos.map((h) => `${h.nombre} → "${h.canal}"`).join(' | ') +
  ' · el pedido queda colgado o falla, y el cliente ve la pantalla vacía');

titulo('Los caminos que el cliente necesita el día del desastre');

// Estos no son "unos canales más". Sin ellos no se puede restaurar, que es lo
// único que le importa a alguien que acaba de perder los datos.
for (const [canal, para] of [
  ['restore:list-local-destinations', 'ver desde dónde restaurar'],
  ['config:get-autostart', 'saber si el respaldo arranca solo'],
  ['fs:medir', 'saber cuánto pesa lo que se va a respaldar'],
  ['fs:accesos-rapidos', 'encontrar el PST de Outlook sin ser técnico'],
]) {
  comprobar(`Está "${canal}" — sirve para ${para}`, r.registrados.includes(canal));
}

console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
if (falladas) { console.log(fallos.map((f) => ` · ${f}`).join('\n')); process.exit(1); }
