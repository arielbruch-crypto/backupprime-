'use strict';
/* El seguidor de progreso de la restauración.

   Se prueba aparte porque calcula velocidad y tiempo restante a partir del
   reloj, y a mano eso se prueba mal: habría que esperar minutos para ver si la
   estimación tiene sentido.

     node pruebas/progreso-restauracion.cjs                                    */

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

// Misma lógica que main.cjs, con el reloj y el emisor inyectados.
function crearSeguidor(totalArchivos, totalBytes, emitirAfuera, reloj) {
  const ahoraMs = () => (reloj ? reloj() : Date.now());
  const inicio = ahoraMs();
  const muestras = [{ t: inicio, b: 0 }];
  let archivos = 0, bytes = 0, fallados = 0, actual = '';

  const velocidad = () => {
    const corte = ahoraMs() - 10000;
    while (muestras.length > 2 && muestras[0].t < corte) muestras.shift();
    const a = muestras[0], z = muestras[muestras.length - 1];
    const seg = (z.t - a.t) / 1000;
    return seg > 0.5 ? (z.b - a.b) / seg : 0;
  };

  function emitir() {
    const bps = velocidad();
    const faltan = Math.max(0, totalBytes - bytes);
    emitirAfuera({
      archivos, totalArchivos, bytes, totalBytes, fallados, actual,
      porcentaje: totalBytes > 0 ? Math.min(100, (bytes / totalBytes) * 100)
                : (totalArchivos ? (archivos / totalArchivos) * 100 : 0),
      bytesPorSegundo: bps,
      segundosRestantes: bps > 0 ? Math.round(faltan / bps) : null,
    });
  }

  return {
    empezar(n) { actual = n; emitir(); },
    sumar(n) { archivos++; bytes += n || 0; muestras.push({ t: ahoraMs(), b: bytes }); emitir(); },
    parcial(n) { bytes += n || 0; muestras.push({ t: ahoraMs(), b: bytes }); emitir(); },
    fallar() { fallados++; emitir(); },
    terminar() { actual = ''; emitir(); },
  };
}

console.log('BackupPrime — progreso de la restauración\n');

let t = 1000000;
const reloj = () => t;
let ultimo = null;
const s = crearSeguidor(4, 400, (p) => { ultimo = p; }, reloj);

titulo('Avance');
s.empezar('balance.xlsx');
comprobar('1. Arranca en cero', ultimo.porcentaje === 0 && ultimo.archivos === 0);
comprobar('2. Dice qué archivo está copiando', ultimo.actual === 'balance.xlsx');

t += 1000; s.sumar(100);
comprobar('3. Al terminar un archivo avanza', ultimo.archivos === 1 && ultimo.porcentaje === 25);
comprobar('4. Calcula la velocidad', ultimo.bytesPorSegundo === 100,
  String(ultimo.bytesPorSegundo));
comprobar('5. Y cuánto falta', ultimo.segundosRestantes === 3,
  String(ultimo.segundosRestantes));

titulo('Archivos grandes');
t += 1000; s.parcial(50);
comprobar('6. La barra se mueve dentro de un archivo grande',
  ultimo.porcentaje === 37.5 && ultimo.archivos === 1,
  `${ultimo.porcentaje}% con ${ultimo.archivos} archivos`);

titulo('Cuando algo falla');
s.fallar();
comprobar('7. Cuenta los que fallaron sin frenar el resto', ultimo.fallados === 1);

titulo('Estimación');
t += 8000; s.sumar(250);
comprobar('8. Nunca pasa del 100%', ultimo.porcentaje <= 100, String(ultimo.porcentaje));

// Diez segundos sin avanzar: la velocidad tiene que caer, no quedarse pegada
// en el promedio histórico.
t += 20000; s.parcial(0);
comprobar('9. Si se frena, la velocidad baja en vez de quedar pegada',
  ultimo.bytesPorSegundo < 50, String(ultimo.bytesPorSegundo));

titulo('Sin tamaños conocidos');
let u2 = null;
const s2 = crearSeguidor(2, 0, (p) => { u2 = p; }, reloj);
s2.sumar(0);
comprobar('10. Si no se sabe cuánto pesa, se mide por cantidad de archivos',
  u2.porcentaje === 50, String(u2.porcentaje));
comprobar('11. Y no inventa un tiempo restante', u2.segundosRestantes === null);

s.terminar();
comprobar('12. Al terminar deja de mostrar un archivo en curso', ultimo.actual === '');

console.log('\n──────────────────────────────────────────────────────');
console.log(`  ${pasadas} de ${pasadas + falladas} pruebas pasadas`);
if (falladas) { console.log('\n  Fallaron:'); for (const f of fallos) console.log(`    · ${f}`); }
console.log('──────────────────────────────────────────────────────\n');
process.exit(falladas ? 1 : 0);
