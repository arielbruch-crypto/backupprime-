'use strict';
/* La ruta de un archivo dentro del destino tiene que ser UNA sola.

   Había dos convenciones a la vez: guardando por bloques "C:\Users\..." quedaba
   como "C/Users/..." y guardando entero como "Users/...". El mismo archivo
   aparecía en dos ramas distintas del árbol, y restaurar una carpeta no traía
   los archivos grandes que estaban adentro.

     node pruebas/rutas-destino.cjs                                            */

const { rutaEnDestino } = require('../electron/backup-engine.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — la ruta dentro del destino\n');

titulo('Rutas de Windows');
comprobar('1. La letra de unidad queda como primera carpeta',
  rutaEnDestino('C:\\Users\\ana\\balance.xlsx') === 'C/Users/ana/balance.xlsx',
  rutaEnDestino('C:\\Users\\ana\\balance.xlsx'));
comprobar('2. Dos unidades distintas NO terminan en la misma clave',
  rutaEnDestino('C:\\datos\\plano.dwg') !== rutaEnDestino('D:\\datos\\plano.dwg'),
  `${rutaEnDestino('C:\\datos\\plano.dwg')} vs ${rutaEnDestino('D:\\datos\\plano.dwg')}`);
comprobar('3. La letra se normaliza en mayúscula',
  rutaEnDestino('c:\\datos\\x.txt') === 'C/datos/x.txt');
comprobar('4. Las barras invertidas se convierten',
  !rutaEnDestino('C:\\a\\b\\c.txt').includes('\\'));

titulo('Casos molestos');
comprobar('5. Barras repetidas no dejan segmentos vacíos',
  rutaEnDestino('C:\\\\a\\\\\\b.txt') === 'C/a/b.txt', rutaEnDestino('C:\\\\a\\\\\\b.txt'));
comprobar('6. No arranca con barra',
  !rutaEnDestino('C:\\a.txt').startsWith('/'));
comprobar('7. Una carpeta de red queda sin las barras iniciales',
  rutaEnDestino('\\\\servidor\\compartido\\x.txt') === 'servidor/compartido/x.txt',
  rutaEnDestino('\\\\servidor\\compartido\\x.txt'));
comprobar('8. No deja subir un nivel con ".."',
  !rutaEnDestino('C:\\a\\..\\..\\secreto.txt').includes('..'),
  rutaEnDestino('C:\\a\\..\\..\\secreto.txt'));
comprobar('9. Rutas de Linux también funcionan',
  rutaEnDestino('/home/ana/x.txt') === 'home/ana/x.txt');
comprobar('10. Acentos y espacios se conservan tal cual',
  rutaEnDestino('C:\\Clientes\\Balance Ferretería Ruiz (final).xlsx') ===
  'C/Clientes/Balance Ferretería Ruiz (final).xlsx');

titulo('Lo mismo para archivos grandes y chicos');
// El punto de todo: un PST guardado por bloques y un Word guardado entero, en la
// misma carpeta, tienen que caer en la misma rama.
const pst = rutaEnDestino('C:\\Users\\ana\\Documents\\Outlook Files\\correo.pst');
const doc = rutaEnDestino('C:\\Users\\ana\\Documents\\Outlook Files\\nota.docx');
comprobar('11. Comparten la carpeta en el destino',
  pst.slice(0, pst.lastIndexOf('/')) === doc.slice(0, doc.lastIndexOf('/')),
  `${pst}\n         ${doc}`);

console.log('\n──────────────────────────────────────────────────────');
console.log(`  ${pasadas} de ${pasadas + falladas} pruebas pasadas`);
if (falladas) { console.log('\n  Fallaron:'); for (const f of fallos) console.log(`    · ${f}`); }
console.log('──────────────────────────────────────────────────────\n');
process.exit(falladas ? 1 : 0);
