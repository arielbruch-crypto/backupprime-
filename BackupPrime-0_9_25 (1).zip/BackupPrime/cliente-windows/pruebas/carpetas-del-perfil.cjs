'use strict';
/* Las carpetas del perfil: sin AppData, y eligiendo con los números a la vista.

   ── Lo que estaba mal ──

   El botón "Perfil de Usuario" agregaba SIETE carpetas de una sola vez,
   incluida **`AppData\Roaming` entera**. Ahí adentro viven las configuraciones
   de todos los programas instalados: decenas de miles de archivos que cambian
   todo el tiempo, cachés que no se llaman "cache", bases de datos de
   aplicaciones abiertas y credenciales guardadas.

   Respaldarla es caro y sirve para poco: no se puede "restaurar" la
   configuración de un programa copiando esos archivos a otra máquina, porque
   están atados a la instalación y al usuario de Windows. Lo que el cliente
   necesita de ahí adentro son cosas concretas —el PST de Outlook— y esas van
   por su propio acceso rápido, por ruta exacta.

   Y además el cliente **no veía qué agregaba ni cuánto pesaba**: apretaba un
   botón y se encontraba con 284 GB seleccionados.

     node pruebas/carpetas-del-perfil.cjs                                     */

const fs = require('node:fs');
const path = require('node:path');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — las carpetas del perfil\n');

const dir = path.join(__dirname, '..', 'electron');
const main = fs.readFileSync(path.join(dir, 'main.cjs'), 'utf8');
const html = fs.readFileSync(path.join(dir, 'renderer.html'), 'utf8');

titulo('AppData NO entra, y no puede volver a entrar');

// Se aísla el handler para mirar solo lo que hace esa función.
const desde = main.indexOf('ipcMain.handle("fs:user-profile-paths"');
const hasta = main.indexOf('\n});', desde) + 4;
const handler = main.slice(desde, hasta);

comprobar('Se encontró el handler del perfil', desde > 0 && hasta > desde);

comprobar('No menciona AppData',
  !/AppData/i.test(handler),
  'AppData\\Roaming son decenas de miles de archivos de configuración que no ' +
  'sirven restaurados en otra máquina');

comprobar('Ni la variable de entorno APPDATA',
  !/APPDATA/.test(handler),
  'process.env.APPDATA es la otra forma de llegar al mismo lugar');

titulo('Se ofrecen las carpetas que la persona reconoce');

for (const c of ['Documents', 'Desktop', 'Pictures', 'Downloads', 'Videos', 'Music']) {
  comprobar(`Se ofrece ${c}`, handler.includes(`"${c}"`));
}

comprobar('Y también los nombres en castellano de Windows en español',
  handler.includes('"Documentos"') && handler.includes('"Escritorio"'),
  'en un Windows en español las carpetas se llaman distinto y no se ofrecería ninguna');

titulo('Lo pesado NO viene marcado, y se explica por qué');

// Descargas, Videos y Música son casi siempre las carpetas más grandes y las
// que menos falta hacen. Marcarlas por defecto es como alguien termina con
// 284 GB seleccionados sin haberlo decidido.
const sugeridas = [...handler.matchAll(/clave: "(\w+)"[^\n]*sugerida: (true|false)/g)]
  .map((m) => ({ clave: m[1], sugerida: m[2] === 'true' }));

comprobar('Se leyeron las carpetas y su marca', sugeridas.length >= 6,
  `${sugeridas.length} encontradas`);

for (const clave of ['documentos', 'escritorio', 'imagenes']) {
  comprobar(`${clave} viene marcada`,
    sugeridas.filter((s) => s.clave === clave).every((s) => s.sugerida),
    'es lo que el cliente casi siempre quiere');
}
// Videos SÍ viene marcado. Una versión anterior lo dejaba afuera "porque pesa
// mucho y rara vez es trabajo del estudio", y ese criterio estaba mal: **un
// video de un cumpleaños no se vuelve a grabar**. Es justo lo que la gente no
// quiere perder, y desmarcarlo es decidir que sus recuerdos valen menos que su
// cuota.
comprobar('videos viene marcada',
  sugeridas.filter((s) => s.clave === 'videos').every((s) => s.sugerida),
  'un video de un cumpleaños no se vuelve a grabar');

for (const clave of ['descargas', 'musica']) {
  comprobar(`${clave} NO viene marcada`,
    sugeridas.filter((s) => s.clave === clave).every((s) => !s.sugerida),
    'Descargas se vuelve a bajar y la música casi siempre está en streaming');
}

titulo('Y en pantalla se ve el motivo de lo que no está marcado');

for (const clave of ['descargas', 'videos', 'musica']) {
  comprobar(`Hay un motivo escrito para ${clave}`,
    html.includes(`"perfil-motivo-${clave}"`),
    'desmarcar algo sin decir por qué deja al cliente sin poder decidir distinto');
}

titulo('El tamaño que se muestra es el REAL, no un parcial');

// ── Por qué esto cambió ──
//
// La primera versión medía con un tope de 1,2 segundos por carpeta y mostraba
// "más de 3,94 GB" cuando la carpeta tenía 12 GB. Ese número parece exacto y
// está muy por debajo del real: el cliente decide con un dato falso, y encima
// una carpeta con recuerdos podía aparecer como "0 B" y quedar afuera.
//
// Ahora se mide sin tope, cada carpeta por separado, informando el parcial
// mientras cuenta para que el número suba en pantalla.
const medir = main.slice(main.indexOf('async function medirRuta'),
  main.indexOf('\n}\n', main.indexOf('async function medirRuta')));

comprobar('Hay un handler que mide UNA carpeta',
  main.includes('"fs:medir-carpeta"'),
  'medirlas todas juntas obliga a esperar a la más lenta para ver cualquier cosa');

comprobar('Se mide sin tope de tiempo',
  /tope\s*=\s*0/.test(medir) && /Infinity/.test(medir),
  'con tope, una carpeta de 12 GB muestra "más de 3,94 GB" y parece exacto');

comprobar('Informa el avance mientras cuenta',
  /alAvanzar/.test(medir),
  'sin avance, la espera parece que se colgó');

comprobar('La pantalla NO usa más el texto "más de" para el tamaño',
  !/t\('perfil-mas-de'/.test(html),
  'ese texto es el que hacía pasar un parcial por exacto');

comprobar('Y distingue una carpeta vacía de una sin medir',
  html.includes("'perfil-vacia'") && html.includes("'perfil-contando'"),
  '"0 B" en una carpeta con videos parece un error del programa');

comprobar('Una carpeta vacía no se puede marcar',
  /inutil/.test(html),
  'marcarla no hace nada y el cliente cree que respaldó algo');

titulo('La medición no cuenta lo que el respaldo no va a copiar');

comprobar('Descarta la basura del sistema al medir',
  /esBasuraDelSistema/.test(medir),
  'mostrar 54 GB y respaldar 20 sería mentirle al cliente en la cara');
comprobar('Y no sigue enlaces simbólicos',
  /isSymbolicLink|realpath/.test(medir),
  'un enlace que apunta a una carpeta padre no termina nunca');

titulo('La pantalla existe y se puede cancelar');

// ── Este control nació de un error propio ──
//
// Al reescribir la tarjeta se perdió el botón `perfilCerrar` del HTML, pero el
// código seguía haciendo `$('perfilCerrar').onclick = …`. Eso tira
// "Cannot set properties of null" y **corta el arranque de la pantalla ahí
// mismo**: todo lo que se configura después —los otros botones, el estado, la
// cuota— queda sin conectar. Un id que falta no es un detalle cosmético.
//
// Se verifica que TODO id usado con $('...') en el bloque del perfil exista en
// el HTML, no una lista escrita a mano: una lista a mano se olvida justo del
// que falta.
const usados = new Set(
  [...html.matchAll(/\$\('(perfil[A-Za-z]+)'\)/g)].map((m) => m[1]));

comprobar('Se encontraron los ids que usa el código', usados.size >= 5,
  `${usados.size} ids`);

const faltantes = [...usados].filter((id) => !html.includes(`id="${id}"`));
comprobar('Todos existen en el HTML',
  faltantes.length === 0,
  `falta(n) ${faltantes.join(', ')} · un id que falta corta el arranque de la ` +
  `pantalla entera, no solo ese botón`);

for (const id of ['perfilModal', 'perfilLista', 'perfilResumen', 'perfilAgregar',
                  'perfilCancelar', 'perfilCerrar']) {
  comprobar(`Está el elemento ${id}`, html.includes(`id="${id}"`));
}

titulo('Y midiendo un disco de verdad, la cuenta da bien');

// Los controles de arriba leen el código. Este CORRE la medición contra
// archivos reales, que es lo único que prueba que el número que ve el cliente
// sea el correcto. Se saca la función del propio `main.cjs`.
{
  const fsp = require('node:fs/promises');
  const os = require('node:os');
  const desdeM = main.indexOf('async function medirRuta');
  const hastaM = main.indexOf('\n}\n', desdeM) + 3;
  const BASURA = /^(thumbs\.db|desktop\.ini|\.ds_store|ntuser\.dat|usrclass\.dat)$/i;
  const medirRuta = new Function('fsp', 'path', 'esBasuraDelSistema',
    main.slice(desdeM, hastaM) + '\nreturn medirRuta;')(
      fsp, path, (n) => BASURA.test(n));

  const T = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-med-'));
  const proceso = (async () => {
    // Videos con contenido en SUBcarpetas: si la medición no bajara, daría 0 y
    // los recuerdos del cliente quedarían afuera sin que nadie se entere.
    const v = path.join(T, 'Videos', '2024', 'cumpleaños');
    await fsp.mkdir(v, { recursive: true });
    for (let k = 0; k < 12; k++) {
      await fsp.writeFile(path.join(v, `vid${k}.mp4`), Buffer.alloc(1048576, 1));
    }
    await fsp.writeFile(path.join(T, 'Videos', 'desktop.ini'), Buffer.alloc(300, 2));

    // Música con SOLO el desktop.ini de Windows: vacía de verdad.
    await fsp.mkdir(path.join(T, 'Music'), { recursive: true });
    await fsp.writeFile(path.join(T, 'Music', 'desktop.ini'), Buffer.alloc(300, 2));

    const avisos = [];
    const vid = await medirRuta(path.join(T, 'Videos'), 0, (x) => avisos.push(x));
    comprobar('Cuenta los archivos de las subcarpetas',
      vid.archivos === 12,
      `contó ${vid.archivos} de 12 — sin bajar a las subcarpetas, una carpeta ` +
      `llena de recuerdos aparece como vacía y queda afuera`);
    comprobar('Y suma bien los bytes',
      vid.bytes === 12 * 1048576, `${vid.bytes} bytes`);
    comprobar('Sin marcar el resultado como incompleto',
      vid.incompleto === false,
      'si se marca incompleto, la pantalla muestra un parcial como si fuera exacto');
    comprobar('No cuenta el desktop.ini de Windows',
      vid.archivos === 12,
      'contarlo mostraría un tamaño que el respaldo después no copia');

    const mus = await medirRuta(path.join(T, 'Music'), 0, null);
    comprobar('Una carpeta con solo desktop.ini da vacía',
      mus.archivos === 0 && mus.bytes === 0,
      `dio ${mus.archivos} archivos · ${mus.bytes} bytes`);
  })();
  proceso.then(() => {
    fs.rmSync(T, { recursive: true, force: true });
    cerrar();
  }).catch((e) => { console.error(e); process.exit(1); });
}

function cerrar() {
console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
if (falladas) { console.log(fallos.map((f) => ` · ${f}`).join('\n')); process.exit(1); }
}
