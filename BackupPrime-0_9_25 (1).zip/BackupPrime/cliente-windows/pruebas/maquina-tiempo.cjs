'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Volver una carpeta a como estaba en una fecha.
 
   Es distinto de restaurar versiones archivo por archivo, y es el caso que de
   verdad importa: cuando entra un ransomware nadie quiere recuperar UN archivo,
   quiere la carpeta entera como estaba el día antes.
 
   Lo que hay que demostrar:
     · que para cada archivo se elige la última versión anterior a la fecha;
     · que un archivo que en ese momento NO existía no aparece;
     · que un archivo borrado después sí aparece, porque entonces existía;
     · y que funciona igual con archivos guardados por bloques.
 
     node pruebas/maquina-tiempo.cjs
   ═══════════════════════════════════════════════════════════════════════════ */

const fs = require('node:fs');
const fsp = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-mt-'));
process.env.BACKUPPRIME_CONFIG_DIR = path.join(TEMP, 'config');
fs.mkdirSync(process.env.BACKUPPRIME_CONFIG_DIR, { recursive: true });

const { crearServidorS3 } = require('./servidor-s3-prueba.cjs');
const { BackupEngine, s3Versiones, s3Descargar, almacenDeBloques } =
  require('../electron/backup-engine.cjs');
const Bloques = require('../electron/bloques.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);
const esperar = (ms) => new Promise((r) => setTimeout(r, ms));

/** La misma lógica que usa el programa: la última versión anterior al corte. */
function versionALaFecha(lista, corte) {
  return lista
    .filter((v) => !v.borrado && v.fecha && new Date(v.fecha) <= corte)
    .sort((a, b) => new Date(b.fecha) - new Date(a.fecha))[0] || null;
}

console.log('BackupPrime — volver a como estaba en una fecha\n');

(async () => {
  const srv = crearServidorS3();
  const puerto = await srv.escuchar();
  const dest = {
    type: 's3', endpoint: `http://127.0.0.1:${puerto}`, region: 'us-east-1',
    bucket: 'respaldos', prefix: 'cliente/', accessKey: 'AKIA', secretKey: 'secreta',
    label: 'e2',
  };

  const carpeta = path.join(TEMP, 'origen', 'Clientes');
  await fsp.mkdir(carpeta, { recursive: true });

  const motor = new BackupEngine();
  const errores = [];
  motor.on('log', (l) => { if (l.includes('[error]')) errores.push(l.trim()); });

  const cfg = {
    server: '', token: '', localPaths: [path.join(TEMP, 'origen')], excludedPaths: [],
    destinations: [dest], maxVersions: 10, systemBackup: false, forceFullBackup: false,
    umbralBloquesMB: 1,   // para que el grande vaya por bloques en la prueba
  };
  const limpiarEstado = () => {
    try { fs.unlinkSync(path.join(process.env.BACKUPPRIME_CONFIG_DIR, 'state.json')); } catch {}
  };

  // ── Lunes: dos archivos ───────────────────────────────────────────────────
  titulo('Tres días de trabajo');

  await fsp.writeFile(path.join(carpeta, 'balance.xlsx'), 'balance del lunes');
  const grande = Buffer.allocUnsafe(3 * 1048576);
  crypto.randomFillSync(grande);
  await fsp.writeFile(path.join(carpeta, 'contabilidad.mdb'), grande);
  await motor.runOnce(cfg);
  await esperar(1100);
  const lunes = new Date();

  // ── Martes: cambia uno y aparece otro ────────────────────────────────────
  await esperar(1100);
  await fsp.writeFile(path.join(carpeta, 'balance.xlsx'), 'balance del martes, corregido');
  await fsp.writeFile(path.join(carpeta, 'IVA.pdf'), 'declaración del martes');
  const conMasDatos = Buffer.from(grande);
  crypto.randomFillSync(conMasDatos, conMasDatos.length - 524288, 524288);
  await fsp.writeFile(path.join(carpeta, 'contabilidad.mdb'), conMasDatos);
  limpiarEstado();
  await motor.runOnce(cfg);
  await esperar(1100);
  const martes = new Date();

  // ── Miércoles: un virus cifra todo ───────────────────────────────────────
  await esperar(1100);
  await fsp.writeFile(path.join(carpeta, 'balance.xlsx'), 'CIFRADO POR UN VIRUS');
  await fsp.writeFile(path.join(carpeta, 'IVA.pdf'), 'CIFRADO POR UN VIRUS');
  await fsp.writeFile(path.join(carpeta, 'contabilidad.mdb'), Buffer.alloc(3 * 1048576, 0xff));
  limpiarEstado();
  await motor.runOnce(cfg);

  comprobar('1. Los tres respaldos salieron sin errores', errores.length === 0, errores[0] || '');

  // ── Reconstruir el estado del martes ─────────────────────────────────────
  titulo('Volver al martes, después del ataque del miércoles');

  const prefijo = 'cliente/';
  const [directos, indices] = await Promise.all([
    s3Versiones(dest, prefijo),
    s3Versiones(dest, `${prefijo}indices/`),
  ]);

  const elegidos = [];
  for (const [clave, lista] of directos) {
    const rel = clave.slice(prefijo.length);
    if (rel.startsWith('indices/') || rel.startsWith('bloques/') || rel.endsWith('.bpi')) continue;
    const v = versionALaFecha(lista, martes);
    if (v) elegidos.push({ rel, clave, versionId: v.versionId });
  }
  for (const [clave, lista] of indices) {
    if (!clave.endsWith('.bpi')) continue;   // el catálogo no es un archivo
    const rel = clave.replace(`${prefijo}indices/`, '').replace(/\.bpi$/, '');
    const v = versionALaFecha(lista, martes);
    if (v) elegidos.push({ rel, versionId: v.versionId, porBloques: true });
  }

  comprobar('2. Encuentra los tres archivos que existían el martes',
    elegidos.length === 3, `${elegidos.length}: ` + elegidos.map((e) => e.rel).join(', '));

  const salida = path.join(TEMP, 'al-martes');
  const almacen = almacenDeBloques(dest);
  for (const e of elegidos) {
    const destinoLocal = path.join(salida, ...e.rel.split('/'));
    if (e.porBloques) {
      await Bloques.restaurarPorBloques(almacen, {
        rutaRelativa: e.rel, destinoLocal, prefijo, versionIndice: e.versionId,
      });
    } else {
      await s3Descargar(dest, e.clave, destinoLocal, e.versionId);
    }
  }

  const leer = (rel) => fs.readFileSync(path.join(salida, ...rel.split('/')));
  const relBalance = elegidos.find((e) => e.rel.endsWith('balance.xlsx')).rel;
  const relIva = elegidos.find((e) => e.rel.endsWith('IVA.pdf')).rel;
  const relMdb = elegidos.find((e) => e.rel.endsWith('contabilidad.mdb')).rel;

  comprobar('3. El balance vuelve con el contenido del martes, no el cifrado',
    leer(relBalance).toString() === 'balance del martes, corregido',
    leer(relBalance).toString().slice(0, 40));
  comprobar('4. La declaración también', leer(relIva).toString() === 'declaración del martes');
  comprobar('5. Y el archivo grande, guardado por bloques, vuelve igual al del martes',
    leer(relMdb).equals(conMasDatos));
  comprobar('6. Ninguno quedó con el contenido del virus',
    !leer(relBalance).includes('VIRUS') && !leer(relIva).includes('VIRUS'));

  // ── Volver al lunes: la declaración todavía no existía ───────────────────
  titulo('Volver al lunes: hay un archivo que todavía no existía');

  const alLunes = [];
  for (const [clave, lista] of directos) {
    const rel = clave.slice(prefijo.length);
    if (rel.startsWith('indices/') || rel.startsWith('bloques/') || rel.endsWith('.bpi')) continue;
    const v = versionALaFecha(lista, lunes);
    if (v) alLunes.push({ rel, clave, versionId: v.versionId });
  }
  for (const [clave, lista] of indices) {
    if (!clave.endsWith('.bpi')) continue;
    const rel = clave.replace(`${prefijo}indices/`, '').replace(/\.bpi$/, '');
    const v = versionALaFecha(lista, lunes);
    if (v) alLunes.push({ rel, versionId: v.versionId, porBloques: true });
  }

  comprobar('7. El lunes había dos archivos, no tres', alLunes.length === 2,
    `${alLunes.length}: ` + alLunes.map((e) => e.rel).join(', '));
  comprobar('8. La declaración del martes no aparece en el estado del lunes',
    !alLunes.some((e) => e.rel.endsWith('IVA.pdf')));

  const salidaLunes = path.join(TEMP, 'al-lunes');
  for (const e of alLunes) {
    const destinoLocal = path.join(salidaLunes, ...e.rel.split('/'));
    if (e.porBloques) {
      await Bloques.restaurarPorBloques(almacen, {
        rutaRelativa: e.rel, destinoLocal, prefijo, versionIndice: e.versionId });
    } else {
      await s3Descargar(dest, e.clave, destinoLocal, e.versionId);
    }
  }
  comprobar('9. Y el balance del lunes es el del lunes',
    fs.readFileSync(path.join(salidaLunes, ...relBalance.split('/'))).toString() === 'balance del lunes');
  comprobar('10. El archivo grande también vuelve a su versión del lunes',
    fs.readFileSync(path.join(salidaLunes, ...relMdb.split('/'))).equals(grande));

  titulo('Una fecha anterior a todo');
  const antes = new Date(Date.now() - 10 * 86400000);
  const nada = [];
  for (const [, lista] of directos) if (versionALaFecha(lista, antes)) nada.push(1);
  comprobar('11. Antes del primer respaldo no hay nada para restaurar', nada.length === 0);

  await srv.cerrar();

  console.log('\n──────────────────────────────────────────────────────');
  console.log(`  ${pasadas} de ${pasadas + falladas} pruebas pasadas`);
  if (falladas) { console.log('\n  Fallaron:'); for (const f of fallos) console.log(`    · ${f}`); }
  console.log('──────────────────────────────────────────────────────\n');
  try { fs.rmSync(TEMP, { recursive: true, force: true }); } catch {}
  process.exit(falladas ? 1 : 0);
})();
