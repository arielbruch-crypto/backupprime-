'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Poco espacio libre en disco.

   Esta prueba existe por un caso real: un cliente con el disco casi lleno
   respaldó 134 GB y la máquina se colgó.

   La causa no es el respaldo en sí. Los bloques se arman en memoria y se suben
   directo, sin copia temporal del archivo: el motor casi no toca el disco. El
   que consume es la INSTANTÁNEA de volumen — Windows reserva espacio en el mismo
   disco y lo va llenando con cada bloque que cambia mientras el respaldo corre,
   hasta un 10% del volumen por defecto. Con el disco al límite, Windows pelea por
   espacio y la máquina se arrastra hasta trabarse.

   No había ningún control: el programa arrancaba igual y dejaba que pasara.

   Un respaldo que cuelga la computadora del cliente es peor que un respaldo que
   no corre. La regla es: avisar, no crear instantáneas, y seguir respaldando —
   porque leer los archivos directamente funciona para casi todo y casi no usa
   disco.

     node pruebas/espacio-en-disco.cjs
   ═══════════════════════════════════════════════════════════════════════════ */

const fs = require('node:fs');
const fsp = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-espacio-'));
process.env.BACKUPPRIME_CONFIG_DIR = path.join(TEMP, 'config');
fs.mkdirSync(process.env.BACKUPPRIME_CONFIG_DIR, { recursive: true });

const { crearServidorS3 } = require('./servidor-s3-prueba.cjs');
const { BackupEngine } = require('../electron/backup-engine.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);
const GB = 1024 * 1024 * 1024;

console.log('BackupPrime — poco espacio libre en disco\n');

/** Simula el espacio que informa el sistema, para no depender del disco real. */
function conEspacio(libre, total, fn) {
  const original = fsp.statfs;
  fsp.statfs = async () => ({ bavail: libre / 4096, bsize: 4096, blocks: total / 4096 });
  return Promise.resolve().then(fn).finally(() => { fsp.statfs = original; });
}

(async () => {
  const srv = crearServidorS3();
  const puerto = await srv.escuchar();

  const origen = path.join(TEMP, 'origen');
  fs.mkdirSync(origen, { recursive: true });
  fs.writeFileSync(path.join(origen, 'balance.xlsx'), 'contenido');

  const cfg = {
    server: '', token: '', localPaths: [origen], excludedPaths: [],
    destinations: [{
      type: 's3', enabled: true, label: 'e2',
      endpoint: `http://127.0.0.1:${puerto}`, region: 'us-east-1',
      bucket: 'respaldos', prefix: 'cliente/', accessKey: 'AKIA', secretKey: 'secreta',
    }],
    maxVersions: 10, systemBackup: false, forceFullBackup: false,
  };
  const limpiar = () => {
    try { fs.unlinkSync(path.join(process.env.BACKUPPRIME_CONFIG_DIR, 'state.json')); } catch {}
  };

  /** Corre un respaldo con un espacio simulado y devuelve el registro y el progreso. */
  async function correr(libre, total) {
    limpiar();
    const motor = new BackupEngine();
    const registro = [];
    const avisos = [];
    motor.on('log', (l) => registro.push(String(l)));
    motor.on('progreso', (p) => avisos.push(JSON.parse(JSON.stringify(p))));
    await conEspacio(libre, total, () => motor.runOnce(cfg));
    return { registro: registro.join('\n'), avisos };
  }

  titulo('Disco con espacio de sobra: no molesta a nadie');
  {
    const { registro, avisos } = await correr(400 * GB, 500 * GB);
    comprobar('no avisa nada sobre el espacio', !/Poco espacio/i.test(registro),
      registro.split('\n').find((l) => /espacio/i.test(l)) || '');
    comprobar('el respaldo termina bien', /terminado/i.test(registro));
    const ultimo = avisos[avisos.length - 1] || {};
    comprobar('la pantalla no muestra ningún aviso de espacio', !ultimo.espacio,
      JSON.stringify(ultimo.espacio));
  }

  titulo('Disco apretado: avisa y NO usa instantáneas');
  {
    // 20 GB libres de 500 GB = 4%. Por debajo del 15% y de los 10 GB de holgura.
    const { registro, avisos } = await correr(8 * GB, 500 * GB);
    comprobar('avisa que hay poco espacio', /Poco espacio libre/i.test(registro),
      registro.split('\n').find((l) => /espacio/i.test(l)) || '');
    comprobar('dice cuánto queda y de cuánto',
      /8[.,]00? GB de 500/.test(registro),
      registro.split('\n').find((l) => /espacio/i.test(l)) || '');

    // El aviso de instantáneas solo aparece en Windows: fuera de Windows no se
    // intentan crear, así que no hay nada que desactivar. Se comprueba sobre el
    // código, que es lo que va a correr en la máquina del cliente.
    const motorSrc = fs.readFileSync(
      path.join(__dirname, '..', 'electron', 'backup-engine.cjs'), 'utf8');
    comprobar('con poco espacio no se crean instantáneas',
      /if \(!espacio\.ok\)[\s\S]{0,600}vssPedido = false/.test(motorSrc),
      'crear una copia sombra con el disco lleno es lo que traba la máquina');

    // Lo importante: el respaldo NO se cancela.
    comprobar('el respaldo se hace igual', /terminado/i.test(registro),
      'leer los archivos directamente casi no usa disco: no hay razón para no respaldar');

    const conEsp = avisos.find((p) => p.espacio && p.espacio.apretadas.length);
    comprobar('la pantalla recibe el aviso', !!conEsp, 'el cliente tiene que enterarse');
    if (conEsp) {
      const u = conEsp.espacio.apretadas[0];
      comprobar('el aviso trae la unidad, lo libre y el porcentaje',
        !!u.unidad && u.libre > 0 && u.total > 0 && typeof u.porcentaje === 'number',
        JSON.stringify(u));
    }
  }

  titulo('Disco al límite: además avisa que conviene liberar espacio');
  {
    const { registro, avisos } = await correr(1 * GB, 500 * GB);   // 0,2%
    comprobar('marca la situación como crítica',
      avisos.some((p) => p.espacio && p.espacio.critica === true));
    comprobar('explica por qué importa',
      /Windows se vuelve lento|liberar espacio/i.test(registro),
      registro.split('\n').filter((l) => /espacio/i.test(l)).join(' | ').slice(0, 160));
    comprobar('aun así respalda', /terminado/i.test(registro),
      'con el disco lleno es cuando MÁS conviene tener los archivos a salvo');
  }

  titulo('Los umbrales');
  {
    // 12 GB libres de 500 GB: solo 2,4%, pero más de 10 GB de holgura. Alcanza
    // para una instantánea, así que no hay por qué molestar al cliente.
    const holgado = await correr(12 * GB, 500 * GB);
    comprobar('con más de 10 GB libres no avisa', !/Poco espacio/i.test(holgado.registro),
      'un disco grande con 12 GB libres tiene margen de sobra para trabajar');

    // 6 GB libres de 20 GB: 30%, poco en términos absolutos pero mucho en
    // proporción. Un disco chico tampoco tiene que dar aviso constantemente.
    const chico = await correr(6 * GB, 20 * GB);
    comprobar('con 30% libre en un disco chico tampoco avisa',
      !/Poco espacio/i.test(chico.registro),
      'el criterio es 10 GB O 15%: alcanza con cumplir uno de los dos');
  }

  titulo('Varias carpetas de la misma unidad se cuentan una sola vez');
  {
    const otra = path.join(TEMP, 'otra');
    fs.mkdirSync(otra, { recursive: true });
    fs.writeFileSync(path.join(otra, 'x.txt'), 'x');
    limpiar();
    const motor = new BackupEngine();
    const registro = [];
    motor.on('log', (l) => registro.push(String(l)));
    await conEspacio(8 * GB, 500 * GB,
      () => motor.runOnce({ ...cfg, localPaths: [origen, otra] }));
    const cuantos = registro.filter((l) => /Poco espacio libre/i.test(l)).length;
    comprobar('el aviso sale una sola vez', cuantos === 1,
      `salió ${cuantos} veces — repetirlo por cada carpeta es ruido`);
  }

  await srv.cerrar();
  try { fs.rmSync(TEMP, { recursive: true, force: true }); } catch {}

  console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
  if (falladas) { console.log('Fallaron:'); fallos.forEach((f) => console.log('  · ' + f)); }
  process.exit(falladas ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
