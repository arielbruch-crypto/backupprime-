'use strict';
// Busca identificadores que se usan pero no están declarados en ninguna parte:
// exactamente el caso de copyToLocalDest, que se llamaba y no existía, y que
// el intérprete solo descubre cuando ese renglón se ejecuta de verdad.
//
//   node pruebas/identificadores.cjs

const fs = require('node:fs');
const path = require('node:path');
const acorn = require('acorn');
const walk = require('acorn-walk');

const GLOBALES = new Set([
  'require', 'module', 'exports', '__dirname', '__filename', 'process', 'console',
  'Buffer', 'setTimeout', 'clearTimeout', 'setInterval', 'clearInterval',
  'setImmediate', 'queueMicrotask', 'globalThis', 'global', 'URL', 'URLSearchParams',
  'TextEncoder', 'TextDecoder', 'AbortController', 'structuredClone', 'fetch',
  'Object', 'Array', 'String', 'Number', 'Boolean', 'Symbol', 'BigInt', 'Math',
  'JSON', 'Date', 'RegExp', 'Error', 'TypeError', 'RangeError', 'SyntaxError',
  'Promise', 'Map', 'Set', 'WeakMap', 'WeakSet', 'Proxy', 'Reflect', 'Intl',
  'ArrayBuffer', 'Uint8Array', 'Uint32Array', 'Int32Array', 'Float64Array', 'DataView', 'isNaN', 'isFinite', 'parseInt',
  'parseFloat', 'encodeURIComponent', 'decodeURIComponent', 'undefined', 'NaN',
  'Infinity', 'arguments', 'window', 'document', 'navigator', 'location',
  'localStorage', 'sessionStorage', 'alert', 'confirm', 'FileReader', 'Blob',
  'Image', 'Event', 'CustomEvent', 'MutationObserver', 'requestAnimationFrame',
  'performance', 'crypto', 'btoa', 'atob', 'AbortSignal', 'Notification', 'CSS',
]);

function declaracionesDe(nodo) {
  // Nombres que un nodo introduce en su ámbito
  const nombres = [];
  const patron = (p) => {
    if (!p) return;
    if (p.type === 'Identifier') nombres.push(p.name);
    else if (p.type === 'ObjectPattern') p.properties.forEach((pr) =>
      patron(pr.type === 'RestElement' ? pr.argument : pr.value));
    else if (p.type === 'ArrayPattern') p.elements.forEach(patron);
    else if (p.type === 'AssignmentPattern') patron(p.left);
    else if (p.type === 'RestElement') patron(p.argument);
  };
  if (nodo.type === 'VariableDeclaration') nodo.declarations.forEach((d) => patron(d.id));
  if (nodo.type === 'FunctionDeclaration' || nodo.type === 'ClassDeclaration') {
    if (nodo.id) nombres.push(nodo.id.name);
  }
  if (/Function/.test(nodo.type)) {
    if (nodo.id) nombres.push(nodo.id.name);
    (nodo.params || []).forEach(patron);
  }
  if (nodo.type === 'CatchClause') patron(nodo.param);
  if (nodo.type === 'ClassExpression' && nodo.id) nombres.push(nodo.id.name);
  return nombres;
}

function analizar(codigo, etiqueta) {
  let ast;
  try {
    ast = acorn.parse(codigo, { ecmaVersion: 2023, sourceType: 'script', locations: true });
  } catch (e) {
    return [{ nombre: '(no se pudo interpretar)', linea: e.loc ? e.loc.line : 0, etiqueta, detalle: e.message }];
  }

  // Todos los nombres declarados en cualquier ámbito del archivo. Es una
  // aproximación deliberadamente amplia: preferimos no avisar de más.
  const declarados = new Set(GLOBALES);
  walk.full(ast, (n) => { for (const d of declaracionesDe(n)) declarados.add(d); });
  walk.full(ast, (n) => {
    if (n.type === 'LabeledStatement') declarados.add(n.label.name);
    if (n.type === 'Property' && n.key && n.key.type === 'Identifier' && !n.computed) {
      /* claves de objeto: no son referencias */
    }
  });

  const faltantes = new Map();
  const visitar = (n, esRef) => { if (esRef && !declarados.has(n.name)) faltantes.set(n.name, n.loc.start.line); };

  walk.ancestor(ast, {
    Identifier(nodo, estado, ancestros) {
      const padre = ancestros[ancestros.length - 2];
      if (!padre) return;
      // No son referencias: claves de objeto, propiedades, etiquetas, declaraciones
      if (padre.type === 'MemberExpression' && padre.property === nodo && !padre.computed) return;
      if (padre.type === 'Property' && padre.key === nodo && !padre.computed) return;
      if (padre.type === 'MethodDefinition' || padre.type === 'PropertyDefinition') return;
      if (padre.type === 'LabeledStatement' || padre.type === 'BreakStatement' || padre.type === 'ContinueStatement') return;
      if (padre.type === 'ExportSpecifier' || padre.type === 'ImportSpecifier') return;
      visitar(nodo, true);
    },
  });

  return [...faltantes].map(([nombre, linea]) => ({ nombre, linea, etiqueta }));
}

const archivos = process.argv.slice(2);
let problemas = [];

for (const f of archivos) {
  const crudo = fs.readFileSync(f, 'utf8');
  if (f.endsWith('.html')) {
    const bloques = [...crudo.matchAll(/<script>([\s\S]*?)<\/script>/g)];
    for (const b of bloques) problemas.push(...analizar(b[1], path.basename(f)));
  } else {
    problemas.push(...analizar(crudo, path.basename(f)));
  }
}

console.log('Identificadores usados que no están declarados en ninguna parte\n');
if (!problemas.length) {
  console.log('  Ninguno.\n');
  process.exit(0);
}
for (const p of problemas) {
  console.log(`  ${p.etiqueta}:${p.linea}  ${p.nombre}${p.detalle ? '  — ' + p.detalle : ''}`);
}
console.log(`\n  ${problemas.length} para revisar.\n`);
process.exit(1);
