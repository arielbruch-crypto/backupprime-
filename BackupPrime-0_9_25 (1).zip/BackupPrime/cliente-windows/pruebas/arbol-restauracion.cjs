'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   El árbol de restauración: qué pasa al hacer clic.

   Esta prueba existe porque el panel "Versiones anteriores" no se abría al hacer
   clic en el nombre de un archivo, que es exactamente lo que el panel pide
   ("Hacé clic en un archivo para ver las versiones"). La causa: el `<span>` con
   el nombre llevaba `data-toggle` también en los archivos, y el handler de
   `data-toggle` hacía `ev.stopPropagation()` ANTES de comprobar si el nodo era
   una carpeta. El evento moría ahí y nunca llegaba al handler de la fila.

   No había ninguna prueba de DOM del lado del cliente, así que nada podía
   agarrar esto: todas las pruebas del cliente son del motor. Esta abre el árbol
   en un navegador simulado y hace los clics de verdad.

     node pruebas/arbol-restauracion.cjs
   ═══════════════════════════════════════════════════════════════════════════ */

const fs = require('node:fs');
const path = require('node:path');

let JSDOM;
try {
  ({ JSDOM } = require('jsdom'));
} catch {
  console.log('Falta jsdom. Instalalo con: npm install');
  process.exit(1);
}

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — clics en el árbol de restauración\n');

// El árbol de tres archivos y sus carpetas, como el del bucket real.
const ARBOL = [{
  name: 'C', relPath: 'C', type: 'folder', fileCount: 3,
  children: [{
    name: 'Users', relPath: 'C/Users', type: 'folder', fileCount: 3,
    children: [{
      name: 'Outlook Files', relPath: 'C/Users/Outlook Files', type: 'folder', fileCount: 3,
      children: [
        { name: '~correo.pst.tmp', relPath: 'C/Users/Outlook Files/~correo.pst.tmp',
          type: 'file', size: 131072 },
        { name: 'correo.pst', relPath: 'C/Users/Outlook Files/correo.pst',
          type: 'file', size: 683051008 },
        { name: 'correo.pst.bpi', relPath: 'C/Users/Outlook Files/correo.pst.bpi',
          type: 'file', size: 6349 },
      ],
    }],
  }],
}];

const RENDERER = path.join(__dirname, '..', 'electron', 'renderer.html');

(async () => {
  const html = fs.readFileSync(RENDERER, 'utf8');

  // Se registra a quién se le pidieron las versiones. Es lo que la prueba mide:
  // no el dibujo del panel, sino si el clic llega a disparar la consulta.
  const pedidos = [];

  const dom = new JSDOM(html, {
    runScripts: 'dangerously',
    pretendToBeVisual: true,
    beforeParse(win) {
      // El puente con el proceso principal no existe en el navegador simulado.
      // Se responde lo mínimo para que la pantalla funcione.
      const vacio = async () => ({});
      win.backupprime = new Proxy({}, {
        get: (_t, prop) => {
          if (prop === 'restoreVersiones') {
            return async (id, relPath) => {
              pedidos.push(relPath);
              return { versiones: [], nombre: String(relPath).split('/').pop() };
            };
          }
          if (String(prop).startsWith('on')) return () => {};
          return vacio;
        },
      });
    },
  });

  const win = dom.window;
  await new Promise((r) => {
    if (win.document.readyState === 'complete') return r();
    win.addEventListener('load', r);
  });

  const api = win.__pruebasRestore;
  comprobar('la pantalla expone un punto de entrada para probar el árbol', !!api,
    'falta `window.__pruebasRestore` en renderer.html');
  if (!api) {
    console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
    process.exit(1);
  }

  api.cargarArbol(ARBOL);
  api.expandirTodo();

  const doc = win.document;
  const clic = (el) => el.dispatchEvent(new win.MouseEvent('click', { bubbles: true }));
  const RUTA_PST = 'C/Users/Outlook Files/correo.pst';
  // Se busca comparando el dataset en vez de armar un selector: las rutas
  // tienen espacios y caracteres que habría que escapar.
  const filaDe = (rel) =>
    [...doc.querySelectorAll('.trow[data-file]')].find((f) => f.dataset.file === rel);

  titulo('El árbol se dibuja');
  comprobar('aparecen los tres archivos',
    doc.querySelectorAll('.trow[data-file]').length === 3,
    `hay ${doc.querySelectorAll('.trow[data-file]').length}`);

  titulo('Clic en el NOMBRE del archivo (el error original)');
  {
    pedidos.length = 0;
    const fila = filaDe(RUTA_PST);
    comprobar('la fila del PST existe', !!fila);
    if (fila) {
      clic(fila.querySelector('.tname'));
      comprobar('pide las versiones de ese archivo',
        pedidos.includes(RUTA_PST),
        `se pidió: ${JSON.stringify(pedidos)}`);
    }
  }

  titulo('El nombre de un archivo no lleva data-toggle');
  {
    // Es la raíz del error: `data-toggle` en un archivo no tiene nada que
    // expandir, y su handler cortaba el evento.
    const conToggle = [...doc.querySelectorAll('.trow[data-file] .tname[data-toggle]')];
    comprobar('ningún nombre de archivo tiene data-toggle', conToggle.length === 0,
      `${conToggle.length} lo tienen`);
  }

  titulo('Clic en el botón del reloj');
  {
    pedidos.length = 0;
    const fila = filaDe(RUTA_PST);
    if (fila) clic(fila.querySelector('.tver'));
    comprobar('pide las versiones', pedidos.includes(RUTA_PST),
      `se pidió: ${JSON.stringify(pedidos)}`);
  }

  titulo('Tildar la casilla del archivo');
  {
    pedidos.length = 0;
    const fila = filaDe(RUTA_PST);
    const cb = fila && fila.querySelector('input[type=checkbox]');
    if (cb) { cb.checked = true; cb.dispatchEvent(new win.Event('change', { bubbles: true })); }
    comprobar('tildar un archivo también trae sus versiones',
      pedidos.includes(RUTA_PST),
      `se pidió: ${JSON.stringify(pedidos)}`);
  }

  titulo('Las carpetas siguen expandiéndose y contrayéndose');
  {
    pedidos.length = 0;
    const nombreCarpeta = [...doc.querySelectorAll('.trow')]
      .find((f) => !f.dataset.file && f.textContent.includes('Outlook Files'))
      ?.querySelector('.tname');
    comprobar('el nombre de la carpeta existe', !!nombreCarpeta);
    if (nombreCarpeta) {
      const antes = doc.querySelectorAll('.trow[data-file]').length;
      clic(nombreCarpeta);
      const despues = doc.querySelectorAll('.trow[data-file]').length;
      comprobar('clic en el nombre de una carpeta la contrae', despues < antes,
        `${antes} → ${despues}`);
      comprobar('clic en una carpeta NO pide versiones', pedidos.length === 0,
        `se pidió: ${JSON.stringify(pedidos)}`);
    }
  }

  titulo('Tildar una carpeta no pide versiones de cada archivo');
  {
    api.cargarArbol(ARBOL);
    api.expandirTodo();
    pedidos.length = 0;
    const cb = doc.querySelector('input[data-sel="C/Users/Outlook Files"]');
    if (cb) { cb.checked = true; cb.dispatchEvent(new win.Event('change', { bubbles: true })); }
    comprobar('tildar una carpeta no dispara consultas por archivo',
      pedidos.length === 0,
      `se pidieron ${pedidos.length}: una consulta por archivo tildado sería una ` +
      `tormenta de pedidos en un backup real`);
  }

  win.close();
  console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
  if (falladas) { console.log('Fallaron:'); fallos.forEach((f) => console.log('  · ' + f)); }
  process.exit(falladas ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
