'use strict';
/* La dirección del servicio S3 escrita como la gente la copia de la consola.

   iDrive e2 la muestra sin https:// adelante. Sin el esquema, `new URL()` tira
   "Invalid URL" y toda la operación falla con un mensaje que habla de
   credenciales, mandando al usuario a revisar la clave equivocada.

     node pruebas/destinos-s3-config.cjs                                       */

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-s3cfg-'));
process.env.BACKUPPRIME_CONFIG_DIR = path.join(TEMP, 'config');
fs.mkdirSync(process.env.BACKUPPRIME_CONFIG_DIR, { recursive: true });

const { crearServidorS3 } = require('./servidor-s3-prueba.cjs');
const { BackupEngine, s3Listar } = require('../electron/backup-engine.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — la dirección del servicio S3\n');

(async () => {
  const srv = crearServidorS3();
  const puerto = await srv.escuchar();

  const base = {
    type: 's3', bucket: 'prueba', region: 'us-east-1',
    accessKey: 'AKIA', secretKey: 'secreta', prefix: 'x/',
  };

  titulo('Escrita de distintas formas');

  // Con esquema, como debería
  const conEsquema = await s3Listar({ ...base, endpoint: `http://127.0.0.1:${puerto}` })
    .then(() => true, (e) => e.message);
  comprobar('1. Con http:// adelante funciona', conEsquema === true, String(conEsquema));

  // Con barra al final
  const conBarra = await s3Listar({ ...base, endpoint: `http://127.0.0.1:${puerto}/` })
    .then(() => true, (e) => e.message);
  comprobar('2. Con una barra al final también', conBarra === true, String(conBarra));

  // Con espacios alrededor, como queda al copiar y pegar
  const conEspacios = await s3Listar({ ...base, endpoint: `  http://127.0.0.1:${puerto}  ` })
    .then(() => true, (e) => e.message);
  comprobar('3. Con espacios alrededor también', conEspacios === true, String(conEspacios));

  titulo('Sin esquema, como la muestra la consola de e2');
  // Este es el caso real: "s3.us-southeast-1.idrivee2.com". No se puede probar
  // contra el servidor local porque se completaría https://, pero sí se puede
  // comprobar que el error ya no es "Invalid URL" sino un problema de red.
  const sinEsquema = await s3Listar({ ...base, endpoint: 's3.us-southeast-1.idrivee2.com' })
    .then(() => 'conectó', (e) => e.message);
  comprobar('4. Ya no falla con "Invalid URL"', !/Invalid URL/i.test(String(sinEsquema)),
    String(sinEsquema).slice(0, 90));

  titulo('Una dirección que de verdad está mal');
  const rota = await s3Listar({ ...base, endpoint: 'http://' })
    .then(() => 'conectó', (e) => e.message);
  comprobar('5. Avisa que la dirección no es válida, con el valor que se cargó',
    /no es válida/i.test(String(rota)), String(rota).slice(0, 90));

  titulo('El mensaje que ve el usuario');
  const { BackupEngine: BE } = require('../electron/backup-engine.cjs');
  const motor = new BE();
  const registro = [];
  motor.on('log', (l) => registro.push(l.trim()));
  const origen = path.join(TEMP, 'origen');
  fs.mkdirSync(origen, { recursive: true });
  fs.writeFileSync(path.join(origen, 'a.txt'), 'hola');
  await motor.runOnce({
    server: '', token: '', localPaths: [origen], excludedPaths: [],
    destinations: [{ ...base, endpoint: 'http://' }],
    maxVersions: 10, systemBackup: false, forceFullBackup: false,
  });
  const error = registro.filter((l) => l.includes('[error]')).join(' ');
  comprobar('6. No dice que las credenciales están mal cuando el problema es la dirección',
    !/credenciales/i.test(error), error.slice(0, 110));
  comprobar('7. Y nombra el destino en lugar de decir "undefined"',
    !/undefined/.test(error) && /prueba/.test(error), error.slice(0, 130));

  await srv.cerrar();

  console.log('\n──────────────────────────────────────────────────────');
  console.log(`  ${pasadas} de ${pasadas + falladas} pruebas pasadas`);
  if (falladas) { console.log('\n  Fallaron:'); for (const f of fallos) console.log(`    · ${f}`); }
  console.log('──────────────────────────────────────────────────────\n');
  try { fs.rmSync(TEMP, { recursive: true, force: true }); } catch {}
  process.exit(falladas ? 1 : 0);
})();
