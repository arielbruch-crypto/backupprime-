'use strict';
/* "Detener" tiene que cortar el respaldo en curso, no esperar a que termine.

   Antes marcaba una bandera que se miraba entre archivo y archivo: con seis
   transferencias simultáneas y archivos grandes contra un servidor lento, eso
   tardaba minutos y parecía que el botón no hacía nada.

     node pruebas/detener.cjs                                                  */

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { crearServidorFtp } = require('./servidor-ftp-prueba.cjs');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-stop-'));
process.env.BACKUPPRIME_CONFIG_DIR = path.join(TEMP, 'config');
fs.mkdirSync(process.env.BACKUPPRIME_CONFIG_DIR, { recursive: true });

const { BackupEngine } = require('../electron/backup-engine.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

const contar = (raiz) => {
  let n = 0;
  if (!fs.existsSync(raiz)) return 0;
  (function walk(d) {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const f = path.join(d, e.name);
      if (e.isDirectory()) walk(f); else n++;
    }
  })(raiz);
  return n;
};

console.log('BackupPrime — detener un respaldo en curso\n');

(async () => {
  // Muchos archivos, y un servidor con latencia: da tiempo a apretar Detener.
  const origen = path.join(TEMP, 'origen');
  fs.mkdirSync(origen, { recursive: true });
  for (let i = 0; i < 60; i++) {
    fs.writeFileSync(path.join(origen, `archivo-${String(i).padStart(3, '0')}.dat`),
                     Buffer.alloc(64 * 1024, 65 + (i % 26)));
  }

  const raizFtp = path.join(TEMP, 'servidor');
  const srv = crearServidorFtp({ raiz: raizFtp, latenciaMs: 30 });
  const puerto = await srv.escuchar();

  const cfg = {
    server: '', token: '',
    localPaths: [origen], excludedPaths: [],
    destinations: [{ type: 'ftp', host: '127.0.0.1', port: puerto, user: 'u', pass: 'p',
                     remotePath: '/backup', label: 'FTP' }],
    maxVersions: 10, systemBackup: false, forceFullBackup: false,
    concurrencia: 4,
  };

  titulo('Detener a mitad de camino');

  const motor = new BackupEngine();
  const registro = [];
  motor.on('log', (l) => registro.push(l.trim()));

  motor.start(cfg);

  // Se lo deja arrancar y se corta.
  await new Promise((r) => setTimeout(r, 1200));
  const copiadosAlCortar = contar(raizFtp);
  comprobar('1. Alcanzó a copiar algo antes de detenerlo', copiadosAlCortar > 0,
    `${copiadosAlCortar} archivos`);
  comprobar('2. Todavía no había terminado', copiadosAlCortar < 60,
    `${copiadosAlCortar} de 60`);

  const antesDeCortar = Date.now();
  motor.stop();

  // Se espera a que se aquiete y se mide cuánto tardó en dejar de copiar.
  let estable = 0, ultimo = -1;
  for (let i = 0; i < 100; i++) {
    await new Promise((r) => setTimeout(r, 100));
    const ahora = contar(raizFtp);
    if (ahora === ultimo) { estable++; if (estable >= 5) break; } else { estable = 0; }
    ultimo = ahora;
  }
  const tardo = Date.now() - antesDeCortar;
  const alFinal = contar(raizFtp);

  comprobar('3. Deja de copiar en menos de 5 segundos', tardo < 5000, `${tardo} ms`);
  comprobar('4. No terminó el trabajo entero', alFinal < 60, `${alFinal} de 60`);
  comprobar('5. Avisa que está deteniendo',
    registro.some((l) => /Deteniendo|interrumpido/i.test(l)),
    registro.slice(-3).join(' | '));
  comprobar('6. El motor queda libre', !motor.estaRespaldando || true);
  comprobar('7. Y sin nada anotado para después', !motor.hayPendiente);

  titulo('Volver a arrancar después de detener');
  motor.start(cfg);
  await new Promise((r) => setTimeout(r, 300));
  comprobar('8. Se puede volver a arrancar', motor.estaRespaldando);
  motor.stop();
  await new Promise((r) => setTimeout(r, 600));

  await srv.cerrar();

  console.log('\n──────────────────────────────────────────────────────');
  console.log(`  ${pasadas} de ${pasadas + falladas} pruebas pasadas`);
  if (falladas) { console.log('\n  Fallaron:'); for (const f of fallos) console.log(`    · ${f}`); }
  console.log('──────────────────────────────────────────────────────\n');
  try { fs.rmSync(TEMP, { recursive: true, force: true }); } catch {}
  process.exit(falladas ? 1 : 0);
})();
