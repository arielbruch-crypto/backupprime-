'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Verificador de firma AWS SigV4, escrito aparte del cliente.

   Por qué existe: el servidor de pruebas decía, textualmente, "no valida la
   firma (eso lo prueba el servidor real)". Consecuencia: cualquier error de
   firma pasaba las 200+ pruebas sin que nadie se enterara, y aparecía como un
   403 SignatureDoesNotMatch recién contra el bucket real. Eso es exactamente lo
   que pasó con el listado de versiones, y es la razón por la que ese error
   "volvía": nunca hubo nada que lo detectara.

   Está escrito siguiendo la especificación de AWS, NO copiando `s3Firmar` del
   cliente. Si copiara la implementación del cliente, los dos errores se
   cancelarían y la validación no serviría para nada: una prueba que reproduce el
   error que quiere detectar no detecta nada.
   ═══════════════════════════════════════════════════════════════════════════ */

const crypto = require('node:crypto');

const sha256 = (d) => crypto.createHash('sha256').update(d).digest('hex');
const hmac = (clave, dato) => crypto.createHmac('sha256', clave).update(dato).digest();

/**
 * Codificación RFC 3986, que es la que pide AWS.
 *
 * `encodeURIComponent` deja sin codificar `! ' ( ) *`, y AWS los exige
 * codificados. Es una diferencia chica que produce firmas distintas.
 */
function rfc3986(texto) {
  return encodeURIComponent(String(texto))
    .replace(/[!'()*]/g, (c) => '%' + c.charCodeAt(0).toString(16).toUpperCase());
}

/**
 * Ruta canónica.
 *
 * Ojo con esto, que es una excepción de S3 y es fácil equivocarse: la ruta va
 * TAL COMO LLEGA, que ya viene codificada. S3 no la codifica dos veces (a
 * diferencia de otros servicios de AWS). Volver a codificarla acá convertía cada
 * "%28" en "%2528" y daba firmas que no coincidían para cualquier archivo con
 * paréntesis, apóstrofo o acento.
 */
function rutaCanonica(rutaCruda) {
  const sinQuery = String(rutaCruda).split('?')[0];
  return sinQuery || '/';
}

/**
 * Query canónica: parámetros ordenados POR NOMBRE, nombre y valor codificados.
 *
 * Ojo con el orden: hay que ordenar por nombre, no por la cadena "nombre=valor"
 * ya armada. Con `version-id-marker` y `versions` da lo mismo, pero con otros
 * pares no, y el error resultante es un 403 imposible de diagnosticar.
 */
function queryCanonica(search) {
  const crudo = String(search || '').replace(/^\?/, '');
  if (!crudo) return '';
  const pares = crudo.split('&').filter(Boolean).map((p) => {
    const i = p.indexOf('=');
    return i < 0
      ? { n: decodeURIComponent(p), v: '' }
      : { n: decodeURIComponent(p.slice(0, i)), v: decodeURIComponent(p.slice(i + 1)) };
  });
  pares.sort((a, b) => (a.n < b.n ? -1 : a.n > b.n ? 1 : (a.v < b.v ? -1 : a.v > b.v ? 1 : 0)));
  return pares.map((p) => `${rfc3986(p.n)}=${rfc3986(p.v)}`).join('&');
}

/**
 * Verifica la firma de una petición entrante.
 *
 * Devuelve `{ ok: true }` o `{ ok: false, codigo, motivo, detalle }`, con el
 * detalle armado para que se pueda ver QUÉ parte de la petición canónica no
 * coincide, en lugar de un "403" pelado.
 */
function verificarFirma(req, cuerpo, { secretas }) {
  const auth = req.headers.authorization || '';
  if (!auth.startsWith('AWS4-HMAC-SHA256')) {
    return { ok: false, codigo: 'AccessDenied', motivo: 'falta el encabezado Authorization' };
  }

  const cred = (auth.match(/Credential=([^,]+)/) || [])[1];
  const firmados = (auth.match(/SignedHeaders=([^,]+)/) || [])[1];
  const firmaRecibida = (auth.match(/Signature=([0-9a-f]+)/) || [])[1];
  if (!cred || !firmados || !firmaRecibida) {
    return { ok: false, codigo: 'AuthorizationHeaderMalformed', motivo: 'Authorization incompleto' };
  }

  const [accessKey, fecha, region, servicio] = cred.split('/');
  const secreta = secretas[accessKey];
  if (!secreta) {
    return { ok: false, codigo: 'InvalidAccessKeyId', motivo: `clave desconocida: ${accessKey}` };
  }

  const amzDate = req.headers['x-amz-date'];
  if (!amzDate) {
    return { ok: false, codigo: 'AccessDenied', motivo: 'falta x-amz-date' };
  }

  const nombresFirmados = firmados.split(';');
  // Todo encabezado firmado tiene que venir en la petición: si se firma uno que
  // no se manda, el servidor real rechaza.
  const ausentes = nombresFirmados.filter((n) => req.headers[n] === undefined && n !== 'host');
  if (ausentes.length) {
    return {
      ok: false, codigo: 'SignatureDoesNotMatch',
      motivo: `se firmaron encabezados que no se enviaron: ${ausentes.join(', ')}`,
    };
  }
  // Y el host firmado tiene que ser el host real, con puerto incluido si lo hay.
  const url = new URL(req.url, `http://${req.headers.host}`);

  const canonicalHeaders = nombresFirmados
    .map((n) => `${n}:${String(n === 'host' ? req.headers.host : req.headers[n]).trim()}\n`)
    .join('');

  const hashCuerpo = req.headers['x-amz-content-sha256'] || sha256(cuerpo || Buffer.alloc(0));

  const peticionCanonica = [
    req.method,
    // `req.url` crudo, no `url.pathname`: el parseo puede normalizar y acá
    // importa exactamente lo que se envió.
    rutaCanonica(req.url),
    queryCanonica(url.search),
    canonicalHeaders,
    firmados,
    hashCuerpo,
  ].join('\n');

  const alcance = `${fecha}/${region}/${servicio}/aws4_request`;
  const aFirmar = ['AWS4-HMAC-SHA256', amzDate, alcance, sha256(peticionCanonica)].join('\n');

  let clave = hmac('AWS4' + secreta, fecha);
  clave = hmac(clave, region);
  clave = hmac(clave, servicio);
  clave = hmac(clave, 'aws4_request');
  const esperada = crypto.createHmac('sha256', clave).update(aFirmar).digest('hex');

  if (esperada !== firmaRecibida) {
    return {
      ok: false, codigo: 'SignatureDoesNotMatch',
      motivo: 'la firma calculada no coincide',
      detalle: {
        peticionCanonica,
        queryRecibida: url.search,
        queryCanonica: queryCanonica(url.search),
        encabezadosFirmados: firmados,
      },
    };
  }
  return { ok: true };
}

module.exports = { verificarFirma, queryCanonica, rutaCanonica, rfc3986 };
