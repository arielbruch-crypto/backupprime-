'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Los puntos de corte NO pueden cambiar nunca.

   Por qué esto es de las pruebas más importantes del proyecto:

   La deduplicación funciona porque un archivo se corta SIEMPRE en los mismos
   lugares. Si un cambio en el algoritmo mueve los cortes aunque sea un byte,
   todos los bloques pasan a tener huellas nuevas, ninguno coincide con lo ya
   guardado, y **el próximo respaldo de cada cliente sube todo de nuevo**.

   Para un cliente con 200 GB respaldados eso significa 200 GB de subida y 200 GB
   más de consumo de su plan, de un día para el otro, sin que nadie lo haya
   pedido. Y no hay forma de darse cuenta mirando la pantalla: el respaldo
   "funciona", solo que tarda días y duplica la factura.

   Los valores de abajo se midieron con la versión 0.7.1 y son el contrato del
   formato. Si esta prueba falla, la respuesta correcta casi nunca es actualizar
   los números: es revisar qué se rompió.

   Si alguna vez hiciera falta cambiar el algoritmo de verdad, hay que subir
   `VERSION_FORMATO` y mantener el lector viejo, no cambiar estos valores.

     node pruebas/cortes-estables.cjs
   ═══════════════════════════════════════════════════════════════════════════ */

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');

const Bloques = require('../electron/bloques.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — los puntos de corte no cambian\n');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-cortes-'));

/**
 * Un archivo idéntico en cualquier máquina y en cualquier momento.
 *
 * Encadenar sha256 desde una semilla fija da bytes que parecen al azar pero son
 * siempre los mismos: es lo que permite comparar contra valores guardados.
 */
function archivoDeterminista(destino, megas, semilla) {
  let h = crypto.createHash('sha256').update(semilla).digest();
  const partes = [];
  let n = 0;
  while (n < megas * 1048576) {
    h = crypto.createHash('sha256').update(h).digest();
    partes.push(h);
    n += 32;
  }
  fs.writeFileSync(destino, Buffer.concat(partes));
  return destino;
}

// Medidos con la versión 0.7.1. NO se actualizan sin entender por qué cambiaron.
const ESPERADOS = {
  'semilla-fija-bp': [2604386, 4385442, 9117874, 13267984, 15515733, 19132899, 26214400],
};

(async () => {
  titulo('Un archivo conocido se corta exactamente donde siempre');
  {
    const f = archivoDeterminista(path.join(TEMP, 'fijo.bin'), 25, 'semilla-fija-bp');
    const cortes = [];
    await Bloques.partir(f, (n, posicion) => cortes.push(posicion));

    const esperado = ESPERADOS['semilla-fija-bp'];
    comprobar('la cantidad de bloques es la misma', cortes.length === esperado.length,
      `${cortes.length} en lugar de ${esperado.length}`);
    comprobar('los cortes caen en las mismas posiciones',
      JSON.stringify(cortes) === JSON.stringify(esperado),
      `obtenido: ${JSON.stringify(cortes)}\n     esperado: ${JSON.stringify(esperado)}\n` +
      '     Si esto cambió, el próximo respaldo de CADA cliente sube todo de nuevo.');
  }

  titulo('Cortar el mismo archivo dos veces da lo mismo');
  {
    const f = path.join(TEMP, 'fijo.bin');
    const a = []; await Bloques.partir(f, (n, p) => a.push(p));
    const b = []; await Bloques.partir(f, (n, p) => b.push(p));
    comprobar('el algoritmo es determinista', JSON.stringify(a) === JSON.stringify(b));
  }

  titulo('Insertar datos al principio NO mueve los cortes de más adelante');
  {
    // Es la propiedad que hace útil al corte por contenido: si moviera todo, un
    // byte agregado al principio obligaría a resubir el archivo entero. Es
    // exactamente lo que pasa con un PST cuando llega un mail nuevo.
    const original = fs.readFileSync(path.join(TEMP, 'fijo.bin'));
    const conPrefijo = Buffer.concat([crypto.randomBytes(5000), original]);
    const g = path.join(TEMP, 'con-prefijo.bin');
    fs.writeFileSync(g, conPrefijo);

    const a = []; await Bloques.partir(path.join(TEMP, 'fijo.bin'), (n, p) => a.push(p));
    const b = []; await Bloques.partir(g, (n, p) => b.push(p));

    // Los cortes del archivo con prefijo tienen que estar corridos exactamente
    // 5000 bytes respecto de los originales, salvo los primeros.
    const corridos = b.map((x) => x - 5000);
    const coinciden = a.filter((x) => corridos.includes(x)).length;
    comprobar('la mayoría de los cortes se mantiene', coinciden >= a.length - 2,
      `coinciden ${coinciden} de ${a.length} — si fueran pocos, un mail nuevo ` +
      `obligaría a resubir el PST entero`);
  }

  titulo('Los límites del formato');
  {
    comprobar('el mínimo sigue siendo 1 MB', Bloques.MINIMO === 1048576,
      String(Bloques.MINIMO));
    comprobar('el máximo sigue siendo 16 MB', Bloques.MAXIMO === 16 * 1048576,
      String(Bloques.MAXIMO));
    comprobar('el objetivo sigue siendo 4 MB', Bloques.OBJETIVO === 4 * 1048576,
      String(Bloques.OBJETIVO));
    comprobar('la versión del formato no cambió sin aviso', Bloques.VERSION_FORMATO === 1,
      `es ${Bloques.VERSION_FORMATO}: si subió a propósito, hay que mantener el ` +
      `lector de la versión anterior y actualizar esta prueba`);
  }

  titulo('Ningún bloque se sale de los límites');
  {
    const f = archivoDeterminista(path.join(TEMP, 'otro.bin'), 60, 'otra-semilla');
    const cortes = [];
    await Bloques.partir(f, (n, p) => cortes.push(p));
    const tam = cortes.map((p, i) => p - (cortes[i - 1] || 0));
    // El último puede ser más chico que el mínimo: es el resto del archivo.
    const intermedios = tam.slice(0, -1);
    comprobar('ninguno por debajo del mínimo',
      intermedios.every((t) => t >= Bloques.MINIMO),
      `el más chico: ${Math.min(...intermedios)}`);
    comprobar('ninguno por encima del máximo', tam.every((t) => t <= Bloques.MAXIMO),
      `el más grande: ${Math.max(...tam)}`);

    const promedio = tam.reduce((a, b) => a + b, 0) / tam.length / 1048576;
    // Con el objetivo en 4 MB, un promedio muy lejos indica que el algoritmo se
    // desbalanceó: bloques grandes ahorran menos, chicos hacen más pedidos.
    comprobar('el promedio queda cerca del objetivo', promedio > 2 && promedio < 9,
      `${promedio.toFixed(1)} MB de promedio`);
  }

  try { fs.rmSync(TEMP, { recursive: true, force: true }); } catch {}

  console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
  if (falladas) {
    console.log('Fallaron:'); fallos.forEach((f) => console.log('  · ' + f));
    console.log('\nATENCIÓN: si cambiaron los puntos de corte, el próximo respaldo de');
    console.log('cada cliente vuelve a subir TODO. Revisar qué se tocó antes de');
    console.log('actualizar los valores esperados.');
  }
  process.exit(falladas ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
