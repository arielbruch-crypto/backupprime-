'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Arranque automático con privilegios.

   Por qué importa: las instantáneas de volumen (VSS) son la única forma de
   copiar un archivo que otro programa tiene abierto —el PST con Outlook
   prendido— y Windows exige permisos de administrador para crearlas.

   El arranque automático se registraba en HKCU\\...\\Run, que arranca el programa
   SIN elevación. Con eso, en la máquina de un cliente el PST no se respaldaba
   nunca y el cliente no se enteraba hasta el día que lo necesitaba. Confiar en
   que el usuario sepa hacer clic derecho → "Ejecutar como administrador" no es
   una solución.

   Lo que se prueba acá es la parte que puede fallar en silencio: cómo se arma el
   comando de la tarea y cómo se interpreta su estado. Lo que NO se prueba —que
   Windows cree la tarea y que arranque elevada— solo se verifica en Windows.

     node pruebas/arranque-privilegiado.cjs
   ═══════════════════════════════════════════════════════════════════════════ */

const fs = require('node:fs');
const path = require('node:path');
const Tarea = require('../electron/tarea-programada.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — arranque automático con privilegios\n');

const EXE = 'C:\\Program Files\\BackupPrime\\BackupPrime.exe';

titulo('El comando de la tarea');
{
  const args = Tarea.argumentosCrear(EXE);
  const tomar = (bandera) => args[args.indexOf(bandera) + 1];

  comprobar('crea la tarea', args[0] === '/Create');
  comprobar('el nombre es BackupPrime', tomar('/TN') === 'BackupPrime');
  comprobar('se dispara al iniciar sesión', tomar('/SC') === 'ONLOGON');

  // Esto es el punto de todo el trabajo: sin /RL HIGHEST la tarea arranca el
  // programa sin elevación y VSS no funciona, así que el PST queda afuera.
  comprobar('pide los privilegios más altos', tomar('/RL') === 'HIGHEST',
    'sin esto, las instantáneas no funcionan y el PST no se respalda');

  comprobar('reemplaza una tarea anterior en lugar de fallar', args.includes('/F'),
    'sin /F, reinstalar o actualizar rompería');

  const tr = tomar('/TR');
  // La ruta de instalación casi siempre tiene espacios ("Program Files"). Sin
  // comillas, schtasks corta el comando en el primer espacio y la tarea queda
  // apuntando a "C:\\Program".
  comprobar('la ruta del programa va entre comillas', tr.startsWith(`"${EXE}"`), tr);
  comprobar('arranca oculto, en la bandeja', tr.includes('--hidden'), tr);
  comprobar('no queda espacio de más al final', tr === tr.trim(), JSON.stringify(tr));
}

titulo('Rutas con caracteres molestos');
{
  for (const exe of [
    'C:\\Program Files (x86)\\BackupPrime\\BackupPrime.exe',
    'D:\\Programas\\Copia de Seguridad\\BackupPrime.exe',
  ]) {
    const tr = Tarea.argumentosCrear(exe)[Tarea.argumentosCrear(exe).indexOf('/TR') + 1];
    comprobar(`queda bien con "${path.basename(path.dirname(exe))}"`,
      tr.startsWith(`"${exe}"`) && tr.endsWith('--hidden'), tr);
  }
}

titulo('Leer el estado de la tarea');
{
  const conPrivilegios = [
    'Nombre de host:                       PC-ESTUDIO',
    'Nombre de tarea:                      \\BackupPrime',
    'Ejecutar como usuario:                usuario',
    'Ejecutar con los privilegios más altos: HIGHEST',
  ].join('\r\n');
  const sinPrivilegios = [
    'Nombre de host:                       PC-ESTUDIO',
    'Nombre de tarea:                      \\BackupPrime',
    'Ejecutar como usuario:                usuario',
    'Ejecutar con los privilegios más altos: LIMITED',
  ].join('\r\n');

  const a = Tarea.interpretarConsulta(conPrivilegios);
  comprobar('detecta que la tarea existe', a.existe === true);
  comprobar('detecta que corre con privilegios', a.privilegiada === true);

  const b = Tarea.interpretarConsulta(sinPrivilegios);
  comprobar('detecta una tarea SIN privilegios', b.existe === true && b.privilegiada === false,
    'una tarea sin privilegios arranca el programa pero deja los archivos ' +
    'abiertos afuera: hay que poder distinguirla');

  const c = Tarea.interpretarConsulta('');
  comprobar('sin tarea, informa que no existe', c.existe === false && c.privilegiada === false);
  comprobar('una salida de error no se toma por una tarea válida',
    Tarea.interpretarConsulta('ERROR: no se encuentra la tarea').existe === false ||
    Tarea.interpretarConsulta('ERROR: no se encuentra la tarea').privilegiada === false);
}

titulo('Fuera de Windows no se intenta nada');
{
  const r = Tarea.estado();
  comprobar('estado() devuelve una promesa que no explota', r instanceof Promise);
  r.then((e) => {
    comprobar('en Linux informa que no está soportado', e.soportado === false);
  });
}

titulo('El cableado: nunca la tarea y el registro a la vez');
{
  const main = fs.readFileSync(path.join(__dirname, '..', 'electron', 'main.cjs'), 'utf8');
  comprobar('el arranque automático usa la tarea programada',
    main.includes('Tarea.crear(process.execPath)'));
  comprobar('si la tarea se crea, se borra la entrada del registro',
    /Tarea\.crear[\s\S]{0,400}registroRun\(false\)/.test(main),
    'con las dos activas, el programa se abriría dos veces');
  comprobar('si la tarea falla, se cae al registro para al menos arrancar',
    /r\.ok[\s\S]{0,600}registroRun\(true\)/.test(main));
  comprobar('se informa a la pantalla si quedó sin privilegios',
    main.includes('privilegiada'));
  comprobar('al desactivar se borra la tarea', main.includes('Tarea.eliminar()'));
}

titulo('El instalador crea la tarea y el desinstalador la borra');
{
  const nsh = fs.readFileSync(path.join(__dirname, '..', 'build', 'installer.nsh'), 'utf8');
  const instalar = nsh.slice(nsh.indexOf('!macro customInstall'), nsh.indexOf('!macro customUnInstall'));
  const desinstalar = nsh.slice(nsh.indexOf('!macro customUnInstall'));

  comprobar('el instalador crea la tarea', /schtasks\.exe" \/Create/.test(instalar));
  comprobar('el instalador pide privilegios altos', /\/RL HIGHEST/.test(instalar),
    'es la razón de crearla desde el instalador: ahí ya hay elevación');
  comprobar('el instalador la reemplaza si existe', /\/F/.test(instalar));
  comprobar('el instalador saca la entrada de Run al crear la tarea',
    /DeleteRegValue HKCU "Software.Microsoft.Windows.CurrentVersion.Run"/.test(instalar),
    'con la tarea y la entrada de Run activas, el programa se abre dos veces');
  comprobar('el instalador deja anotado si no pudo',
    /sin-privilegios/.test(instalar),
    'para que la app pueda avisar en lugar de seguir en silencio');
  comprobar('el desinstalador borra la tarea', /schtasks\.exe" \/Delete/.test(desinstalar),
    'si no, queda una tarea disparándose contra un .exe que ya no existe');
}

titulo('La pantalla distingue los dos problemas');
{
  const html = fs.readFileSync(path.join(__dirname, '..', 'electron', 'renderer.html'), 'utf8');
  comprobar('hay un aviso para "no arranca solo"', html.includes('id="autoStartWarn"'));
  comprobar('hay un aviso aparte para "arranca sin privilegios"',
    html.includes('id="privWarn"'),
    'son dos problemas distintos: uno no respalda nada, el otro respalda todo ' +
    'menos los archivos abiertos, que es peor porque parece funcionar');
  comprobar('el aviso explica qué archivos quedan afuera',
    /Outlook/.test(html) && /privWarn/.test(html));
  comprobar('si está todo bien, se confirma en pantalla', html.includes('id="privOk"'));
}

setTimeout(() => {
  console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
  if (falladas) { console.log('Fallaron:'); fallos.forEach((f) => console.log('  · ' + f)); }
  console.log('\nNota: que Windows cree la tarea y que arranque elevada se verifica');
  console.log('solo en Windows. Después de instalar: Outlook abierto, respaldo, y');
  console.log('que el PST no dé EBUSY.');
  process.exit(falladas ? 1 : 0);
}, 100);
