'use strict';

// ---------------------------------------------------------------------------
// Pruebas de destinos locales y de red.
//
//   node pruebas/destinos.cjs
//
// Cubren lo que estaba roto en 0.5.3: copyToLocalDest no existía, así que
// ningún destino local o de red recibía un solo archivo, y agregar un segundo
// destino no copiaba nada. También cubren que la estructura de carpetas que
// escribe el motor sea la que espera la restauración.
// ---------------------------------------------------------------------------

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-destinos-'));
process.env.BACKUPPRIME_CONFIG_DIR = path.join(TEMP, 'config');
fs.mkdirSync(process.env.BACKUPPRIME_CONFIG_DIR, { recursive: true });

const {
  BackupEngine, copyToLocalDest, rutaEnDestinoLocal, existeEnDestinoLocal,
} = require('../electron/backup-engine.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];

function comprobar(nombre, condicion, detalle = '') {
  if (condicion) { pasadas++; console.log(`  ok   ${nombre}`); }
  else { falladas++; fallos.push(nombre); console.log(`  FALLA ${nombre}${detalle ? ' — ' + detalle : ''}`); }
}
const titulo = (t) => console.log(`\n${t}`);

const listar = (raiz) => {
  const out = [];
  if (!fs.existsSync(raiz)) return out;
  (function walk(dir) {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      const f = path.join(dir, e.name);
      if (e.isDirectory()) walk(f); else out.push(path.relative(raiz, f));
    }
  })(raiz);
  return out.sort();
};

// Copia de backupPathToOriginal() de main.cjs. Si el motor y la restauración
// dejan de coincidir en la estructura, esta prueba lo detecta.
function backupPathToOriginal(destBasePath, backupFilePath) {
  const rel = path.relative(destBasePath, backupFilePath);
  const parts = rel.split(path.sep);
  if (parts.length > 1 && /^[A-Za-z]$/.test(parts[0])) {
    return `${parts[0].toUpperCase()}:\\${parts.slice(1).join('\\')}`;
  }
  return rel;
}

console.log('BackupPrime — pruebas de destinos');
console.log(`Carpeta temporal: ${TEMP}`);

(async () => {

  // ── Traducción de rutas ───────────────────────────────────────────────────
  titulo('Ubicación dentro del destino');

  const D = path.join(TEMP, 'dest');

  comprobar('1. La letra de disco queda como primera carpeta',
    rutaEnDestinoLocal(D, 'C:\\Users\\ana\\balance.xlsx')
      === path.join(D, 'C', 'Users', 'ana', 'balance.xlsx'));

  comprobar('2. La letra se normaliza a mayúscula',
    rutaEnDestinoLocal(D, 'd:\\Datos\\x.txt') === path.join(D, 'D', 'Datos', 'x.txt'));

  comprobar('3. Una ruta de red UNC no pierde el servidor',
    rutaEnDestinoLocal(D, '\\\\servidor\\compartido\\a.txt')
      === path.join(D, 'servidor', 'compartido', 'a.txt'));

  comprobar('4. No se escapa de la carpeta de destino con ..',
    rutaEnDestinoLocal(D, 'C:\\Users\\..\\..\\Windows\\x.dll').startsWith(D + path.sep));

  comprobar('5. La restauración vuelve a la ruta original',
    backupPathToOriginal(D, rutaEnDestinoLocal(D, 'C:\\Users\\ana\\balance.xlsx'))
      === 'C:\\Users\\ana\\balance.xlsx');

  // ── Copia ─────────────────────────────────────────────────────────────────
  titulo('Copia al destino');

  const origen = path.join(TEMP, 'origen');
  fs.mkdirSync(path.join(origen, 'Documentos'), { recursive: true });
  const arch = path.join(origen, 'Documentos', 'balance.xlsx');
  fs.writeFileSync(arch, 'planilla contable');

  const r1 = await copyToLocalDest(arch, D);
  comprobar('6. Copia el archivo', r1.copiado && fs.existsSync(r1.ruta));

  comprobar('7. El contenido llega intacto',
    fs.readFileSync(r1.ruta, 'utf8') === 'planilla contable');

  comprobar('8. Conserva la fecha de modificación',
    Math.abs(fs.statSync(r1.ruta).mtimeMs - fs.statSync(arch).mtimeMs) < 2000);

  const r2 = await copyToLocalDest(arch, D);
  comprobar('9. No vuelve a copiar lo que ya está igual', r2.copiado === false);

  fs.writeFileSync(arch, 'planilla contable corregida');
  const r3 = await copyToLocalDest(arch, D);
  comprobar('10. Sí vuelve a copiar cuando el archivo cambió',
    r3.copiado && fs.readFileSync(r3.ruta, 'utf8') === 'planilla contable corregida');

  comprobar('11. No deja archivos temporales tirados',
    listar(D).every((f) => !f.includes('.bp-tmp-')));

  comprobar('12. existeEnDestinoLocal ve el archivo',
    existeEnDestinoLocal(D, arch, fs.statSync(arch).size));

  comprobar('13. existeEnDestinoLocal detecta un tamaño distinto',
    existeEnDestinoLocal(D, arch, 999999) === false);

  let fallo = null;
  try { await copyToLocalDest(arch, ''); } catch (e) { fallo = e; }
  comprobar('14. Avisa si el destino no tiene carpeta configurada', !!fallo);

  // ── Respaldo completo con varios destinos ─────────────────────────────────
  titulo('Varios destinos a la vez');

  const src = path.join(TEMP, 'trabajo');
  fs.mkdirSync(path.join(src, 'Documentos'), { recursive: true });
  fs.writeFileSync(path.join(src, 'Documentos', 'balance.xlsx'), 'planilla');
  fs.writeFileSync(path.join(src, 'Documentos', 'contrato.pdf'), 'contrato');
  fs.writeFileSync(path.join(src, 'notas.txt'), 'notas');

  const A = path.join(TEMP, 'destinoA');
  const B = path.join(TEMP, 'destinoB');
  const C = path.join(TEMP, 'destinoDesconectado');
  fs.mkdirSync(A, { recursive: true });
  fs.mkdirSync(B, { recursive: true });

  const engine = new BackupEngine();
  const registro = [];
  engine.on('log', (l) => registro.push(l.trim()));

  const cfg = (dests) => ({
    server: '', token: '',
    localPaths: [src], excludedPaths: [],
    destinations: dests, maxVersions: 10,
    systemBackup: false, forceFullBackup: false,
  });
  const dA = { type: 'local', path: A, label: 'A' };
  const dB = { type: 'local', path: B, label: 'B' };

  await engine.runOnce(cfg([dA]));
  comprobar('15. Con un destino, copia los 3 archivos', listar(A).length === 3,
    `copiados: ${listar(A).length}`);

  await engine.runOnce(cfg([dA, dB]));
  comprobar('16. Al agregar un destino, se le copia lo que ya estaba respaldado',
    listar(B).length === 3, `copiados: ${listar(B).length}`);

  comprobar('17. El destino que ya tenía todo no se duplica', listar(A).length === 3);

  const antes = registro.length;
  await engine.runOnce(cfg([dA, dB]));
  comprobar('18. Sin cambios no copia nada',
    !registro.slice(antes).some((l) => l.includes('[subido]')));

  // Alguien borra un archivo del destino B por fuera del programa.
  const victima = path.join(B, listar(B)[0]);
  fs.unlinkSync(victima);
  await engine.runOnce(cfg([dA, dB]));
  comprobar('19. Detecta que falta un archivo en el destino y lo repone',
    fs.existsSync(victima));

  // Destino apuntando a una carpeta que no existe (disco desenchufado).
  const antes2 = registro.length;
  await engine.runOnce(cfg([dA, { type: 'local', path: C, label: 'USB' }]));
  const nuevos = registro.slice(antes2);
  comprobar('20. Avisa una sola vez que el destino no está disponible',
    nuevos.filter((l) => l.includes('no está disponible')).length === 1);

  comprobar('21. No inventa la carpeta del destino desconectado', !fs.existsSync(C));

  // Al volver a estar disponible, tiene que recibir todo.
  fs.mkdirSync(C, { recursive: true });
  await engine.runOnce(cfg([dA, { type: 'local', path: C, label: 'USB' }]));
  comprobar('22. Cuando el destino vuelve, recibe todo lo pendiente',
    listar(C).length === 3, `copiados: ${listar(C).length}`);

  // ── Estado ────────────────────────────────────────────────────────────────
  titulo('Registro de estado');

  const estado = JSON.parse(
    fs.readFileSync(path.join(process.env.BACKUPPRIME_CONFIG_DIR, 'state.json'), 'utf8'));
  const unaEntrada = Object.values(estado)[0];

  comprobar('23. Anota a qué destinos llegó cada archivo',
    Array.isArray(unaEntrada.destKeys) && unaEntrada.destKeys.length > 0);

  comprobar('24. No marca destinos que no recibieron el archivo',
    !Object.values(estado).some((e) => (e.destKeys || []).includes(`local:${path.join(TEMP, 'inexistente')}`)));

  // ── Dos respaldos en paralelo ─────────────────────────────────────────────
  titulo('Respaldos simultáneos');

  const e2 = new BackupEngine();
  const log2 = [];
  e2.on('log', (l) => log2.push(l.trim()));
  const p1 = e2.runOnce(cfg([dA, dB]));
  const p2 = e2.runOnce(cfg([dA, dB]));
  await Promise.all([p1, p2]);
  comprobar('25. El segundo respaldo espera en vez de pisar al primero',
    log2.some((l) => l.includes('Ya hay un respaldo en curso')));

  // ── Resultado ─────────────────────────────────────────────────────────────
  console.log('\n──────────────────────────────────────────────────────');
  console.log(`  ${pasadas} de ${pasadas + falladas} pruebas pasadas`);
  if (falladas) {
    console.log('\n  Fallaron:');
    for (const f of fallos) console.log(`    · ${f}`);
  }
  console.log('──────────────────────────────────────────────────────\n');

  try { fs.rmSync(TEMP, { recursive: true, force: true }); } catch {}
  process.exit(falladas ? 1 : 0);
})();
