'use strict';
// Servidor SFTP mínimo para probar el cliente de BackupPrime, montado sobre una
// carpeta temporal. Implementa lo que usa el programa: crear carpetas, escribir,
// listar, leer y consultar atributos.

const fs = require('node:fs');
const path = require('node:path');
const { Server, utils } = require('ssh2');

const ESTADO = {
  OK: 0, EOF: 1, NO_SUCH_FILE: 2, PERMISSION_DENIED: 3, FAILURE: 4,
};

function crearServidorSftp({ raiz, usuario = 'u', clave = 'p', host = '127.0.0.1' }) {
  fs.mkdirSync(raiz, { recursive: true });
  const stats = { conexiones: 0, escritos: 0, leidos: 0 };

  // `generateKeyPairSync('ed25519')` de ssh2 devuelve, de vez en cuando, una
  // clave que su propio `Server` rechaza con "Malformed OpenSSH private key".
  // Pasaba una corrida de cada varias y hacía fallar el suite entero al azar.
  // Una prueba que falla sola es peor que no tenerla: enseña a ignorar los
  // resultados. Se genera y se valida hasta obtener una que sirva.
  const hostKey = (() => {
    let ultimo;
    for (let i = 0; i < 12; i++) {
      const k = utils.generateKeyPairSync('ed25519').private;
      try { new Server({ hostKeys: [k] }, () => {}).close(); return k; }
      catch (e) { ultimo = e; }
    }
    throw new Error(`No se pudo generar una clave de host usable: ${ultimo && ultimo.message}`);
  })();

  const real = (p) => {
    const limpio = path.posix.normalize('/' + String(p)).replace(/^(\.\.[/])+/, '');
    return path.join(raiz, limpio);
  };

  const servidor = new Server({ hostKeys: [hostKey] }, (cliente) => {
    stats.conexiones++;
    cliente.on('authentication', (ctx) => {
      if (ctx.method === 'password' && ctx.username === usuario && ctx.password === clave) return ctx.accept();
      if (ctx.method === 'none') return ctx.reject(['password']);
      ctx.reject();
    });

    cliente.on('ready', () => {
      cliente.on('session', (aceptar) => {
        const sesion = aceptar();
        sesion.on('sftp', (aceptarSftp) => {
          const sftp = aceptarSftp();
          const abiertos = new Map();   // handle -> { ruta, fd, modo }
          const listados = new Map();   // handle -> { entradas, i }
          let n = 0;
          const nuevoHandle = (mapa, valor) => {
            const h = Buffer.from(String(++n));
            mapa.set(h.toString(), valor);
            return h;
          };

          sftp.on('REALPATH', (id, ruta) => {
            const p = path.posix.normalize(ruta === '.' ? '/' : ruta);
            sftp.name(id, [{ filename: p, longname: p, attrs: {} }]);
          });

          sftp.on('OPEN', (id, ruta, banderas) => {
            const destino = real(ruta);
            const escritura = (banderas & 0x0000000A) !== 0;   // WRITE | CREAT
            try {
              if (escritura) {
                fs.mkdirSync(path.dirname(destino), { recursive: true });
                const fd = fs.openSync(destino, 'w');
                return sftp.handle(id, nuevoHandle(abiertos, { ruta: destino, fd, escritura: true }));
              }
              const fd = fs.openSync(destino, 'r');
              sftp.handle(id, nuevoHandle(abiertos, { ruta: destino, fd, escritura: false }));
            } catch {
              sftp.status(id, ESTADO.NO_SUCH_FILE);
            }
          });

          sftp.on('WRITE', (id, handle, offset, datos) => {
            const a = abiertos.get(handle.toString());
            if (!a) return sftp.status(id, ESTADO.FAILURE);
            try {
              fs.writeSync(a.fd, datos, 0, datos.length, offset);
              stats.escritos += datos.length;
              sftp.status(id, ESTADO.OK);
            } catch { sftp.status(id, ESTADO.FAILURE); }
          });

          sftp.on('READ', (id, handle, offset, largo) => {
            const a = abiertos.get(handle.toString());
            if (!a) return sftp.status(id, ESTADO.FAILURE);
            const buf = Buffer.alloc(largo);
            let leidos = 0;
            try { leidos = fs.readSync(a.fd, buf, 0, largo, offset); } catch { return sftp.status(id, ESTADO.FAILURE); }
            if (!leidos) return sftp.status(id, ESTADO.EOF);
            stats.leidos += leidos;
            sftp.data(id, buf.slice(0, leidos));
          });

          sftp.on('CLOSE', (id, handle) => {
            const k = handle.toString();
            const a = abiertos.get(k);
            if (a) { try { fs.closeSync(a.fd); } catch {} abiertos.delete(k); }
            listados.delete(k);
            sftp.status(id, ESTADO.OK);
          });

          sftp.on('MKDIR', (id, ruta) => {
            try { fs.mkdirSync(real(ruta), { recursive: true }); sftp.status(id, ESTADO.OK); }
            catch { sftp.status(id, ESTADO.FAILURE); }
          });

          sftp.on('OPENDIR', (id, ruta) => {
            const dir = real(ruta);
            let entradas;
            try { entradas = fs.readdirSync(dir, { withFileTypes: true }); }
            catch { return sftp.status(id, ESTADO.NO_SUCH_FILE); }
            sftp.handle(id, nuevoHandle(listados, { dir, entradas, i: 0 }));
          });

          sftp.on('READDIR', (id, handle) => {
            const l = listados.get(handle.toString());
            if (!l) return sftp.status(id, ESTADO.FAILURE);
            if (l.i >= l.entradas.length) return sftp.status(id, ESTADO.EOF);
            const lote = l.entradas.slice(l.i, l.i + 50).map((e) => {
              const st = fs.statSync(path.join(l.dir, e.name));
              return {
                filename: e.name,
                longname: `${e.isDirectory() ? 'd' : '-'}rw-r--r-- 1 u g ${st.size} Jan 1 00:00 ${e.name}`,
                attrs: { mode: e.isDirectory() ? 0o040755 : 0o100644, size: st.size,
                         uid: 0, gid: 0, atime: 0, mtime: 0 },
              };
            });
            l.i += lote.length;
            sftp.name(id, lote);
          });

          const atributos = (id, ruta) => {
            try {
              const st = fs.statSync(real(ruta));
              sftp.attrs(id, {
                mode: st.isDirectory() ? 0o040755 : 0o100644,
                size: st.size, uid: 0, gid: 0, atime: 0, mtime: 0,
              });
            } catch { sftp.status(id, ESTADO.NO_SUCH_FILE); }
          };
          sftp.on('STAT', atributos);
          sftp.on('LSTAT', atributos);
          sftp.on('FSTAT', (id, handle) => {
            const a = abiertos.get(handle.toString());
            if (!a) return sftp.status(id, ESTADO.FAILURE);
            atributos(id, path.relative(raiz, a.ruta));
          });
          sftp.on('SETSTAT', (id) => sftp.status(id, ESTADO.OK));
          sftp.on('FSETSTAT', (id) => sftp.status(id, ESTADO.OK));
          sftp.on('REMOVE', (id, ruta) => {
            try { fs.unlinkSync(real(ruta)); sftp.status(id, ESTADO.OK); }
            catch { sftp.status(id, ESTADO.NO_SUCH_FILE); }
          });
        });
      });
    });
    cliente.on('error', () => {});
  });

  return {
    stats,
    escuchar: () => new Promise((r) => servidor.listen(0, host, () => r(servidor.address().port))),
    cerrar: () => new Promise((r) => { try { servidor.close(r); } catch { r(); } }),
  };
}

module.exports = { crearServidorSftp };
