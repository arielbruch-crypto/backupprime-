'use strict';
/* La pantalla tiene que aguantar 165.000 archivos.

   Esto se detectó en producción, con un cliente real: el respaldo "se colgaba".
   Pero el motor NO estaba colgado — el administrador de tareas mostraba 24 MB/s
   de disco y 26% de CPU, y el contador seguía subiendo. Lo que quedaba muerta
   era la ventana.

   Tres causas, y las tres solo aparecen con muchos archivos:

     1. `logs.textContent += texto` no agrega texto: LEE todo lo que hay, lo
        concatena y reescribe el nodo entero. Con 25.000 líneas son varios megas
        releídos y reescritos en cada mensaje. Trabajo al cuadrado.
     2. La lista de actividad se repintaba en CADA mensaje, sin agrupar.
     3. El motor forzaba un aviso de progreso al empezar y al terminar cada
        archivo, salteando el limitador de 400 ms. Con archivos chicos —que son
        la mayoría en un estudio— eran miles de avisos por segundo.

   Un respaldo que funciona pero deja la ventana muerta es, para el cliente, un
   respaldo colgado: va a matar el proceso y se va a quedar sin respaldo.

     node pruebas/pantalla-muchos-archivos.cjs                                */

const fs = require('node:fs');
const path = require('node:path');

let JSDOM;
try { ({ JSDOM } = require('jsdom')); }
catch { console.log('Falta jsdom. Instalalo con: npm install'); process.exit(1); }

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — la pantalla con muchos archivos\n');

const html = fs.readFileSync(path.join(__dirname, '..', 'electron', 'renderer.html'), 'utf8');

let mandarLog = null;
let repintados = 0;

const dom = new JSDOM(html, {
  runScripts: 'dangerously',
  pretendToBeVisual: true,
  beforeParse(win) {
    win.backupprime = new Proxy({}, {
      get: (_t, p) => {
        const n = String(p);
        if (n === 'onLog') return (fn) => { mandarLog = fn; };
        if (n.startsWith('on')) return () => {};
        return async () => ({});
      },
    });
  },
});
const win = dom.window;

new Promise((r) => {
  if (win.document.readyState === 'complete') return r();
  win.addEventListener('load', r);
}).then(async () => {
  const doc = win.document;

  comprobar('La pantalla se suscribe al registro', typeof mandarLog === 'function');
  if (!mandarLog) throw new Error('sin punto de entrada');

  // Se cuenta cuántas veces se repinta de verdad la lista.
  const cont = doc.getElementById('actList');
  if (cont) {
    const original = Object.getOwnPropertyDescriptor(
      win.Element.prototype, 'innerHTML');
    Object.defineProperty(cont, 'innerHTML', {
      configurable: true,
      get() { return original.get.call(this); },
      set(v) { repintados++; original.set.call(this, v); },
    });
  }

  titulo('Veinticinco mil líneas de registro, como un respaldo real');

  const N = 25000;
  const arranque = Date.now();
  for (let i = 0; i < N; i++) {
    mandarLog(`[subido] Documento-${i}.docx · 240.0 KB\n`);
  }
  const duro = Date.now() - arranque;

  // El umbral no es de rendimiento fino: es la diferencia entre una ventana
  // viva y una ventana muerta. Con el defecto puesto esto tarda decenas de
  // segundos o directamente no termina.
  comprobar('No tarda una eternidad en procesarlas',
    duro < 8000, `tardó ${(duro / 1000).toFixed(1)} s para ${N} líneas`);

  // Se fuerza el repintado agrupado, que es cuando el nodo se escribe.
  await new Promise((r) => setTimeout(r, 120));
  const caja = doc.getElementById('logs');
  comprobar('El registro crudo NO crece sin límite',
    caja.textContent.length < 600000,
    `${(caja.textContent.length / 1024).toFixed(0)} KB acumulados — sin tope, cada mensaje relee y reescribe todo`);

  comprobar('Pero conserva lo último, que es lo que sirve',
    caja.textContent.includes(`Documento-${N - 1}.docx`),
    'se cortó por el lado equivocado: quedó el principio en vez del final');

  comprobar('Y no deja una línea partida al medio',
    caja.textContent.startsWith('[') || caja.textContent === '',
    caja.textContent.slice(0, 40));

  titulo('Los repintados se agrupan');

  if (cont) {
    // Sin agrupar serían 25.000 repintados. Agrupando, el navegador repinta
    // una vez por cuadro: unos pocos, no uno por mensaje.
    comprobar('No se repinta una vez por mensaje',
      repintados < N / 10, `${repintados} repintados para ${N} mensajes`);
  } else {
    comprobar('se encontró la lista de actividad', false, 'no está el contenedor');
  }

  titulo('La lista de actividad sigue acotada');

  const items = cont ? cont.querySelectorAll('*').length : 0;
  comprobar('No hay veinticinco mil elementos en pantalla',
    items < 5000, `${items} elementos`);

  console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
  if (falladas) { console.log(fallos.map((f) => ` · ${f}`).join('\n')); process.exit(1); }
}).catch((e) => { console.error(e); process.exit(1); });
