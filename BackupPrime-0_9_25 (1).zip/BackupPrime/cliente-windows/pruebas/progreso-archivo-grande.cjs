'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Que un archivo grande mueva la barra MIENTRAS se respalda.

   Esta prueba existe por un error real que se vio en pantalla: respaldando un
   PST de 651 MB, el cartel decía "Copiando archivos… 0 B copiados", la
   velocidad "—" y el tiempo restante "—" durante todo el proceso.

   La causa: `progreso.bytesSubidos` se actualizaba únicamente al TERMINAR cada
   archivo. Con archivos chicos no se nota; con uno grande, la pantalla queda
   congelada justo cuando el usuario más necesita saber que algo pasa. Y como la
   velocidad se promediaba sobre esas mismas muestras, tampoco había velocidad ni
   estimación.

   Lo que se comprueba:
     · que durante el respaldo de un archivo grande llegue más de un aviso;
     · que el avance informado crezca y no retroceda;
     · que se informe el avance del archivo en curso, con su total;
     · que haya velocidad distinta de cero antes de terminar;
     · y que al terminar no quede nada colgado en vuelo.

     node pruebas/progreso-archivo-grande.cjs
   ═══════════════════════════════════════════════════════════════════════════ */

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-grande-'));
process.env.BACKUPPRIME_CONFIG_DIR = path.join(TEMP, 'config');
fs.mkdirSync(process.env.BACKUPPRIME_CONFIG_DIR, { recursive: true });

const { crearServidorS3 } = require('./servidor-s3-prueba.cjs');
const { BackupEngine } = require('../electron/backup-engine.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — la barra se mueve con archivos grandes\n');

/** Un archivo con datos poco compresibles y con estructura repetida, para que
 *  el partido por bloques se comporte como con un PST real. */
function archivoGrande(destino, megas) {
  const bloque = crypto.randomBytes(1048576);
  const fd = fs.openSync(destino, 'w');
  for (let i = 0; i < megas; i++) fs.writeSync(fd, bloque);
  fs.closeSync(fd);
}

async function correr({ umbralBloquesMB, etiqueta }) {
  titulo(etiqueta);

  const srv = crearServidorS3();
  const puerto = await srv.escuchar();

  const origen = path.join(TEMP, `origen-${umbralBloquesMB}`);
  fs.mkdirSync(origen, { recursive: true });
  const grande = path.join(origen, 'correo.pst');
  archivoGrande(grande, 40);                       // 40 MB
  const tamano = fs.statSync(grande).size;

  const cfg = {
    server: '', token: '',
    localPaths: [origen], excludedPaths: [],
    destinations: [{
      type: 's3', enabled: true, label: 'e2',
      endpoint: `http://127.0.0.1:${puerto}`, region: 'us-east-1',
      bucket: 'respaldos', prefix: 'cliente/',
      accessKey: 'AKIA', secretKey: 'secreta',
    }],
    maxVersions: 10, systemBackup: false, forceFullBackup: false,
    concurrencia: 2,
    umbralBloquesMB,
  };
  // Estado limpio: si el archivo figura como ya subido, no hay nada que medir.
  try { fs.unlinkSync(path.join(process.env.BACKUPPRIME_CONFIG_DIR, 'state.json')); } catch {}

  const engine = new BackupEngine();
  const avisos = [];
  engine.on('progreso', (p) => avisos.push(JSON.parse(JSON.stringify(p))));
  engine.on('log', () => {});

  await engine.runOnce(cfg);
  await srv.cerrar();

  // Solo los avisos de mientras trabaja: el último ("terminado") no cuenta.
  const enCurso = avisos.filter((p) => p.fase !== 'terminado');
  const conArchivoGrande = enCurso.filter(
    (p) => (p.enVuelo || []).some((g) => g.nombre === 'correo.pst'));

  comprobar('llegaron avisos de progreso', enCurso.length > 1,
    `llegaron ${enCurso.length}`);

  comprobar('se informó el avance del archivo grande mientras se procesaba',
    conArchivoGrande.length > 1,
    `avisos con el archivo en vuelo: ${conArchivoGrande.length}`);

  const detalles = conArchivoGrande.map(
    (p) => p.enVuelo.find((g) => g.nombre === 'correo.pst'));

  comprobar('el avance del archivo trae el tamaño total correcto',
    detalles.length > 0 && detalles.every((g) => g.total === tamano),
    `total informado: ${detalles.length ? detalles[0].total : '—'} vs ${tamano}`);

  const hechos = detalles.map((g) => g.hechos);
  comprobar('el avance del archivo crece', hechos.length > 1 && hechos.some((h) => h > 0),
    `valores: ${hechos.slice(0, 6).join(', ')}…`);
  comprobar('el avance del archivo nunca supera su tamaño',
    detalles.every((g) => g.hechos <= g.total));
  comprobar('el porcentaje del archivo queda entre 0 y 100',
    detalles.every((g) => g.porcentaje >= 0 && g.porcentaje <= 100));

  const maxPct = Math.max(0, ...detalles.map((g) => g.porcentaje));
  comprobar('el archivo llegó a informar más del 30% antes de terminar', maxPct > 30,
    `máximo informado: ${maxPct.toFixed(1)}%`);

  // El error original: durante el archivo grande no había ni velocidad ni bytes.
  comprobar('hubo velocidad distinta de cero antes de terminar',
    enCurso.some((p) => p.velocidad > 0),
    'si es 0 en todos, la velocidad sigue calculándose solo al terminar archivos');

  const copiados = enCurso.map((p) => (p.bytesSubidos || 0) + (p.bytesEnVuelo || 0));
  comprobar('lo copiado informado avanza durante el archivo grande',
    copiados.some((c) => c > 0 && c < tamano),
    'no hubo ningún valor intermedio: la barra salta de 0 al total');

  const final = avisos[avisos.length - 1];
  comprobar('al terminar no queda nada en vuelo',
    (final.bytesEnVuelo || 0) === 0 && (final.enVuelo || []).length === 0,
    `bytesEnVuelo=${final.bytesEnVuelo}, enVuelo=${(final.enVuelo || []).length}`);
  comprobar('al terminar se contabilizó el archivo completo',
    final.bytesSubidos >= tamano,
    `${final.bytesSubidos} de ${tamano}`);
}

(async () => {
  // Umbral alto: el archivo se sube entero, por s3Upload.
  await correr({ umbralBloquesMB: 500, etiqueta: 'Archivo grande subido entero' });
  // Umbral bajo: el archivo se parte por bloques, que es el camino real del PST.
  await correr({ umbralBloquesMB: 25, etiqueta: 'Archivo grande subido por bloques' });

  try { fs.rmSync(TEMP, { recursive: true, force: true }); } catch {}

  console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
  if (falladas) { console.log('Fallaron:'); fallos.forEach((f) => console.log('  · ' + f)); }
  process.exit(falladas ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
