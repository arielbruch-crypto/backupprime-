'use strict';
/* La máquina del tiempo: versiones anteriores de un archivo.

   Con el versionado activado en el bucket, cada vez que un archivo cambia el
   proveedor guarda la versión anterior. Esto prueba que el programa las puede
   listar y bajar la que el usuario elija — sin eso, el versionado existe en el
   proveedor pero es invisible, que es como no existir.

     node pruebas/versiones.cjs                                                */

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { crearServidorS3 } = require('./servidor-s3-prueba.cjs');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-ver-'));
process.env.BACKUPPRIME_CONFIG_DIR = path.join(TEMP, 'config');
fs.mkdirSync(process.env.BACKUPPRIME_CONFIG_DIR, { recursive: true });

const { BackupEngine, s3Versiones, s3Descargar, s3Listar } =
  require('../electron/backup-engine.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

const esperar = (ms) => new Promise((r) => setTimeout(r, ms));

console.log('BackupPrime — versiones anteriores\n');

(async () => {
  const srv = crearServidorS3();
  const puerto = await srv.escuchar();
  const dest = {
    type: 's3', endpoint: `http://127.0.0.1:${puerto}`, region: 'us-east-1',
    bucket: 'respaldos', prefix: 'cliente/', accessKey: 'AKIA', secretKey: 'secreta',
    label: 'e2',
  };

  const origen = path.join(TEMP, 'Documentos');
  fs.mkdirSync(origen, { recursive: true });
  const archivo = path.join(origen, 'Balance Ferretería Ruiz.xlsx');

  const cfg = {
    server: '', token: '', localPaths: [origen], excludedPaths: [],
    destinations: [dest], maxVersions: 10, systemBackup: false, forceFullBackup: false,
  };

  const limpiarEstado = () => {
    try { fs.unlinkSync(path.join(process.env.BACKUPPRIME_CONFIG_DIR, 'state.json')); } catch {}
  };

  titulo('Tres días de trabajo sobre el mismo archivo');

  const motor = new BackupEngine();
  const errores = [];
  motor.on('log', (l) => { if (l.includes('[error]')) errores.push(l.trim()); });

  fs.writeFileSync(archivo, 'balance del lunes');
  await motor.runOnce(cfg);

  await esperar(1100);
  fs.writeFileSync(archivo, 'balance del martes, corregido');
  limpiarEstado();                       // como si fuera otro día
  await motor.runOnce(cfg);

  await esperar(1100);
  fs.writeFileSync(archivo, 'balance del miércoles, cifrado por un virus');
  limpiarEstado();
  await motor.runOnce(cfg);

  comprobar('1. Los tres respaldos salieron sin errores', errores.length === 0, errores[0] || '');

  const listado = await s3Listar(dest);
  comprobar('2. En el destino hay un solo archivo, no tres',
    listado.archivos.length === 1, listado.archivos.map((a) => a.clave).join(' | '));

  titulo('Listar las versiones');

  const versiones = await s3Versiones(dest);
  const clave = [...versiones.keys()][0];
  const lista = versiones.get(clave);

  comprobar('3. Encuentra el archivo', !!clave && /Ferreter/.test(clave), String(clave));
  comprobar('4. Con sus tres versiones', lista.length === 3, `${lista ? lista.length : 0} versiones`);
  comprobar('5. Cada una con su identificador y su fecha',
    lista.every((v) => v.versionId && v.fecha));
  comprobar('6. Ordenadas de la más nueva a la más vieja',
    lista[0].fecha >= lista[lista.length - 1].fecha);
  comprobar('7. Y una sola marcada como la actual',
    lista.filter((v) => v.actual).length === 1);

  titulo('Volver el tiempo atrás');

  // Lo que haría el usuario: "el archivo de hoy está cifrado, quiero el de ayer".
  const anteriores = lista.filter((v) => !v.actual);
  const deAyer = anteriores[0];

  const salida = path.join(TEMP, 'recuperado.xlsx');
  await s3Descargar(dest, clave, salida, deAyer.versionId);
  const contenido = fs.readFileSync(salida, 'utf8');

  comprobar('8. Baja la versión anterior, no la actual',
    contenido === 'balance del martes, corregido', contenido);
  comprobar('9. Y la actual sigue disponible por separado', await (async () => {
    const otra = path.join(TEMP, 'actual.xlsx');
    await s3Descargar(dest, clave, otra);
    return fs.readFileSync(otra, 'utf8').includes('virus');
  })());

  const laPrimera = anteriores[anteriores.length - 1];
  const salida2 = path.join(TEMP, 'primera.xlsx');
  await s3Descargar(dest, clave, salida2, laPrimera.versionId);
  comprobar('10. Se puede volver a la primera de todas',
    fs.readFileSync(salida2, 'utf8') === 'balance del lunes',
    fs.readFileSync(salida2, 'utf8'));

  titulo('Casos que no tienen que romper');

  let fallo = null;
  try { await s3Descargar(dest, clave, path.join(TEMP, 'x'), 'version-inventada'); }
  catch (e) { fallo = e; }
  comprobar('11. Una versión que no existe avisa sin romperse', !!fallo);
  comprobar('12. Y no deja un archivo a medias', !fs.existsSync(path.join(TEMP, 'x')));

  const vacio = await s3Versiones({ ...dest, prefix: 'no-hay-nada/' });
  comprobar('13. Un prefijo sin nada devuelve una lista vacía', vacio.size === 0);

  await srv.cerrar();

  console.log('\n──────────────────────────────────────────────────────');
  console.log(`  ${pasadas} de ${pasadas + falladas} pruebas pasadas`);
  if (falladas) { console.log('\n  Fallaron:'); for (const f of fallos) console.log(`    · ${f}`); }
  console.log('──────────────────────────────────────────────────────\n');
  try { fs.rmSync(TEMP, { recursive: true, force: true }); } catch {}
  process.exit(falladas ? 1 : 0);
})();
