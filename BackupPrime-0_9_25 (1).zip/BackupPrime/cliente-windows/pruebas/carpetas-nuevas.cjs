'use strict';
/* Agregar carpetas a un trabajo que ya existe, con varios destinos a la vez.
   Es el caso que reportó el usuario: las carpetas nuevas llegaban al destino
   local pero no al FTP.

     node pruebas/carpetas-nuevas.cjs                                          */

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { crearServidorFtp } = require('./servidor-ftp-prueba.cjs');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-nuevas-'));
process.env.BACKUPPRIME_CONFIG_DIR = path.join(TEMP, 'config');
fs.mkdirSync(process.env.BACKUPPRIME_CONFIG_DIR, { recursive: true });

const { BackupEngine } = require('../electron/backup-engine.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

const listar = (raiz) => {
  const out = [];
  if (!fs.existsSync(raiz)) return out;
  (function walk(d) {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const f = path.join(d, e.name);
      if (e.isDirectory()) walk(f); else out.push(path.relative(raiz, f).split(path.sep).join('/'));
    }
  })(raiz);
  return out.sort();
};

console.log('BackupPrime — carpetas agregadas a un trabajo que ya existe\n');

(async () => {
  const carpetaA = path.join(TEMP, 'Documentos');
  const carpetaB = path.join(TEMP, 'Fotos');
  fs.mkdirSync(carpetaA, { recursive: true });
  fs.mkdirSync(carpetaB, { recursive: true });
  fs.writeFileSync(path.join(carpetaA, 'balance.xlsx'), 'planilla');
  fs.writeFileSync(path.join(carpetaA, 'contrato.pdf'), 'contrato');

  const destLocal = path.join(TEMP, 'destinoLocal');
  fs.mkdirSync(destLocal, { recursive: true });

  const raizFtp = path.join(TEMP, 'servidorFtp');
  const srv = crearServidorFtp({ raiz: raizFtp, latenciaMs: 1 });
  const puerto = await srv.escuchar();

  const dests = [
    { type: 'local', path: destLocal, label: 'Disco externo' },
    { type: 'ftp', host: '127.0.0.1', port: puerto, user: 'u', pass: 'p',
      remotePath: '/backup', label: 'FTP' },
  ];

  const motor = new BackupEngine();
  const registro = [];
  motor.on('log', (l) => registro.push(l.trim()));

  const cfg = (carpetas) => ({
    server: '', token: '',
    localPaths: carpetas, excludedPaths: [],
    destinations: dests, maxVersions: 10,
    systemBackup: false, forceFullBackup: false,
  });

  // ── Primera corrida: una sola carpeta ─────────────────────────────────────
  titulo('Primera corrida, con una carpeta');
  await motor.runOnce(cfg([carpetaA]));

  comprobar('1. Los 2 archivos llegan al destino local', listar(destLocal).length === 2,
    listar(destLocal).join(', '));
  comprobar('2. Y también al FTP', listar(raizFtp).length === 2,
    listar(raizFtp).join(', '));

  // ── Se agrega una carpeta al mismo trabajo ────────────────────────────────
  titulo('Se agrega una carpeta al trabajo');
  fs.writeFileSync(path.join(carpetaB, 'foto1.jpg'), 'una foto');
  fs.writeFileSync(path.join(carpetaB, 'foto2.jpg'), 'otra foto');

  const antesRegistro = registro.length;
  await motor.runOnce(cfg([carpetaA, carpetaB]));
  const nuevos = registro.slice(antesRegistro);

  comprobar('3. Las fotos llegan al destino local', listar(destLocal).length === 4,
    listar(destLocal).join(', '));
  comprobar('4. Las fotos llegan al FTP', listar(raizFtp).length === 4,
    listar(raizFtp).join(', '));
  comprobar('5. Sin errores en el camino',
    !nuevos.some((l) => l.includes('[error]')),
    nuevos.filter((l) => l.includes('[error]'))[0] || '');

  // ── Un archivo nuevo dentro de una carpeta que ya estaba ──────────────────
  titulo('Un archivo nuevo en una carpeta que ya estaba');
  fs.writeFileSync(path.join(carpetaA, 'IVA.pdf'), 'declaración');
  await motor.runOnce(cfg([carpetaA, carpetaB]));

  comprobar('6. Llega al destino local',
    listar(destLocal).some((f) => f.endsWith('IVA.pdf')));
  comprobar('7. Llega al FTP',
    listar(raizFtp).some((f) => f.endsWith('IVA.pdf')),
    listar(raizFtp).join(', '));

  // ── Se agrega un destino nuevo a un trabajo con historia ──────────────────
  titulo('Se agrega un destino nuevo');
  const destLocal2 = path.join(TEMP, 'destinoLocal2');
  fs.mkdirSync(destLocal2, { recursive: true });
  dests.push({ type: 'local', path: destLocal2, label: 'Segundo disco' });

  await motor.runOnce(cfg([carpetaA, carpetaB]));
  comprobar('8. El destino nuevo recibe todo lo que ya existía',
    listar(destLocal2).length === 5, `recibió ${listar(destLocal2).length}`);

  // ── Nada cambia: no debería re-subir ──────────────────────────────────────
  titulo('Corrida sin cambios');
  const antes2 = srv.stats.archivos;
  await motor.runOnce(cfg([carpetaA, carpetaB]));
  comprobar('9. No vuelve a subir nada al FTP', srv.stats.archivos === antes2,
    `subió ${srv.stats.archivos - antes2} de más`);

  // ── Pedidos mientras hay un respaldo en curso ─────────────────────────────
  titulo('Pedir un respaldo mientras hay otro corriendo');

  fs.writeFileSync(path.join(carpetaB, 'foto3.jpg'), 'tercera foto');

  const motor2 = new BackupEngine();
  const log2 = [];
  motor2.on('log', (l) => log2.push(l.trim()));

  // Se lanzan dos casi juntos, como cuando el usuario aprieta "Respaldar ahora"
  // mientras el programado sigue trabajando.
  const primero = motor2.runOnce(cfg([carpetaA, carpetaB]));
  const segundo = motor2.runOnce(cfg([carpetaA, carpetaB]));
  const [r1, r2] = await Promise.all([primero, segundo]);

  comprobar('10. El segundo pedido no se descarta: queda anotado',
    r2 && r2.corrio === false && r2.motivo === 'ocupado',
    JSON.stringify(r2));
  comprobar('11. Y se avisa que quedó anotado, no que se omitió',
    log2.some((l) => /queda anotado/.test(l)),
    log2.filter((l) => /curso/.test(l))[0] || '');
  comprobar('12. Al terminar, corre el que había quedado pendiente',
    log2.some((l) => /había quedado pendiente/.test(l)));

  // ── Carpetas agregadas durante un respaldo ────────────────────────────────
  titulo('Carpetas agregadas mientras el respaldo corre');

  const carpetaC = path.join(TEMP, 'Escritorio');
  fs.mkdirSync(carpetaC, { recursive: true });
  fs.writeFileSync(path.join(carpetaC, 'notas.txt'), 'apuntes');

  const motor3 = new BackupEngine();
  motor3.start(cfg([carpetaA, carpetaB]));
  // Sin esperar a que termine, se agrega una carpeta, como al tocar "Agregar".
  motor3.reconfigure(cfg([carpetaA, carpetaB, carpetaC]));

  // Se espera a que se aquieten las dos corridas.
  for (let i = 0; i < 60 && (motor3.estaRespaldando || motor3.hayPendiente); i++) {
    await new Promise((r) => setTimeout(r, 200));
  }
  motor3.stop();

  comprobar('13. La carpeta agregada durante el respaldo llega al destino local',
    listar(destLocal).some((f) => f.endsWith('notas.txt')),
    listar(destLocal).join(', '));
  comprobar('14. Y también al FTP',
    listar(raizFtp).some((f) => f.endsWith('notas.txt')),
    listar(raizFtp).filter((f) => f.includes('Escritorio')).join(', ') || 'no llegó');

  await srv.cerrar();

  console.log('\n──────────────────────────────────────────────────────');
  console.log(`  ${pasadas} de ${pasadas + falladas} pruebas pasadas`);
  if (falladas) { console.log('\n  Fallaron:'); for (const f of fallos) console.log(`    · ${f}`); }
  console.log('──────────────────────────────────────────────────────\n');

  try { fs.rmSync(TEMP, { recursive: true, force: true }); } catch {}
  process.exit(falladas ? 1 : 0);
})();
