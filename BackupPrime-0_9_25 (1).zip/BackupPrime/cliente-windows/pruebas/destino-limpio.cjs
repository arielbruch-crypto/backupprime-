'use strict';
/* El destino no se ensucia, y el cliente nunca ve un índice.

   Por qué existe esta prueba:

   Hasta la 0.9.8 la segunda copia del índice se guardaba PEGADA al archivo
   original: junto a `backup ASSOFT 2026-08-13 (Completo).zip` aparecía un
   `backup ASSOFT 2026-08-13 (Completo).zip.bpi` de 3 KB. Dos consecuencias:

     · el cliente que entra a su bucket ve un archivito por cada archivo real,
       y no encuentra lo que busca;
     · y en el listado de RESTAURAR aparecían los dos, uno al lado del otro. Un
       cliente que elige el `.bpi` se lleva un JSON de 3 KB creyendo que
       recuperó su respaldo, y se entera cuando ya borró el original. En un
       producto de backup ese es el peor error posible.

   La prueba vieja (`bloques-e2e.cjs`, control 8) decía cubrir esto y NO lo
   cubría: solo miraba que ninguna clave EMPEZARA con `bloques/` o `indices/`,
   y el `.bpi` pegado al archivo no empieza con ninguno de los dos. Pasaba en
   verde con el bug puesto.

     node pruebas/destino-limpio.cjs                                          */

const fs = require('node:fs');
const fsp = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-limpio-'));
process.env.BACKUPPRIME_CONFIG_DIR = path.join(TEMP, 'config');
fs.mkdirSync(process.env.BACKUPPRIME_CONFIG_DIR, { recursive: true });

const { crearServidorS3 } = require('./servidor-s3-prueba.cjs');
const { BackupEngine, s3Listar, almacenDeBloques } = require('../electron/backup-engine.cjs');
const Bloques = require('../electron/bloques.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — el destino limpio y el listado sin basura\n');

/**
 * Arma el listado igual que lo hace la pantalla de restaurar
 * (`main.cjs`, explorarDestino para destinos S3): objetos del bucket menos las
 * ramas de servicio, más los archivos lógicos que salen del catálogo.
 *
 * Usa `Bloques.esRutaDeServicio`, que es EXACTAMENTE la función que corre en el
 * producto. Reimplementar el filtro acá sería el error de siempre: la prueba
 * quedaría verde con la pantalla rota, porque estaría probando su propia copia.
 */
function listadoQueVeElCliente(claves, catalogo, prefijo) {
  const quitar = (k) => (k.startsWith(prefijo) ? k.slice(prefijo.length) : k);
  const items = claves.map(quitar).filter((rel) => !Bloques.esRutaDeServicio(rel));
  return items.concat(Object.keys(catalogo || {}));
}

(async () => {
  const srv = crearServidorS3();
  const puerto = await srv.escuchar();
  const prefijo = 'cliente/';
  const dest = {
    type: 's3', endpoint: `http://127.0.0.1:${puerto}`, region: 'us-east-1',
    bucket: 'respaldos', prefix: prefijo, accessKey: 'AKIA', secretKey: 'secreta',
    label: 'e2',
  };

  const origen = path.join(TEMP, 'origen', 'Desktop', 'backups-assoft');
  await fsp.mkdir(origen, { recursive: true });

  // Tres respaldos comprimidos grandes, como los que tiene el cliente real.
  const nombres = [];
  for (const d of ['2026-08-11', '2026-08-12', '2026-08-13']) {
    const nombre = `backup ASSOFT ${d} (Completo).zip`;
    const b = Buffer.allocUnsafe(30 * 1048576);
    for (let i = 0; i < b.length; i += 1048576) {
      crypto.randomFillSync(b, i, Math.min(1048576, b.length - i));
    }
    await fsp.writeFile(path.join(origen, nombre), b);
    nombres.push(nombre);
  }
  // Y un archivo chico, que va entero y tiene que verse siempre.
  await fsp.writeFile(path.join(origen, 'Notas.docx'), crypto.randomBytes(200 * 1024));

  const cfg = {
    server: '', token: '', localPaths: [path.join(TEMP, 'origen')], excludedPaths: [],
    destinations: [dest], maxVersions: 10, systemBackup: false, forceFullBackup: false,
    umbralBloquesMB: 25,
  };

  const motor = new BackupEngine();
  const registro = [];
  motor.on('log', (l) => registro.push(l.trim()));
  await motor.runOnce(cfg);

  comprobar('Sin errores en el respaldo', !registro.some((l) => l.includes('[error]')),
    registro.filter((l) => l.includes('[error]'))[0] || '');

  const { archivos } = await s3Listar(dest);
  const claves = archivos.map((a) => a.clave);

  titulo('En el bucket, los índices viven en su propia rama');

  const sueltos = claves.filter((k) => {
    const rel = k.slice(prefijo.length);
    return rel.endsWith('.bpi')
        && !rel.startsWith('indices/')
        && !rel.startsWith('indices-copia/');
  });
  comprobar('No queda ni un .bpi mezclado con los archivos del cliente',
    sueltos.length === 0, sueltos.slice(0, 3).join(' | '));

  comprobar('El índice principal está en indices/',
    claves.some((k) => k.startsWith(`${prefijo}indices/`) && k.endsWith('.bpi')));
  comprobar('Y la segunda copia está en indices-copia/',
    claves.some((k) => k.startsWith(`${prefijo}indices-copia/`) && k.endsWith('.bpi')),
    'la redundancia del índice no se negocia: sin él los bloques son pedazos anónimos');

  const principales = claves.filter((k) => k.startsWith(`${prefijo}indices/`) && k.endsWith('.bpi'));
  const copias = claves.filter((k) => k.startsWith(`${prefijo}indices-copia/`) && k.endsWith('.bpi'));
  comprobar('Hay exactamente dos copias de cada índice, ni más ni menos',
    principales.length === 3 && copias.length === 3,
    `${principales.length} principales, ${copias.length} copias`);

  titulo('Lo que ve el cliente en la pantalla de restaurar');

  const almacen = almacenDeBloques(dest);
  const catalogo = JSON.parse(await almacen.bajarTexto(`${prefijo}indices/_catalogo.json`));
  const visibles = listadoQueVeElCliente(claves, catalogo, prefijo);

  comprobar('No aparece ningún .bpi',
    !visibles.some((r) => r.endsWith('.bpi')),
    visibles.filter((r) => r.endsWith('.bpi')).slice(0, 3).join(' | '));
  comprobar('No aparece ningún bloque',
    !visibles.some((r) => r.includes('bloques/')));
  comprobar('Sí aparecen los tres respaldos, con su nombre real',
    nombres.every((n) => visibles.some((r) => r.endsWith(n))),
    visibles.join(' | ').slice(0, 200));
  comprobar('Y el archivo chico también',
    visibles.some((r) => r.endsWith('Notas.docx')));

  // Un archivo lógico por archivo real. Si se cuela una copia, este número sube
  // y es la forma más directa de detectar que el listado se volvió a ensuciar.
  comprobar('Cada archivo aparece UNA sola vez',
    visibles.length === 4, `${visibles.length} entradas: ${visibles.join(' | ').slice(0, 200)}`);

  titulo('Un respaldo viejo, con el índice pegado al archivo, se sigue restaurando');

  // Esto es lo que hay hoy en el bucket del cliente: la copia vieja. Se simula
  // dejando SOLO esa copia y borrando las dos nuevas, que es el peor caso.
  const rel = `${path.join(TEMP, 'origen').replace(/^\/+/, '').replace(/\\/g, '/')}/Desktop/backups-assoft/${nombres[0]}`;
  const relDestino = claves
    .map((k) => k.slice(prefijo.length))
    .find((k) => k.startsWith('indices/') && k.endsWith(`${nombres[0]}.bpi`))
    .replace(/^indices\//, '')
    .replace(/\.bpi$/, '');

  const textoIndice = await almacen.bajarTexto(`${prefijo}indices/${relDestino}.bpi`);
  await almacen.subirTexto(`${prefijo}${relDestino}.bpi`, textoIndice);
  await almacen.borrar(`${prefijo}indices/${relDestino}.bpi`);
  await almacen.borrar(`${prefijo}indices-copia/${relDestino}.bpi`);

  // Antes de restaurar: ese objeto viejo NO tiene que aparecer en el listado.
  // Es el caso del cliente que ya tiene el bucket ensuciado — se arregla la
  // vista sin tocarle un solo objeto del destino, que es como tiene que ser:
  // un producto de backup no borra cosas del bucket del cliente por su cuenta.
  const { archivos: archivos2 } = await s3Listar(dest);
  const visibles2 = listadoQueVeElCliente(
    archivos2.map((a) => a.clave), catalogo, prefijo);
  comprobar('Un .bpi viejo, pegado al archivo, tampoco se muestra',
    !visibles2.some((r) => r.endsWith('.bpi')),
    visibles2.filter((r) => r.endsWith('.bpi')).join(' | '));
  comprobar('Y el objeto viejo sigue en el bucket: la vista se limpia, no se borra nada',
    archivos2.some((a) => a.clave === `${prefijo}${relDestino}.bpi`));

  const destinoLocal = path.join(TEMP, 'restaurado', nombres[0]);
  let restauroOk = false, motivo = '';
  try {
    await Bloques.restaurarPorBloques(almacen, {
      rutaRelativa: relDestino, destinoLocal, prefijo,
    });
    const original = await fsp.readFile(path.join(origen, nombres[0]));
    const vuelto = await fsp.readFile(destinoLocal);
    restauroOk = Buffer.compare(original, vuelto) === 0;
  } catch (e) { motivo = e.message; }

  comprobar('Encuentra el índice en la ubicación vieja y devuelve el archivo exacto',
    restauroOk, motivo || 'el archivo restaurado no coincide con el original');

  await srv.cerrar();
  fs.rmSync(TEMP, { recursive: true, force: true });

  console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
  if (falladas) { console.log(fallos.map((f) => ` · ${f}`).join('\n')); process.exit(1); }
})().catch((e) => { console.error(e); process.exit(1); });
