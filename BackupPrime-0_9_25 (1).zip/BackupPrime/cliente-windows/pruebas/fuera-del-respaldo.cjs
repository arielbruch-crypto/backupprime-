'use strict';
// ---------------------------------------------------------------------------
// Archivos guardados que el respaldo actual ya no cubre.
//
// Cuando el cliente saca una carpeta del trabajo o mueve un directorio, lo ya
// subido queda en la nube. Eso está bien: el archivo sigue ahí y se restaura.
// Lo que estaba mal es que no se distinguía — un archivo cuya última copia es
// de marzo se veía igual que uno de esta mañana. Y esa confusión es la peor de
// todas: el cliente cree que una carpeta se respalda y hace meses que no.
//
//   node pruebas/fuera-del-respaldo.cjs
// ---------------------------------------------------------------------------

const { marcarFueraDelRespaldo, estaCubierta, textoAviso } =
  require('../electron/fuera-del-respaldo.cjs');
const { armarArbol } = require('../electron/restore-remoto.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
function comprobar(nombre, condicion, detalle = '') {
  if (condicion) { pasadas++; console.log(`  ok   ${nombre}`); }
  else { falladas++; fallos.push(nombre); console.log(`  FALLA ${nombre}${detalle ? ' — ' + detalle : ''}`); }
}
const titulo = (t) => console.log(`\n${t}`);

titulo('Qué está dentro del trabajo');
comprobar('Un archivo adentro de la carpeta está cubierto',
  estaCubierta('C:\\Datos\\balance.xlsx', ['C:\\Datos']));
comprobar('También en una subcarpeta',
  estaCubierta('C:\\Datos\\2026\\enero\\balance.xlsx', ['C:\\Datos']));
comprobar('La carpeta misma cuenta como cubierta',
  estaCubierta('C:\\Datos', ['C:\\Datos']));
comprobar('Las barras y las mayúsculas no importan',
  estaCubierta('c:/datos/BALANCE.xlsx', ['C:\\Datos']));

titulo('La trampa del prefijo');
// Con startsWith pelado, "C:\Datos2" quedaría cubierto por "C:\Datos".
comprobar('C:\\Datos2 NO está cubierto por C:\\Datos',
  !estaCubierta('C:\\Datos2\\x.txt', ['C:\\Datos']));
comprobar('Y C:\\Datos sí lo está por sí mismo',
  estaCubierta('C:\\Datos\\x.txt', ['C:\\Datos', 'D:\\Otra']));

titulo('Marcado del inventario');
const inventario = [
  { rel: 'C/Datos/balance.xlsx', ruta: 'x', size: 1000, originalPath: 'C:\\Datos\\balance.xlsx' },
  { rel: 'C/Datos/iva.pdf', ruta: 'x', size: 2000, originalPath: 'C:\\Datos\\iva.pdf' },
  { rel: 'D/Viejo/2024.pst', ruta: 'x', size: 5000, originalPath: 'D:\\Viejo\\2024.pst' },
];
let r = marcarFueraDelRespaldo(inventario, ['C:\\Datos']);
comprobar('Marca solo lo que quedó afuera', r.resumen.archivosFuera === 1,
  JSON.stringify(r.resumen));
comprobar('Suma los bytes de lo que quedó afuera', r.resumen.bytesFuera === 5000,
  String(r.resumen.bytesFuera));
comprobar('Los cubiertos NO quedan marcados',
  r.items.filter((i) => i.fueraDelRespaldo).length === 1);
comprobar('Y el marcado es el correcto',
  r.items.find((i) => i.fueraDelRespaldo).originalPath === 'D:\\Viejo\\2024.pst');

titulo('Si no sabemos qué cubre el trabajo, NO se marca nada');
// Decirle al cliente que todo quedó fuera del respaldo porque no pudimos leer
// la configuración sería el peor aviso posible.
r = marcarFueraDelRespaldo(inventario, []);
comprobar('Con la configuración vacía no se marca nada',
  r.resumen.archivosFuera === 0, JSON.stringify(r.resumen));
comprobar('Y se dice que no se sabe, que no es lo mismo que "está todo bien"',
  r.resumen.desconocido === true);
comprobar('Sin datos no se muestra cartel', textoAviso(r.resumen) === null);

r = marcarFueraDelRespaldo(inventario, null);
comprobar('Con la configuración nula tampoco', r.resumen.archivosFuera === 0);

titulo('Un archivo sin ruta original no se marca a ciegas');
r = marcarFueraDelRespaldo([{ rel: 'x', size: 1, originalPath: '' }], ['C:\\Datos']);
comprobar('No se marca lo que no se puede ubicar', r.resumen.archivosFuera === 0,
  JSON.stringify(r.resumen));

titulo('El cartel dice primero que NO se perdieron');
r = marcarFueraDelRespaldo(inventario, ['C:\\Datos']);
const aviso = textoAviso(r.resumen);
comprobar('Hay cartel cuando corresponde', !!aviso);
comprobar('Lo primero que dice es que se pueden restaurar',
  /podés restaurar/.test(aviso.cuerpo), aviso.cuerpo);
comprobar('Y explica que no se están actualizando',
  /no se están actualizando/.test(aviso.cuerpo));
comprobar('Con un solo archivo, el texto va en singular',
  /1 archivo guardado/.test(textoAviso({ hayFuera: true, archivosFuera: 1 }).titulo),
  textoAviso({ hayFuera: true, archivosFuera: 1 }).titulo);

titulo('Sin nada afuera, no se molesta al cliente');
r = marcarFueraDelRespaldo(inventario, ['C:\\Datos', 'D:\\Viejo']);
comprobar('Todo cubierto: cero marcados', r.resumen.archivosFuera === 0);
comprobar('Y no hay cartel', textoAviso(r.resumen) === null);

titulo('En el árbol de restauración');
r = marcarFueraDelRespaldo(inventario, ['C:\\Datos']);
const arbol = armarArbol(r.items);
function buscar(nodos, rel) {
  for (const n of nodos) {
    if (n.relPath === rel) return n;
    if (n.children) { const h = buscar(n.children, rel); if (h) return h; }
  }
  return null;
}
comprobar('El archivo de afuera llega marcado a la pantalla',
  buscar(arbol, 'D/Viejo/2024.pst').fueraDelRespaldo === true);
comprobar('El archivo cubierto NO llega marcado',
  buscar(arbol, 'C/Datos/balance.xlsx').fueraDelRespaldo === false);
comprobar('La carpeta con TODO afuera se marca entera',
  buscar(arbol, 'D/Viejo').fueraDelRespaldo === true);
comprobar('La carpeta cubierta no se marca',
  buscar(arbol, 'C/Datos').fueraDelRespaldo === false);

titulo('Una carpeta a medias NO se marca entera');
// Marcarla toda mentiría al revés: diría que no se respalda algo que sí.
const mezcla = marcarFueraDelRespaldo([
  { rel: 'C/Mixta/a.txt', size: 1, originalPath: 'C:\\Mixta\\a.txt' },
  { rel: 'C/Mixta/vieja/b.txt', size: 1, originalPath: 'C:\\Mixta\\vieja\\b.txt' },
], ['C:\\Mixta\\vieja']);
const arbolMezcla = armarArbol(mezcla.items);
comprobar('Con una parte cubierta, la carpeta queda sin marcar',
  buscar(arbolMezcla, 'C/Mixta').fueraDelRespaldo === false,
  JSON.stringify(buscar(arbolMezcla, 'C/Mixta').fueraDelRespaldo));

console.log('\n──────────────────────────────');
console.log(`${pasadas} pasadas, ${falladas} falladas`);
if (falladas) { console.log('Fallaron:'); fallos.forEach((f) => console.log('  · ' + f)); }
process.exit(falladas ? 1 : 0);
