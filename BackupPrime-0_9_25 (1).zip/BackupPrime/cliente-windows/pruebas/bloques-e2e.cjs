'use strict';
/* Respaldo por bloques de punta a punta, contra un S3 de prueba.

   Lo que tiene que quedar demostrado, porque es lo que ve el usuario:
     · un archivo grande se guarda por bloques y el segundo día casi no sube nada;
     · en el listado de restaurar aparece el ARCHIVO, no los bloques;
     · restaurarlo devuelve el archivo idéntico;
     · y se puede volver a una versión anterior.

     node pruebas/bloques-e2e.cjs                                              */

const fs = require('node:fs');
const fsp = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-e2e-'));
process.env.BACKUPPRIME_CONFIG_DIR = path.join(TEMP, 'config');
fs.mkdirSync(process.env.BACKUPPRIME_CONFIG_DIR, { recursive: true });

const { crearServidorS3 } = require('./servidor-s3-prueba.cjs');
const { s3Versiones } = require('../electron/backup-engine.cjs');
const { BackupEngine, s3Listar, almacenDeBloques } = require('../electron/backup-engine.cjs');
const Bloques = require('../electron/bloques.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);
const mb = (b) => (b / 1048576).toFixed(1) + ' MB';

console.log('BackupPrime — archivos grandes, de punta a punta\n');

(async () => {
  const srv = crearServidorS3();
  const puerto = await srv.escuchar();
  const dest = {
    type: 's3', endpoint: `http://127.0.0.1:${puerto}`, region: 'us-east-1',
    bucket: 'respaldos', prefix: 'cliente/', accessKey: 'AKIA', secretKey: 'secreta',
    label: 'e2',
  };

  const origen = path.join(TEMP, 'origen', 'Documentos');
  await fsp.mkdir(origen, { recursive: true });

  // Un PST de 40 MB (arriba del umbral) y un Word de 2 MB (abajo).
  const pst = path.join(origen, 'Outlook.pst');
  const grande = Buffer.allocUnsafe(40 * 1048576);
  for (let i = 0; i < grande.length; i += 1048576) {
    crypto.randomFillSync(grande, i, Math.min(1048576, grande.length - i));
  }
  await fsp.writeFile(pst, grande);

  const chico = path.join(origen, 'Informe.docx');
  await fsp.writeFile(chico, crypto.randomBytes(2 * 1048576));

  const cfg = {
    server: '', token: '', localPaths: [path.join(TEMP, 'origen')], excludedPaths: [],
    destinations: [dest], maxVersions: 10, systemBackup: false, forceFullBackup: false,
    umbralBloquesMB: 25,
  };
  const limpiarEstado = () => {
    try { fs.unlinkSync(path.join(process.env.BACKUPPRIME_CONFIG_DIR, 'state.json')); } catch {}
  };

  titulo('Primer respaldo');

  const motor = new BackupEngine();
  const registro = [];
  motor.on('log', (l) => registro.push(l.trim()));
  await motor.runOnce(cfg);

  comprobar('1. Sin errores', !registro.some((l) => l.includes('[error]')),
    registro.filter((l) => l.includes('[error]'))[0] || '');

  const { archivos } = await s3Listar(dest);
  const claves = archivos.map((a) => a.clave);
  comprobar('2. El archivo grande se guardó por bloques',
    claves.some((k) => k.includes('/bloques/')) && claves.some((k) => k.endsWith('.bpi')));
  comprobar('3. El chico se guardó entero, como siempre',
    claves.some((k) => k.endsWith('Informe.docx')));
  comprobar('4. El grande NO está entero en el bucket',
    !claves.some((k) => k.endsWith('Outlook.pst')));

  titulo('Al día siguiente llegan mails nuevos');

  const conMails = Buffer.from(grande);
  crypto.randomFillSync(conMails, conMails.length - 1048576, 1048576);
  await fsp.writeFile(pst, conMails);
  limpiarEstado();

  const antes = srv.stats.puts;
  await motor.runOnce(cfg);
  const nuevos = srv.stats.puts - antes;

  comprobar('5. Sube unos pocos objetos, no el archivo entero',
    nuevos <= 6, `${nuevos} objetos subidos`);
  comprobar('6. Y lo dice en el registro',
    registro.some((l) => l.includes('[bloques]')),
    registro.filter((l) => l.includes('[bloques]')).slice(-1)[0] || '');

  titulo('Lo que ve el usuario al restaurar');

  // Se arma el listado igual que lo hace la pantalla.
  const almacen = almacenDeBloques(dest);
  const catalogo = JSON.parse(await almacen.bajarTexto('cliente/indices/_catalogo.json'));
  const visibles = archivos
    .map((a) => a.clave.replace(/^cliente\//, ''))
    .filter((r) => !r.startsWith('bloques/') && !r.startsWith('indices/'))
    .concat(Object.keys(catalogo));

  comprobar('7. En el listado aparece Outlook.pst como un archivo normal',
    visibles.some((r) => r.endsWith('Outlook.pst')), visibles.join(' | ').slice(0, 120));
  comprobar('8. Y no aparece ni un bloque ni un índice',
    !visibles.some((r) => r.startsWith('bloques/') || r.startsWith('indices/')));
  comprobar('9. Con su tamaño real, no el de un pedazo',
    Object.values(catalogo)[0].bytes === grande.length,
    mb(Object.values(catalogo)[0].bytes));

  titulo('Restaurar');

  const rel = Object.keys(catalogo)[0];
  const salida = path.join(TEMP, 'recuperado', 'Outlook.pst');
  await Bloques.restaurarPorBloques(almacen, {
    rutaRelativa: rel, destinoLocal: salida, prefijo: 'cliente/',
  });

  comprobar('10. El archivo vuelve entero e idéntico',
    (await fsp.readFile(salida)).equals(conMails), mb((await fsp.stat(salida)).size));

  titulo('Volver a la versión de ayer');

  // s3Versiones se importa arriba
  const mapa = await s3Versiones(dest, `cliente/${Bloques.claveIndice('', rel)}`);
  const versiones = mapa.get(`cliente/${Bloques.claveIndice('', rel)}`) || [];
  comprobar('11. El índice tiene dos versiones', versiones.length === 2,
    `${versiones.length} versiones`);

  const anterior = versiones.find((v) => !v.actual);
  const salidaVieja = path.join(TEMP, 'ayer', 'Outlook.pst');
  await Bloques.restaurarPorBloques(almacen, {
    rutaRelativa: rel, destinoLocal: salidaVieja, prefijo: 'cliente/',
    versionIndice: anterior.versionId,
  });
  comprobar('12. Y devuelve el archivo tal como estaba ayer',
    (await fsp.readFile(salidaVieja)).equals(grande));

  titulo('Cuánto se ahorró');
  let ocupado = 0;
  for (const a of (await s3Listar(dest)).archivos) ocupado += a.size;
  const sinBloques = grande.length + conMails.length + 2 * 1048576 * 2;
  comprobar('13. Dos versiones de 40 MB ocupan mucho menos que dos copias',
    ocupado < sinBloques * 0.75,
    `${mb(ocupado)} contra ${mb(sinBloques)}`);

  titulo('Cuando el servidor no contesta bien a "¿existe?"');

  // Varios servicios compatibles con S3 contestan 403 en lugar de 404 cuando el
  // objeto no existe. Con eso, preguntar bloque por bloque da siempre "no
  // existe" y el archivo se sube entero todos los días. Se simula ese servidor.
  srv.responderMalAHead = true;

  crypto.randomFillSync(conMails, conMails.length - 2 * 1048576, 1048576);
  await fsp.writeFile(pst, conMails);
  limpiarEstado();

  const antesMal = srv.stats.puts;
  await motor.runOnce(cfg);
  const subidosMal = srv.stats.puts - antesMal;

  comprobar('14. Aun así reutiliza los bloques y no sube el archivo entero',
    subidosMal <= 8, `${subidosMal} objetos subidos`);

  const salidaMal = path.join(TEMP, 'tras-head-roto', 'Outlook.pst');
  await Bloques.restaurarPorBloques(almacen, {
    rutaRelativa: rel, destinoLocal: salidaMal, prefijo: 'cliente/',
  });
  comprobar('15. Y el archivo sigue restaurándose perfecto',
    (await fsp.readFile(salidaMal)).equals(conMails));

  srv.responderMalAHead = false;

  titulo('Las versiones de un archivo guardado por bloques');

  // El bug: un archivo por bloques NO existe como objeto con su nombre, así que
  // buscar sus versiones por el nombre del archivo devolvía vacío y la pantalla
  // decía "no hay versiones anteriores". Mentira, y justo en el archivo más
  // importante del cliente.
  const claveDirecta = `cliente/${rel}`;
  const porNombre = await s3Versiones(dest, claveDirecta);
  comprobar('16. Por el nombre del archivo no hay nada: no es un objeto',
    !(porNombre.get(claveDirecta) || []).length);

  // Donde SÍ están: en el índice.
  const claveDelIndice = `cliente/indices/${rel}.bpi`;
  const porIndice = await s3Versiones(dest, claveDelIndice);
  const lista = (porIndice.get(claveDelIndice) || []).filter((v) => !v.borrado);
  comprobar('17. En el índice están todas las versiones', lista.length >= 2,
    `${lista.length} versiones`);
  comprobar('18. Con una sola marcada como la actual',
    lista.filter((v) => v.actual).length === 1);

  // Y la segunda copia también las tiene: es la red de seguridad. Desde la
  // 0.9.9 vive en `indices-copia/` y no pegada al archivo del cliente, pero el
  // requisito no cambió: si se pierde la rama `indices/`, el historial completo
  // tiene que seguir estando. La clave se pide con la función del producto, no
  // escrita a mano, para que no puedan separarse.
  const claveCopia = Bloques.claveIndiceCopia('cliente/', rel);
  const porCopia = await s3Versiones(dest, claveCopia);
  comprobar('19. La copia del índice también guarda el historial',
    (porCopia.get(claveCopia) || []).filter((v) => !v.borrado).length >= 2,
    `en ${claveCopia}`);

  // Y no quedó ninguna copia mezclada con los archivos del cliente. Es lo que
  // el control 8 decía cubrir y no cubría: solo miraba que la clave no empezara
  // con `bloques/` ni `indices/`, y `…/Outlook.pst.bpi` no empieza con ninguno.
  const { archivos: todos } = await s3Listar(dest);
  const pegados = todos
    .map((a) => a.clave.replace(/^cliente\//, ''))
    .filter((k) => k.endsWith('.bpi')
                && !k.startsWith('indices/') && !k.startsWith('indices-copia/'));
  comprobar('19b. Y no hay ningún índice pegado al archivo del cliente',
    pegados.length === 0, pegados.slice(0, 2).join(' | '));

  // Restaurar una versión anterior por su identificador tiene que dar el
  // contenido de esa versión, no el actual.
  const anteriorIdx = lista.find((v) => !v.actual);
  const salidaVersion = path.join(TEMP, 'por-version', 'Outlook.pst');
  await Bloques.restaurarPorBloques(almacen, {
    rutaRelativa: rel, destinoLocal: salidaVersion, prefijo: 'cliente/',
    versionIndice: anteriorIdx.versionId,
  });
  comprobar('20. Restaurar esa versión devuelve el contenido de entonces',
    !(await fsp.readFile(salidaVersion)).equals(conMails),
    'devolvió el archivo actual en lugar del anterior');

  await srv.cerrar();

  console.log('\n──────────────────────────────────────────────────────');
  console.log(`  ${pasadas} de ${pasadas + falladas} pruebas pasadas`);
  if (falladas) { console.log('\n  Fallaron:'); for (const f of fallos) console.log(`    · ${f}`); }
  console.log('──────────────────────────────────────────────────────\n');
  try { fs.rmSync(TEMP, { recursive: true, force: true }); } catch {}
  process.exit(falladas ? 1 : 0);
})();
