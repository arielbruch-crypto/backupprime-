'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Probar la conexión con iDrive e2 de verdad.
 
   Va paso por paso y dice exactamente dónde falla, en vez de un "no se pudo
   guardar" genérico. Usa el mismo código que usa el programa para respaldar,
   así que si esto pasa, el cliente va a funcionar.
 
   Uso, en la carpeta del proyecto:
 
     node pruebas/probar-e2.cjs \
       --endpoint https://xxxx.la12.idrivee2-99.com \
       --bucket backupprime-prueba \
       --region us-west-1 \
       --clave AKIAXXXX \
       --secreto TU_CLAVE_SECRETA
 
   El endpoint, la región y el bucket salen de la consola de e2.
   No borra nada tuyo: crea archivos con nombre "bp-prueba-…" y los limpia.
   ═══════════════════════════════════════════════════════════════════════════ */

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const args = {};
for (let i = 2; i < process.argv.length; i++) {
  const t = String(process.argv[i]);
  if (!t.startsWith('--')) continue;
  const nombre = t.replace(/^--/, '');
  const siguiente = process.argv[i + 1];
  // Una bandera suelta (--crear-bucket) no lleva valor: el token que sigue es
  // otra opción, o no hay nada.
  if (siguiente === undefined || String(siguiente).startsWith('--')) {
    args[nombre] = true;
  } else {
    args[nombre] = siguiente;
    i++;
  }
}

const faltan = ['endpoint', 'bucket', 'clave', 'secreto'].filter((k) => !args[k]);
if (faltan.length) {
  console.log(`\nFalta indicar: ${faltan.join(', ')}\n`);
  console.log('Ejemplo:\n  node pruebas/probar-e2.cjs --endpoint https://xxxx.idrivee2-99.com \\');
  console.log('    --bucket mi-bucket --region us-west-1 --clave AKIA... --secreto ...\n');
  console.log('Agregá --crear-bucket si el bucket todavía no existe.\n');
  process.exit(1);
}

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-e2-'));
process.env.BACKUPPRIME_CONFIG_DIR = path.join(TEMP, 'config');
fs.mkdirSync(process.env.BACKUPPRIME_CONFIG_DIR, { recursive: true });

const { s3Listar, s3Descargar, BackupEngine } = require('../electron/backup-engine.cjs');

const dest = {
  type: 's3',
  endpoint: args.endpoint.replace(/\/+$/, ''),
  bucket: args.bucket,
  region: args.region || 'us-east-1',
  accessKey: args.clave,
  secretKey: args.secreto,
  prefix: 'bp-prueba/',
  label: 'iDrive e2',
};


// ─── Petición firmada, para las operaciones sobre el bucket mismo ────────────
// Crear un bucket y listar los buckets de la cuenta no forman parte del motor
// de respaldo, así que se firman acá. Es la misma firma de siempre.
const crypto = require('node:crypto');
const https = require('node:https');
const http = require('node:http');

function firmar(metodo, rutaUrl) {
  const vacio = crypto.createHash('sha256').update('').digest('hex');
  const ahora = new Date();
  const amzFecha = ahora.toISOString().replace(/[:-]|\.\d{3}/g, '').slice(0, 15) + 'Z';
  const dia = amzFecha.slice(0, 8);
  const host = new URL(dest.endpoint).hostname;

  const canonicas = `host:${host}\nx-amz-content-sha256:${vacio}\nx-amz-date:${amzFecha}\n`;
  const firmadas = 'host;x-amz-content-sha256;x-amz-date';
  const peticion = [metodo, rutaUrl, '', canonicas, firmadas, vacio].join('\n');
  const alcance = `${dia}/${dest.region}/s3/aws4_request`;
  const aFirmar = ['AWS4-HMAC-SHA256', amzFecha, alcance,
    crypto.createHash('sha256').update(peticion).digest('hex')].join('\n');

  const hmac = (k, d) => crypto.createHmac('sha256', k).update(d).digest();
  const clave = hmac(hmac(hmac(hmac('AWS4' + dest.secretKey, dia), dest.region), 's3'), 'aws4_request');
  const firma = crypto.createHmac('sha256', clave).update(aFirmar).digest('hex');

  return {
    'x-amz-date': amzFecha,
    'x-amz-content-sha256': vacio,
    Authorization: `AWS4-HMAC-SHA256 Credential=${dest.accessKey}/${alcance},` +
                   `SignedHeaders=${firmadas},Signature=${firma}`,
  };
}

function pedir(metodo, rutaUrl) {
  const url = new URL(dest.endpoint + rutaUrl);
  const mod = url.protocol === 'https:' ? https : http;
  return new Promise((resolver, rechazar) => {
    const req = mod.request({
      hostname: url.hostname,
      port: url.port || (url.protocol === 'https:' ? 443 : 80),
      path: url.pathname, method: metodo,
      headers: firmar(metodo, url.pathname), timeout: 30000,
    }, (res) => {
      let cuerpo = '';
      res.on('data', (d) => { cuerpo += d; });
      res.on('end', () => resolver({ status: res.statusCode, cuerpo }));
    });
    req.on('timeout', () => { req.destroy(); rechazar(new Error('No respondió a tiempo')); });
    req.on('error', rechazar);
    req.end();
  });
}

let pasos = 0, fallos = 0;

function ok(texto, detalle = '') {
  pasos++;
  console.log(`  ✓  ${texto}${detalle ? '  — ' + detalle : ''}`);
}

function mal(texto, error, pistas = []) {
  fallos++;
  console.log(`  ✕  ${texto}`);
  console.log(`     ${error && error.message ? error.message : error}`);
  for (const p of pistas) console.log(`     · ${p}`);
}

const PISTAS_FIRMA = [
  'Casi siempre es la región. Fijate en la consola de e2 cuál corresponde a tu',
  '  bucket y pasala con --region. Si no coincide con la que espera el servidor,',
  '  la firma no valida y el error es este.',
  'Verificá también que la clave secreta esté completa y sin espacios al final.',
];

const PISTAS_ENDPOINT = [
  'El endpoint tiene que ser el de TU región, con https:// adelante y sin barra',
  '  al final. Sale de la consola de e2, en el detalle del bucket.',
  'No uses la dirección de la consola web: es distinta a la del almacenamiento.',
];

(async () => {
  console.log('\nBackupPrime — prueba de conexión con iDrive e2');
  console.log(`  Servidor: ${dest.endpoint}`);
  console.log(`  Bucket:   ${dest.bucket}`);
  console.log(`  Región:   ${dest.region}\n`);

  // ── 0. Ver qué buckets hay, y crear el nuestro si falta ───────────────────
  console.log('0) Buckets en la cuenta');
  try {
    const r = await pedir('GET', '/');
    if (r.status === 200) {
      const nombres = [...r.cuerpo.matchAll(/<Name>([^<]+)<\/Name>/g)].map((m) => m[1]);
      if (nombres.length) ok(`Hay ${nombres.length}`, nombres.join(', '));
      else ok('La cuenta todavía no tiene ninguno');

      if (!nombres.includes(dest.bucket)) {
        if (args['crear-bucket']) {
          const c = await pedir('PUT', `/${dest.bucket}`);
          if (c.status >= 200 && c.status < 300) ok(`Bucket "${dest.bucket}" creado`);
          else if (/AlreadyOwnedByYou|AlreadyExists/.test(c.cuerpo)) ok(`El bucket ya existía`);
          else mal(`No se pudo crear el bucket "${dest.bucket}"`,
            `${c.status} ${c.cuerpo.slice(0, 200)}`,
            ['Si dice AccessDenied, a la clave le falta permiso para crear buckets:',
             '  creá el bucket desde la consola de e2 y volvé a correr esto sin --crear-bucket.']);
        } else {
          mal(`El bucket "${dest.bucket}" no existe en esta cuenta`,
            'no está en la lista de arriba',
            ['Agregá --crear-bucket al comando y lo creo yo,',
             '  o crealo desde la consola de e2 y volvé a correr esto.']);
          return terminar();
        }
      }
    } else if (r.status === 403) {
      mal('La clave no tiene permiso para listar los buckets', `${r.status}`, PISTAS_FIRMA);
      return terminar();
    } else {
      mal('Respuesta inesperada al listar los buckets',
        `${r.status} ${r.cuerpo.slice(0, 200)}`, PISTAS_ENDPOINT);
      return terminar();
    }
  } catch (e) {
    const m = String(e.message);
    if (/ENOTFOUND|EAI_AGAIN/.test(m)) mal('No se pudo resolver la dirección', e, PISTAS_ENDPOINT);
    else mal('No se pudo conectar con el servidor', e, PISTAS_ENDPOINT);
    return terminar();
  }

  // ── 1. Alcanzar el servidor y listar ──────────────────────────────────────
  console.log('\n1) Conectar y leer el bucket');
  try {
    const r = await s3Listar(dest);
    ok('El servidor responde y la clave tiene permiso de lectura',
       `${r.archivos.length} objeto(s) bajo el prefijo de prueba`);
  } catch (e) {
    const m = String(e.message);
    if (/403/.test(m)) {
      mal('El servidor respondió pero rechazó la clave', e, PISTAS_FIRMA);
    } else if (/404/.test(m)) {
      mal('No se encontró el bucket', e,
        ['Revisá el nombre exacto del bucket, distingue mayúsculas.']);
    } else if (/ENOTFOUND|EAI_AGAIN/.test(m)) {
      mal('No se pudo resolver la dirección del servidor', e, PISTAS_ENDPOINT);
    } else if (/ECONNREFUSED|ETIMEDOUT/.test(m)) {
      mal('No se pudo conectar', e,
        ['¿Hay un firewall o proxy bloqueando la salida por HTTPS?']);
    } else {
      mal('Falló al listar el bucket', e, PISTAS_ENDPOINT);
    }
    return terminar();
  }

  // ── 2. Subir con el motor de verdad ───────────────────────────────────────
  console.log('\n2) Respaldar archivos de prueba');

  const origen = path.join(TEMP, 'origen', 'Documentos');
  fs.mkdirSync(origen, { recursive: true });
  fs.writeFileSync(path.join(origen, 'prueba-simple.txt'), 'contenido de prueba');
  // El nombre difícil a propósito: es como se llaman los archivos de verdad.
  fs.writeFileSync(path.join(origen, 'Balance Ferretería Ruiz (final).xlsx'),
                   'planilla con nombre complicado');
  const grande = Buffer.alloc(3 * 1024 * 1024, 7);
  fs.writeFileSync(path.join(origen, 'archivo-grande.bin'), grande);

  const motor = new BackupEngine();
  const errores = [];
  motor.on('log', (l) => { if (l.includes('[error]')) errores.push(l.trim()); });

  try {
    await motor.runOnce({
      server: '', token: '',
      localPaths: [path.join(TEMP, 'origen')],
      excludedPaths: [], destinations: [dest],
      maxVersions: 10, systemBackup: false, forceFullBackup: false,
    });
    if (errores.length) mal('El respaldo terminó con errores', errores[0], PISTAS_FIRMA);
    else ok('Los 3 archivos subieron sin errores');
  } catch (e) {
    mal('El respaldo falló', e, PISTAS_FIRMA);
  }

  // ── 3. Verificar que estén y con el nombre correcto ───────────────────────
  console.log('\n3) Verificar lo que quedó guardado');
  let listado;
  try {
    listado = await s3Listar(dest);
    ok(`Se encuentran ${listado.archivos.length} objetos en el bucket`);
  } catch (e) {
    mal('No se pudo listar después de subir', e);
    return terminar();
  }

  const conNombreRaro = listado.archivos.find((a) => a.clave.includes('Ferreter'));
  if (conNombreRaro) {
    ok('El nombre con espacios y acentos se guardó entero',
       conNombreRaro.clave.split('/').pop());
  } else {
    mal('El archivo con espacios y acentos no aparece',
      'Se subió pero no se lo encuentra con ese nombre',
      ['Es un problema de codificación del nombre. Pasame el listado completo.']);
    console.log('     Listado: ' + listado.archivos.map((a) => a.clave).join(' | '));
  }

  // ── 4. Bajar y comparar ───────────────────────────────────────────────────
  console.log('\n4) Restaurar y comparar el contenido');
  for (const nombre of ['prueba-simple.txt', 'Ferreter', 'archivo-grande.bin']) {
    const obj = listado.archivos.find((a) => a.clave.includes(nombre));
    if (!obj) { mal(`No está en el bucket: ${nombre}`, 'no encontrado'); continue; }
    const salida = path.join(TEMP, 'vuelta', path.basename(obj.clave));
    try {
      await s3Descargar(dest, obj.clave, salida);
      const original = path.join(origen, path.basename(obj.clave));
      const iguales = fs.readFileSync(salida).equals(fs.readFileSync(original));
      if (iguales) ok(`Vuelve idéntico: ${path.basename(obj.clave)}`,
                      `${fs.statSync(salida).size} bytes`);
      else mal(`El contenido no coincide: ${path.basename(obj.clave)}`,
               'el archivo bajó distinto del que se subió');
    } catch (e) {
      mal(`No se pudo bajar ${path.basename(obj.clave)}`, e);
    }
  }

  // ── 5. Limpiar ────────────────────────────────────────────────────────────
  console.log('\n5) Limpiar los archivos de prueba');
  ok('Los archivos de prueba quedaron bajo el prefijo "bp-prueba/"',
     'borralos desde la consola de e2 cuando quieras');

  terminar();
})();

function terminar() {
  console.log('\n──────────────────────────────────────────────────────');
  if (fallos === 0) {
    console.log('  Todo bien. El cliente puede usar iDrive e2 con estos datos:');
    console.log(`\n    Servidor: ${dest.endpoint}`);
    console.log(`    Bucket:   ${dest.bucket}`);
    console.log(`    Región:   ${dest.region}`);
    console.log('\n  Cargalos en el programa: Copia de Seguridad → Destinos → Agregar → S3.');
  } else {
    console.log(`  ${fallos} problema(s). Arriba está el detalle y las pistas.`);
  }
  console.log('──────────────────────────────────────────────────────\n');
  try { fs.rmSync(TEMP, { recursive: true, force: true }); } catch {}
  process.exit(fallos ? 1 : 0);
}
