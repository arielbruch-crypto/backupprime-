'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Un servidor FTP que se porta mal a propósito.

   El programa se estaba muriendo entero durante la restauración — la pantalla
   mostraba "reply was never sent", que significa que el proceso principal dejó
   de existir a mitad de la operación. Con un servidor que anda bien eso no se
   reproduce nunca, así que hace falta uno que corte conexiones, se quede mudo
   y rechace clientes de más, que es lo que hacen los servidores FTP baratos
   cuando les abrís seis conexiones a la vez.

   La prueba no mira si la descarga sale bien: mira que el proceso SIGA VIVO.

     node pruebas/ftp-hostil.cjs
   ═══════════════════════════════════════════════════════════════════════════ */

const net = require('node:net');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-hostil-'));
process.env.BACKUPPRIME_CONFIG_DIR = path.join(TEMP, 'config');
fs.mkdirSync(process.env.BACKUPPRIME_CONFIG_DIR, { recursive: true });

const { SesionFtp } = require('../electron/backup-engine.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

// Si algo revienta fuera de un try, el proceso se muere: es exactamente lo que
// le pasaba al usuario. Se anota y se sigue, para poder reportarlo al final.
const muertes = [];
process.on('uncaughtException', (e) => muertes.push('excepción sin atrapar: ' + e.message));
process.on('unhandledRejection', (e) => muertes.push('promesa sin atender: ' + (e && e.message)));

/**
 * @param {string} modo  cortar-en-saludo | cortar-en-listado | cortar-en-datos
 *                       | mudo | rechazar-de-mas
 */
function servidorHostil(modo, maxConexiones = 99) {
  let vivas = 0;
  const abiertos = new Set();
  const servidor = net.createServer((ctrl) => {
    vivas++;
    abiertos.add(ctrl);
    ctrl.on('close', () => abiertos.delete(ctrl));
    ctrl.on('error', () => {});

    if (modo === 'rechazar-de-mas' && vivas > maxConexiones) {
      ctrl.write('421 Demasiadas conexiones\r\n');
      return ctrl.destroy();
    }
    if (modo === 'cortar-en-saludo') return ctrl.destroy();

    ctrl.write('220 Servidor hostil\r\n');
    let pasv = null;

    ctrl.on('data', (d) => {
      const linea = String(d).trim();
      const cmd = linea.split(' ')[0].toUpperCase();

      if (modo === 'mudo' && cmd !== 'USER') return;   // nunca contesta

      if (cmd === 'USER') return ctrl.write('331 Dale\r\n');
      if (cmd === 'PASS') return ctrl.write('230 Adelante\r\n');
      if (cmd === 'TYPE') return ctrl.write('200 Ok\r\n');

      if (cmd === 'PASV') {
        if (modo === 'cortar-en-listado') return ctrl.destroy();
        pasv = net.createServer((datos) => {
          datos.on('error', () => {});
          if (modo === 'cortar-en-datos') {
            // Manda medio archivo y corta: el caso más traicionero.
            datos.write('mitad de un archi');
            setTimeout(() => datos.destroy(), 30);
          } else {
            datos.end('-rw-r--r-- 1 u g 100 Jan 1 00:00 archivo.txt\r\n');
          }
        });
        return pasv.listen(0, '127.0.0.1', () => {
          const p = pasv.address().port;
          ctrl.write(`227 Modo pasivo (127,0,0,1,${p >> 8},${p & 255})\r\n`);
        });
      }

      if (cmd === 'LIST' || cmd === 'RETR') {
        ctrl.write('150 Ahí va\r\n');
        if (modo === 'cortar-en-datos') {
          // El canal de control se cae mientras el archivo viaja.
          return setTimeout(() => ctrl.destroy(), 60);
        }
        return setTimeout(() => ctrl.write('226 Listo\r\n'), 40);
      }

      ctrl.write('200 Ok\r\n');
    });

    ctrl.on('close', () => { vivas--; });
  });

  return {
    escuchar: () => new Promise((r) => servidor.listen(0, '127.0.0.1', () => r(servidor.address().port))),
    // Hay que romper los sockets a mano: con el servidor mudo quedan abiertos
    // y close() esperaría para siempre. Colgaba la prueba, no el programa.
    cerrar: () => new Promise((r) => {
      for (const s of abiertos) { try { s.destroy(); } catch {} }
      servidor.close(r);
    }),
  };
}

const conDest = (puerto) => ({
  type: 'ftp', host: '127.0.0.1', port: puerto,
  user: 'u', pass: 'p', remotePath: '/backup',
});

async function probar(nombre, modo, tarea, opciones = {}) {
  const srv = servidorHostil(modo, opciones.max);
  const puerto = await srv.escuchar();
  const antes = muertes.length;
  let error = null;
  try { await tarea(conDest(puerto)); } catch (e) { error = e; }
  // Le damos un instante a los sockets para que emitan lo que tengan pendiente.
  await new Promise((r) => setTimeout(r, 250));
  await srv.cerrar();
  return { error, murio: muertes.length > antes, detalle: muertes.slice(antes).join(' | ') };
}

console.log('BackupPrime — el programa sobrevive a un servidor FTP que se porta mal\n');

(async () => {
  titulo('Conexión');

  let r = await probar('saludo', 'cortar-en-saludo', async (dest) => {
    const s = new SesionFtp(dest);
    await s.conectar();
  });
  comprobar('1. Si corta apenas conecta, avisa sin matar el proceso', !r.murio, r.detalle);
  comprobar('2. Y el error llega como error, no como silencio', !!r.error);

  titulo('Listado');

  r = await probar('listado', 'cortar-en-listado', async (dest) => {
    const s = new SesionFtp(dest);
    await s.conectar();
    await s.listarTodo('/backup');
    await s.cerrar().catch(() => {});
  });
  comprobar('3. Si corta al pedir el listado, sobrevive', !r.murio, r.detalle);

  titulo('Descarga cortada a la mitad');

  r = await probar('datos', 'cortar-en-datos', async (dest) => {
    const s = new SesionFtp(dest);
    await s.conectar();
    await s.descargar('/backup/archivo.txt', path.join(TEMP, 'bajado.txt'));
    await s.cerrar().catch(() => {});
  });
  comprobar('4. Si el archivo se corta a la mitad, sobrevive', !r.murio, r.detalle);
  comprobar('5. No deja un archivo a medias haciéndose pasar por bueno',
    !fs.existsSync(path.join(TEMP, 'bajado.txt')));

  titulo('Varias descargas a la vez, con el servidor cortando');

  r = await probar('paralelo', 'cortar-en-datos', async (dest) => {
    // Como en la restauración real: seis conexiones bajando a la vez.
    await Promise.all(Array.from({ length: 6 }, async (_, i) => {
      try {
        const s = new SesionFtp(dest);
        await s.conectar();
        await s.descargar('/backup/archivo.txt', path.join(TEMP, `p${i}.txt`));
        await s.cerrar().catch(() => {});
      } catch { /* cada una falla por su cuenta */ }
    }));
  });
  comprobar('6. Seis descargas simultáneas contra un servidor que corta: sobrevive',
    !r.murio, r.detalle);

  titulo('El servidor no acepta tantas conexiones');

  r = await probar('demasiadas', 'rechazar-de-mas', async (dest) => {
    await Promise.all(Array.from({ length: 6 }, async () => {
      try {
        const s = new SesionFtp(dest);
        await s.conectar();
        await s.cerrar().catch(() => {});
      } catch { /* esperable */ }
    }));
  }, { max: 2 });
  comprobar('7. Si rechaza las conexiones de más, sobrevive', !r.murio, r.detalle);

  titulo('El servidor se queda mudo');

  r = await probar('mudo', 'mudo', async (dest) => {
    const s = new SesionFtp(dest);
    await s.conectar();
    await s.cerrar().catch(() => {});
  });
  comprobar('8. Si no contesta, corta por tiempo y sobrevive', !r.murio, r.detalle);

  titulo('El servidor manda una dirección a la que no se puede llegar');

  // Caso clásico: el FTP está detrás de un router y contesta con su IP interna.
  // Si el cliente le hace caso, intenta conectar a una dirección que desde
  // afuera no existe y se queda esperando para siempre. Era el cuelgue en
  // "Contando archivos…".
  const conIpInterna = net.createServer((ctrl) => {
    ctrl.on('error', () => {});
    ctrl.write('220 Servidor detrás de un router\r\n');
    ctrl.on('data', (d) => {
      const cmd = String(d).trim().split(' ')[0].toUpperCase();
      if (cmd === 'USER') return ctrl.write('331 Dale\r\n');
      if (cmd === 'PASS') return ctrl.write('230 Adelante\r\n');
      if (cmd === 'TYPE') return ctrl.write('200 Ok\r\n');
      // Contesta con 10.9.9.9, que no se puede alcanzar desde acá.
      if (cmd === 'PASV') return ctrl.write('227 Modo pasivo (10,9,9,9,200,1)\r\n');
      ctrl.write('200 Ok\r\n');
    });
  });
  const puertoIp = await new Promise((r) =>
    conIpInterna.listen(0, '127.0.0.1', () => r(conIpInterna.address().port)));

  const antesMuertes = muertes.length;
  const arranque = Date.now();
  let errorIp = null;
  try {
    const s = new SesionFtp(conDest(puertoIp));
    await s.conectar();
    await s.listar('/');
    await s.cerrar().catch(() => {});
  } catch (e) { errorIp = e; }
  const tardo = Date.now() - arranque;
  try { conIpInterna.close(); } catch {}

  comprobar('9. No se cuelga para siempre esperando esa dirección',
    tardo < 40000, `tardó ${Math.round(tardo / 1000)} s`);
  comprobar('10. Y el proceso sigue vivo', muertes.length === antesMuertes);
  comprobar('11. El error explica qué pasó', !!errorIp);

  console.log('\n──────────────────────────────────────────────────────');
  console.log(`  ${pasadas} de ${pasadas + falladas} pruebas pasadas`);
  if (falladas) { console.log('\n  Fallaron:'); for (const f of fallos) console.log(`    · ${f}`); }
  if (muertes.length) {
    console.log('\n  El proceso se habría muerto por:');
    for (const m of [...new Set(muertes)]) console.log(`    · ${m}`);
  }
  console.log('──────────────────────────────────────────────────────\n');

  try { fs.rmSync(TEMP, { recursive: true, force: true }); } catch {}
  process.exit(falladas ? 1 : 0);
})();
