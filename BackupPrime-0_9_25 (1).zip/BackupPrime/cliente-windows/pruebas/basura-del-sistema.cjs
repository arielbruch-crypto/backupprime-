'use strict';
/* La basura del sistema no se le ofrece al cliente.

   En el selector aparecía, mezclado con los documentos del estudio:

     snx_rhive{a59635f9-96b3-11f1-b705-74d02b304b36}.TMContainer0000…0001.regtrans-ms

   Son archivos de transacción del registro de Windows. No son datos del
   cliente, están siempre abiertos por el sistema, cambian todo el tiempo y no
   sirven de nada restaurados. Ofrecerlos tiene tres costos concretos:

     · llenan la lista de ruido y el cliente no encuentra lo suyo;
     · si los elige, generan errores de archivo bloqueado en CADA respaldo, y
       un cliente que ve errores todos los días deja de mirar los errores;
     · y `hiberfil.sys` o `pagefile.sys` son gigas de nada que se le cobran.

     node pruebas/basura-del-sistema.cjs                                      */

const fs = require('node:fs');
const fsp = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — la basura del sistema no se ofrece\n');

// Se lee el filtro DEL PRODUCTO, no una copia. Reimplementarlo acá haría que la
// prueba quede verde con el selector roto.
const fuente = fs.readFileSync(path.join(__dirname, '..', 'electron', 'main.cjs'), 'utf8');
const trozo = (nombre) => {
  const i = fuente.indexOf(`const ${nombre} = [`);
  if (i < 0) throw new Error(`no se encontró ${nombre} en main.cjs`);
  const j = fuente.indexOf('];', i);
  return eval(fuente.slice(i + `const ${nombre} = `.length, j + 1));
};
const BASURA = trozo('BASURA_DEL_SISTEMA');
const CARPETAS = trozo('CARPETAS_DEL_SISTEMA');
const esBasura = (n) => BASURA.some((r) => r.test(n));
const esCarpeta = (n) => CARPETAS.some((r) => r.test(n));

titulo('Lo que el cliente vio en su pantalla');

comprobar('El archivo exacto de la captura queda afuera',
  esBasura('snx_rhive{a59635f9-96b3-11f1-b705-74d02b304b36}.TMContainer00000000000000000001.regtrans-ms'));

titulo('Y el resto de la basura conocida');

for (const n of ['NTUSER.DAT', 'ntuser.dat.LOG1', 'UsrClass.dat',
                 'hiberfil.sys', 'pagefile.sys', 'swapfile.sys',
                 'Thumbs.db', 'desktop.ini', '.DS_Store',
                 'algo.blf', 'Acceso directo.lnk']) {
  comprobar(`Queda afuera: ${n}`, esBasura(n));
}

for (const n of ['$Recycle.Bin', '$WinREAgent', 'System Volume Information',
                 'Recovery', 'node_modules']) {
  comprobar(`Carpeta que queda afuera: ${n}`, esCarpeta(n));
}

titulo('Y —esto es lo que importa— los archivos del cliente SÍ pasan');

// Un filtro que se pasa de listo es peor que no tenerlo: dejar afuera un
// archivo del cliente es exactamente la falla que este producto no puede tener,
// y encima silenciosa.
for (const n of ['Balance 2026.xlsx', 'Libro IVA.pdf', 'ariel.bruch@itstandard.org.pst',
                 'Contrato.docx', 'backup ASSOFT 2026-08-13 (Completo).zip',
                 'foto familia.jpg', 'base.mdb', 'Clearswift 6.vdi',
                 'certificado.p12', 'notas.txt', 'sistema.sql',
                 'planilla.ods', 'documento.odt', 'presentacion.pptx']) {
  comprobar(`Se respalda: ${n}`, !esBasura(n));
}

for (const n of ['Documentos', 'Balances', 'Clientes 2026', 'Outlook Files',
                 'Mis documentos', 'Archivos de Outlook']) {
  comprobar(`Carpeta que se respalda: ${n}`, !esCarpeta(n));
}

titulo('Un archivo que solo CONTIENE una palabra prohibida no se filtra');

// El filtro tiene que mirar el nombre completo, no un pedazo. Si filtrara por
// "contiene", un archivo llamado `Balance ntuser.xlsx` desaparecería sin que
// nadie se entere.
comprobar('Balance ntuser.xlsx se respalda', !esBasura('Balance ntuser.xlsx'));
comprobar('mis lnk favoritos.docx se respalda', !esBasura('mis lnk favoritos.docx'));
comprobar('pagefile explicado.pdf se respalda', !esBasura('pagefile explicado.pdf'));

console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
if (falladas) { console.log(fallos.map((f) => ` · ${f}`).join('\n')); process.exit(1); }
