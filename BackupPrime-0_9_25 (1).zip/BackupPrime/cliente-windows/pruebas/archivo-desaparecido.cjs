'use strict';
// ---------------------------------------------------------------------------
// Un archivo que desapareció durante el respaldo no es una falla del respaldo.
//
// La pantalla de Actividad mostraba, en cada corrida:
//
//     No se pudo leer "app.asar": el archivo o la carpeta ya no existe
//
// Tres problemas en una línea:
//   1. dice el nombre pelado, sin la ruta: hay decenas de app.asar en un equipo
//      y el cliente no puede saber cuál es ni si le importa
//   2. no aclara que habla de SU equipo, no de la nube — la duda razonable es
//      "¿se me borró de la nube?"
//   3. lo cuenta como ERROR, así que el resumen dice "fallaron 1 archivo(s)"
//      todas las veces, siempre por lo mismo. Un aviso rojo permanente que no
//      significa nada enseña al cliente a ignorar TODOS los avisos, incluidos
//      los que sí importan.
//
//   node pruebas/archivo-desaparecido.cjs
// ---------------------------------------------------------------------------

const fs = require('node:fs');
const path = require('node:path');

let pasadas = 0, falladas = 0;
const fallos = [];
function comprobar(nombre, condicion, detalle = '') {
  if (condicion) { pasadas++; console.log(`  ok   ${nombre}`); }
  else { falladas++; fallos.push(nombre); console.log(`  FALLA ${nombre}${detalle ? ' — ' + detalle : ''}`); }
}
const titulo = (t) => console.log(`\n${t}`);

const { friendlyError } = require('../electron/backup-engine.cjs');
const motor = fs.readFileSync(path.join(__dirname, '..', 'electron', 'backup-engine.cjs'), 'utf8');

titulo('El texto dice qué pasó de verdad');
const texto = friendlyError('ENOENT: no such file or directory');
comprobar('Aclara que es en el equipo del cliente, no en la nube',
  /en tu equipo/.test(texto), texto);
comprobar('Y explica que se borró o se movió durante el respaldo',
  /mientras corría el respaldo/.test(texto), texto);
comprobar('Ya no dice el críptico "el archivo o la carpeta ya no existe"',
  !/^el archivo o la carpeta ya no existe$/.test(texto), texto);

titulo('Se muestra la ruta completa, no el nombre pelado');
const bloque = motor.slice(motor.indexOf('const desaparecido = classifyError'),
  motor.indexOf('const desaparecido = classifyError') + 900);
comprobar('El aviso usa file.sourcePath', /Se salteó "\$\{file\.sourcePath\}"/.test(bloque),
  bloque.slice(0, 200));
comprobar('Y el error también', /No se pudo leer "\$\{file\.sourcePath\}"/.test(bloque));
comprobar('No queda ningún basename en esos mensajes',
  !/basename\(file\.sourcePath\)/.test(bloque), bloque.slice(0, 300));

titulo('Un archivo que desapareció NO se cuenta como error');
comprobar('Se distingue por el tipo de error',
  /classifyError\(err\.message\) === "missing"/.test(bloque));
comprobar('Va a salteados, no a errores', /skipped\+\+/.test(bloque), bloque.slice(0, 400));
comprobar('Y se registra como aviso, no como error', /\[aviso\] Se salteó/.test(bloque));
comprobar('Lo demás sigue contando como error', /errors\+\+/.test(bloque));
comprobar('Le dice al cliente que puede ser normal',
  /es normal/.test(bloque));

titulo('La clasificación sigue funcionando para el resto');
comprobar('Un problema de permisos NO se saltea en silencio',
  /en uso o no hay permisos/.test(friendlyError('EACCES: permission denied')),
  friendlyError('EACCES: permission denied'));
comprobar('Sin espacio del plan se sigue diciendo claro',
  /espacio de tu plan/.test(friendlyError('QuotaExceeded: se agotó')),
  friendlyError('QuotaExceeded: se agotó'));

console.log('\n──────────────────────────────');
console.log(`${pasadas} pasadas, ${falladas} falladas`);
if (falladas) { console.log('Fallaron:'); fallos.forEach((f) => console.log('  · ' + f)); }
process.exit(falladas ? 1 : 0);
