'use strict';
// Respaldo y restauración de punta a punta contra S3 y SFTP, con servidores de
// prueba propios. Cubren lo que no tenía ninguna prueba: que un respaldo hecho
// a esos destinos se pueda efectivamente recuperar.
//
//   node pruebas/s3-sftp.cjs

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { crearServidorS3 } = require('./servidor-s3-prueba.cjs');
const { crearServidorSftp } = require('./servidor-sftp-prueba.cjs');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-s3sftp-'));
process.env.BACKUPPRIME_CONFIG_DIR = path.join(TEMP, 'config');
fs.mkdirSync(process.env.BACKUPPRIME_CONFIG_DIR, { recursive: true });

const {
  BackupEngine, s3Listar, s3Descargar, sftpListar, sftpDescargarVarios,
} = require('../electron/backup-engine.cjs');
const { armarArbol, rutasElegidas, filtrarSeleccion } = require('../electron/restore-remoto.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
function comprobar(nombre, condicion, detalle = '') {
  if (condicion) { pasadas++; console.log(`  ok   ${nombre}`); }
  else { falladas++; fallos.push(nombre); console.log(`  FALLA ${nombre}${detalle ? ' — ' + detalle : ''}`); }
}
const titulo = (t) => console.log(`\n${t}`);

const origen = path.join(TEMP, 'origen');
fs.mkdirSync(path.join(origen, 'Documentos'), { recursive: true });
fs.writeFileSync(path.join(origen, 'Documentos', 'balance.xlsx'), 'planilla contable');
fs.writeFileSync(path.join(origen, 'Documentos', 'contrato.pdf'), 'contrato firmado');
fs.writeFileSync(path.join(origen, 'notas.txt'), 'notas varias');

const cfgCon = (dests) => ({
  server: '', token: '',
  localPaths: [origen], excludedPaths: [],
  destinations: dests, maxVersions: 10,
  systemBackup: false, forceFullBackup: false,
});

const limpiarEstado = () => {
  try { fs.unlinkSync(path.join(process.env.BACKUPPRIME_CONFIG_DIR, 'state.json')); } catch {}
};

console.log('BackupPrime — pruebas de S3 y SFTP');

(async () => {
  // ══ S3 ═══════════════════════════════════════════════════════════════════
  titulo('S3 — respaldo');

  const s3 = crearServidorS3();
  const puertoS3 = await s3.escuchar();
  const destS3 = {
    type: 's3', endpoint: `http://127.0.0.1:${puertoS3}`, region: 'us-east-1',
    bucket: 'respaldos', prefix: 'estudio/', accessKey: 'AKIA', secretKey: 'secreta',
    label: 'S3 de prueba',
  };

  const motor = new BackupEngine();
  const log = [];
  motor.on('log', (l) => log.push(l.trim()));

  limpiarEstado();
  await motor.runOnce(cfgCon([destS3]));

  comprobar('1. Sube los 3 archivos', s3.stats.puts === 3, `puts: ${s3.stats.puts}`);
  comprobar('2. Sin errores', !log.some((l) => l.includes('[error]')),
    log.filter((l) => l.includes('[error]'))[0] || '');
  comprobar('3. Firma las peticiones', s3.stats.firmados >= 3);

  const antesS3 = s3.stats.puts;
  await motor.runOnce(cfgCon([destS3]));
  comprobar('4. La segunda corrida no vuelve a subir', s3.stats.puts === antesS3);

  titulo('S3 — restauración');

  const listado = await s3Listar(destS3);
  comprobar('5. Lista lo que hay en el bucket', listado.archivos.length === 3,
    `encontrados: ${listado.archivos.length}`);

  const itemsS3 = listado.archivos.map((a) => ({
    ruta: a.clave, size: a.size,
    rel: a.clave.replace(/^estudio\//, ''),
  }));
  const arbolS3 = armarArbol(itemsS3);
  comprobar('6. Arma el árbol de carpetas', arbolS3.length > 0);

  const buscar = (nodos, pred) => {
    for (const n of nodos) {
      if (pred(n)) return n;
      if (n.children) { const f = buscar(n.children, pred); if (f) return f; }
    }
    return null;
  };
  const carpeta = buscar(arbolS3, (n) => n.type === 'folder' && n.name === 'Documentos');
  const elegidos = filtrarSeleccion(itemsS3, rutasElegidas([{
    relPath: carpeta.relPath, fullPath: carpeta.fullPath, type: 'folder', name: carpeta.name,
  }], ''));
  comprobar('7. Elegir una carpeta baja lo que tiene adentro', elegidos.length === 2,
    `bajaría ${elegidos.length}`);

  const salidaS3 = path.join(TEMP, 'recuperado-s3');
  for (const a of elegidos) {
    await s3Descargar(destS3, a.ruta, path.join(salidaS3, ...a.rel.split('/')));
  }
  const balanceS3 = path.join(salidaS3, ...elegidos.find((a) => a.rel.endsWith('balance.xlsx')).rel.split('/'));
  comprobar('8. El archivo vuelve entero',
    fs.existsSync(balanceS3) && fs.readFileSync(balanceS3, 'utf8') === 'planilla contable');

  let fallo = null;
  try { await s3Descargar(destS3, 'estudio/no-existe.txt', path.join(TEMP, 'x')); }
  catch (e) { fallo = e; }
  comprobar('9. Avisa si el objeto no está', !!fallo);
  comprobar('10. No deja temporales al fallar', !fs.existsSync(path.join(TEMP, 'x')));

  titulo('S3 — nombres con espacios y acentos');

  // El primer archivo real de un estudio se llama así. Si la ruta que se firma
  // y la que se envía no coinciden exactamente, el archivo se guarda con un
  // nombre y se busca con otro.
  const raros = path.join(origen, 'Documentos');
  fs.writeFileSync(path.join(raros, 'Balance Ferretería Ruiz (final).xlsx'), 'planilla con nombre raro');

  limpiarEstado();
  const log3 = [];
  const motor3 = new BackupEngine();
  motor3.on('log', (l) => log3.push(l.trim()));
  await motor3.runOnce(cfgCon([destS3]));

  comprobar('9b. Sube un archivo con espacios, acentos y paréntesis',
    !log3.some((l) => l.includes('[error]')),
    log3.filter((l) => l.includes('[error]'))[0] || '');

  const listado2 = await s3Listar(destS3);
  const raro = listado2.archivos.find((a) => a.clave.includes('Ferreter'));
  comprobar('9c. Y aparece en el listado con su nombre entero', !!raro,
    listado2.archivos.map((a) => a.clave).join(' | '));

  const vuelta = path.join(TEMP, 'raro.xlsx');
  await s3Descargar(destS3, raro.clave, vuelta);
  comprobar('9d. Y se puede volver a bajar, con el mismo contenido',
    fs.readFileSync(vuelta, 'utf8') === 'planilla con nombre raro');

  // Se saca de la carpeta de origen: las pruebas de SFTP que siguen cuentan
  // archivos y este las descolocaba.
  fs.unlinkSync(path.join(raros, 'Balance Ferretería Ruiz (final).xlsx'));

  await s3.cerrar();

  // ══ SFTP ═════════════════════════════════════════════════════════════════
  titulo('SFTP — respaldo');

  const raizSftp = path.join(TEMP, 'sftp');
  const srvSftp = crearServidorSftp({ raiz: raizSftp, usuario: 'ana', clave: 'secreta' });
  const puertoSftp = await srvSftp.escuchar();
  const destSftp = {
    type: 'sftp', host: '127.0.0.1', port: puertoSftp,
    user: 'ana', pass: 'secreta', remotePath: '/respaldo', label: 'SFTP de prueba',
  };

  const log2 = [];
  const motor2 = new BackupEngine();
  motor2.on('log', (l) => log2.push(l.trim()));

  limpiarEstado();
  await motor2.runOnce(cfgCon([destSftp]));

  const contar = (raiz) => {
    let n = 0;
    (function walk(d) {
      for (const e of fs.readdirSync(d, { withFileTypes: true })) {
        if (e.isDirectory()) walk(path.join(d, e.name)); else n++;
      }
    })(raiz);
    return n;
  };
  comprobar('11. Sube los 3 archivos', contar(raizSftp) === 3, `en el servidor: ${contar(raizSftp)}`);
  comprobar('12. Sin errores', !log2.some((l) => l.includes('[error]')),
    log2.filter((l) => l.includes('[error]'))[0] || '');

  titulo('SFTP — restauración');

  const listadoSftp = await sftpListar(destSftp);
  comprobar('13. Lista lo que hay en el servidor', listadoSftp.archivos.length === 3,
    `encontrados: ${listadoSftp.archivos.length}`);
  comprobar('14. Conserva la estructura',
    listadoSftp.archivos.some((a) => a.ruta.includes('/Documentos/balance.xlsx')),
    listadoSftp.archivos.map((a) => a.ruta).join(' | '));

  const base = listadoSftp.base;
  const itemsSftp = listadoSftp.archivos.map((a) => ({
    ruta: a.ruta, size: a.size,
    rel: a.ruta.slice(base.length).replace(/^\/+/, ''),
  }));
  const salidaSftp = path.join(TEMP, 'recuperado-sftp');
  const r = await sftpDescargarVarios(destSftp, itemsSftp.map((a) => ({
    remotePath: a.ruta, destinoLocal: path.join(salidaSftp, ...a.rel.split('/')),
  })));
  comprobar('15. Baja todo por una sola conexión', r.ok === 3 && r.fallados === 0,
    `ok ${r.ok}, fallados ${r.fallados}`);
  comprobar('16. Una sola conexión para todo', srvSftp.stats.conexiones <= 12,
    `conexiones: ${srvSftp.stats.conexiones}`);

  const balanceSftp = path.join(salidaSftp,
    ...itemsSftp.find((a) => a.rel.endsWith('balance.xlsx')).rel.split('/'));
  comprobar('17. El archivo vuelve entero',
    fs.existsSync(balanceSftp) && fs.readFileSync(balanceSftp, 'utf8') === 'planilla contable');

  const rFallo = await sftpDescargarVarios(destSftp, [{
    remotePath: '/respaldo/no-existe.txt', destinoLocal: path.join(TEMP, 'y'),
  }]);
  comprobar('18. Cuenta como fallado lo que no está', rFallo.fallados === 1 && rFallo.ok === 0);
  comprobar('19. No deja temporales al fallar', !fs.existsSync(path.join(TEMP, 'y')));

  await srvSftp.cerrar();

  console.log('\n──────────────────────────────────────────────────────');
  console.log(`  ${pasadas} de ${pasadas + falladas} pruebas pasadas`);
  if (falladas) { console.log('\n  Fallaron:'); for (const f of fallos) console.log(`    · ${f}`); }
  console.log('──────────────────────────────────────────────────────\n');

  try { fs.rmSync(TEMP, { recursive: true, force: true }); } catch {}
  process.exit(falladas ? 1 : 0);
})();
