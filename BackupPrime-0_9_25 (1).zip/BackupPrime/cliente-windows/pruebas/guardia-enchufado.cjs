'use strict';
// ---------------------------------------------------------------------------
// El guardia anti-ransomware está ENCHUFADO al motor.
//
// El módulo `guardia-cifrado.cjs` estaba escrito y probado desde hacía
// versiones, y no lo llamaba nadie. Sus pruebas pasaban en verde mientras el
// producto no tenía ninguna protección: probaban el módulo aislado, no que el
// respaldo lo usara.
//
// Estas pruebas son de la conexión, no del módulo:
//   1. el motor lo importa y lo arma con la referencia y las extensiones reales
//   2. el bucle de archivos lo consulta ANTES de subir
//   3. al disparar, corta el respaldo y avisa
//   4. main.cjs escucha ese aviso y lo manda al servidor
//
//   node pruebas/guardia-enchufado.cjs
// ---------------------------------------------------------------------------

const fs = require('node:fs');
const path = require('node:path');

let pasadas = 0, falladas = 0;
const fallos = [];
function comprobar(nombre, condicion, detalle = '') {
  if (condicion) { pasadas++; console.log(`  ok   ${nombre}`); }
  else { falladas++; fallos.push(nombre); console.log(`  FALLA ${nombre}${detalle ? ' — ' + detalle : ''}`); }
}
const titulo = (t) => console.log(`\n${t}`);

const motor = fs.readFileSync(path.join(__dirname, '..', 'electron', 'backup-engine.cjs'), 'utf8');
const principal = fs.readFileSync(path.join(__dirname, '..', 'electron', 'main.cjs'), 'utf8');

titulo('El motor conoce al guardia');
comprobar('backup-engine importa guardia-cifrado',
  /require\(["']\.\/guardia-cifrado\.cjs["']\)/.test(motor));
comprobar('Arma un GuardiaCifrado', /new GuardiaCifrado\(/.test(motor));

titulo('Lo arma con datos reales, no con valores de relleno');
const armado = (motor.match(/new GuardiaCifrado\(\{[\s\S]{0,400}?\}\)/) || [''])[0];
comprobar('Le pasa cuándo fue el último respaldo',
  /referenciaMs:\s*ultimoRespaldoMs/.test(armado), armado.slice(0, 160));
comprobar('Le pasa las extensiones que ya se habían visto',
  /extensionesConocidas:\s*extensionesDelEstado\(/.test(armado));
comprobar('En el primer respaldo no dispara: ahí TODO es nuevo',
  /primerRespaldo:\s*!ultimoRespaldoMs/.test(armado));

titulo('Se consulta en el recorrido, archivo por archivo');
comprobar('El bucle consulta al guardia', /revisarConGuardia\(guardia, file, this\)/.test(motor));

// Lo importante: que la consulta esté ANTES de meter el archivo en la cola de
// subida. Si estuviera después, el archivo cifrado ya viajó.
const posVer = motor.indexOf('revisarConGuardia(guardia, file, this)');
const posEncolar = motor.indexOf('reserva.push(file)', posVer > 0 ? posVer - 500 : 0);
comprobar('Y consulta ANTES de encolar el archivo para subir',
  posVer > 0 && posEncolar > posVer, `ver=${posVer} encolar=${posEncolar}`);

// ── Comportamiento, no texto ──────────────────────────────────────────────
//
// Lo de arriba es lectura de código y tiene un límite: envolver la llamada en
// `if (false && ...)` dejaba el guardia desenchufado y la prueba pasaba igual.
// Por eso la decisión vive en una función exportada y acá se EJECUTA.
titulo('Al disparar, corta de verdad (ejecutando)');
const { revisarConGuardia } = require('../electron/backup-engine.cjs');

function motorFalso() {
  const eventos = [], registro = [];
  return {
    _cancelado: false, _ransomware: null, eventos, registro,
    log: (t) => registro.push(t),
    emit: (nombre, datos) => eventos.push({ nombre, datos }),
  };
}
const guardiaQueDispara = { ver: () => true, informe: () => ({ disparo: true, motivos: ['motivo de prueba'] }) };
const guardiaTranquilo = { ver: () => false, informe: () => ({ disparo: false, motivos: [] }) };

let m = motorFalso();
let corta = revisarConGuardia(guardiaQueDispara, { sourcePath: 'x', mtimeMs: 1 }, m);
comprobar('Devuelve true para cortar el recorrido', corta === true);
comprobar('Cancela el respaldo', m._cancelado === true);
comprobar('Guarda el informe para poder explicar por qué', !!m._ransomware);
comprobar('Emite el aviso', m.eventos.some((e) => e.nombre === 'ransomware'));
comprobar('Lo deja en el registro', m.registro.some((l) => /\[ALERTA\]/.test(l)));
comprobar('Y el registro dice el motivo concreto',
  m.registro.some((l) => /motivo de prueba/.test(l)), JSON.stringify(m.registro));

m = motorFalso();
corta = revisarConGuardia(guardiaTranquilo, { sourcePath: 'x', mtimeMs: 1 }, m);
comprobar('Un día normal NO corta nada', corta === false && m._cancelado === false);
comprobar('Ni avisa', m.eventos.length === 0);

titulo('Con archivos cifrados de verdad, el guardia dispara');
const { GuardiaCifrado } = require('../electron/guardia-cifrado.cjs');
const os = require('node:os');
const crypto = require('node:crypto');
const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-ransom-'));
const ahora = Date.now();
const g = new GuardiaCifrado({ referenciaMs: ahora - 3600e3, extensionesConocidas: new Set(['.xlsx', '.pdf']) });
const motorReal = motorFalso();
let cortoEn = -1;
for (let i = 0; i < 60; i++) {
  // Bytes al azar = entropía de cifrado, con una extensión que nunca se vio.
  const ruta = path.join(TEMP, `documento-${i}.xlsx.bloqueado`);
  fs.writeFileSync(ruta, crypto.randomBytes(70000));
  const archivo = { sourcePath: ruta, mtimeMs: ahora - (60 - i) * 200 };
  if (revisarConGuardia(g, archivo, motorReal)) { cortoEn = i; break; }
}
comprobar('Frenó el respaldo antes de recorrer los 60 archivos', cortoEn > 0 && cortoEn < 60,
  `cortó en ${cortoEn}`);
comprobar('Y explica por qué, con números', (motorReal._ransomware.motivos || []).length >= 2,
  JSON.stringify(motorReal._ransomware.motivos));
fs.rmSync(TEMP, { recursive: true, force: true });

titulo('La alerta llega al usuario y al servidor');
comprobar('main.cjs escucha el aviso', /engine\.on\(["']ransomware["']/.test(principal));
const oyente = principal.slice(principal.indexOf('engine.on("ransomware"'),
  principal.indexOf('engine.on("ransomware"') + 1600);
comprobar('Muestra una notificación', /new Notification\(/.test(oyente));
comprobar('Marcada como urgente: un cifrado a la madrugada tiene que despertar',
  /urgency:\s*["']critical["']/.test(oyente));
comprobar('No la silencia', /silent:\s*false/.test(oyente));
comprobar('Avisa al servidor', /\/api\/agent\/alerta/.test(oyente));
comprobar('Le dice al cliente que sus copias anteriores están a salvo',
  /a salvo/.test(oyente), oyente.slice(0, 200));
comprobar('Si no se puede avisar al servidor, la alerta local igual sale',
  /catch[\s\S]{0,160}No se pudo avisar al servidor/.test(oyente));

titulo('El servidor recibe la alerta');
const servidor = fs.readFileSync(
  path.join(__dirname, '..', '..', 'servidor-y-portal', 'servidor', 'servidor.cjs'), 'utf8');
comprobar('Existe la ruta /api/agent/alerta',
  /'POST \/api\/agent\/alerta'/.test(servidor));
const ruta = servidor.slice(servidor.indexOf("'POST /api/agent/alerta'"),
  servidor.indexOf("'POST /api/agent/alerta'") + 2200);
comprobar('Solo la puede usar un agente con sesión',
  /tipo !== 'agente'/.test(ruta));
comprobar('Queda en la auditoría', /auditar\(/.test(ruta));
comprobar('Le avisa por mail al cliente', /encolarAviso\(/.test(ruta));
comprobar('Y también a Ariel, que el cliente puede no leer el mail',
  /admin\.email/.test(ruta));

console.log('\n──────────────────────────────');
console.log(`${pasadas} pasadas, ${falladas} falladas`);
if (falladas) { console.log('Fallaron:'); fallos.forEach((f) => console.log('  · ' + f)); }
process.exit(falladas ? 1 : 0);
