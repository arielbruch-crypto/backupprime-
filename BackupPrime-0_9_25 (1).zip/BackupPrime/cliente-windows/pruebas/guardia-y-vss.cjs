'use strict';

// ---------------------------------------------------------------------------
// Pruebas de los módulos agregados a BackupPrime 0.5.3.
//
//   node pruebas/guardia-y-vss.cjs
//
// No toca backup-engine.cjs ni main.cjs. Prueba solo los módulos nuevos, para
// que si algo falla se sepa que es del agregado y no del motor que ya andaba.
// ---------------------------------------------------------------------------

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');

const { GuardiaCifrado, entropia, extensionesDelEstado } =
  require('../electron/guardia-cifrado.cjs');
const vss = require('../electron/vss.cjs');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-guardia-'));

let pasadas = 0, falladas = 0;
const fallos = [];

function comprobar(nombre, condicion, detalle = '') {
  if (condicion) { pasadas++; console.log(`  ok   ${nombre}`); }
  else { falladas++; fallos.push(nombre); console.log(`  FALLA ${nombre}${detalle ? ' — ' + detalle : ''}`); }
}
const titulo = (t) => console.log(`\n${t}`);

// Genera un archivo con contenido de entropía controlada.
function archivo(nombre, tipo, mtimeMs) {
  const ruta = path.join(TEMP, nombre);
  if (tipo === 'cifrado') fs.writeFileSync(ruta, crypto.randomBytes(80000));
  else if (tipo === 'texto') fs.writeFileSync(ruta, 'Balance general del ejercicio 2025. '.repeat(3000));
  else fs.writeFileSync(ruta, Buffer.alloc(80000, 0x41));
  if (mtimeMs) fs.utimesSync(ruta, mtimeMs / 1000, mtimeMs / 1000);
  const st = fs.statSync(ruta);
  return { sourcePath: ruta, size: st.size, mtimeMs: mtimeMs || st.mtimeMs };
}

console.log('BackupPrime — pruebas de los módulos agregados');
console.log(`Carpeta temporal: ${TEMP}`);

// ---------------------------------------------------------------- entropía
titulo('Entropía');
const cif = archivo('cifrado.bin', 'cifrado');
const txt = archivo('balance.txt', 'texto');
comprobar('1. Datos aleatorios miden entropía de cifrado', entropia(cif.sourcePath) >= 7.6,
  String(entropia(cif.sourcePath).toFixed(2)));
comprobar('2. Texto normal mide entropía baja', entropia(txt.sourcePath) < 6,
  String(entropia(txt.sourcePath).toFixed(2)));
comprobar('3. Archivo inexistente devuelve 0 en vez de romper',
  entropia(path.join(TEMP, 'no-existe.bin')) === 0);

// ------------------------------------------------------------- primer respaldo
titulo('Primer respaldo');
const g0 = new GuardiaCifrado({ primerRespaldo: true });
let disparo0 = false;
for (let i = 0; i < 100; i++) disparo0 = g0.ver(archivo(`p${i}.locked`, 'cifrado', Date.now())) || disparo0;
comprobar('4. No dispara nunca en el primer respaldo', !disparo0 && !g0.informe().disparo);

// -------------------------------------------------------------- caso legítimo
titulo('Trabajo normal de un estudio contable');
const ayer = Date.now() - 86400000;
const conocidas = new Set(['.xlsx', '.pdf', '.docx', '.txt']);
const g1 = new GuardiaCifrado({ referenciaMs: ayer, extensionesConocidas: conocidas });
let disparo1 = false;
for (let i = 0; i < 30; i++) {
  // Un contador guarda 30 planillas a lo largo de la mañana: 4 minutos entre cada una.
  const f = archivo(`libro${i}.txt`, 'texto', ayer + 3600000 + i * 240000);
  disparo1 = g1.ver(f) || disparo1;
}
comprobar('5. No dispara con trabajo espaciado en el tiempo', !disparo1, g1.informe().motivos.join('; '));

titulo('Exportación masiva legítima (una sola señal)');
const g2 = new GuardiaCifrado({ referenciaMs: ayer, extensionesConocidas: conocidas });
let disparo2 = false;
for (let i = 0; i < 400; i++) {
  // Tango exporta 400 recibos en dos minutos. Tasa altísima, pero entropía baja
  // y extensión conocida: una sola señal, no alcanza.
  const f = archivo(`recibo${i}.txt`, 'texto', ayer + 3600000 + i * 300);
  disparo2 = g2.ver(f) || disparo2;
}
const inf2 = g2.informe();
comprobar('6. La tasa alta sola no alcanza para cortar', !disparo2, inf2.motivos.join('; '));
comprobar('7. Igual registra la señal de tasa', inf2.motivos.length === 1, `${inf2.motivos.length} motivos`);

// ---------------------------------------------------------------- ransomware
titulo('Ransomware');
const g3 = new GuardiaCifrado({ referenciaMs: ayer, extensionesConocidas: conocidas });
let disparo3 = false, vistosHastaDisparo = 0;
for (let i = 0; i < 300; i++) {
  const f = archivo(`doc${i}.locked`, 'cifrado', ayer + 3600000 + i * 150);
  vistosHastaDisparo++;
  if (g3.ver(f)) { disparo3 = true; break; }
}
const inf3 = g3.informe();
comprobar('8. Detecta cifrado masivo', disparo3, inf3.motivos.join('; '));
comprobar('9. Corta antes de recorrer todo', vistosHastaDisparo < 300, `cortó en ${vistosHastaDisparo}`);
comprobar('10. Explica con al menos dos señales', inf3.motivos.length >= 2);
comprobar('11. El informe trae los números para el portal',
  inf3.señales.archivosPorMinuto > 0 && inf3.señales.medidos > 0);

// -------------------------------------------------- formatos ya comprimidos
titulo('Falsos positivos por formato');
const g4 = new GuardiaCifrado({ referenciaMs: ayer, extensionesConocidas: new Set(['.xlsx']) });
for (let i = 0; i < 60; i++) {
  // 60 xlsx nuevos: los xlsx miden ~7.9 de entropía estando sanos.
  g4.ver(archivo(`planilla${i}.xlsx`, 'cifrado', ayer + 3600000 + i * 200));
}
const inf4 = g4.informe();
comprobar('12. No mide entropía de formatos ya comprimidos', inf4.señales.medidos === 0);
comprobar('13. Un lote de xlsx no dispara el guardia', !inf4.disparo, inf4.motivos.join('; '));

// --------------------------------------------------------- extensiones nuevas
titulo('Extensiones nuevas');
const g5 = new GuardiaCifrado({ referenciaMs: ayer, extensionesConocidas: conocidas });
for (let i = 0; i < 25; i++) g5.ver(archivo(`x${i}.crypt`, 'texto', ayer + 3600000 + i * 240000));
const inf5 = g5.informe();
comprobar('14. Detecta un lote con extensión desconocida',
  inf5.señales.extensionesNuevas.some((e) => e.extension === '.crypt'));
comprobar('15. Sola tampoco alcanza para cortar', !inf5.disparo);

comprobar('16. Deriva las extensiones conocidas del StateStore',
  extensionesDelEstado({ 'C:\\a\\x.xlsx': {}, 'C:\\b\\y.pdf': {} }).has('.xlsx'));

// ---------------------------------------------------------------------- VSS
titulo('VSS');
const disp = vss.disponible();
comprobar('17. Informa por qué no hay instantáneas en vez de romper',
  typeof disp.ok === 'boolean' && (disp.ok || typeof disp.motivo === 'string'), disp.motivo);
comprobar('18. Agrupa carpetas por volumen', vss.volumenesDe(['C:\\a', 'C:\\b', 'D:\\c']).length === 2);
const vacio = { activas: [], porVolumen: new Map() };
comprobar('19. Sin instantánea lee del archivo original',
  vss.rutaDeLectura('C:\\x\\y.mdb', vacio) === 'C:\\x\\y.mdb');
const falsa = { volumen: 'C', dispositivo: '\\\\?\\GLOBALROOT\\Device\\HarddiskVolumeShadowCopy7', id: 'x' };
comprobar('20. Traduce la ruta al dispositivo sombra',
  (vss.traducirRuta('C:\\Tango\\Padron.mdb', falsa) || '').includes('ShadowCopy7'));
comprobar('21. No traduce rutas de otro volumen',
  vss.traducirRuta('D:\\Tango\\Padron.mdb', falsa) === null);
comprobar('22. crearParaCarpetas devuelve un objeto usable aunque falle',
  (() => { const e = vss.crearParaCarpetas(['C:\\x'], () => {}); return Array.isArray(e.activas); })());

console.log('\n' + '─'.repeat(54));
console.log(`  ${pasadas} de ${pasadas + falladas} pruebas pasadas`);
if (falladas) { console.log('\n  Fallaron:'); for (const f of fallos) console.log(`   · ${f}`); }
console.log('─'.repeat(54));

try { fs.rmSync(TEMP, { recursive: true, force: true }); } catch (_) {}
process.exit(falladas > 0 ? 1 : 0);
