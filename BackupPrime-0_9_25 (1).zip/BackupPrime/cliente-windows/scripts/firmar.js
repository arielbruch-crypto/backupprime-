'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Firma del instalador.

   Desde 2023 ningún certificado de firma de código se entrega como archivo:
   la clave privada vive en un token USB o en un HSM en la nube, y firmar es
   pedirle al proveedor que firme. Por eso esto no es "poner un archivo .pfx en
   una carpeta" sino llamar a signtool con el proveedor configurado.

   Si no hay certificado configurado, NO falla la compilación: sigue sin firmar,
   avisando por pantalla. Así el build de todos los días no depende del token.

   Variables que activan la firma:

     BP_FIRMA=certum        Certum Standard Code Signing in the Cloud (SimplySign)
     BP_FIRMA=sslcom        SSL.com eSigner
     BP_FIRMA=token         Certificado en token USB ya instalado en Windows
     BP_FIRMA_SUJETO        Nombre exacto del titular, ej. "BackupPrime SRL"
     BP_FIRMA_HUELLA        Alternativa al nombre: huella SHA-1 del certificado
     BP_FIRMA_CSP           Proveedor criptográfico, si el proveedor pide uno
     BP_FIRMA_CONTENEDOR    Contenedor de la clave, si el proveedor pide uno
   ═══════════════════════════════════════════════════════════════════════════ */

const { execFileSync } = require('node:child_process');

const SELLO = 'http://timestamp.digicert.com';

module.exports = async function firmar(configuracion) {
  const archivo = configuracion.path;
  const modo = process.env.BP_FIRMA;

  if (!modo) {
    console.log(`  ⚠ Sin firmar: ${archivo}`);
    console.log('    Windows va a mostrar "Editor desconocido" al instalarlo.');
    console.log('    Ver FIRMA.md para configurar el certificado.');
    return;
  }

  const argumentos = ['sign', '/fd', 'sha256', '/td', 'sha256', '/tr', SELLO];

  if (process.env.BP_FIRMA_HUELLA) {
    argumentos.push('/sha1', process.env.BP_FIRMA_HUELLA);
  } else if (process.env.BP_FIRMA_SUJETO) {
    argumentos.push('/n', process.env.BP_FIRMA_SUJETO);
  } else {
    throw new Error('Falta BP_FIRMA_SUJETO o BP_FIRMA_HUELLA para poder firmar.');
  }

  // Los certificados en la nube se usan a través de un proveedor criptográfico
  // que el instalador del servicio deja registrado en Windows.
  if (process.env.BP_FIRMA_CSP) argumentos.push('/csp', process.env.BP_FIRMA_CSP);
  if (process.env.BP_FIRMA_CONTENEDOR) argumentos.push('/kc', process.env.BP_FIRMA_CONTENEDOR);

  // El almacén de máquina se usa cuando el certificado está instalado para
  // todos los usuarios, que es lo habitual con los tokens.
  if (modo === 'token') argumentos.push('/sm');

  argumentos.push(archivo);

  try {
    execFileSync('signtool.exe', argumentos, { stdio: 'inherit' });
    console.log(`  ✓ Firmado: ${archivo}`);
  } catch (e) {
    // Acá sí conviene cortar: un instalador a medio firmar es peor que uno sin
    // firmar, porque Windows lo trata como archivo alterado.
    throw new Error(
      `Falló la firma de ${archivo}. Revisá que el token esté conectado o que la ` +
      `sesión del servicio en la nube esté abierta. Detalle: ${e.message}`);
  }
};
