'use strict';
/* Antes de compilar una versión para publicar, comprueba que la firma esté
   realmente configurada. Sirve para no descubrir después de subir el archivo
   que salió sin firmar.

     node scripts/verificar-firma.cjs                                          */

const { execFileSync } = require('node:child_process');

let problemas = [];
let avisos = [];

const modo = process.env.BP_FIRMA;
if (!modo) {
  problemas.push('BP_FIRMA no está definida. Sin eso el instalador sale sin firmar.');
} else if (!['certum', 'sslcom', 'token'].includes(modo)) {
  avisos.push(`BP_FIRMA="${modo}" no es uno de los conocidos (certum, sslcom, token).`);
}

if (!process.env.BP_FIRMA_SUJETO && !process.env.BP_FIRMA_HUELLA) {
  problemas.push('Falta BP_FIRMA_SUJETO (el titular del certificado) o BP_FIRMA_HUELLA.');
}

if (process.platform !== 'win32') {
  problemas.push('La firma solo se puede hacer desde Windows: signtool.exe es de Windows.');
} else {
  try {
    execFileSync('where', ['signtool.exe'], { stdio: 'pipe' });
  } catch {
    problemas.push('No se encontró signtool.exe. Se instala con el Windows SDK.');
  }
}

if (modo === 'token' && !process.env.BP_FIRMA_HUELLA) {
  avisos.push('Con token conviene usar BP_FIRMA_HUELLA: si tenés más de un ' +
              'certificado con nombre parecido, signtool puede elegir el equivocado.');
}

console.log('\nVerificación de la firma\n');
for (const a of avisos) console.log(`  aviso   ${a}`);
for (const p of problemas) console.log(`  FALTA   ${p}`);

if (!problemas.length) {
  console.log('  ok      Todo listo para firmar.');
  console.log(`  ok      Titular: ${process.env.BP_FIRMA_SUJETO || process.env.BP_FIRMA_HUELLA}`);
  console.log('\nDespués de compilar, verificá el resultado con:');
  console.log('  signtool verify /pa /v dist\\BackupPrime-Setup-0.5.7.exe\n');
  process.exit(0);
}

console.log('\nEl instalador saldría con "Editor desconocido". Ver FIRMA.md.\n');
process.exit(1);
