#!/usr/bin/env node
"use strict";
/**
 * Compila la versión "legacy" de BackupPrime para Windows 7, 8 y 8.1.
 *
 * Por qué hace falta un build aparte:
 * Electron dejó de soportar Windows 7/8/8.1 a partir de la versión 23.
 * La versión 22 es la última que arranca en esos sistemas. Como no se puede
 * tener dos versiones de Electron en el mismo package.json, este script
 * arma una copia del proyecto con Electron 22 y compila desde ahí.
 *
 * El código de la app es el mismo: no mantenemos dos versiones del producto.
 *
 * Uso:  npm run build:win-legacy
 * Sale: dist-legacy/BackupPrime Setup <version> (Windows 7-8.1).exe
 */

const fs = require("fs");
const path = require("path");
const { execSync } = require("child_process");

const ROOT = path.join(__dirname, "..");
const WORK = path.join(ROOT, ".legacy-build");
const OUT = path.join(ROOT, "dist-legacy");

const ELECTRON_LEGACY = "22.3.27"; // última que arranca en Windows 7/8/8.1

function log(msg) { console.log(`[legacy] ${msg}`); }

function copyApp() {
  fs.rmSync(WORK, { recursive: true, force: true });
  fs.mkdirSync(WORK, { recursive: true });

  // Copiamos solo el código de la app; las dependencias se instalan limpias
  fs.cpSync(path.join(ROOT, "electron"), path.join(WORK, "electron"), { recursive: true });

  const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, "package.json"), "utf8"));

  pkg.devDependencies = {
    electron: ELECTRON_LEGACY,
    "electron-builder": pkg.devDependencies["electron-builder"] || "^25.0.0",
  };
  pkg.scripts = { build: "electron-builder --win --ia32" };

  // ia32 (32 bits) porque muchas máquinas viejas corren Windows de 32 bits,
  // y el instalador de 32 bits funciona también en las de 64.
  pkg.build = {
    appId: "com.backupprime.agent",
    productName: "BackupPrime",
    directories: { output: OUT },
    artifactName: "BackupPrime Setup ${version} (Windows 7-8.1).${ext}",
    win: {
      target: [{ target: "nsis", arch: ["ia32"] }],
      requestedExecutionLevel: "asInvoker",
    },
    nsis: {
      oneClick: false,
      allowToChangeInstallationDirectory: true,
      perMachine: false,
      createDesktopShortcut: true,
      shortcutName: "BackupPrime",
    },
  };

  fs.writeFileSync(path.join(WORK, "package.json"), JSON.stringify(pkg, null, 2));
  log(`proyecto preparado con Electron ${ELECTRON_LEGACY}`);
}

function build() {
  log("instalando dependencias (puede tardar unos minutos)…");
  execSync("npm install --no-audit --no-fund", { cwd: WORK, stdio: "inherit" });

  log("compilando instalador de 32 bits…");
  execSync("npx electron-builder --win --ia32", { cwd: WORK, stdio: "inherit" });

  log(`listo → ${OUT}`);
}

try {
  copyApp();
  build();
} catch (err) {
  console.error("[legacy] falló la compilación:", err.message);
  process.exit(1);
} finally {
  fs.rmSync(WORK, { recursive: true, force: true });
}
