@echo off
REM ============================================================
REM  BackupPrime - compilar instalador para Windows 10 y 11
REM
REM  Requisitos: Node.js 18 o superior instalado.
REM  Uso: doble clic en este archivo.
REM ============================================================
setlocal
cd /d "%~dp0"

echo.
echo   BackupPrime - compilando instalador
echo   -----------------------------------
echo.

where node >nul 2>&1
if errorlevel 1 (
  echo   [ERROR] No se encontro Node.js.
  echo   Instalalo desde https://nodejs.org y volve a ejecutar este archivo.
  echo.
  pause
  exit /b 1
)

echo   [1/2] Instalando dependencias...
call npm install --no-audit --no-fund
if errorlevel 1 (
  echo.
  echo   [ERROR] Fallo la instalacion de dependencias.
  pause
  exit /b 1
)

echo.
echo   [2/2] Compilando el instalador...
call npm run build:win
if errorlevel 1 (
  echo.
  echo   [ERROR] Fallo la compilacion.
  pause
  exit /b 1
)

echo.
echo   Listo. El instalador quedo en la carpeta dist\
echo.
if exist dist (start "" "dist")
pause
