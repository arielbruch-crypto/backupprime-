# Instalador de Windows — BackupPrime 0.5.3

Archivo generado: **`BackupPrime-Setup-0.5.3.exe`** (77 MB, Windows 10 y 11, 64 bits).

---

## Qué hace el instalador

| | |
|---|---|
| Tipo | NSIS asistido (siguiente → siguiente), en castellano |
| Alcance | Para todos los usuarios del equipo (pide UAC) |
| Carpeta | `C:\Program Files\BackupPrime`, el usuario la puede cambiar |
| Licencia | Muestra `build/licencia.txt` y exige aceptarla |
| Accesos directos | Escritorio y menú Inicio |
| Al terminar | Ofrece abrir BackupPrime |
| Registro | Guarda versión y carpeta en `HKCU\Software\BackupPrime` |

**Al desinstalar** saca la entrada de arranque automático (si no, Windows tira
error en cada inicio buscando un `.exe` que ya no existe) y **pregunta** si
borrar también la configuración —cuenta, destinos, programación e historial—.
Durante una actualización no pregunta nada y conserva todo: el instalador nuevo
corre el desinstalador viejo en silencio, y ahí borrar sería perder la cuenta
del cliente en cada update.

Los archivos ya respaldados en el destino no se tocan nunca.

---

## Lo que no incluye

**No está firmado.** Windows va a mostrar el cartel de SmartScreen ("Editor
desconocido") en cada instalación. Está detallado en `FIRMA.md`; para vender a
estudios contables ese cartel es el primer obstáculo, así que el certificado EV
conviene resolverlo antes de salir a vender.

**El guardia anti-cifrado y VSS viajan adentro pero no están enchufados.**
`guardia-cifrado.cjs` y `vss.cjs` quedaron empaquetados y las 22 pruebas pasan,
pero `backup-engine.cjs` todavía no los llama: falta agregar los cinco
fragmentos de `INTEGRACION.md`. Instalado así, el programa se comporta
exactamente igual que el 0.5.3 sin los módulos. Cuando los integres, recompilás
y listo — el instalador no cambia.

---

## Recompilar

En una PC con Windows y Node.js 18 o superior: doble clic en
**`compilar-windows.bat`**. Instala dependencias, compila y abre `dist\`.

A mano:

```
npm install
npm run build:win
```

Otros comandos: `npm start` (abrir la app sin compilar), `npm run pruebas`
(las 22 pruebas de guardia y VSS), `npm run build:dir` (arma la carpeta
`win-unpacked` sin generar instalador, sirve para probar rápido).

---

## Dónde tocar cada cosa

| Querés cambiar | Archivo |
|---|---|
| Textos, macros y comportamiento de desinstalación | `build/installer.nsh` |
| Contrato de licencia | `build/licencia.txt` |
| Icono del programa y del instalador | `build/icon.ico` |
| Banner superior (150×57 px) | `build/installerHeader.bmp` |
| Panel lateral (164×314 px) | `build/installerSidebar.bmp` |
| Versión, alcance, accesos directos | bloque `build` de `package.json` |

Para que el instalador quede **por usuario** en vez de para todo el equipo
—sin UAC, instala en `%LOCALAPPDATA%`— poné `"perMachine": false` en el bloque
`nsis` de `package.json`.
