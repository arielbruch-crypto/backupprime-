'use strict';

const crypto = require('node:crypto');

/* ═══════════════════════════════════════════════════════════════════════════
   Cifrado de los archivos antes de subirlos.

   HASTA AHORA NO EXISTÍA: los archivos se subían tal cual, protegidos solo por
   TLS en tránsito y por el cifrado en reposo del proveedor de almacenamiento.
   Eso significa que el proveedor —y cualquiera que acceda a esa cuenta— puede
   leer los archivos de los clientes.

   ── Los dos modos ──────────────────────────────────────────────────────────

   El cliente elige, y la diferencia es quién puede recuperarlo si pierde la
   contraseña:

   · GESTIONADA (por defecto). La clave la guarda BackupPrime. Si el cliente
     pierde su contraseña, se le puede restablecer el acceso y bajar sus
     archivos. También permite restaurar desde la web. A cambio, BackupPrime
     puede técnicamente leer los archivos, y un ataque al servidor los expone.

   · PRIVADA. La clave se deriva de una frase que solo conoce el cliente y NUNCA
     viaja al servidor. Ni BackupPrime ni nadie que comprometa el servidor puede
     leer los archivos. A cambio: **si el cliente pierde esa frase, pierde todo,
     y no hay nada que se pueda hacer.** No es una limitación que se pueda
     sortear: es matemática. Y sin la clave en el servidor, la restauración por
     web no funciona para esa cuenta.

   Es el mismo esquema que ofrece IDrive, y existe porque los dos casos son
   reales: hay clientes que priorizan la privacidad y clientes que priorizan
   poder llamar por teléfono cuando se olvidaron la clave.

   ── Por qué la deduplicación sigue funcionando ─────────────────────────────

   Cada bloque se guarda bajo la huella de su contenido SIN cifrar, que es lo que
   el motor ya calcula. Antes de subir se pregunta si esa huella ya está en el
   destino; si está, no se sube nada. Recién si falta se cifra —con un vector de
   inicialización al azar— y se sube.

   Es importante que el vector sea al azar y no derivado del contenido. Derivarlo
   haría que dos archivos idénticos produzcan bytes idénticos, y eso permite
   confirmar si un archivo concreto está guardado sin tener la clave. Con vector
   al azar eso no se puede, y la deduplicación no se pierde, porque el ahorro
   sale de no volver a subir un bloque que ya está.
   ═══════════════════════════════════════════════════════════════════════════ */

const ALGORITMO = 'aes-256-gcm';
const MARCA = Buffer.from('BPE1');    // BackupPrime Encrypted, formato 1
const LARGO_IV = 12;                  // 96 bits, lo recomendado para GCM
const LARGO_ETIQUETA = 16;
const LARGO_SAL = 16;

/** Cabecera: marca(4) + iv(12) + etiqueta(16) = 32 bytes antes de los datos. */
const LARGO_CABECERA = MARCA.length + LARGO_IV + LARGO_ETIQUETA;

/**
 * Deriva la clave de cifrado a partir de una frase.
 *
 * scrypt con parámetros deliberadamente costosos: si alguien se lleva los datos
 * cifrados, probar frases una por una tiene que salirle caro. N=2^17 tarda del
 * orden de cien milisegundos, que es imperceptible al abrir el programa y
 * carísimo para quien quiera probar millones.
 */
function claveDesdeFrase(frase, sal) {
  if (!frase || String(frase).length < 8) {
    throw new Error('La frase de cifrado tiene que tener al menos 8 caracteres.');
  }
  return crypto.scryptSync(String(frase).normalize('NFKC'), sal, 32, {
    N: 131072, r: 8, p: 1, maxmem: 256 * 1024 * 1024,
  });
}

/** Una sal nueva, para guardar junto a la configuración de la cuenta. */
function salNueva() {
  return crypto.randomBytes(LARGO_SAL);
}

/** Una clave al azar, para el modo gestionado. */
function claveNueva() {
  return crypto.randomBytes(32);
}

/**
 * Cifra un bloque de datos.
 *
 * Formato: BPE1 | iv(12) | etiqueta(16) | datos cifrados
 *
 * La etiqueta de GCM va en la cabecera y no al final para poder validarla antes
 * de descifrar: si el archivo llegó corrupto o alterado, se detecta en lugar de
 * devolver basura. En un producto de backup, entregar datos corruptos que
 * parecen correctos es peor que fallar.
 */
function cifrar(datos, clave) {
  if (!Buffer.isBuffer(clave) || clave.length !== 32) {
    throw new Error('La clave de cifrado no es válida.');
  }
  const iv = crypto.randomBytes(LARGO_IV);
  const c = crypto.createCipheriv(ALGORITMO, clave, iv);
  const cuerpo = Buffer.concat([c.update(datos), c.final()]);
  return Buffer.concat([MARCA, iv, c.getAuthTag(), cuerpo]);
}

/** ¿Estos datos están cifrados por BackupPrime? */
function estaCifrado(datos) {
  return Buffer.isBuffer(datos) && datos.length >= LARGO_CABECERA &&
         datos.subarray(0, MARCA.length).equals(MARCA);
}

/**
 * Descifra un bloque.
 *
 * Si los datos no están cifrados, se devuelven tal cual: es lo que permite que
 * un cliente que ya tenía respaldos SIN cifrar los siga restaurando después de
 * activar el cifrado. Sin esto, activar la función rompería todo lo anterior.
 */
function descifrar(datos, clave) {
  if (!estaCifrado(datos)) return datos;
  if (!Buffer.isBuffer(clave) || clave.length !== 32) {
    throw new Error(
      'Estos archivos están cifrados y falta la clave para leerlos. ' +
      'Si usás una frase propia, escribila para poder restaurar.');
  }
  const iv = datos.subarray(MARCA.length, MARCA.length + LARGO_IV);
  const etiqueta = datos.subarray(MARCA.length + LARGO_IV, LARGO_CABECERA);
  const cuerpo = datos.subarray(LARGO_CABECERA);
  const d = crypto.createDecipheriv(ALGORITMO, clave, iv);
  d.setAuthTag(etiqueta);
  try {
    return Buffer.concat([d.update(cuerpo), d.final()]);
  } catch {
    // GCM falla si los datos fueron alterados O si la clave es la equivocada.
    // No se puede distinguir, así que el mensaje cubre los dos casos sin
    // afirmar cuál es.
    throw new Error(
      'No se pudieron descifrar los datos. La frase de cifrado puede ser ' +
      'incorrecta, o el archivo llegó dañado. No se restauró nada a medias.');
  }
}

/**
 * Comprobante para verificar que una frase es la correcta ANTES de restaurar.
 *
 * Sin esto, alguien que escribe mal su frase se entera después de bajar
 * gigabytes, cuando el primer bloque falla. Se guarda junto a la configuración
 * de la cuenta y se valida al ingresar.
 *
 * Es un texto conocido cifrado con la clave: no revela nada sobre la frase, pero
 * solo descifra bien con la clave correcta.
 */
const TESTIGO = Buffer.from('BackupPrime clave correcta');

function crearComprobante(clave) {
  return cifrar(TESTIGO, clave).toString('base64');
}

function comprobanteValido(comprobante, clave) {
  try {
    return descifrar(Buffer.from(String(comprobante), 'base64'), clave).equals(TESTIGO);
  } catch {
    return false;
  }
}

/**
 * Arma el juego de claves de una cuenta a partir de su configuración.
 *
 * `modo` es 'gestionada' o 'privada'. En gestionada la clave viene del servidor
 * ya lista; en privada se deriva de la frase que escribe el cliente y el
 * servidor nunca la ve.
 */
function abrirClave({ modo, claveServidor, frase, salBase64, comprobante }) {
  if (modo === 'privada') {
    if (!salBase64) throw new Error('Falta la configuración de cifrado de la cuenta.');
    const clave = claveDesdeFrase(frase, Buffer.from(salBase64, 'base64'));
    // Se valida ANTES de empezar, para no descubrir el error a mitad de una
    // restauración de horas.
    if (comprobante && !comprobanteValido(comprobante, clave)) {
      throw new Error(
        'La frase de cifrado no coincide con la de esta cuenta. ' +
        'Revisala: sin ella no se pueden leer los archivos, y nadie —tampoco ' +
        'BackupPrime— puede recuperarlos.');
    }
    return clave;
  }
  if (!claveServidor) return null;   // cuenta sin cifrado configurado todavía
  const clave = Buffer.from(claveServidor, 'base64');
  if (clave.length !== 32) throw new Error('La clave que envió el servidor no es válida.');
  return clave;
}

module.exports = {
  ALGORITMO, LARGO_CABECERA,
  cifrar, descifrar, estaCifrado,
  claveDesdeFrase, claveNueva, salNueva,
  crearComprobante, comprobanteValido, abrirClave,
};
