"use strict";
/**
 * BackupPrime backup engine — runs directly inside Electron's Node.js process.
 * Supports: Cloud (BackupPrime server), S3-compatible, FTP, Local/Network destinations.
 * Scheduler: interval OR specific days+time.
 * Incremental: tracks hash+mtime per file; first run is Full, subsequent are Incremental.
 */

const fs = require("node:fs");
const fsp = require("node:fs/promises");
const path = require("node:path");
const Vss = require("./vss.cjs");
const Cifrado = require("./cifrado.cjs");
const os = require("node:os");
const crypto = require("node:crypto");
const Bloques = require("./bloques.cjs");
const { GuardiaCifrado, extensionesDelEstado } = require("./guardia-cifrado.cjs");
const Cobertura = require("./cobertura.cjs");
const net = require("node:net");
const { EventEmitter } = require("node:events");
const https = require("node:https");
const http = require("node:http");

// Cuántos archivos se transfieren a la vez. Seis anda bien tanto en un disco
// externo como contra un servidor remoto: suficiente para tapar la latencia,
// sin saturar la conexión ni hacer que el servidor corte por exceso de
// conexiones simultáneas. Se puede cambiar desde la configuración.
const CONCURRENCIA_POR_DEFECTO = 6;

// A partir de este tamaño, un archivo se guarda por bloques en lugar de subirse
// entero cada vez que cambia. Medido: por debajo de 25 MB los bloques casi no
// ahorran (un archivo de 5 MB tiene 3 bloques, así que tocar algo cambia casi
// todo), y a partir de ahí el ahorro es enorme con un índice de menos de 1 KB.
// 25 MB agarra los PST, los CAD y los archivos de los sistemas de gestión.
const UMBRAL_BLOQUES_MB = 25;

// ─── Config dir ──────────────────────────────────────────────────────────────

function defaultConfigDir() {
  if (process.platform === "win32")
    return path.join(process.env.APPDATA || os.homedir(), "BackupPrime");
  if (process.platform === "darwin")
    return path.join(os.homedir(), "Library", "Application Support", "BackupPrime");
  return path.join(os.homedir(), ".config", "backupprime");
}

function getConfigDir() {
  return process.env.BACKUPPRIME_CONFIG_DIR || defaultConfigDir();
}

/** "3 días", "5 horas", "40 minutos". Para explicarle al usuario por qué se
 *  está respaldando ahora en lugar de esperar al horario. */
function fmtDuracion(ms) {
  const min = Math.floor(ms / 60000);
  if (min < 60) return `${min} minuto${min === 1 ? "" : "s"}`;
  const h = Math.floor(min / 60);
  if (h < 24) return `${h} hora${h === 1 ? "" : "s"}`;
  const d = Math.floor(h / 24);
  return `${d} día${d === 1 ? "" : "s"}`;
}

// ─── Espacio libre en disco ──────────────────────────────────────────────────
//
// Por qué esto existe: un cliente con el disco casi lleno respaldó 134 GB y la
// máquina se colgó. La causa no es el respaldo en sí —los bloques se arman en
// memoria y se suben directo, sin copia temporal— sino la INSTANTÁNEA de
// volumen. Cuando Windows crea una copia sombra reserva espacio en el mismo
// disco y lo va llenando con cada bloque que cambia mientras el respaldo corre.
// El máximo por defecto es el 10% del volumen. Con el disco al límite, Windows
// pelea por espacio y la máquina se arrastra hasta trabarse.
//
// El programa no puede dejar que eso pase sin avisar. Un respaldo que cuelga la
// computadora del cliente es peor que un respaldo que no corre.

/** Mínimos por debajo de los cuales conviene no crear instantáneas. */
const LIBRE_MINIMO_BYTES = 10 * 1024 * 1024 * 1024;   // 10 GB
const LIBRE_MINIMO_PROPORCION = 0.15;                  // o 15% del disco

/** Espacio libre y total de la unidad donde está esa ruta. */
async function espacioDe(ruta) {
  try {
    const st = await fsp.statfs(ruta);
    return {
      libre: st.bavail * st.bsize,
      total: st.blocks * st.bsize,
    };
  } catch {
    return null;
  }
}

/**
 * Revisa el espacio de cada unidad involucrada.
 *
 * Devuelve `{ ok, apretadas, critica }`. "Apretada" es una unidad donde no
 * conviene crear una instantánea; "crítica" es una donde el respaldo podría
 * directamente dejar la máquina inutilizable.
 */
async function revisarEspacio(rutas) {
  const porUnidad = new Map();
  for (const r of rutas) {
    // Una entrada por unidad, no por carpeta: da lo mismo cuántas carpetas se
    // respalden de C:, el espacio es el mismo.
    const unidad = process.platform === "win32"
      ? (String(r).match(/^([a-z]:)/i) || [null, r])[1]
      : "/";
    if (!porUnidad.has(unidad)) porUnidad.set(unidad, r);
  }

  const apretadas = [];
  let critica = false;
  for (const [unidad, muestra] of porUnidad) {
    const e = await espacioDe(muestra);
    if (!e || !e.total) continue;
    const proporcion = e.libre / e.total;
    const suficiente = e.libre >= LIBRE_MINIMO_BYTES || proporcion >= LIBRE_MINIMO_PROPORCION;
    if (!suficiente) {
      apretadas.push({ unidad, ...e, proporcion });
      // Por debajo del 3% Windows ya empieza a tener problemas por su cuenta.
      if (proporcion < 0.03 || e.libre < 2 * 1024 * 1024 * 1024) critica = true;
    }
  }
  return { ok: apretadas.length === 0, apretadas, critica };
}

// ─── State store ─────────────────────────────────────────────────────────────

class StateStore {
  constructor(configDir) {
    this._path = path.join(configDir, "state.json");
    this._data = {};
    this._sucio = false;
    this._ultimoFlush = 0;
    if (fs.existsSync(this._path)) {
      try { this._data = JSON.parse(fs.readFileSync(this._path, "utf8")); }
      catch { this._data = {}; }
    }
  }
  get(p) { return this._data[p]; }
  set(p, v) { this._data[p] = v; this._sucio = true; }
  delete(p) { delete this._data[p]; this._sucio = true; }
  /**
   * Las entradas que son ARCHIVOS, sin los datos internos del programa.
   *
   * Las claves que empiezan con "__" son del propio programa (la fecha del
   * último respaldo, la de la última verificación). Colarlas acá haría que el
   * programa trate esos valores como si fueran archivos del cliente.
   */
  entradas() {
    return Object.entries(this._data)
      .filter(([k, v]) => !k.startsWith("__") && v && typeof v === "object");
  }

  /**
   * ¿Hay registro de archivos ya respaldados? (o sea, ¿se puede hacer incremental?)
   *
   * Las claves que empiezan con "__" son datos del propio programa —como la fecha
   * del último respaldo—, no archivos. Sin excluirlas, un equipo que nunca
   * respaldó nada parecería tener estado y el primer respaldo se trataría como
   * incremental: no subiría nada.
   */
  hasState() {
    return Object.keys(this._data).some((k) => !k.startsWith("__"));
  }

  /**
   * Guarda el registro en disco.
   *
   * Antes se escribía el archivo entero después de CADA archivo respaldado, y
   * encima con sangría. Con 50.000 archivos eso son 50.000 escrituras de un
   * archivo que va creciendo: el respaldo se frena solo, y cada vez más a
   * medida que avanza. Ahora se agrupa: como mucho una escritura cada dos
   * segundos, y una final obligatoria al terminar.
   *
   * La escritura es atómica (temporal + renombrado): si se corta la luz en el
   * medio, el registro anterior queda entero. Un registro corrupto significa
   * volver a subir todo desde cero.
   */
  flush(forzar = false) {
    if (!this._sucio && !forzar) return;
    if (!forzar && Date.now() - this._ultimoFlush < 2000) return;
    const tmp = `${this._path}.tmp-${process.pid}`;
    try {
      fs.writeFileSync(tmp, JSON.stringify(this._data));
      fs.renameSync(tmp, this._path);
      this._sucio = false;
      this._ultimoFlush = Date.now();
    } catch (e) {
      try { fs.unlinkSync(tmp); } catch {}
      throw e;
    }
  }
}

// ─── Scanner ─────────────────────────────────────────────────────────────────

const EXT_MAP = {
  jpg:"image/jpeg",jpeg:"image/jpeg",png:"image/png",gif:"image/gif",
  webp:"image/webp",svg:"image/svg+xml",heic:"image/heic",
  mp4:"video/mp4",mov:"video/quicktime",mkv:"video/x-matroska",avi:"video/x-msvideo",
  mp3:"audio/mpeg",wav:"audio/wav",flac:"audio/flac",m4a:"audio/mp4",aac:"audio/aac",
  pdf:"application/pdf",doc:"application/msword",
  docx:"application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  xls:"application/vnd.ms-excel",
  xlsx:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  ppt:"application/vnd.ms-powerpoint",
  pptx:"application/vnd.openxmlformats-officedocument.presentationml.presentation",
  txt:"text/plain",md:"text/markdown",csv:"text/csv",
  json:"application/json",xml:"application/xml",
  zip:"application/zip",gz:"application/gzip",tar:"application/x-tar",
  "7z":"application/x-7z-compressed",rar:"application/vnd.rar",
  db:"application/x-sqlite3",sqlite:"application/x-sqlite3",
};

function guessContentType(filePath) {
  const ext = path.extname(filePath).slice(1).toLowerCase();
  return EXT_MAP[ext] || "application/octet-stream";
}

function isExcluded(p, patterns) {
  if (!patterns || !patterns.length) return false;
  const norm = p.replace(/\\/g, "/");
  for (const raw of patterns) {
    const pat = (raw || "").replace(/\\/g, "/").trim();
    if (!pat) continue;
    if (norm.includes(pat)) return true;
  }
  return false;
}

// Identificador estable de un destino (no depende del orden en el array,
// solo de a dónde apunta realmente). Se usa para saber, por archivo, a
// qué destinos ya fue subido — así, cuando el usuario agrega o saca un
// destino, los archivos que no cambiaron se re-suben solo a lo que falta
// en vez de quedar salteados para siempre por el chequeo incremental.
// Clasifica un error para poder explicarle al cliente QUÉ pasó y qué hacer,
// en vez de mandarle el mensaje técnico crudo. El servidor usa esta etiqueta
// para redactar el informe por email en castellano llano.
// Traduce el error técnico a algo que el cliente pueda entender y accionar.
/**
 * ¿Es una conexión que se cortó?
 *
 * Node avisa estos casos con mensajes que no le dicen nada a un usuario
 * ("socket hang up", "ECONNRESET"). En una descarga importa distinguirlos: no es
 * que el archivo esté mal en el destino, es que la red falló y conviene
 * reintentar.
 */
function esCorteDeConexion(e) {
  const t = String((e && (e.code || e.message)) || "");
  return /ECONNRESET|EPIPE|socket hang up|aborted|ETIMEDOUT|ECONNABORTED/i.test(t);
}

function friendlyError(message) {
  // Un dato mal cargado no es un problema de credenciales: decirle "tus
  // credenciales no son válidas" a alguien que se olvidó el https:// lo manda
  // a revisar la clave equivocada.
  if (/Invalid URL|ERR_INVALID_URL|no es válida/i.test(String(message))) {
    return "la dirección del servidor está mal escrita";
  }
  const kind = classifyError(message);
  const textos = {
    auth: "las credenciales no son válidas o la suscripción no está al día",
    quota: "se agotó el espacio de tu plan",
    network: "no hay conexión con el servidor",
    permission: "el archivo está en uso o no hay permisos para leerlo",
    missing: "ya no está en tu equipo: se borró o se movió mientras corría el respaldo",
  };
  return textos[kind] || String(message || "error desconocido").slice(0, 120);
}

function fmtSize(b) {
  if (!b) return "0 B";
  if (b < 1024) return b + " B";
  if (b < 1048576) return (b / 1024).toFixed(1) + " KB";
  if (b < 1073741824) return (b / 1048576).toFixed(1) + " MB";
  return (b / 1073741824).toFixed(2) + " GB";
}

function classifyError(message) {
  const m = String(message || "").toLowerCase();
  if (/401|403|token|unauthorized|credenciales|invalid/.test(m)) return "auth";
  if (/402|quota|espacio|storage|agotado|full/.test(m)) return "quota";
  if (/enotfound|econnrefused|etimedout|econnreset|network|socket|dns|timed out/.test(m)) return "network";
  if (/eacces|eperm|permission|denied|acceso denegado|in use|being used/.test(m)) return "permission";
  if (/enoent|no such file|not found|no existe/.test(m)) return "missing";
  return "otro";
}

/** Cómo se nombra un destino en los mensajes que lee el usuario. */
function nombreDestino(dest) {
  if (!dest) return "el destino";
  if (dest.label) return dest.label;
  switch (dest.type) {
    case "cloud": return "la nube";
    case "local": case "network": return dest.path || "la carpeta";
    case "s3": return `${dest.bucket || "S3"} en ${dest.endpoint || "Amazon"}`;
    case "ftp": case "sftp": return dest.host || dest.type.toUpperCase();
    default: return dest.type || "el destino";
  }
}

/**
 * Cómo se llama un archivo dentro del destino.
 *
 * Una sola función para todos los destinos y para las dos formas de guardar
 * (entero o por bloques). Antes había dos convenciones: al guardar por bloques
 * "C:\Users\..." quedaba como "C/Users/..." y al guardar entero como
 * "Users/...". Resultado: el mismo archivo aparecía en dos ramas distintas del
 * árbol, y restaurar una carpeta no traía los archivos grandes que había dentro.
 *
 * La letra de unidad se conserva como primera carpeta. Es necesario: sin ella,
 * "C:\datos\plano.dwg" y "D:\datos\plano.dwg" terminan en la misma clave y uno
 * pisa al otro.
 */
function rutaEnDestino(sourcePath) {
  let resto = String(sourcePath || "");
  const partes = [];

  const disco = /^([A-Za-z]):[\\/]?/.exec(resto);
  if (disco) {
    partes.push(disco[1].toUpperCase());
    resto = resto.slice(disco[0].length);
  } else if (/^[\\/]{2}/.test(resto)) {
    // Ruta de red \\servidor\compartido\… → servidor/compartido/…
    resto = resto.replace(/^[\\/]{2,}/, "");
  }

  for (const seg of resto.split(/[\\/]+/)) {
    if (seg && seg !== "." && seg !== "..") partes.push(seg);
  }
  return partes.join("/");
}

function destKey(dest) {
  switch (dest.type) {
    case "cloud": return "cloud";
    case "local":
    case "network": return `${dest.type}:${dest.path || ""}`;
    case "s3": return `s3:${dest.endpoint || "aws"}:${dest.bucket || ""}:${dest.prefix || ""}`;
    case "ftp": return `ftp:${dest.host || ""}:${dest.port || 21}:${dest.remotePath || ""}`;
    case "sftp": return `sftp:${dest.host || ""}:${dest.port || 22}:${dest.remotePath || ""}`;
    default: return `${dest.type}:${dest.host || dest.path || ""}`;
  }
}

// ─── Destinos locales y de red ────────────────────────────────────────────────
//
// Un archivo se guarda dentro del destino respetando su ruta original, con la
// letra de disco como primera carpeta:
//
//   C:\Users\ana\Documentos\balance.xlsx  ->  D:\Backups\C\Users\ana\Documentos\balance.xlsx
//   \\servidor\compartido\a.txt           ->  D:\Backups\servidor\compartido\a.txt
//
// Esa estructura es la que espera la restauración (backupPathToOriginal en
// main.cjs) y es la que permite recuperar los datos entrando a la carpeta con
// el Explorador, sin la aplicación.

function rutaEnDestinoLocal(destBase, sourcePath) {
  // Misma convención que los destinos remotos: la letra de unidad es la primera
  // carpeta. Así el árbol de una carpeta local y el de un bucket coinciden, y
  // dos unidades distintas no se pisan.
  return path.join(destBase, ...rutaEnDestino(sourcePath).split("/"));
}


// ¿El archivo ya está en el destino, con el mismo tamaño? Chequear el disco
// cuesta un stat y evita el peor error posible en un backup: creer que hay
// copia donde no hay nada porque el registro interno quedó desactualizado
// (el usuario borró la carpeta, formateó el disco o cambió el pendrive).
function existeEnDestinoLocal(destBase, sourcePath, size) {
  try {
    const st = fs.statSync(rutaEnDestinoLocal(destBase, sourcePath));
    return st.isFile() && (size === undefined || st.size === size);
  } catch {
    return false;
  }
}

async function copyToLocalDest(sourcePath, destBase, opciones = {}) {
  if (!destBase) throw new Error("El destino no tiene una carpeta configurada");

  const origen = opciones.rutaLectura || sourcePath;
  const destino = rutaEnDestinoLocal(destBase, sourcePath);
  const st = await fsp.stat(origen);

  // Ya está y coincide: no se vuelve a copiar.
  try {
    const ya = await fsp.stat(destino);
    if (ya.isFile() && ya.size === st.size && Math.abs(ya.mtimeMs - st.mtimeMs) < 2000) {
      return { copiado: false, ruta: destino, bytes: 0 };
    }
  } catch { /* no existe todavía */ }

  await fsp.mkdir(path.dirname(destino), { recursive: true });

  // Escritura atómica: se copia a un temporal en la misma carpeta y recién
  // ahí se renombra. Si se corta la luz o se desenchufa el disco a mitad de
  // la copia, la versión anterior queda intacta en vez de quedar truncada.
  const tmp = `${destino}.bp-tmp-${process.pid}-${Date.now()}`;
  try {
    await fsp.copyFile(origen, tmp);
    await fsp.utimes(tmp, st.atime, st.mtime);
    await fsp.rename(tmp, destino);
  } catch (e) {
    try { await fsp.unlink(tmp); } catch {}
    throw e;
  }
  return { copiado: true, ruta: destino, bytes: st.size };
}

// ─── Transferencias en vuelo ─────────────────────────────────────────────────
//
// "Detener" marcaba una bandera que se miraba entre archivo y archivo. Con seis
// transferencias simultáneas y archivos grandes contra un servidor lento, eso
// puede tardar minutos: el usuario aprieta Detener y no pasa nada visible.
// Acá se anotan las conexiones y lecturas abiertas para poder cortarlas de una.
const enVuelo = new Set();

function anotarEnVuelo(cosa) {
  if (cosa) enVuelo.add(cosa);
  return cosa;
}

function olvidarEnVuelo(cosa) {
  enVuelo.delete(cosa);
}

function cortarTodoEnVuelo() {
  for (const cosa of enVuelo) {
    try {
      if (typeof cosa.destroy === "function") cosa.destroy();
      else if (typeof cosa.abort === "function") cosa.abort();
    } catch {}
  }
  enVuelo.clear();
}

// ── Lo que NO se respalda nunca ──────────────────────────────────────────────
//
// OJO: esta lista tiene que decir lo MISMO que la del selector de carpetas
// (`main.cjs`). Estaban desincronizadas: el selector escondía la basura del
// sistema, pero el motor la respaldaba igual. El cliente elegía una carpeta
// "limpia" y terminaba con archivos que la pantalla nunca le mostró.
const WINDOWS_SKIP_DIRS = new Set([
  "$recycle.bin",
  "system volume information",
  "$windows.~bt",
  "$windows.~ws",
  "recovery",
  "node_modules",             // se reinstala con un comando
]);
const WINDOWS_SKIP_FILES = new Set([
  "pagefile.sys", "hiberfil.sys", "swapfile.sys",
  "ntuser.dat", "usrclass.dat",   // perfil de usuario, siempre abierto
  "thumbs.db", "desktop.ini", ".ds_store",
]);

// ── La caché de los navegadores ──
//
// Chrome, Edge y Firefox guardan decenas de miles de archivitos con nombres
// como `8d26b1f1032e8a48_0`. Son páginas e imágenes descargadas que el
// navegador vuelve a bajar solo si hacen falta.
//
// Respaldarlos es lo peor de los dos mundos: **cambian todo el tiempo**, así
// que se suben en cada respaldo y consumen cuota del cliente, y **no le sirven
// a nadie** — nadie restauró jamás la caché de su navegador. En un equipo
// normal son la mitad de los archivos del perfil de usuario, y cada uno cuesta
// una consulta al disco en cada recorrido.
//
// Se saltea la CARPETA entera, que es lo que ahorra el recorrido.
const CACHE_DE_NAVEGADORES = [
  /^cache$/i, /^cache_data$/i, /^code cache$/i, /^gpucache$/i, /^shadercache$/i,
  /^graphitedawncache$/i, /^dawncache$/i, /^service worker$/i,
  /^startupcache$/i, /^cache2$/i, /^offlinecache$/i, /^jumplisticons$/i,
  /^crashpad$/i, /^component_crx_cache$/i, /^optimizationguide/i,
];

// Otras carpetas que se regeneran solas y no valen una copia.
const CARPETAS_QUE_SE_REGENERAN = [
  /^temporary internet files$/i,
  /^inetcache$/i,
  /^webcache$/i,
  /^cachestorage$/i,
  /^\.git$/i,
];

const esCarpetaDescartable = (nombre) => {
  const n = String(nombre).toLowerCase();
  if (WINDOWS_SKIP_DIRS.has(n)) return true;
  if (n.startsWith("$")) return true;
  return CACHE_DE_NAVEGADORES.some((r) => r.test(nombre))
      || CARPETAS_QUE_SE_REGENERAN.some((r) => r.test(nombre));
};

const esArchivoDescartable = (nombre) => {
  const n = String(nombre).toLowerCase();
  return WINDOWS_SKIP_FILES.has(n)
      || /\.regtrans-ms$/i.test(n)   // transacciones del registro
      || /\.blf$/i.test(n);          // registro de transacciones comunes
};

/**
 * Recorre una carpeta entregando archivos de a uno.
 *
 * `abandonar()` se consulta en cada carpeta Y en cada archivo. Sin eso, apretar
 * "Detener" durante el recorrido no hacía nada: la bandera de cancelación solo
 * se miraba dentro del bucle de subida, que arranca DESPUÉS de recorrer. Con
 * 165.000 archivos eso son decenas de segundos en los que el botón parece roto,
 * y el cliente termina matando el proceso — que deja archivos a medio subir.
 */
async function* walkDir(root, excluded, abandonar = null) {
  const stack = [path.resolve(root)];
  while (stack.length) {
    if (abandonar && abandonar()) return;
    const dir = stack.pop();
    let entries;
    try { entries = await fsp.readdir(dir, { withFileTypes: true }); }
    catch { continue; }
    for (const e of entries) {
      if (abandonar && abandonar()) return;
      const full = path.join(dir, e.name);
      if (isExcluded(full, excluded)) continue;
      try {
        if (e.isSymbolicLink()) continue;
        if (e.isDirectory()) {
          // Saltear la CARPETA es lo que ahorra el recorrido: no se entra ni se
          // consulta el disco por cada uno de sus miles de archivos.
          if (esCarpetaDescartable(e.name)) continue;
          stack.push(full);
        } else if (e.isFile()) {
          if (esArchivoDescartable(e.name)) continue;
          const st = await fsp.stat(full);
          yield { sourcePath: full, size: st.size, mtimeMs: st.mtimeMs };
        }
      } catch { continue; }
    }
  }
}

/**
 * Huella sha-256 del archivo.
 *
 * `alAvanzar(bytesLeidos)` es opcional. Leer un PST de 651 MB para saber si
 * cambió lleva minutos y no movía nada en pantalla: la fase de análisis se veía
 * exactamente igual a un programa colgado.
 */
/**
 * Reintenta abrir y leer un archivo que otro programa tiene tomado.
 *
 * Por qué existe acá: `bloques.cjs` ya tenía `abrirConReintentos` para esto, y
 * el EBUSY del PST "estaba arreglado". Pero el arreglo estaba en el lugar
 * equivocado. El motor llama primero a `hashFile` para decidir si el archivo
 * cambió, y `hashFile` abría el archivo de una sola vez, sin reintentos. Con
 * Outlook abierto eso falla con EBUSY, el archivo se cuenta como error y NUNCA
 * llega al camino por bloques, que era el único que sabía reintentar. Por eso el
 * error "volvía": nunca se había ido, solo se había arreglado la mitad del
 * recorrido que hace un archivo bloqueado.
 */
function esBloqueoTemporal(e) {
  return /EBUSY|EPERM|EACCES|ELOCKED|resource busy/i.test(String((e && (e.code || e.message)) || ""));
}

async function hashFile(filePath, tiempoLimite = 120000, alAvanzar = null, intentos = 4) {
  let ultimo;
  for (let i = 0; i < intentos; i++) {
    try {
      return await hashFileUnaVez(filePath, tiempoLimite, alAvanzar);
    } catch (e) {
      ultimo = e;
      if (!esBloqueoTemporal(e)) throw e;
      // Espera creciente: Outlook y los antivirus toman y sueltan los archivos
      // todo el tiempo, así que la mayoría de los EBUSY se resuelven solos.
      await new Promise((r) => setTimeout(r, 500 * (i + 1)));
    }
  }
  const err = new Error(
    `"${path.basename(filePath)}" está tomado por otro programa y no se pudo leer ` +
    `después de ${intentos} intentos. Si es un archivo de correo o de un sistema de ` +
    `gestión, se suelta al cerrar ese programa. Detalle: ${ultimo && ultimo.message}`);
  err.code = (ultimo && ultimo.code) || "EBUSY";
  err.bloqueado = true;
  throw err;
}

function hashFileUnaVez(filePath, tiempoLimite = 120000, alAvanzar = null) {
  return new Promise((resolve, reject) => {
    const h = crypto.createHash("sha256");
    const rs = fs.createReadStream(filePath);
    anotarEnVuelo(rs);
    let leidos = 0;

    // Sin límite de tiempo, un archivo que el antivirus está revisando —o que
    // otro programa tiene tomado— deja la corrida entera esperando. Se corta,
    // se avisa, y se sigue con el resto.
    let temporizador = setTimeout(cortar, tiempoLimite);
    function reiniciar() {
      clearTimeout(temporizador);
      temporizador = setTimeout(cortar, tiempoLimite);
    }
    function cortar() {
      try { rs.destroy(); } catch {}
      olvidarEnVuelo(rs);
      reject(new Error(
        "no se pudo leer a tiempo. Puede estar en uso por otro programa o " +
        "revisándolo el antivirus"));
    }

    rs.on("data", (d) => {
      h.update(d);
      reiniciar();
      if (alAvanzar) {
        leidos += d.length;
        try { alAvanzar(leidos); } catch {}
      }
    });
    rs.on("end", () => {
      clearTimeout(temporizador);
      olvidarEnVuelo(rs);
      resolve(h.digest("hex"));
    });
    rs.on("error", (e) => {
      clearTimeout(temporizador);
      olvidarEnVuelo(rs);
      reject(e);
    });

    // ── Por qué hace falta escuchar "close" ──
    //
    // Al apretar "Detener", `cortarTodoEnVuelo()` llama a `rs.destroy()`. Y
    // `destroy()` SIN argumento no emite "error": emite "close" y nada más. O
    // sea que ni el `end` ni el `error` de arriba se disparaban, y esta promesa
    // se quedaba esperando **los 120 segundos completos** del temporizador.
    //
    // Consecuencia medida: el respaldo tardaba 120 segundos en cerrar después de
    // que el cliente pidiera detenerlo. Dos minutos mirando un botón que ya
    // apretó, que es exactamente cuando decide matar el proceso.
    rs.on("close", () => {
      clearTimeout(temporizador);
      olvidarEnVuelo(rs);
      // Si ya se resolvió o rechazó, esto no hace nada: la primera llamada gana.
      reject(new Error("la lectura se cortó antes de terminar"));
    });
  });
}


// ─── HTTP helpers ─────────────────────────────────────────────────────────────

function nodeRequest(method, url, headers, bodyBuf, timeoutMs = 60000) {
  return new Promise((resolve, reject) => {
    const parsed = new URL(url);
    const mod = parsed.protocol === "https:" ? https : http;
    const opts = {
      hostname: parsed.hostname,
      port: parsed.port || (parsed.protocol === "https:" ? 443 : 80),
      path: parsed.pathname + parsed.search,
      method,
      headers: { ...headers },
      timeout: timeoutMs,
    };
    if (bodyBuf) opts.headers["Content-Length"] = bodyBuf.length;
    const req = mod.request(opts, (res) => {
      const chunks = [];
      res.on("data", (c) => chunks.push(c));
      res.on("end", () => resolve({
        status: res.statusCode,
        headers: res.headers,
        body: Buffer.concat(chunks).toString("utf8"),
      }));
    });
    req.on("timeout", () => { req.destroy(); reject(new Error("Request timed out")); });
    req.on("error", reject);
    if (bodyBuf) req.write(bodyBuf);
    req.end();
  });
}

async function apiReq(server, token, method, apiPath, body) {
  const url = `${server}/api${apiPath}`;
  const bodyBuf = body !== undefined ? Buffer.from(JSON.stringify(body), "utf8") : undefined;
  const headers = { Authorization: `Bearer ${token}`, Accept: "application/json" };
  if (bodyBuf) headers["Content-Type"] = "application/json";
  const { status, body: text } = await nodeRequest(method, url, headers, bodyBuf);
  if (status < 200 || status >= 300) throw new Error(`${method} ${apiPath} → ${status}: ${text}`);
  try { return JSON.parse(text); } catch { return text; }
}

// Como nodeRequest pero transmite el archivo en streaming en vez de cargarlo
// entero en un Buffer — evita quedarse sin memoria con archivos grandes
// (videos, imágenes de disco, VMs, etc.)
function streamRequest(method, url, headers, sourcePath, timeoutMs = 120000, alAvanzar = null) {
  return new Promise((resolve, reject) => {
    const parsed = new URL(url);
    const mod = parsed.protocol === "https:" ? https : http;
    const opts = {
      hostname: parsed.hostname,
      port: parsed.port || (parsed.protocol === "https:" ? 443 : 80),
      path: parsed.pathname + parsed.search,
      method,
      headers,
      timeout: timeoutMs,
    };
    const req = mod.request(opts, (res) => {
      const chunks = [];
      res.on("data", (c) => chunks.push(c));
      res.on("end", () => {
        olvidarEnVuelo(req);
        resolve({ status: res.statusCode, body: Buffer.concat(chunks).toString("utf8") });
      });
    });
    anotarEnVuelo(req);
    req.on("timeout", () => { olvidarEnVuelo(req); req.destroy(); reject(new Error("Request timed out")); });
    req.on("error", (e) => { olvidarEnVuelo(req); reject(e); });
    const rs = fs.createReadStream(sourcePath);
    rs.on("error", (e) => { olvidarEnVuelo(req); reject(e); });
    // Se informa a medida que salen los datos. Sin esto, subir un archivo de
    // 651 MB no movía nada en pantalla hasta que terminaba: el usuario veía
    // "0 B copiados" durante minutos y asumía que el programa estaba colgado.
    if (alAvanzar) {
      let enviados = 0;
      rs.on("data", (c) => {
        enviados += c.length;
        try { alAvanzar({ bytes: enviados, delta: c.length }); } catch {}
      });
    }
    rs.pipe(req);
  });
}

async function uploadFileHTTP(uploadURL, sourcePath, size, contentType) {
  const parsed = new URL(uploadURL);
  const mod = parsed.protocol === "https:" ? https : http;
  return new Promise((resolve, reject) => {
    const opts = {
      hostname: parsed.hostname,
      port: parsed.port || (parsed.protocol === "https:" ? 443 : 80),
      path: parsed.pathname + parsed.search,
      method: "PUT",
      headers: { "Content-Type": contentType, "Content-Length": size },
    };
    const req = mod.request(opts, (res) => {
      res.resume();
      res.on("end", () => {
        if (res.statusCode < 200 || res.statusCode >= 300)
          reject(new Error(`PUT upload → ${res.statusCode}`));
        else resolve();
      });
    });
    req.on("error", reject);
    const rs = fs.createReadStream(sourcePath);
    rs.on("error", reject);
    rs.pipe(req);
  });
}

// ─── S3 destination (SigV4, no external deps) ────────────────────────────────

function hmacSha256(key, data) {
  return crypto.createHmac("sha256", key).update(data).digest();
}
function sha256hex(data) {
  return crypto.createHash("sha256").update(data).digest("hex");
}
function s3SigningKey(secretKey, dateStamp, region, service) {
  const kDate    = hmacSha256("AWS4" + secretKey, dateStamp);
  const kRegion  = hmacSha256(kDate, region);
  const kService = hmacSha256(kRegion, service);
  return hmacSha256(kService, "aws4_request");
}

/**
 * Codifica una clave de S3 para meterla en una URL.
 *
 * No alcanza con encodeURIComponent: la firma de Amazon exige codificar además
 * ! ' ( ) *, y exige que la barra de las carpetas quede sin codificar. Y sobre
 * todo, la ruta que se firma y la que se envía tienen que ser IDÉNTICAS: si al
 * subir va sin codificar y al bajar codificada, el archivo se guarda con un
 * nombre y se busca con otro. Con nombres como "Balance Ferretería Ruiz.xlsx"
 * eso pasa en el primer archivo real.
 */
/**
 * Normaliza la dirección del servicio S3.
 *
 * Si el usuario copia "s3.us-southeast-1.idrivee2.com" de la consola —sin
 * https:// adelante, que es como suele estar escrito— `new URL()` tira
 * "Invalid URL" y toda la operación falla con un mensaje que no dice nada.
 * Se completa el esquema en lugar de castigar al usuario por un detalle.
 */
/**
 * El valor de `Host` tal como lo va a mandar Node: con puerto si no es el
 * estándar del esquema. Firmar algo distinto da 403 SignatureDoesNotMatch.
 */
function hostFirmable(endpoint) {
  const u = new URL(endpoint);
  const estandar = (u.protocol === "https:" && (u.port === "" || u.port === "443")) ||
                   (u.protocol === "http:"  && (u.port === "" || u.port === "80"));
  return estandar ? u.hostname : `${u.hostname}:${u.port}`;
}

/**
 * Codificación de valores para la query FIRMADA, según RFC 3986.
 *
 * `encodeURIComponent` deja sin codificar `! ' ( ) *`, y AWS exige que vayan
 * codificados al armar la petición canónica. Un archivo llamado "Copia (1).docx"
 * —o cualquiera con paréntesis, apóstrofo o admiración, que en Windows son
 * pan de cada día— produce una firma que no coincide, y el servidor contesta
 * 403 SignatureDoesNotMatch sin decir por qué.
 */
/**
 * Arma la query canónica ordenando POR NOMBRE de parámetro.
 *
 * `partes.sort()` ordenaba las cadenas "nombre=valor" completas. Para los
 * parámetros que se usan hoy da el mismo resultado, pero es una coincidencia:
 * en cuanto un valor contenga un carácter menor que "=" el orden cambia y la
 * firma deja de coincidir. Ordenar por nombre es lo que pide la especificación.
 */
function ordenarQuery(partes) {
  return partes
    .map((p) => {
      const i = p.indexOf("=");
      return i < 0 ? { n: p, v: "", txt: p + "=" } : { n: p.slice(0, i), v: p.slice(i + 1), txt: p };
    })
    .sort((a, b) => (a.n < b.n ? -1 : a.n > b.n ? 1 : (a.v < b.v ? -1 : a.v > b.v ? 1 : 0)))
    .map((x) => x.txt)
    .join("&");
}

/**
 * Cuando el servidor rechaza la firma, la respuesta sola no alcanza para
 * diagnosticar: hay que ver QUÉ se firmó. Esto agrega la petición canónica al
 * mensaje de error para poder compararla contra lo que esperaba el servidor.
 */
function pistaDeFirma(status, firma, query) {
  if (status !== 403 || !firma || !firma.canonica) return "";
  return "\n\n--- detalle para diagnóstico ---\nquery firmada: " + query +
    "\npetición canónica:\n" + firma.canonica;
}

function s3EncodeQuery(valor) {
  return encodeURIComponent(String(valor))
    .replace(/[!'()*]/g, (c) => "%" + c.charCodeAt(0).toString(16).toUpperCase());
}

function s3Endpoint(dest) {
  let e = String(dest.endpoint || "").trim();
  if (!e) return `https://s3.${dest.region || "us-east-1"}.amazonaws.com`;
  // Primero el esquema, después la barra final: al revés, "http://" quedaba en
  // "http:" y terminaba armando un servidor llamado "http".
  if (!/^https?:\/\//i.test(e)) e = "https://" + e;
  e = e.replace(/\/+$/, "");
  let url;
  try { url = new URL(e); } catch { url = null; }
  if (!url || !url.hostname) {
    throw new Error(`La dirección del servicio no es válida: "${dest.endpoint}"`);
  }
  return e;
}

function s3Ruta(clave) {
  return String(clave).split("/").map((parte) =>
    encodeURIComponent(parte).replace(/[!'()*]/g, (c) =>
      "%" + c.charCodeAt(0).toString(16).toUpperCase())
  ).join("/");
}

/**
 * Cifra un archivo a uno temporal y devuelve su ruta, tamaño y huella.
 *
 * ── Por qué a un temporal y no al vuelo ──
 *
 * El formato pone la etiqueta de autenticación de AES-GCM en la CABECERA, y esa
 * etiqueta recién se conoce cuando se terminó de cifrar todo. Para escribirla
 * adelante hay que tener el resultado completo. Cargarlo en memoria no es una
 * opción: un archivo de cientos de megas en RAM, en un equipo de estudio
 * contable, es cómo se cuelga el respaldo.
 *
 * Cifrar a disco cuesta una escritura extra y es la única forma honesta de
 * hacerlo sin cambiar el formato ni arriesgar la memoria. El temporal se borra
 * siempre, salga bien o mal.
 *
 * Devuelve también la huella de los bytes CIFRADOS, que es lo que hay que
 * firmar: la firma SigV4 cubre el contenido que realmente viaja, no el
 * original. Firmar con la huella del original da un 403 imposible de rastrear.
 */
async function cifrarAArchivoTemporal(rutaOrigen, clave) {
  const tmp = `${os.tmpdir()}${path.sep}bp-cif-${process.pid}-${Date.now()}-${Math.random().toString(36).slice(2)}`;
  const iv = crypto.randomBytes(12);
  const cifrador = crypto.createCipheriv(Cifrado.ALGORITMO, clave, iv);
  const huella = crypto.createHash("sha256");

  // Se reserva el lugar de la cabecera y se rellena al final, cuando la etiqueta
  // existe. Escribir el cuerpo primero evita tener que retenerlo.
  const cuerpoTmp = `${tmp}.cuerpo`;
  try {
    await new Promise((resolver, rechazar) => {
      const entrada = fs.createReadStream(rutaOrigen);
      const salida = fs.createWriteStream(cuerpoTmp);
      entrada.on("error", rechazar);
      salida.on("error", rechazar);
      cifrador.on("error", rechazar);
      salida.on("close", resolver);
      entrada.pipe(cifrador).pipe(salida);
    });

    const cabecera = Buffer.concat([
      Buffer.from("BPE1"), iv, cifrador.getAuthTag(),
    ]);
    if (cabecera.length !== Cifrado.LARGO_CABECERA) {
      throw new Error("La cabecera de cifrado quedó con un tamaño inesperado.");
    }

    // Cabecera + cuerpo en el archivo final, calculando la huella de lo que va
    // a viajar mientras se escribe: una sola pasada más, no dos.
    await new Promise((resolver, rechazar) => {
      const salida = fs.createWriteStream(tmp);
      salida.on("error", rechazar);
      salida.on("close", resolver);
      huella.update(cabecera);
      salida.write(cabecera);
      const entrada = fs.createReadStream(cuerpoTmp);
      entrada.on("error", rechazar);
      entrada.on("data", (b) => huella.update(b));
      entrada.on("end", () => salida.end());
      entrada.pipe(salida, { end: false });
    });

    const st = await fsp.stat(tmp);
    return { ruta: tmp, tamano: st.size, huella: huella.digest("hex") };
  } catch (e) {
    try { await fsp.unlink(tmp); } catch {}
    throw e;
  } finally {
    try { await fsp.unlink(cuerpoTmp); } catch {}
  }
}

async function s3Upload(dest, key, sourcePath, size, contentHash, contentType, alAvanzar, clave) {
  // ── Cifrado del archivo entero ──
  //
  // Hasta la 0.9.9 este camino subía el archivo TAL CUAL. Los archivos por
  // bloques sí se cifraban, pero los que van enteros —todo lo que está por
  // debajo del umbral: los Excel, los Word, los PDF de un estudio contable—
  // salían de la máquina en claro. Era el agujero más grave del producto, y
  // estaba anotado como pendiente en vez de estar cerrado.
  let temporal = null;
  if (clave) {
    temporal = await cifrarAArchivoTemporal(sourcePath, clave);
    sourcePath = temporal.ruta;
    size = temporal.tamano;
    contentHash = temporal.huella;
  }
  try {
    return await s3UploadCrudo(dest, key, sourcePath, size, contentHash, contentType, alAvanzar);
  } finally {
    if (temporal) { try { await fsp.unlink(temporal.ruta); } catch {} }
  }
}

async function s3UploadCrudo(dest, key, sourcePath, size, contentHash, contentType, alAvanzar) {
  // dest: { endpoint, bucket, region, accessKey, secretKey }
  // contentHash: sha-256 hex del archivo completo, ya calculado antes por hashFile()
  // (evita tener que leer el archivo dos veces solo para firmar la request)
  const region = dest.region || "us-east-1";
  const now = new Date();
  const amzDate  = now.toISOString().replace(/[:-]|\.\d{3}/g, "").slice(0, 15) + "Z";
  const dateStamp = amzDate.slice(0, 8);

  const payloadHash = contentHash;
  const endpoint = s3Endpoint(dest);
  // `host` a firmar: tiene que ser IDÉNTICO al encabezado Host que manda Node,
  // y Node incluye el puerto cuando no es el estándar del esquema. Firmando solo
  // `hostname` la firma no coincide contra cualquier endpoint con puerto
  // explícito (un MinIO en :9000, un proxy interno, el servidor de pruebas).
  // Contra iDrive e2 no se notaba porque va por el 443.
  const host = hostFirmable(endpoint);
  const urlPath = `/${dest.bucket}/${s3Ruta(key)}`;

  const canonicalHeaders =
    `content-type:${contentType}\n` +
    `host:${host}\n` +
    `x-amz-content-sha256:${payloadHash}\n` +
    `x-amz-date:${amzDate}\n`;
  const signedHeaders = "content-type;host;x-amz-content-sha256;x-amz-date";

  const canonicalRequest = [
    "PUT", urlPath, "",
    canonicalHeaders, signedHeaders, payloadHash,
  ].join("\n");

  const credScope = `${dateStamp}/${region}/s3/aws4_request`;
  const strToSign = [
    "AWS4-HMAC-SHA256", amzDate, credScope,
    sha256hex(canonicalRequest),
  ].join("\n");

  const sigKey = s3SigningKey(dest.secretKey, dateStamp, region, "s3");
  const sig = crypto.createHmac("sha256", sigKey).update(strToSign).digest("hex");

  const authHeader =
    `AWS4-HMAC-SHA256 Credential=${dest.accessKey}/${credScope},` +
    `SignedHeaders=${signedHeaders},Signature=${sig}`;

  const headers = {
    "Content-Type": contentType,
    "Content-Length": size,
    "x-amz-date": amzDate,
    "x-amz-content-sha256": payloadHash,
    Authorization: authHeader,
  };
  const { status, body } = await streamRequest(
    "PUT", `${endpoint}${urlPath}`, headers, sourcePath, 120000, alAvanzar);
  if (status < 200 || status >= 300) throw new Error(`S3 PUT ${key} → ${status}: ${body}`);
}

// ─── SFTP destination (via ssh2) ─────────────────────────────────────────────

async function sftpUpload(dest, remotePath, sourcePath) {
  // dest: { host, port, user, pass, privateKey, remotePath }
  let Client;
  try { Client = require("ssh2").Client; }
  catch { throw new Error("ssh2 module not available — reinstall the app."); }

  return new Promise((resolve, reject) => {
    const conn = new Client();
    const fail = (e) => { try { conn.end(); } catch {} reject(e instanceof Error ? e : new Error(String(e))); };

    conn.on("ready", () => {
      conn.sftp((err, sftp) => {
        if (err) { fail(err); return; }

        // Ensure remote directory exists, then write file
        const dir = remotePath.substring(0, remotePath.lastIndexOf("/")) || "/";
        const mkdirP = (segments, idx, cb) => {
          if (idx > segments.length) { cb(); return; }
          const p = "/" + segments.slice(0, idx).join("/");
          sftp.mkdir(p, () => mkdirP(segments, idx + 1, cb)); // Ignore errors (already exists)
        };
        const parts = dir.split("/").filter(Boolean);
        mkdirP(parts, 1, () => {
          const ws = sftp.createWriteStream(remotePath);
          ws.on("close", () => { conn.end(); resolve(); });
          ws.on("error", fail);
          const rs = fs.createReadStream(sourcePath);
          rs.on("error", fail);
          rs.pipe(ws);
        });
      });
    });

    conn.on("error", fail);

    const connOpts = {
      host: dest.host,
      port: dest.port || 22,
      username: dest.user || "anonymous",
      readyTimeout: 20000,
    };
    if (dest.privateKey) {
      connOpts.privateKey = dest.privateKey;
      if (dest.passphrase) connOpts.passphrase = dest.passphrase;
    } else {
      connOpts.password = dest.pass || "";
    }
    conn.connect(connOpts);
  });
}


// ─── Listar y bajar desde S3 y SFTP ──────────────────────────────────────────
//
// Sin esto, un respaldo hecho contra S3 o SFTP se sube bien pero no hay forma
// de recuperarlo desde el programa. Es la mitad que importa de un backup.

/** Firma una petición a S3 con SigV4 y devuelve los encabezados. */
function s3Firmar(dest, metodo, urlPath, query, payloadHash, extras) {
  const region = dest.region || "us-east-1";
  const now = new Date();
  const amzDate = now.toISOString().replace(/[:-]|\.\d{3}/g, "").slice(0, 15) + "Z";
  const dateStamp = amzDate.slice(0, 8);
  const endpoint = s3Endpoint(dest);
  // `host` a firmar: tiene que ser IDÉNTICO al encabezado Host que manda Node,
  // y Node incluye el puerto cuando no es el estándar del esquema. Firmando solo
  // `hostname` la firma no coincide contra cualquier endpoint con puerto
  // explícito (un MinIO en :9000, un proxy interno, el servidor de pruebas).
  // Contra iDrive e2 no se notaba porque va por el 443.
  const host = hostFirmable(endpoint);

  // Los encabezados adicionales —los metadatos de cada bloque, por ejemplo—
  // tienen que ir firmados: si se mandan sin firmar, el servidor rechaza la
  // petición entera.
  const propios = {};
  for (const [k, v] of Object.entries(extras || {})) {
    propios[String(k).toLowerCase()] = String(v);
  }
  const nombres = ["host", "x-amz-content-sha256", "x-amz-date", ...Object.keys(propios)].sort();
  const valores = {
    host, "x-amz-content-sha256": payloadHash, "x-amz-date": amzDate, ...propios,
  };

  const canonicalHeaders = nombres.map((n) => `${n}:${valores[n]}\n`).join("");
  const signedHeaders = nombres.join(";");

  const canonicalRequest = [
    metodo, urlPath, query || "",
    canonicalHeaders, signedHeaders, payloadHash,
  ].join("\n");

  const credScope = `${dateStamp}/${region}/s3/aws4_request`;
  const strToSign = ["AWS4-HMAC-SHA256", amzDate, credScope, sha256hex(canonicalRequest)].join("\n");
  const sigKey = s3SigningKey(dest.secretKey, dateStamp, region, "s3");
  const sig = crypto.createHmac("sha256", sigKey).update(strToSign).digest("hex");

  return {
    // Se devuelve para poder mostrarla si el servidor rechaza la firma.
    canonica: canonicalRequest,
    url: `${endpoint}${urlPath}${query ? "?" + query : ""}`,
    headers: {
      "x-amz-date": amzDate,
      "x-amz-content-sha256": payloadHash,
      ...propios,
      Authorization: `AWS4-HMAC-SHA256 Credential=${dest.accessKey}/${credScope},` +
                     `SignedHeaders=${signedHeaders},Signature=${sig}`,
    },
  };
}

const HASH_VACIO = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";

/** Lista todo lo que hay en el bucket bajo el prefijo del destino. */
/**
 * Lista todo lo que hay en el bucket bajo el prefijo del destino.
 *
 * Sin tope. Un programa de backup no puede tener un límite de archivos: había
 * uno de 50.000 "por prudencia" y lo único que lograba era ocultar dos tercios
 * del respaldo de un escritorio común, sin que nada lo dijera claramente. Se
 * pagina hasta que el servidor avisa que no hay más, y si el listado es enorme
 * se informa el avance para que la pantalla no parezca colgada.
 */
async function s3Listar(dest, alAvanzar) {
  const encontrados = [];
  let token = null;
  const prefijo = (dest.prefix || "").replace(/^\/+/, "");
  let paginas = 0;

  do {
    const partes = ["list-type=2", "max-keys=1000"];
    if (prefijo) partes.push(`prefix=${s3EncodeQuery(prefijo)}`);
    if (token) partes.push(`continuation-token=${s3EncodeQuery(token)}`);
    const query = ordenarQuery(partes);
    const firma = s3Firmar(dest, "GET", `/${dest.bucket}`, query, HASH_VACIO);
    const { status, body } = await nodeRequest("GET", firma.url, firma.headers, null, 60000);
    if (status < 200 || status >= 300) {
      throw new Error(`S3 devolvió ${status}: ${body.slice(0, 200)}` +
        pistaDeFirma(status, firma, query));
    }

    for (const m of body.matchAll(/<Contents>([\s\S]*?)<\/Contents>/g)) {
      const clave = (m[1].match(/<Key>([\s\S]*?)<\/Key>/) || [])[1];
      const tam = (m[1].match(/<Size>(\d+)<\/Size>/) || [])[1];
      if (clave) encontrados.push({ clave: desescaparXml(clave), size: Number(tam) || 0 });
    }

    token = /<IsTruncated>true<\/IsTruncated>/.test(body)
      ? (body.match(/<NextContinuationToken>([\s\S]*?)<\/NextContinuationToken>/) || [])[1]
      : null;

    paginas++;
    if (alAvanzar) alAvanzar(encontrados.length, paginas);
  } while (token);

  return { archivos: encontrados, truncado: false };
}

function desescaparXml(t) {
  return String(t).replace(/&amp;/g, "&").replace(/&lt;/g, "<")
                  .replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'");
}


/**
 * Lista las versiones anteriores de los archivos del destino.
 *
 * Es la máquina del tiempo: el bucket con versionado activado guarda cada
 * versión de cada archivo, y esto las pide para poder ofrecerlas al usuario.
 * Sin esto, el versionado existe en el proveedor pero es invisible desde el
 * programa, que es como no existir.
 *
 * Devuelve un mapa: clave del archivo → lista de versiones, de la más nueva a
 * la más vieja.
 */
/**
 * Todas las versiones guardadas bajo un prefijo.
 *
 * `abandonar()` se consulta antes de pedir cada página. Sin eso, "Cancelar" no
 * cancelaba nada durante la búsqueda: con 148.000 archivos esto son cientos de
 * viajes de ida y vuelta al servidor, y el botón no hacía absolutamente nada
 * hasta que la búsqueda terminaba sola. Un botón que no responde es peor que no
 * tener botón, porque el cliente termina cerrando el programa a la fuerza.
 */
async function s3Versiones(dest, prefijoBuscado, alAvanzar, abandonar = null) {
  const porClave = new Map();
  let claveMarcador = null;
  let versionMarcador = null;
  const prefijo = prefijoBuscado != null
    ? String(prefijoBuscado).replace(/^\/+/, "")
    : (dest.prefix || "").replace(/^\/+/, "");

  do {
    if (abandonar && abandonar()) return porClave;   // lo que se juntó hasta acá
    const partes = ["versions=", "max-keys=1000"];
    if (prefijo) partes.push(`prefix=${s3EncodeQuery(prefijo)}`);
    if (claveMarcador) partes.push(`key-marker=${s3EncodeQuery(claveMarcador)}`);
    if (versionMarcador) partes.push(`version-id-marker=${s3EncodeQuery(versionMarcador)}`);
    const query = ordenarQuery(partes);

    const firma = s3Firmar(dest, "GET", `/${dest.bucket}`, query, HASH_VACIO);
    const { status, body } = await nodeRequest("GET", firma.url, firma.headers, null, 60000);
    if (status < 200 || status >= 300) {
      throw new Error(`S3 devolvió ${status} al pedir las versiones: ${body.slice(0, 200)}` +
        pistaDeFirma(status, firma, query));
    }

    const sacar = (bloque, etiqueta) =>
      (bloque.match(new RegExp(`<${etiqueta}>([\\s\\S]*?)</${etiqueta}>`)) || [])[1];

    for (const m of body.matchAll(/<(Version|DeleteMarker)>([\s\S]*?)<\/\1>/g)) {
      const esBorrado = m[1] === "DeleteMarker";
      const bloque = m[2];
      const clave = desescaparXml(sacar(bloque, "Key") || "");
      if (!clave) continue;
      if (!porClave.has(clave)) porClave.set(clave, []);
      porClave.get(clave).push({
        versionId: sacar(bloque, "VersionId") || null,
        actual: /^true$/i.test(sacar(bloque, "IsLatest") || ""),
        fecha: sacar(bloque, "LastModified") || null,
        bytes: Number(sacar(bloque, "Size")) || 0,
        borrado: esBorrado,
      });
    }

    const hayMas = /<IsTruncated>true<\/IsTruncated>/i.test(body);
    // Los marcadores vienen escapados como XML. Sin desescaparlos, una clave con
    // "&" volvía como "&amp;" y la página siguiente se pedía sobre una clave que
    // no existe: se perdían versiones en silencio a partir de ahí.
    claveMarcador = hayMas ? desescaparXml(sacar(body, "NextKeyMarker") || "") || null : null;
    versionMarcador = hayMas ? desescaparXml(sacar(body, "NextVersionIdMarker") || "") || null : null;
    if (alAvanzar) alAvanzar(porClave.size);
  } while (claveMarcador);

  // De la más nueva a la más vieja, que es como la gente busca "la de antes".
  for (const lista of porClave.values()) {
    lista.sort((a, b) => String(b.fecha || "").localeCompare(String(a.fecha || "")));
  }
  return porClave;
}

/**
 * Baja un objeto de S3 a una ruta local, escribiendo de forma atómica.
 *
 * `alAvanzar` es opcional y recibe `{ total, bytes, delta }` a medida que llegan
 * los datos. Sin esto, restaurar un solo archivo grande dejaba la barra clavada
 * en 0% hasta que terminaba y saltaba a 100%: el usuario no tenía forma de saber
 * si estaba pasando algo o si el programa se había colgado.
 */
/**
 * Descifra un archivo en el lugar, si tiene la marca de BackupPrime.
 *
 * Trabaja en flujo: nunca hay más de un pedazo en memoria. Un PST de 650 MB no
 * se puede descifrar cargándolo entero.
 *
 * Si el archivo NO está cifrado, no se toca: así los respaldos hechos antes de
 * que existiera el cifrado se siguen restaurando.
 */
async function descifrarArchivoSiHaceFalta(ruta, clave) {
  const st = await fsp.stat(ruta);
  if (st.size < Cifrado.LARGO_CABECERA) return false;

  const fd = await fsp.open(ruta, "r");
  let cabecera;
  try {
    cabecera = Buffer.alloc(Cifrado.LARGO_CABECERA);
    await fd.read(cabecera, 0, Cifrado.LARGO_CABECERA, 0);
  } finally { await fd.close(); }

  if (!Cifrado.estaCifrado(cabecera)) return false;

  if (!Buffer.isBuffer(clave) || clave.length !== 32) {
    throw new Error(
      "Este archivo está cifrado y falta la clave para leerlo. " +
      "Si usás una frase propia, escribila para poder restaurar.");
  }

  const iv = cabecera.subarray(4, 4 + 12);
  const etiqueta = cabecera.subarray(4 + 12, Cifrado.LARGO_CABECERA);
  const descifrador = crypto.createDecipheriv(Cifrado.ALGORITMO, clave, iv);
  descifrador.setAuthTag(etiqueta);

  const salida = `${ruta}.bp-claro-${process.pid}`;
  try {
    await new Promise((resolver, rechazar) => {
      const entrada = fs.createReadStream(ruta, { start: Cifrado.LARGO_CABECERA });
      const ws = fs.createWriteStream(salida);
      entrada.on("error", rechazar);
      descifrador.on("error", rechazar);
      ws.on("error", rechazar);
      ws.on("close", resolver);
      entrada.pipe(descifrador).pipe(ws);
    });
    await fsp.rename(salida, ruta);
    return true;
  } catch (e) {
    try { await fsp.unlink(salida); } catch {}
    // AES-GCM detecta que los datos fueron alterados. Un error acá no es "no se
    // pudo abrir": es que el contenido no es el que se guardó, o que la clave no
    // es la correcta. Las dos cosas hay que decirlas, no tragarlas.
    throw new Error(
      "No se pudo descifrar el archivo. O la frase de cifrado no es la correcta, " +
      "o los datos guardados fueron alterados. El archivo no se restauró.");
  }
}

async function s3Descargar(dest, clave, destinoLocal, versionId, alAvanzar, claveCifrado) {
  // Con versionId se baja una versión anterior; sin él, la actual.
  const consulta = versionId ? `versionId=${encodeURIComponent(versionId)}` : "";
  const firma = s3Firmar(dest, "GET", `/${dest.bucket}/${s3Ruta(clave)}`, consulta, HASH_VACIO);
  await fsp.mkdir(path.dirname(destinoLocal), { recursive: true });
  const tmp = `${destinoLocal}.bp-tmp-${process.pid}-${Date.now()}`;
  const parsed = new URL(firma.url);
  const mod = parsed.protocol === "https:" ? https : http;

  try {
    const bytes = await new Promise((resolve, reject) => {
      const req = mod.request({
        hostname: parsed.hostname,
        port: parsed.port || (parsed.protocol === "https:" ? 443 : 80),
        path: parsed.pathname + parsed.search,
        method: "GET",
        headers: firma.headers,
        timeout: 120000,
      }, (res) => {
        if (res.statusCode < 200 || res.statusCode >= 300) {
          res.resume();
          return reject(new Error(`S3 devolvió ${res.statusCode} al bajar ${clave}`));
        }
        let n = 0;
        // El tamaño real de ESTA versión lo dice el servidor. Es el único dato
        // confiable: el listado del bucket puede traer el tamaño de la versión
        // actual, que no es la que se está bajando.
        const total = Number(res.headers["content-length"]) || 0;
        if (alAvanzar) { try { alAvanzar({ total, bytes: 0, delta: 0 }); } catch {} }
        const ws = fs.createWriteStream(tmp);
        res.on("data", (b) => {
          n += b.length;
          if (alAvanzar) { try { alAvanzar({ total, bytes: n, delta: b.length }); } catch {} }
        });
        res.on("error", reject);
        ws.on("error", reject);
        ws.on("close", () => {
          // Verificar que llegó COMPLETO antes de dar el archivo por bueno.
          //
          // Sin esto, una conexión que se corta a mitad de camino resolvía igual
          // y el archivo se renombraba a su nombre definitivo: el cliente
          // restauraba un PST truncado que parece entero, lo abría, y recién ahí
          // descubría que estaba roto —cuando ya había perdido el original—.
          //
          // Es el peor modo de falla que puede tener un producto de backup: no
          // que falle, sino que parezca haber funcionado. Mejor un error claro y
          // volver a intentar.
          if (total > 0 && n !== total) {
            return reject(new Error(
              `La descarga quedó incompleta: llegaron ${n} de ${total} bytes. ` +
              `Puede haberse cortado la conexión. Probá de nuevo.`));
          }
          resolve(n);
        });
        // Si la respuesta se corta antes de terminar, Node emite "aborted" y el
        // flujo de escritura cierra normalmente: sin esto, un corte de red se
        // vería como una descarga exitosa.
        res.on("aborted", () => reject(new Error(
          "La conexión se cortó mientras se bajaba el archivo. Probá de nuevo.")));
        res.pipe(ws);
      });
      req.on("timeout", () => { req.destroy(); reject(new Error("Se agotó el tiempo de espera")); });
      // "socket hang up" o "ECONNRESET" no le dicen nada a nadie. Es una conexión
      // que se cortó a mitad de la descarga, y lo que el cliente necesita saber
      // es que el archivo NO quedó bien y que puede reintentar.
      req.on("error", (e) => reject(esCorteDeConexion(e)
        ? new Error(`Se cortó la conexión mientras se bajaba ${clave}. ` +
                    `El archivo no se guardó a medias. Probá de nuevo.`)
        : e));
      req.end();
    });
    // ── Descifrado ──
    //
    // Se hace sobre el TEMPORAL, antes de renombrarlo. Si la clave no sirve, el
    // archivo con su nombre definitivo nunca llega a existir: el cliente ve un
    // error claro en vez de encontrarse un archivo ilegible que parece
    // restaurado. En un producto de backup, un archivo que parece estar y no
    // sirve es peor que un error.
    //
    // Un archivo sin la marca se deja tal cual: es lo que permite restaurar los
    // respaldos hechos antes de que existiera el cifrado.
    await descifrarArchivoSiHaceFalta(tmp, claveCifrado);

    await fsp.rename(tmp, destinoLocal);
    return { bytes };
  } catch (e) {
    try { await fsp.unlink(tmp); } catch {}
    throw e;
  }
}

/** Abre una conexión SFTP y ejecuta algo con ella. */
function conSftp(dest, tarea) {
  let Client;
  try { Client = require("ssh2").Client; }
  catch { return Promise.reject(new Error("Falta el módulo ssh2 — reinstalá la aplicación.")); }

  return new Promise((resolve, reject) => {
    const conn = new Client();
    conn.on("ready", () => {
      conn.sftp(async (err, sftp) => {
        if (err) { conn.end(); return reject(err); }
        try { resolve(await tarea(sftp)); }
        catch (e) { reject(e); }
        finally { conn.end(); }
      });
    });
    conn.on("error", reject);
    const opts = {
      host: dest.host, port: dest.port || 22,
      username: dest.user || "root", readyTimeout: 15000,
    };
    if (dest.privateKey) {
      opts.privateKey = dest.privateKey;
      if (dest.passphrase) opts.passphrase = dest.passphrase;
    } else opts.password = dest.pass || "";
    conn.connect(opts);
  });
}

/** Recorre el destino SFTP entero y devuelve los archivos que encuentra. */
async function sftpListar(dest, alAvanzar) {
  const base = (dest.remotePath || "/").replace(/\/+$/, "") || "/";
  return conSftp(dest, (sftp) => new Promise((resolve, reject) => {
    const encontrados = [];
    const pendientes = [base];

    const leerDir = (dir) => new Promise((r) => {
      sftp.readdir(dir, (err, lista) => r(err ? [] : lista));
    });

    (async () => {
      try {
        while (pendientes.length) {
          const dir = pendientes.pop();
          for (const e of await leerDir(dir)) {
            const ruta = (dir === "/" ? "" : dir) + "/" + e.filename;
            const esDir = e.attrs && typeof e.attrs.isDirectory === "function"
              ? e.attrs.isDirectory()
              : ((e.attrs && e.attrs.mode & 0o040000) !== 0);
            if (esDir) pendientes.push(ruta);
            else {
              encontrados.push({ ruta, size: (e.attrs && e.attrs.size) || 0 });
              if (alAvanzar && encontrados.length % 1000 === 0) alAvanzar(encontrados.length);
            }
          }
        }
        resolve({ archivos: encontrados, truncado: false, base });
      } catch (e) { reject(e); }
    })();
  }));
}


/** Baja varios archivos por SFTP reutilizando una sola conexión. */
async function sftpDescargarVarios(dest, trabajos, alTerminarUno) {
  return conSftp(dest, async (sftp) => {
    let ok = 0, fallados = 0, bytes = 0;
    for (const t of trabajos) {
      const tmp = `${t.destinoLocal}.bp-tmp-${process.pid}-${Date.now()}`;
      try {
        await fsp.mkdir(path.dirname(t.destinoLocal), { recursive: true });
        const n = await new Promise((resolve, reject) => {
          let leidos = 0;
          const rs = sftp.createReadStream(t.remotePath);
          const ws = fs.createWriteStream(tmp);
          rs.on("data", (b) => { leidos += b.length; });
          rs.on("error", reject);
          ws.on("error", reject);
          ws.on("close", () => resolve(leidos));
          rs.pipe(ws);
        });
        await fsp.rename(tmp, t.destinoLocal);
        ok++; bytes += n;
      } catch {
        try { await fsp.unlink(tmp); } catch {}
        fallados++;
      }
      if (alTerminarUno) alTerminarUno(ok + fallados);
    }
    return { ok, fallados, bytes };
  });
}

/** Baja un archivo por SFTP, escribiendo de forma atómica. */
async function sftpDescargar(dest, remotePath, destinoLocal) {
  await fsp.mkdir(path.dirname(destinoLocal), { recursive: true });
  const tmp = `${destinoLocal}.bp-tmp-${process.pid}-${Date.now()}`;
  try {
    const bytes = await conSftp(dest, (sftp) => new Promise((resolve, reject) => {
      let n = 0;
      const rs = sftp.createReadStream(remotePath);
      const ws = fs.createWriteStream(tmp);
      rs.on("data", (b) => { n += b.length; });
      rs.on("error", reject);
      ws.on("error", reject);
      ws.on("close", () => resolve(n));
      rs.pipe(ws);
    }));
    await fsp.rename(tmp, destinoLocal);
    return { bytes };
  } catch (e) {
    try { await fsp.unlink(tmp); } catch {}
    throw e;
  }
}

// ─── FTP destination (passive mode, pure Node net) ────────────────────────────

/** ¿Es una dirección de red interna, de las que no se pueden alcanzar desde afuera? */

// ─── S3: piezas que necesita el respaldo por bloques ─────────────────────────

/** ¿Existe este objeto? Se pregunta con HEAD: no baja el contenido. */
async function s3Existe(dest, clave) {
  const ruta = `/${dest.bucket}/${s3Ruta(clave)}`;
  const firma = s3Firmar(dest, "HEAD", ruta, "", HASH_VACIO);
  const { status } = await nodeRequest("HEAD", firma.url, firma.headers, null, 30000);
  if (status >= 200 && status < 300) return true;
  if (status === 404) return false;

  // Algunos servicios no contestan HEAD como corresponde. Antes de dar el
  // bloque por inexistente —y volver a subir el archivo entero— se pregunta
  // pidiendo un solo byte, que cuesta prácticamente lo mismo.
  const firma2 = s3Firmar(dest, "GET", ruta, "", HASH_VACIO, { range: "bytes=0-0" });
  const r2 = await nodeRequest("GET", firma2.url,
    { ...firma2.headers, Range: "bytes=0-0" }, null, 30000);
  return r2.status >= 200 && r2.status < 300;
}

/**
 * Lee los metadatos de un objeto sin bajarlo.
 *
 * Es lo que permite reconstruir un índice perdido: cada bloque lleva anotado a
 * qué archivo pertenece y en qué posición.
 */
async function s3Metadatos(dest, clave) {
  const firma = s3Firmar(dest, "HEAD", `/${dest.bucket}/${s3Ruta(clave)}`, "", HASH_VACIO);
  const { status, headers } = await nodeRequest("HEAD", firma.url, firma.headers, null, 30000);
  if (status < 200 || status >= 300) return null;
  const meta = {};
  for (const [k, v] of Object.entries(headers || {})) {
    if (k.toLowerCase().startsWith("x-amz-meta-")) meta[k.slice(11)] = v;
  }
  return meta;
}

/** Sube un buffer que ya está en memoria (un bloque, un índice). */
async function s3SubirDatos(dest, clave, datos, tipo, meta) {
  const hash = crypto.createHash("sha256").update(datos).digest("hex");
  const extra = {};
  if (tipo) extra["content-type"] = tipo;
  // Metadatos del objeto. Para los bloques son la red de última instancia: dicen
  // de qué archivo salió cada pedazo y en qué posición va, así que si algún día
  // se perdieran TODOS los índices, el respaldo sigue siendo reconstruible.
  for (const [k, v] of Object.entries(meta || {})) {
    extra[`x-amz-meta-${k}`] = String(v);
  }
  const firma = s3Firmar(dest, "PUT", `/${dest.bucket}/${s3Ruta(clave)}`, "", hash, extra);

  const parsed = new URL(firma.url);
  const mod = parsed.protocol === "https:" ? https : http;

  return new Promise((resolver, rechazar) => {
    const req = mod.request({
      hostname: parsed.hostname,
      port: parsed.port || (parsed.protocol === "https:" ? 443 : 80),
      path: parsed.pathname, method: "PUT",
      headers: { ...firma.headers, "Content-Length": datos.length },
      timeout: 120000,
    }, (res) => {
      const trozos = [];
      res.on("data", (c) => trozos.push(c));
      res.on("end", () => {
        olvidarEnVuelo(req);
        if (res.statusCode >= 200 && res.statusCode < 300) return resolver({ bytes: datos.length });
        rechazar(new Error(`El almacenamiento respondió ${res.statusCode} al guardar ${clave}`));
      });
    });
    anotarEnVuelo(req);
    req.on("timeout", () => { olvidarEnVuelo(req); req.destroy(); rechazar(new Error("Se agotó el tiempo de espera")); });
    req.on("error", (e) => { olvidarEnVuelo(req); rechazar(e); });
    req.end(datos);
  });
}

/** Baja un objeto a memoria. Para bloques e índices, que son chicos. */
async function s3BajarDatos(dest, clave, versionId) {
  const consulta = versionId ? `versionId=${encodeURIComponent(versionId)}` : "";
  const firma = s3Firmar(dest, "GET", `/${dest.bucket}/${s3Ruta(clave)}`, consulta, HASH_VACIO);
  const parsed = new URL(firma.url);
  const mod = parsed.protocol === "https:" ? https : http;

  return new Promise((resolver, rechazar) => {
    const req = mod.request({
      hostname: parsed.hostname,
      port: parsed.port || (parsed.protocol === "https:" ? 443 : 80),
      path: parsed.pathname + parsed.search, method: "GET",
      headers: firma.headers, timeout: 120000,
    }, (res) => {
      const trozos = [];
      const total = Number(res.headers["content-length"]) || 0;
      res.on("data", (c) => trozos.push(c));
      // Un corte de conexión emite "aborted" y NO "end": sin esto se devolvía lo
      // que hubiera llegado como si fuera el objeto completo. Con un bloque, eso
      // significa rearmar el archivo con un pedazo truncado.
      res.on("aborted", () => {
        olvidarEnVuelo(req);
        rechazar(new Error(`Se cortó la conexión al leer ${clave}. Probá de nuevo.`));
      });
      res.on("end", () => {
        olvidarEnVuelo(req);
        if (res.statusCode < 200 || res.statusCode >= 300) {
          return rechazar(new Error(`El almacenamiento respondió ${res.statusCode} al leer ${clave}`));
        }
        const datos = Buffer.concat(trozos);
        // Que haya llegado entero. Un bloque incompleto rearma un archivo roto
        // que parece correcto, y eso es peor que un error.
        if (total > 0 && datos.length !== total) {
          return rechazar(new Error(
            `Lectura incompleta de ${clave}: llegaron ${datos.length} de ${total} bytes.`));
        }
        resolver(datos);
      });
    });
    anotarEnVuelo(req);
    req.on("timeout", () => { olvidarEnVuelo(req); req.destroy(); rechazar(new Error("Se agotó el tiempo de espera")); });
    req.on("error", (e) => {
      olvidarEnVuelo(req);
      rechazar(esCorteDeConexion(e)
        ? new Error(`Se cortó la conexión al leer ${clave}. Probá de nuevo.`)
        : e);
    });
    req.end();
  });
}

/** Lee los metadatos de un objeto sin bajar el contenido. */

async function s3Borrar(dest, clave) {
  const firma = s3Firmar(dest, "DELETE", `/${dest.bucket}/${s3Ruta(clave)}`, "", HASH_VACIO);
  const { status } = await nodeRequest("DELETE", firma.url, firma.headers, null, 30000);
  if (status >= 400 && status !== 404) {
    throw new Error(`No se pudo borrar ${clave}: ${status}`);
  }
  return { borrado: true };
}

/**
 * Adaptador para que el módulo de bloques hable con S3 sin saber que es S3.
 * El módulo de bloques no conoce ningún proveedor: solo pide guardar y leer.
 */
/**
 * Adaptador de almacenamiento para el respaldo por bloques.
 *
 * El cifrado se enchufa acá y no adentro de `bloques.cjs` a propósito: así el
 * módulo de bloques sigue ocupándose solo de partir y rearmar, y hay UN solo
 * lugar por donde pasan todas las lecturas y escrituras. Un cifrado repartido en
 * varios puntos es un cifrado que en algún camino se olvida.
 *
 * `clave` es la clave de 32 bytes de la cuenta, o null si esa cuenta todavía no
 * tiene cifrado configurado. Con null, todo funciona como antes.
 *
 * Al bajar SIEMPRE se intenta descifrar, aunque la cuenta no tenga clave: los
 * datos guardados antes de activar el cifrado no llevan la marca y se devuelven
 * tal cual. Sin eso, activar el cifrado dejaría ilegible todo lo anterior.
 */
function almacenDeBloques(dest, clave = null) {
  const cifrarSi = (datos) => (clave ? Cifrado.cifrar(datos, clave) : datos);
  const descifrarSi = (datos) => Cifrado.descifrar(datos, clave);

  return {
    existe: (clave_) => s3Existe(dest, clave_),
    subirDatos: (clave_, datos, meta) =>
      s3SubirDatos(dest, clave_, cifrarSi(datos), "application/octet-stream", meta),
    leerMeta: (clave_) => s3Metadatos(dest, clave_),
    // El índice también se cifra: dice los nombres y las rutas de los archivos
    // del cliente, y eso ya es información sensible aunque no sea el contenido.
    subirTexto: (clave_, texto) =>
      s3SubirDatos(dest, clave_, cifrarSi(Buffer.from(texto, "utf8")),
        clave ? "application/octet-stream" : "application/json"),
    bajarDatos: (clave_, version) =>
      s3BajarDatos(dest, clave_, version).then(descifrarSi),
    bajarTexto: (clave_, version) =>
      s3BajarDatos(dest, clave_, version).then((b) => descifrarSi(b).toString("utf8")),
    borrar: (clave_) => s3Borrar(dest, clave_),

    async listarIndices(prefijo) {
      // Todas las copias del índice: `indices/`, `indices-copia/` y —en los
      // respaldos hechos antes de la 0.9.9— la que quedó junto al archivo. La
      // revisión de salud tiene que verlas todas, porque si se borró una rama
      // entera la otra sigue sirviendo.
      const mapa = await s3Versiones(dest, prefijo);
      return [...mapa.entries()]
        .filter(([k]) => k.endsWith(".bpi"))
        .map(([clave, versiones]) => ({
          clave,
          versiones: versiones.filter((v) => !v.borrado).map((v) => v.versionId),
        }));
    },

    async listarBloques(prefijo) {
      const { archivos } = await s3Listar({ ...dest, prefix: `${prefijo}bloques/` });
      return archivos.map((a) => ({ clave: a.clave, bytes: a.size, fecha: a.fecha || null }));
    },
  };
}


function esDireccionInterna(ip) {
  return /^(10\.|127\.|0\.|169\.254\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(String(ip || ""));
}

function ftpReadReply(sock, timeoutMs = 30000) {
  return new Promise((resolve, reject) => {
    let buf = "";
    let temporizador;

    // Todos los listeners se quitan al terminar, salga bien o mal.
    // Sin esto se acumulan en la conexión reutilizada: con cientos de
    // archivos, Node avisa de fuga de memoria y termina degradándose.
    const limpiar = () => {
      clearTimeout(temporizador);
      sock.removeListener("data", alRecibir);
      sock.removeListener("error", alFallar);
      sock.removeListener("close", alCerrar);
    };

    const alRecibir = (data) => {
      buf += data.toString("ascii");
      // Las respuestas de varias líneas terminan con "NNN <texto>"
      for (const line of buf.split("\r\n")) {
        if (/^\d{3} /.test(line)) {
          limpiar();
          resolve({ code: parseInt(line.slice(0, 3)), line });
          return;
        }
      }
    };

    const alFallar = (e) => { limpiar(); reject(e); };
    const alCerrar = () => { limpiar(); reject(new Error("El servidor cerró la conexión")); };

    temporizador = setTimeout(() => {
      limpiar();
      reject(new Error("El servidor no respondió a tiempo"));
    }, timeoutMs);

    sock.on("data", alRecibir);
    sock.on("error", alFallar);
    sock.on("close", alCerrar);
  });
}

async function ftpSend(sock, cmd) {
  return new Promise((resolve, reject) => {
    sock.write(cmd + "\r\n", "ascii", (err) => {
      if (err) reject(err); else resolve();
    });
  });
}

/**
 * Sesión FTP reutilizable.
 *
 * Antes se abría una conexión nueva por cada archivo: conectar, autenticar,
 * crear carpetas, negociar el canal de datos, subir y cerrar. Son unas doce
 * idas y vueltas al servidor por archivo, y con 50 ms de latencia eso son
 * 600 ms perdidos antes de mandar un solo byte. Con mil archivos chicos, diez
 * minutos de puro protocolo.
 *
 * Ahora la conexión de control se abre una vez y se reutiliza para toda la
 * corrida. También se recuerdan las carpetas ya creadas, para no repetir
 * MKD/CWD en cada archivo.
 */
class SesionFtp {
  constructor(dest, carpetasCompartidas) {
    this.dest = dest;
    this.ctrl = null;
    // Registro de carpetas ya creadas. Si viene de afuera, lo comparten todas
    // las conexiones al mismo destino y los MKD se hacen una sola vez.
    this.carpetasCreadas = carpetasCompartidas || new Set();
    this.dirActual = "";
    this.rutaAbsolutaOk = true;   // se apaga si el servidor no la acepta
  }

  async conectar() {
    if (this.ctrl && !this.ctrl.destroyed) return;

    this.ctrl = net.createConnection(this.dest.port || 21, this.dest.host);
    this.ctrl.setEncoding("ascii");
    this.ctrl.setKeepAlive(true, 30000);

    // Escucha permanente de errores.
    //
    // Antes esto era un `once`: se consumía al conectar y después el socket
    // quedaba sin nadie escuchando. Cuando el servidor FTP cortaba la conexión
    // a mitad de un listado —cosa que hacen por inactividad, por límite de
    // conexiones o por un hipo de red— Node emitía 'error' sobre un socket sin
    // escucha, y eso en Node no es un error atrapable: se muere el proceso
    // entero. Desde la pantalla se veía como "reply was never sent".
    this.ultimoError = null;
    anotarEnVuelo(this.ctrl);
    this.ctrl.on("error", (e) => {
      this.ultimoError = e;
      try { this.ctrl.destroy(); } catch {}
    });

    await new Promise((resolve, reject) => {
      const alFallar = (e) => reject(e);
      this.ctrl.once("connect", resolve);
      this.ctrl.once("error", alFallar);
    });

    await ftpReadReply(this.ctrl);
    await ftpSend(this.ctrl, `USER ${this.dest.user || "anonymous"}`);
    await ftpReadReply(this.ctrl);
    await ftpSend(this.ctrl, `PASS ${this.dest.pass || ""}`);
    const login = await ftpReadReply(this.ctrl);
    if (login.code !== 230) throw new Error(`Login rechazado: ${login.line}`);

    await ftpSend(this.ctrl, "TYPE I");
    await ftpReadReply(this.ctrl);

    this.carpetasCreadas.clear();
    this.dirActual = "";
  }

  /**
   * Se asegura de que exista la carpeta, creando lo que falte.
   *
   * Antes esto entraba carpeta por carpeta con CWD, y lo repetía para cada
   * archivo que cambiaba de carpeta: media docena de viajes de ida y vuelta
   * por archivo. Ahora se manda MKD con la ruta completa, una sola vez por
   * carpeta y compartido entre todas las conexiones del destino. Un archivo
   * en una carpeta ya conocida no gasta ni un comando.
   */
  async asegurarCarpeta(dir) {
    if (!dir || dir === "/" || this.carpetasCreadas.has(dir)) return;

    let acumulado = "";
    for (const parte of dir.split("/").filter(Boolean)) {
      acumulado += "/" + parte;
      if (this.carpetasCreadas.has(acumulado)) continue;
      await ftpSend(this.ctrl, `MKD ${acumulado}`);
      await ftpReadReply(this.ctrl);   // 257 creada, o 550 ya existía
      this.carpetasCreadas.add(acumulado);
    }
    this.carpetasCreadas.add(dir);
  }

  /** Entra a una carpeta. Solo se usa si el servidor rechaza rutas absolutas. */
  async irA(dir) {
    if (!dir || dir === this.dirActual) return;
    await ftpSend(this.ctrl, `CWD ${dir}`);
    const r = await ftpReadReply(this.ctrl);
    if (r.code !== 250) throw new Error(`No se pudo entrar a ${dir}: ${r.line}`);
    this.dirActual = dir;
  }

  async subir(remotePath, sourcePath) {
    // Si la conexión se cayó (inactividad, corte de red), reconectamos
    if (!this.ctrl || this.ctrl.destroyed) await this.conectar();

    const dir = remotePath.substring(0, remotePath.lastIndexOf("/"));
    const nombre = path.posix.basename(remotePath);

    await this.asegurarCarpeta(dir);

    // La mayoría de los servidores aceptan STOR con la ruta completa, lo que
    // ahorra un CWD por archivo. Si este no la acepta, se pasa a CWD + nombre
    // por el resto de la corrida.
    let destinoStor;
    if (this.rutaAbsolutaOk) {
      destinoStor = remotePath;
    } else {
      await this.irA(dir);
      destinoStor = nombre;
    }

    await ftpSend(this.ctrl, "PASV");
    const pasv = await ftpReadReply(this.ctrl);
    const m = pasv.line.match(/\((\d+),(\d+),(\d+),(\d+),(\d+),(\d+)\)/);
    if (!m) throw new Error("El servidor no aceptó el modo pasivo: " + pasv.line);

    const dataHost = `${m[1]}.${m[2]}.${m[3]}.${m[4]}`;
    const dataPort = (parseInt(m[5]) << 8) + parseInt(m[6]);

    const dataSock = net.createConnection(dataPort, dataHost);
    // Buffer más grande: menos llamadas al sistema, más velocidad
    dataSock.setNoDelay(true);

    await new Promise((r, e) => {
      dataSock.once("connect", r);
      dataSock.once("error", e);
    });

    await ftpSend(this.ctrl, `STOR ${destinoStor}`);
    const listo = await ftpReadReply(this.ctrl);
    if (listo.code !== 150 && listo.code !== 125) {
      try { dataSock.destroy(); } catch {}
      // ¿Rechazó la ruta completa? Se reintenta a la vieja usanza y se recuerda.
      if (this.rutaAbsolutaOk && destinoStor !== nombre) {
        this.rutaAbsolutaOk = false;
        return this.subir(remotePath, sourcePath);
      }
      throw new Error(`El servidor rechazó la subida: ${listo.line}`);
    }

    // En FTP, cerrar el canal de datos es lo que le indica al servidor que
    // la transferencia terminó. `pipe` lo hace por defecto al agotarse el
    // archivo; esperamos el "finish" del socket, no su "close", porque el
    // cierre puede demorar hasta que actúe el keep-alive.
    await new Promise((r, e) => {
      const rs = fs.createReadStream(sourcePath, { highWaterMark: 256 * 1024 });
      let terminado = false;
      const listo = () => { if (!terminado) { terminado = true; r(); } };

      rs.on("error", e);
      dataSock.on("error", e);
      dataSock.on("finish", listo);   // terminamos de escribir y cerramos
      dataSock.on("close", listo);    // por si el servidor cierra primero

      rs.pipe(dataSock);              // pipe cierra dataSock al terminar
    });

    try { dataSock.destroy(); } catch {}

    const fin = await ftpReadReply(this.ctrl);
    if (fin.code !== 226 && fin.code !== 250) {
      throw new Error(`Transferencia incompleta: ${fin.line}`);
    }
  }

  /** Abre un canal de datos en modo pasivo y devuelve el socket conectado. */
  /**
   * Abre el canal de datos en modo pasivo.
   *
   * Dos cosas que parecen detalles y son la diferencia entre andar y colgarse:
   *
   * · **La dirección que devuelve el servidor puede ser mentira.** Muchísimos
   *   servidores FTP están detrás de un router y contestan con su IP interna
   *   (192.168.x.x, 10.x.x.x). Si le hacemos caso, intentamos conectar a una
   *   dirección que desde acá no existe. Los clientes de escritorio resuelven
   *   esto hace décadas ignorando esa IP y reusando la del canal de control;
   *   nosotros no lo hacíamos.
   *
   * · **Tiene que haber límite de tiempo.** Sin él, si el puerto de datos no
   *   acepta la conexión, la espera es eterna: la pantalla se queda en
   *   "Contando archivos…" para siempre y no hay forma de salir.
   */
  async _abrirDatos(tiempoLimite = 20000) {
    await ftpSend(this.ctrl, "PASV");
    const pasv = await ftpReadReply(this.ctrl);
    const m = pasv.line.match(/\((\d+),(\d+),(\d+),(\d+),(\d+),(\d+)\)/);
    if (!m) throw new Error("El servidor no aceptó el modo pasivo: " + pasv.line);

    let host = `${m[1]}.${m[2]}.${m[3]}.${m[4]}`;
    const puerto = (parseInt(m[5]) << 8) + parseInt(m[6]);

    if (esDireccionInterna(host) && !esDireccionInterna(this.dest.host)) {
      host = this.dest.host;
    }

    const sock = net.createConnection(puerto, host);
    sock.setNoDelay(true);
    sock.on("error", () => {});   // sin esto, un error tardío mata el proceso

    await new Promise((resolver, rechazar) => {
      const temporizador = setTimeout(() => {
        try { sock.destroy(); } catch {}
        rechazar(new Error(
          `El servidor pidió conectarse a ${host}:${puerto} y no responde. ` +
          `Suele pasar cuando el FTP está detrás de un router mal configurado.`));
      }, tiempoLimite);
      sock.once("connect", () => { clearTimeout(temporizador); resolver(); });
      sock.once("error", (e) => { clearTimeout(temporizador); rechazar(e); });
    });
    return sock;
  }

  /** Lista una carpeta. Devuelve [{ nombre, carpeta, size }]. */
  async listar(dir) {
    if (!this.ctrl || this.ctrl.destroyed) await this.conectar();
    const sock = await this._abrirDatos();
    await ftpSend(this.ctrl, `LIST ${dir || "/"}`);
    const abierto = await ftpReadReply(this.ctrl);
    if (abierto.code !== 150 && abierto.code !== 125) {
      try { sock.destroy(); } catch {}
      throw new Error(`No se pudo listar ${dir}: ${abierto.line}`);
    }
    const texto = await new Promise((resolver, rechazar) => {
      let buf = "";
      sock.setEncoding("utf8");
      // Si el servidor abre el canal y después no manda nada ni lo cierra, sin
      // este límite la espera es eterna.
      let temporizador = setTimeout(() => {
        try { sock.destroy(); } catch {}
        rechazar(new Error(`El servidor dejó de responder al listar ${dir}`));
      }, 60000);
      const reiniciar = () => {
        clearTimeout(temporizador);
        temporizador = setTimeout(() => {
          try { sock.destroy(); } catch {}
          rechazar(new Error(`El servidor dejó de responder al listar ${dir}`));
        }, 60000);
      };
      sock.on("data", (d) => { buf += d; reiniciar(); });
      sock.on("end", () => { clearTimeout(temporizador); resolver(buf); });
      sock.on("error", (e) => { clearTimeout(temporizador); rechazar(e); });
    });
    try { sock.destroy(); } catch {}
    await ftpReadReply(this.ctrl);

    const items = [];
    for (const linea of texto.split(/\r?\n/)) {
      if (!linea.trim()) continue;
      // Formato UNIX: drwxr-xr-x 1 usuario grupo  1234 Jan 01 00:00 nombre
      const m = linea.match(/^([\-dl])\S*\s+\S+\s+\S+\s+\S+\s+(\d+)\s+\S+\s+\S+\s+\S+\s+(.+)$/);
      if (!m) continue;
      const nombre = m[3].trim();
      if (nombre === "." || nombre === "..") continue;
      items.push({ nombre, carpeta: m[1] === "d", size: Number(m[2]) || 0 });
    }
    return items;
  }

  /** Recorre el destino entero y devuelve todos los archivos que encuentra. */
  /**
   * Recorre el destino entero.
   *
   * Va carpeta por carpeta y cada una cuesta varios viajes de ida y vuelta, así
   * que en un respaldo con cientos de carpetas esto es lo que hace que
   * "Contando archivos…" tarde una eternidad. Con `sesionesExtra` el recorrido
   * se reparte entre varias conexiones y baja proporcionalmente.
   */
  /**
   * Recorre el destino entero. Sin tope: un respaldo con 150.000 archivos es
   * normal, y ocultar los que sobran es peor que tardar en listarlos.
   *
   * Va carpeta por carpeta y cada una cuesta varios viajes de ida y vuelta, así
   * que el recorrido se reparte entre varias conexiones e informa el avance.
   */
  async listarTodo(base, sesionesExtra = [], alAvanzar) {
    const encontrados = [];
    const pendientes = [base || "/"];
    const equipos = [this, ...sesionesExtra];

    while (pendientes.length) {
      const lote = pendientes.splice(0, equipos.length);
      const resultados = await Promise.all(lote.map((dir, i) =>
        equipos[i].listar(dir).then(
          (items) => ({ dir, items }),
          () => ({ dir, items: [] }))));

      for (const { dir, items } of resultados) {
        for (const it of items) {
          const ruta = (dir === "/" ? "" : dir) + "/" + it.nombre;
          if (it.carpeta) pendientes.push(ruta);
          else encontrados.push({ ruta, size: it.size });
        }
      }
      if (alAvanzar) alAvanzar(encontrados.length, pendientes.length);
    }
    return { archivos: encontrados, truncado: false };
  }

  /** Descarga un archivo a una ruta local. */
  async descargar(remotePath, destinoLocal) {
    if (!this.ctrl || this.ctrl.destroyed) await this.conectar();
    await fsp.mkdir(path.dirname(destinoLocal), { recursive: true });
    const sock = await this._abrirDatos();
    await ftpSend(this.ctrl, `RETR ${remotePath}`);
    const abierto = await ftpReadReply(this.ctrl);
    if (abierto.code !== 150 && abierto.code !== 125) {
      try { sock.destroy(); } catch {}
      throw new Error(`No se pudo descargar ${remotePath}: ${abierto.line}`);
    }
    const tmp = `${destinoLocal}.bp-tmp-${process.pid}-${Date.now()}`;
    let bytes = 0;
    try {
      await new Promise((r, e) => {
        const ws = fs.createWriteStream(tmp);
        sock.on("data", (b) => { bytes += b.length; });
        sock.on("error", e);
        ws.on("error", e);
        ws.on("close", r);
        sock.pipe(ws);
      });
      await ftpReadReply(this.ctrl);
      await fsp.rename(tmp, destinoLocal);
    } catch (e) {
      try { await fsp.unlink(tmp); } catch {}
      throw e;
    }
    try { sock.destroy(); } catch {}
    return { bytes };
  }

  async cerrar() {
    olvidarEnVuelo(this.ctrl);
    if (!this.ctrl || this.ctrl.destroyed) return;
    try {
      await ftpSend(this.ctrl, "QUIT");
      this.ctrl.destroy();
    } catch {}
    this.ctrl = null;
  }
}

/** Subida suelta (se usa al probar el destino). */
async function ftpUpload(dest, remotePath, sourcePath) {
  const sesion = new SesionFtp(dest);
  try {
    await sesion.conectar();
    await sesion.subir(remotePath, sourcePath);
  } finally {
    await sesion.cerrar();
  }
}

// ─── Prueba de destinos ───────────────────────────────────────────────────────
//
// Escribe un archivo pequeño, lo verifica y lo borra. Probar de verdad la
// escritura es la única forma de saber si el destino sirve: conectarse no
// alcanza, porque puede faltar permiso de escritura o espacio.

async function probarDestino(dest) {
  const inicio = Date.now();
  const nombrePrueba = `backupprime-prueba-${Date.now()}.txt`;
  const contenido = "Prueba de escritura de BackupPrime. Este archivo se borra solo.";

  try {
    switch (dest.type) {
      case "local":
      case "network": {
        if (!dest.path) throw new Error("Falta indicar la carpeta de destino");
        await fsp.mkdir(dest.path, { recursive: true });
        const ruta = path.join(dest.path, nombrePrueba);
        await fsp.writeFile(ruta, contenido);
        const leido = await fsp.readFile(ruta, "utf8");
        await fsp.unlink(ruta);
        if (leido !== contenido) throw new Error("El archivo se escribió mal");

        // Espacio disponible, si el sistema lo informa
        let libre = null;
        try {
          const st = await fsp.statfs(dest.path);
          libre = st.bavail * st.bsize;
        } catch {}

        return {
          ok: true,
          mensaje: dest.type === "network"
            ? "Carpeta de red accesible y con permiso de escritura"
            : "Carpeta accesible y con permiso de escritura",
          detalles: libre ? [`Espacio libre: ${fmtSize(libre)}`] : [],
          ms: Date.now() - inicio,
        };
      }

      case "ftp": {
        if (!dest.host) throw new Error("Falta el servidor FTP");
        const remoto = `${dest.remotePath || ""}/${nombrePrueba}`.replace(/\/+/g, "/");
        const tmp = path.join(os.tmpdir(), nombrePrueba);
        await fsp.writeFile(tmp, contenido);
        try {
          await ftpUpload(dest, remoto, tmp);
        } finally {
          await fsp.unlink(tmp).catch(() => {});
        }
        await ftpBorrar(dest, remoto).catch(() => {});
        return {
          ok: true,
          mensaje: `Conectado a ${dest.host} y archivo de prueba subido`,
          detalles: [
            `Usuario: ${dest.user || "anonymous"}`,
            `Carpeta: ${dest.remotePath || "/"}`,
            "⚠ FTP no cifra la conexión: usuario, contraseña y archivos viajan sin protección",
          ],
          ms: Date.now() - inicio,
        };
      }

      case "sftp": {
        if (!dest.host) throw new Error("Falta el servidor SFTP");
        const remoto = `${dest.remotePath || "/"}/${nombrePrueba}`.replace(/\/+/g, "/");
        const tmp = path.join(os.tmpdir(), nombrePrueba);
        await fsp.writeFile(tmp, contenido);
        try {
          await sftpUpload(dest, remoto, tmp);
        } finally {
          await fsp.unlink(tmp).catch(() => {});
        }
        await sftpBorrar(dest, remoto).catch(() => {});
        return {
          ok: true,
          mensaje: `Conectado a ${dest.host} y archivo de prueba subido`,
          detalles: [
            `Usuario: ${dest.user || "root"}`,
            `Carpeta: ${dest.remotePath || "/"}`,
            dest.privateKey ? "Autenticación por clave" : "Autenticación por contraseña",
          ],
          ms: Date.now() - inicio,
        };
      }

      case "s3": {
        if (!dest.bucket) throw new Error("Falta el nombre del bucket");
        if (!dest.accessKey || !dest.secretKey) throw new Error("Faltan las credenciales");
        const tmp = path.join(os.tmpdir(), nombrePrueba);
        await fsp.writeFile(tmp, contenido);
        const key = `${dest.prefix || ""}${nombrePrueba}`;
        try {
          const hash = await hashFile(tmp);
          await s3Upload(dest, key, tmp, contenido.length, hash, "text/plain");
        } finally {
          await fsp.unlink(tmp).catch(() => {});
        }
        return {
          ok: true,
          mensaje: `Escritura correcta en el bucket ${dest.bucket}`,
          detalles: [
            `Servidor: ${dest.endpoint || "AWS S3"}`,
            `Región: ${dest.region || "us-east-1"}`,
          ],
          ms: Date.now() - inicio,
        };
      }

      case "cloud":
        return { ok: true, mensaje: "Se prueba desde la pestaña Configuración", ms: 0 };

      default:
        throw new Error(`Tipo de destino desconocido: ${dest.type}`);
    }
  } catch (e) {
    return {
      ok: false,
      mensaje: friendlyError(e.message),
      detalleTecnico: e.message,
      ms: Date.now() - inicio,
    };
  }
}

/** Borra un archivo del FTP (se usa para limpiar la prueba). */
async function ftpBorrar(dest, remotePath) {
  const ctrl = net.createConnection(dest.port || 21, dest.host);
  ctrl.setEncoding("ascii");
  return new Promise((resolve, reject) => {
    ctrl.once("connect", async () => {
      try {
        await ftpReadReply(ctrl);
        await ftpSend(ctrl, `USER ${dest.user || "anonymous"}`);
        await ftpReadReply(ctrl);
        await ftpSend(ctrl, `PASS ${dest.pass || ""}`);
        await ftpReadReply(ctrl);
        await ftpSend(ctrl, `DELE ${remotePath}`);
        await ftpReadReply(ctrl);
        await ftpSend(ctrl, "QUIT");
        ctrl.destroy();
        resolve();
      } catch (e) { ctrl.destroy(); reject(e); }
    });
    ctrl.once("error", reject);
  });
}

/** Borra un archivo del SFTP. */
async function sftpBorrar(dest, remotePath) {
  let Client;
  try { Client = require("ssh2").Client; } catch { return; }
  return new Promise((resolve, reject) => {
    const conn = new Client();
    conn.on("ready", () => {
      conn.sftp((err, sftp) => {
        if (err) { conn.end(); return reject(err); }
        sftp.unlink(remotePath, () => { conn.end(); resolve(); });
      });
    });
    conn.on("error", reject);
    const opts = {
      host: dest.host, port: dest.port || 22,
      username: dest.user || "root", readyTimeout: 15000,
    };
    if (dest.privateKey) {
      opts.privateKey = dest.privateKey;
      if (dest.passphrase) opts.passphrase = dest.passphrase;
    } else opts.password = dest.pass || "";
    conn.connect(opts);
  });
}

// ─── Version pruning via API ──────────────────────────────────────────────────

async function pruneVersions(server, token, sourcePath, maxVersions) {
  if (!maxVersions || maxVersions <= 0) return;
  try {
    const data = await apiReq(server, token, "GET",
      `/agent/files?sourcePath=${encodeURIComponent(sourcePath)}&limit=50&page=1`);
    const versions = (data.files || []).filter(f => f.sourcePath === sourcePath);
    if (versions.length <= maxVersions) return;
    // Sort oldest first
    versions.sort((a, b) => new Date(a.backedUpAt) - new Date(b.backedUpAt));
    const toDelete = versions.slice(0, versions.length - maxVersions);
    for (const v of toDelete) {
      await apiReq(server, token, "DELETE", `/agent/files/${v.id}`).catch(() => {});
    }
  } catch {}
}

// ─── Scheduler ────────────────────────────────────────────────────────────────
// cfg.schedule:
//   { mode: "interval", intervalMins: 60 }
//   { mode: "cron", days: [0..6], hour: 2, minute: 0 }   (days: 0=Sun, 6=Sat)

class Scheduler extends EventEmitter {
  constructor() {
    super();
    this._timer = null;
    this._lastRunDate = null; // For cron mode dedup
  }

  start(schedule) {
    this.stop();
    if (!schedule || schedule.mode === "interval") {
      const mins = (schedule && schedule.intervalMins) || 60;
      this._timer = setInterval(() => this.emit("tick"), mins * 60 * 1000);
    } else if (schedule.mode === "cron") {
      // Check every minute
      this._timer = setInterval(() => {
        const now = new Date();
        const day = now.getDay();
        const hour = now.getHours();
        const min = now.getMinutes();
        const days = schedule.days || [0,1,2,3,4,5,6];
        if (days.includes(day) && hour === (schedule.hour || 0) && min === (schedule.minute || 0)) {
          const key = `${now.toDateString()}-${hour}-${min}`;
          if (this._lastRunDate !== key) {
            this._lastRunDate = key;
            this.emit("tick");
          }
        }
      }, 60 * 1000);
    }
  }

  stop() {
    if (this._timer) { clearInterval(this._timer); this._timer = null; }
  }

  nextDescription(schedule) {
    // Este texto va al registro de actividad, que el cliente lee. Estaba en
    // inglés ("every 12 hours", "Mon, Tue at 03:00") dentro de un programa en
    // castellano.
    if (!schedule || schedule.mode === "interval") {
      const mins = (schedule && schedule.intervalMins) || 60;
      if (mins < 60) return `cada ${mins} minutos`;
      if (mins === 60) return "cada hora";
      if (mins < 1440) {
        const h = mins / 60;
        return `cada ${h} hora${h === 1 ? "" : "s"}`;
      }
      const d = mins / 1440;
      return `cada ${d} día${d === 1 ? "" : "s"}`;
    }
    if (schedule.mode === "cron") {
      const nombres = ["domingo","lunes","martes","miércoles","jueves","viernes","sábado"];
      const elegidos = schedule.days || [0,1,2,3,4,5,6];
      const h = String(schedule.hour || 0).padStart(2,"0");
      const m = String(schedule.minute || 0).padStart(2,"0");
      if (elegidos.length === 7) return `todos los días a las ${h}:${m}`;
      const dias = elegidos.map((d) => nombres[d]);
      const lista = dias.length > 1
        ? `${dias.slice(0, -1).join(", ")} y ${dias[dias.length - 1]}`
        : dias[0];
      return `${lista} a las ${h}:${m}`;
    }
    return "sin programación";
  }
}

// ─── BackupEngine ─────────────────────────────────────────────────────────────

class BackupEngine extends EventEmitter {
  constructor() {
    super();
    this._scheduler = new Scheduler();
    // Se lee el registro ya en el constructor: `start()` necesita saber cuándo
    // fue el último respaldo ANTES de que corra el primero.
    try { this._state = new StateStore(getConfigDir()); } catch { this._state = null; }
    this._running = false;
    this._active = false;
    this._scheduler.on("tick", () => {
      if (!this._active) return;
      this._runBackup(this._cfg).catch((e) => this.log(`[error] ${friendlyError(e.message)}`));
    });
  }

  log(msg) {
    const line = `[${new Date().toLocaleTimeString()}] ${msg}\n`;
    this.emit("log", line);
  }

  get isActive() { return this._active; }
  get isRunning() { return this._running; }

  // Aplica una configuración nueva (destinos, horario) sin cortar el respaldo
  // que pueda estar corriendo. Antes esto se hacía con stop() + start(), y
  // como stop() marcaba el motor como libre mientras el recorrido seguía vivo,
  // arrancaban dos respaldos a la vez sobre el mismo registro de estado: el
  // viejo terminaba pisando lo que anotaba el nuevo, y los archivos quedaban
  // marcados como respaldados en destinos donde nunca llegaron.
  reconfigure(cfg) {
    this._cfg = cfg;
    if (!this._active) return;
    this._scheduler.start(cfg.schedule || { mode: "interval", intervalMins: 60 });
    if (this._running) {
      // Queda anotado: al terminar el respaldo en curso se vuelve a correr con
      // la configuración nueva. Antes solo se avisaba y el cambio se perdía
      // hasta la próxima corrida programada.
      this._pendiente = cfg;
      this.log("[info] Cambio guardado. Se aplica apenas termine el respaldo en curso.");
      return;
    }
    this._runBackup(cfg).catch((e) => this.log(`[error] ${friendlyError(e.message)}`));
  }

  start(cfg) {
    if (this._active) return;
    this._active = true;
    this._cancelado = false;
    this._cfg = cfg;
    this.emit("status", { running: true });
    const sched = cfg.schedule || { mode: "interval", intervalMins: 60 };
    const desc = this._scheduler.nextDescription(sched);
    this._scheduler.start(sched);

    // ── ¿Respaldar ahora mismo o esperar al horario? ──
    //
    // Antes se respaldaba SIEMPRE al arrancar. Con el programa configurado para
    // correr, por ejemplo, cada 12 horas, abrir la ventana disparaba un respaldo
    // igual: el horario no se respetaba y el usuario perdía el control sobre
    // cuándo se usa su conexión. Peor todavía en una notebook con datos móviles.
    //
    // Pero tampoco se puede esperar sin más: si la máquina estuvo apagada tres
    // días, el momento programado ya pasó y esperar al siguiente dejaría al
    // cliente sin respaldo por más tiempo del que él eligió.
    //
    // Regla: se respalda al arrancar solo si YA CORRESPONDÍA. Es decir, si nunca
    // se respaldó, o si desde el último pasó más tiempo del que dice la
    // programación. Si no, se espera al horario.
    const motivo = this._porQueCorrerAhora(sched);
    if (motivo) {
      this.log(`[inicio] Vigilancia activada — ${desc}. ${motivo}`);
      this._runBackup(cfg).catch((e) => this.log(`[error] ${friendlyError(e.message)}`));
    } else {
      this.log(`[inicio] Vigilancia activada — ${desc}. ` +
        `El último respaldo está al día, así que se espera al horario configurado.`);
    }
  }

  /**
   * Devuelve el motivo por el que corresponde respaldar al arrancar, o null si
   * hay que esperar al horario.
   */
  _porQueCorrerAhora(sched) {
    const ultimo = Number(this._state && this._state.get("__ultimoRespaldo")) || 0;
    if (!ultimo) return "Es el primer respaldo de este equipo, así que empieza ahora.";

    const transcurrido = Date.now() - ultimo;
    if (transcurrido < 0) {
      // Reloj cambiado hacia atrás: no se puede confiar en la cuenta.
      return "Empezando un respaldo para ponerse al día.";
    }

    if (!sched || sched.mode === "interval") {
      const cada = ((sched && sched.intervalMins) || 60) * 60 * 1000;
      if (transcurrido >= cada) {
        return `Pasaron ${fmtDuracion(transcurrido)} desde el último respaldo, ` +
          `así que empieza uno ahora para ponerse al día.`;
      }
      return null;
    }

    // Modo días y hora: si el momento de hoy ya pasó y no se respaldó desde
    // entonces, corresponde ponerse al día.
    const ahora = new Date();
    const dias = sched.days || [0, 1, 2, 3, 4, 5, 6];
    const programadoHoy = new Date(ahora);
    programadoHoy.setHours(sched.hour || 0, sched.minute || 0, 0, 0);
    const tocabaHoy = dias.includes(ahora.getDay()) && ahora >= programadoHoy;
    if (tocabaHoy && ultimo < programadoHoy.getTime()) {
      return "El respaldo de hoy todavía no se hizo, así que empieza ahora.";
    }
    return null;
  }

  stop() {
    this._active = false;
    this._cancelado = true;
    this._pendiente = null;
    // Se cortan las transferencias abiertas: si no, con seis en paralelo y
    // archivos grandes, "Detener" tardaba minutos en hacerse notar.
    cortarTodoEnVuelo();
    this.log("[stop] Deteniendo: se cortan las transferencias en curso.");
    this._scheduler.stop();
    // _running NO se toca: lo limpia el propio respaldo al terminar. Marcarlo
    // libre acá dejaba entrar un segundo respaldo en paralelo.
    this.emit("status", { running: false });
    this.log("[stop] Vigilancia detenida. No se van a hacer respaldos automáticos.");
  }

  async runOnce(cfg) {
    this._cfg = cfg;
    this._cancelado = false;
    return this._runBackup(cfg);
  }

  /** Para que la pantalla sepa si hay algo corriendo. */
  get estaRespaldando() { return !!this._running; }
  get hayPendiente() { return !!this._pendiente; }

  /**
   * Corre un respaldo.
   *
   * Si ya hay uno en curso, ANOTA el pedido en lugar de descartarlo, y lo
   * ejecuta apenas termina el que está corriendo.
   *
   * Antes se descartaba con una línea en el registro que nadie ve. El efecto
   * era desconcertante: con destino local el respaldo termina en segundos y
   * "Respaldar ahora" siempre funcionaba; con FTP tarda, así que al apretar el
   * botón todavía estaba corriendo el anterior y no pasaba nada. Y las carpetas
   * agregadas durante un respaldo quedaban esperando a la próxima corrida
   * programada, que con un intervalo de una hora es una eternidad.
   */
  async _runBackup(cfg) {
    if (this._running) {
      this._pendiente = cfg;
      this.log("[info] Ya hay un respaldo en curso. Este pedido queda anotado para cuando termine.");
      this.emit("ocupado", { encolado: true });
      return { corrio: false, motivo: "ocupado" };
    }

    this._running = true;
    try {
      await this._doBackup(cfg);
    } finally {
      this._running = false;
    }

    // Si mientras tanto cambió la configuración o alguien pidió otro respaldo,
    // se corre ahora con lo último, sin esperar al próximo horario.
    if (this._pendiente && !this._cancelado) {
      const siguiente = this._pendiente;
      this._pendiente = null;
      this.log("[info] Corriendo el respaldo que había quedado pendiente.");
      await this._runBackup(siguiente);
    }

    return { corrio: true };
  }

  async _doBackup(cfg) {
    const {
      server, token,
      localPaths, excludedPaths,
      destinations,       // Array of destination objects
      forceFullBackup,    // Boolean - reset state and do full backup
      maxVersions,        // Number - versions to keep per file (cloud only)
      systemBackup,       // Boolean - scan all drives
    } = cfg;

    const dests = destinations || [];
    const cloudDest = dests.find(d => d.type === "cloud");

    // Un destino local o de red que no está montado (disco desenchufado,
    // carpeta de red caída) se saca de esta corrida entera. Si lo dejáramos,
    // fallaría archivo por archivo llenando el registro de errores, y ninguno
    // quedaría marcado como pendiente para ese destino en particular.
    const otherDests = [];
    for (const d of dests) {
      if (d.type === "cloud") continue;
      if ((d.type === "local" || d.type === "network") && !fs.existsSync(d.path || "")) {
        this.log(`[error] El destino "${d.label || d.path}" no está disponible. Se omite en esta corrida.`);
        continue;
      }
      otherDests.push(d);
    }
    const hasCloud = !!(cloudDest && server && token);
    const hasOther = otherDests.length > 0;

    // Claves de TODOS los destinos configurados ahora mismo (no en la corrida
    // anterior). Se usan para detectar destinos nuevos/removidos por archivo.
    const currentDestKeys = [
      ...(hasCloud ? ["cloud"] : []),
      ...otherDests.map(destKey),
    ];

    // Conjunto de conexiones FTP por destino. FTP no permite mandar dos
    // archivos por la misma conexión al mismo tiempo, así que para transferir
    // en paralelo hace falta una conexión por transferencia simultánea. Se
    // abren a medida que se necesitan y se reutilizan hasta el final de la
    // corrida: abrir y autenticar cuesta varios viajes de ida y vuelta.
    //
    // Las carpetas ya creadas se recuerdan en un registro compartido por todas
    // las conexiones del mismo destino, para que la segunda conexión no repita
    // los MKD que ya hizo la primera.
    const poolFtp = new Map();   // destKey -> { libres, todas, carpetas }
    const grupoFtp = (dest) => {
      const k = destKey(dest);
      if (!poolFtp.has(k)) poolFtp.set(k, { libres: [], todas: [], carpetas: new Set() });
      return poolFtp.get(k);
    };
    const tomarSesionFtp = async (dest) => {
      const g = grupoFtp(dest);
      const libre = g.libres.pop();
      if (libre) return libre;
      const s = new SesionFtp(dest, g.carpetas);
      await s.conectar();
      g.todas.push(s);
      return s;
    };
    const soltarSesionFtp = (dest, sesion) => {
      grupoFtp(dest).libres.push(sesion);
    };

    if (!hasCloud && !hasOther) {
      this.log("[aviso] No hay ningún destino configurado. Agregá uno en la pestaña Backup.");
      return;
    }

    const configDir = getConfigDir();
    const state = new StateStore(configDir);
    // Se guarda para que `start()` pueda preguntar cuándo fue el último respaldo
    // y decidir si corresponde correr al arrancar o esperar al horario.
    this._state = state;

    // ── Guardia anti-ransomware ───────────────────────────────────────────
    //
    // Estaba construido y probado desde hacía versiones, y no lo llamaba nadie.
    // Un guardia que no se enchufa no protege de nada.
    //
    // Mira cada archivo que entrega el recorrido y cruza tres señales: cuántos
    // archivos se modificaron por minuto, cuántos tienen entropía de cifrado, y
    // cuántos aparecen con una extensión que nunca se había visto. Con UNA sola
    // no corta —exportar un lote desde Tango dispara la tasa, instalar un
    // programa dispara las extensiones—; con dos, sí.
    //
    // Y corta ANTES de subir: si el respaldo sigue, las versiones cifradas se
    // suben y empujan a las sanas fuera del historial. El ataque termina de
    // hacer el trabajo usando nuestro propio producto.
    const ultimoRespaldoMs = Number(state.get("__ultimoRespaldo")) || 0;
    const guardia = new GuardiaCifrado({
      referenciaMs: ultimoRespaldoMs,
      extensionesConocidas: extensionesDelEstado(state._data),
      // En el primer respaldo TODO es nuevo y TODO cambió: el guardia no puede
      // distinguir eso de un cifrado masivo, así que no dispara.
      primerRespaldo: !ultimoRespaldoMs,
    });
    this._guardia = guardia;

    // Force full backup — reset state
    if (forceFullBackup) {
      this.log("[info] Respaldo completo forzado: se van a volver a subir todos los archivos.");
      try { fs.unlinkSync(state._path); } catch {}
      state._data = {};
    }

    // ── Modo verificar ──
    //
    // Comprueba que lo que dice el registro esté realmente en el destino, y
    // sube SOLO lo que falta. No es lo mismo que "respaldo completo": ese borra
    // el registro y vuelve a subir todo, lo que con versionado activo duplica
    // el consumo del cliente sin ningún beneficio.
    //
    // Sirve cuando un respaldo se cortó a mitad de camino —se colgó la máquina,
    // se cortó la luz, se cayó la red— y quedó la duda de si lo que figura como
    // subido está entero.
    // ── Clave de cifrado de la cuenta ──
    //
    // Se resuelve UNA vez por corrida, no por archivo: derivarla de una frase
    // cuesta cerca de un segundo a propósito —para que probar frases al azar le
    // salga caro a quien se lleve los datos— y hacerlo por archivo dejaría el
    // respaldo inservible.
    let claveCifrado = null;
    try {
      claveCifrado = Cifrado.abrirClave({
        modo: cfg.cifradoModo || "gestionada",
        claveServidor: cfg.cifradoClave,
        frase: cfg.cifradoFrase,
        salBase64: cfg.cifradoSal,
        comprobante: cfg.cifradoComprobante,
      });
    } catch (e) {
      // Sin clave no se puede respaldar en una cuenta con cifrado privado:
      // subir sin cifrar sería peor que fallar, porque el cliente creería que
      // sus archivos están protegidos y no lo estarían.
      this.log(`[error] ${e.message}`);
      this.emit("done", { uploaded: 0, skipped: 0, errors: 1, bytes: 0, backupMode: "ninguno" });
      return;
    }
    if (claveCifrado) {
      this.log(`[info] Los archivos se cifran antes de subirse` +
        (cfg.cifradoModo === "privada"
          ? ` con tu frase privada. Nadie más puede leerlos.`
          : `.`));
    }

    // ── Cuándo hay que verificar, sin que nadie se acuerde de pedirlo ────────
    //
    // Saltear un archivo sin tocar la red es rápido, y es lo correcto. Pero
    // tiene una consecuencia que hay que mirar de frente: `state.json` pasa a
    // ser la ÚNICA verdad sobre lo que hay en el destino. Si el destino perdió
    // un objeto, el cliente no se entera nunca: cada corrida dice "sin cambios"
    // y el archivo no está. Eso es exactamente lo que este producto existe para
    // que no pase — un respaldo que parece estar y no está es peor que no tener
    // respaldo, porque el cliente no toma ninguna otra precaución.
    //
    // Dos redes, y son distintas:
    //
    //   · VERIFICACIÓN PROGRAMADA (semanal): revisa TODO contra el destino.
    //     Es la que da la respuesta completa.
    //   · REVALIDACIÓN ROTATIVA (cada corrida): revisa la tajada más vieja, la
    //     que hace más días que nadie mira. Existe porque la semanal depende de
    //     que la máquina esté prendida ese día, y en un estudio contable el
    //     domingo está apagada. Con la rotativa, ningún archivo pasa más de
    //     `revalidarMaxDias` sin que alguien lo haya mirado de verdad, sin
    //     importar qué día se prenda la máquina.
    const DIAS = 86400000;
    const cadaDias = Number(cfg.verificacionCadaDias) > 0
      ? Number(cfg.verificacionCadaDias) : 7;
    const revalidarMaxDias = Number(cfg.revalidarMaxDias) > 0
      ? Number(cfg.revalidarMaxDias) : 14;

    const ultimaVerificacion = Number(state.get("__ultimaVerificacion")) || 0;
    const tocaVerificacionCompleta = state.hasState()
      && cfg.verificacionAutomatica !== false
      && (Date.now() - ultimaVerificacion) >= cadaDias * DIAS;

    let verificacionProgramada = false;
    if (!cfg.verificar && tocaVerificacionCompleta) {
      verificacionProgramada = true;
      this.log(ultimaVerificacion
        ? `[verificar] Pasaron ${Math.floor((Date.now() - ultimaVerificacion) / DIAS)} días ` +
          `desde la última verificación. Se revisa todo contra el destino.`
        : `[verificar] Primera verificación del respaldo contra el destino.`);
    }

    const modoVerificar = !!cfg.verificar || verificacionProgramada;

    // ── Señal de vida, ANTES de leer un solo archivo ──
    //
    // Entre apretar "Respaldar ahora" y el primer archivo procesado pueden
    // pasar treinta segundos: se lee el registro (27 MB con 120.000 entradas),
    // se pide el inventario del destino y se empiezan a recorrer las carpetas.
    // Durante todo ese rato la pantalla no recibía NADA y parecía que el botón
    // no había hecho nada — el cliente lo aprieta cuatro veces más.
    //
    // Esto se manda apenas arranca, y las fases siguientes lo van reemplazando.
    this.emit("progreso", {
      fase: "preparando", archivoActual: "", procesados: 0, totalEstimado: 0,
      subidos: 0, salteados: 0, errores: 0, bytesSubidos: 0, bytesTotales: 0,
      velocidad: 0, restanteSeg: null, transcurridoSeg: 0, enVuelo: [],
      inicio: Date.now(),
      // Todavía no se contó nada. `listo: false` es lo que hace que la pantalla
      // diga "contando…" en vez de "0 de 0 archivos", que parecería que revisó
      // y no encontró nada.
      trabajo: { archivos: 0, bytes: 0, listo: false },
      bytesRecorridos: 0, porcentaje: null,
    });

    // Los archivos que hace demasiado que nadie mira. Se calcula SIEMPRE, para
    // poder decir en pantalla cuántos hay aunque esta corrida no revalide.
    const vencidos = [];
    if (!modoVerificar && state.hasState()) {
      const corte = Date.now() - revalidarMaxDias * DIAS;
      for (const [ruta, datos] of state.entradas()) {
        if (!(Number(datos.verificadoEn) > corte)) vencidos.push(ruta);
      }
    }
    const revalidarRotativo = vencidos.length > 0;
    const aRevalidar = new Set(vencidos);

    // ── Cuentas de la verificación, SOLO sobre los archivos de esta corrida ──
    //
    // Antes esto se calculaba recorriendo `state.json` entero al final, y ahí
    // está el error: el registro guarda también archivos que YA NO EXISTEN
    // —borrados, renombrados, o sacados de la selección—. Esos nunca se
    // procesan, así que nunca se marcan como comprobados, y con miles de
    // entradas siempre queda alguno. Resultado: la pantalla decía "todavía hay
    // archivos sin comprobar" para siempre, incluso recién terminada una
    // verificación completa que había revisado todo. Una advertencia que no se
    // puede apagar es ruido, y el ruido enseña a ignorar los avisos que sí
    // importan.
    const verif = { comprobados: 0, sinComprobar: 0, peorDias: 0 };
    if (revalidarRotativo) {
      this.log(`[verificar] ${vencidos.length} archivo(s) llevan más de ${revalidarMaxDias} ` +
               `días sin comprobarse contra el destino. Se revisan en esta corrida.`);
    }

    let faltantesVerificados = 0;
    // Los bloques que ya están en cada destino. Se declara ACÁ, antes del
    // inventario, porque el inventario lo llena de paso: así el bucket se
    // recorre una sola vez y no dos.
    const bloquesPorDestino = new Map();
    let inventarioDestino = null;
    // El inventario es UN listado por destino, paginado, y sirve igual para la
    // verificación completa que para la rotativa. Preguntar archivo por archivo
    // con HEAD sería peor por dos motivos: son cientos de viajes, y varios
    // servicios compatibles con S3 contestan 403 en vez de 404 cuando el objeto
    // no existe — con esa respuesta el programa concluye que no está nada y
    // resube todo. Ya nos pasó.
    if (modoVerificar || revalidarRotativo) {
      inventarioDestino = new Map();
      for (const d of (destinations || []).filter((x) => x.enabled !== false && x.type === "s3")) {
        // Pedir la lista de un destino con 115.000 objetos son más de cien
        // viajes de ida y vuelta. Si el cliente apretó "Detener" mientras eso
        // pasaba, hay que abandonar acá: seguir pidiendo páginas de una lista
        // que ya no se va a usar es hacerlo esperar por nada.
        if (this._cancelado) break;
        try {
          const { archivos } = await s3Listar(d);
          if (this._cancelado) break;
          const porDestino = new Map();
          const bloquesDeAca = new Set();
          const prefijoBloques = `${d.prefix || ""}bloques/`;
          // ── Un solo recorrido, dos usos ──
          //
          // Antes el bucket se listaba DOS VECES por corrida: una acá para el
          // inventario y otra en `bloquesYaGuardados` para los bloques, que ya
          // venían en esta misma lista. Con 115.000 archivos son 120 pedidos
          // paginados de ida y vuelta, repetidos al pepe.
          //
          // Además, las claves de `bloques/` NO se guardan en el inventario:
          // ahí nunca se busca un bloque, se busca un archivo o un índice.
          // Guardarlas es cargar decenas de miles de entradas en memoria para
          // no consultarlas jamás.
          for (const a of archivos) {
            if (a.clave.startsWith(prefijoBloques)) {
              bloquesDeAca.add(a.clave.split("/").pop());
              continue;
            }
            // Ojo con el nombre del campo: `s3Listar` devuelve `size`, no
            // `bytes`. Leyendo el que no era, todos los tamaños daban 0, ningún
            // archivo coincidía y la verificación resubía TODO — justo lo que
            // este modo existe para evitar.
            porDestino.set(a.clave, Number(a.size) || 0);
          }
          inventarioDestino.set(destKey(d), porDestino);
          // Se aprovecha para el resto de la corrida: `bloquesYaGuardados` ya
          // no necesita salir a pedir nada.
          bloquesPorDestino.set(destKey(d), bloquesDeAca);
          if (modoVerificar) {
            this.log(`[info] Verificando contra ${nombreDestino(d)}: ` +
                     `${porDestino.size} archivo(s) y ${bloquesDeAca.size} bloque(s) en el destino.`);
          }
        } catch (e) {
          this.log(`[aviso] No se pudo leer el destino ${nombreDestino(d)} para verificar: ${friendlyError(e.message)}`);
        }
      }
      // Sin inventario no se puede verificar nada, y —esto importa— tampoco se
      // puede marcar ningún archivo como verificado. Marcarlos igual sería
      // anotar una tranquilidad que nadie comprobó.
      if (inventarioDestino.size === 0) inventarioDestino = null;
    }

    const isFirstRun = !state.hasState();
    const backupMode = isFirstRun ? "Full" : "Incremental";
    this.log(`[inicio] Comenzando respaldo ${backupMode === "Full" ? "completo" : "incremental"}…`);

    // Cloud: heartbeat + get policy
    let includedPathsFromPolicy = [];
    let excludedFromPolicy = [];
    let job = null;

    if (hasCloud) {
      try {
        const hb = await apiReq(server, token, "POST", "/agent/heartbeat", {
          hostname: os.hostname(),
          os: process.platform === "win32" ? "windows" : process.platform === "darwin" ? "macos" : "linux",
          agentVersion: require(path.join(__dirname, "..", "package.json")).version,
        });
        includedPathsFromPolicy = hb.policy?.includedPaths || [];
        excludedFromPolicy = hb.policy?.excludedPaths || [];
        this.log(`[ok] Conectado al servidor como "${hb.device?.name || "este equipo"}".`);
      } catch (e) {
        this.log(`[error] No se pudo conectar con el servidor: ${friendlyError(e.message)}`);
        if (!hasOther) return;
        this.log("[info] Se continúa respaldando solo a los destinos locales.");
      }

      // Start cloud job
      if (hasCloud) {
        try {
          job = await apiReq(server, token, "POST", "/agent/jobs", {});
          
        } catch (e) {
          this.log(`[aviso] No se pudo registrar el respaldo en el servidor: ${friendlyError(e.message)}`);
          job = null;
        }
      }
    }

    // System backup: scan all drives on the machine
    let systemDrivePaths = [];
    if (systemBackup) {
      if (process.platform === "win32") {
        for (let i = 67; i <= 90; i++) {
          const d = String.fromCharCode(i) + ":\\";
          if (fs.existsSync(d)) systemDrivePaths.push(d);
        }
      } else {
        systemDrivePaths = ["/"];
      }
    }

    const includedPaths = systemBackup
      ? systemDrivePaths
      : (localPaths && localPaths.length > 0)
        ? localPaths
        : includedPathsFromPolicy;
    const excluded = [...(excludedPaths || []), ...excludedFromPolicy];


    if (!includedPaths.length) {
      this.log("[aviso] No elegiste ninguna carpeta para respaldar. Agregalas en la pestaña Backup.");
      if (job) await apiReq(server, token, "POST", `/agent/jobs/${job.id}/finish`, {
        status: "failed", filesCount: 0, bytesCount: 0, errorsCount: 0,
        errorKind: "missing",
        errorSample: ["No hay carpetas configuradas para respaldar"],
      }).catch(() => {});
      return;
    }

    // ── Instantánea de volumen (VSS) ──
    //
    // Es lo que permite leer archivos que otro programa tiene abiertos. Sin
    // esto, el PST de Outlook —el archivo que un estudio contable más lamenta
    // perder— falla con EBUSY si el cliente dejó Outlook abierto, que es
    // siempre. Los reintentos de `hashFile` sirven para bloqueos pasajeros
    // (antivirus, un guardado momentáneo); Outlook mantiene el archivo tomado
    // toda la sesión y solo se resuelve con la copia sombra.
    //
    // Si no se puede crear (sin permisos de administrador, volumen que no es
    // NTFS, servicio VSS caído) el respaldo SIGUE sin instantánea. Un respaldo
    // degradado con aviso es mejor que ningún respaldo; lo que no se hace es
    // fingir que salió bien.
    let instantaneas = null;
    // Lo que la pantalla necesita saber sobre la instantánea, para poder decirle
    // al usuario si sus archivos abiertos quedaron cubiertos o no.
    let progresoVss = null;
    let progresoEspacio = null;
    let vssPedido = cfg.usarVss !== false && process.platform === "win32";

    // ── Espacio libre ──
    // Con el disco al límite, crear una instantánea puede dejar la máquina
    // inutilizable: Windows reserva espacio en el mismo disco y lo llena con
    // cada cambio mientras el respaldo corre. Le pasó a un cliente real.
    const espacio = await revisarEspacio(includedPaths);
    if (!espacio.ok) {
      for (const u of espacio.apretadas) {
        this.log(`[aviso] Poco espacio libre en ${u.unidad}: ` +
          `${fmtSize(u.libre)} de ${fmtSize(u.total)} (${(u.proporcion * 100).toFixed(1)}%).`);
      }
      if (vssPedido) {
        // No se crea la instantánea. Se respalda igual leyendo los archivos
        // directamente, que es lo que funciona para casi todo.
        vssPedido = false;
        this.log(`[aviso] No se van a usar instantáneas en este respaldo, para no ` +
          `llenar el disco. El respaldo sigue normalmente.`);
      }
      if (espacio.critica) {
        this.log(`[aviso] El disco está muy lleno. Conviene liberar espacio: con el ` +
          `disco al límite, Windows se vuelve lento y cualquier programa puede trabarse.`);
      }
    }
    progresoEspacio = espacio.ok ? null : {
      apretadas: espacio.apretadas.map((u) => ({
        unidad: u.unidad, libre: u.libre, total: u.total,
        porcentaje: Math.round(u.proporcion * 1000) / 10,
      })),
      critica: espacio.critica,
    };
    if (vssPedido) {
      // Instantáneas de una corrida anterior que se cerró mal: si no se limpian,
      // se acumulan y comen disco del cliente.
      const huerfanas = Vss.limpiarHuerfanas();
      if (huerfanas > 0) this.log(`[info] Se liberaron ${huerfanas} instantánea(s) que habían quedado colgadas`);

      // El módulo ya avisa por su cuenta cuando no puede crear la instantánea.
      // Duplicar el aviso acá dejaba dos renglones seguidos diciendo lo mismo en
      // el registro de actividad, que es ruido y hace parecer que hay dos
      // problemas distintos.
      instantaneas = Vss.crearParaCarpetas(includedPaths, (m, tipo) => {
        if (tipo === "aviso") {
          // Un aviso sin salida no sirve. Si falta administrador, se dice cómo
          // resolverlo en la misma línea.
          const comoResolver = /administrador/i.test(m)
            ? " Cerrá BackupPrime y volvé a abrirlo con \"Ejecutar como administrador\", " +
              "o activá el arranque automático, que lo hace solo."
            : "";
          this.log(`[aviso] ${m}${comoResolver}`);
        } else {
          this.log(`[${tipo === "exito" ? "ok" : "info"}] ${m}`);
        }
      });
      progresoVss = {
        activa: instantaneas.activas.length > 0,
        volumenes: instantaneas.activas.map((i) => i.volumen),
        degradado: !!instantaneas.degradado,
        motivo: instantaneas.motivo || null,
      };
    }

    // Desde acá y hasta el final, la instantánea tiene que liberarse pase lo
    // que pase: si el respaldo falla a mitad de camino y queda una copia
    // sombra colgada, le come disco al cliente hasta que reinicie.
    try {

    let uploaded = 0, skipped = 0, errors = 0, bytes = 0;

    // ── Progreso en vivo ──
    // Sin esto el usuario ve una pantalla quieta y asume que no funciona.
    // Emitimos el avance con un límite de frecuencia para no saturar la
    // interfaz con miles de mensajes por segundo.
    const progreso = {
      fase: "escaneando",
      archivoActual: "",
      procesados: 0,
      totalEstimado: 0,
      subidos: 0,
      salteados: 0,
      errores: 0,
      bytesSubidos: 0,
      bytesTotales: 0,
      velocidad: 0,          // bytes por segundo
      inicio: Date.now(),
      restanteSeg: null,
      // Tamaños de los archivos que faltan subir. Se usa para que el
      // porcentaje avance de forma pareja en vez de saltar.
      pendientes: [],
      // Avance del archivo que se está procesando ahora. Sin esto, un PST de
      // 651 MB dejaba la pantalla congelada de punta a punta: `bytesSubidos`
      // solo se actualizaba al TERMINAR cada archivo, así que durante los
      // minutos que tardaba el archivo grande no se movía ni un byte, la
      // velocidad quedaba en "—" y el tiempo restante en "—". Para el usuario
      // eso es indistinguible de un programa colgado, y con archivos grandes es
      // justamente cuando más necesita saber que algo está pasando.
      bytesEnVuelo: 0,
      enVuelo: [],
      // ── El total del trabajo y el tiempo que falta ──
      //
      // El motor descubre los archivos mientras los copia, así que hasta ahora
      // no había denominador: la pantalla podía decir "12.480 archivos" pero no
      // "de cuántos". Sin total no hay porcentaje honesto y no hay tiempo
      // restante del trabajo completo, que es lo primero que mira alguien que
      // dejó un respaldo corriendo y quiere saber si se va a dormir o espera.
      //
      // `listo` es lo que separa un número exacto de uno parcial. Mientras el
      // conteo corre, los totales SUBEN, y decir "12.480 de 40.000" cuando
      // todavía faltan carpetas por contar es exactamente el error de "un
      // número parcial mostrado como exacto". Por eso el porcentaje y el tiempo
      // restante NO salen hasta que `listo` es verdadero; antes de eso la
      // pantalla dice que está contando.
      trabajo: { archivos: 0, bytes: 0, listo: false },
      // Bytes de los archivos ya despachados —subidos, salteados o con error—.
      // No es lo mismo que `bytesSubidos`: en un incremental donde no cambió
      // nada, `bytesSubidos` queda en cero y sin embargo el trabajo avanza.
      // Esto es lo que mide cuánto del trabajo se masticó, que es lo único con
      // lo que se puede estimar cuánto falta.
      bytesRecorridos: 0,
      porcentaje: null,
      // Estado de la instantánea: si está activa, sobre qué volúmenes, y si no
      // se pudo crear, por qué.
      vss: progresoVss,
      // Unidades con poco espacio libre, para avisarle al cliente antes de que
      // se le trabe la máquina.
      espacio: progresoEspacio,
    };
    // ruta -> { nombre, total, hechos, fase }
    const archivosEnVuelo = new Map();

    const refrescarEnVuelo = () => {
      let suma = 0;
      for (const v of archivosEnVuelo.values()) suma += v.hechos;
      progreso.bytesEnVuelo = suma;
      // Solo se manda a la pantalla lo que vale mostrar: los archivos grandes,
      // de mayor a menor. Con 6 trabajadores en paralelo, listar los seis
      // archivos chicos que están pasando no ayuda a nadie.
      progreso.enVuelo = [...archivosEnVuelo.values()]
        .filter((v) => v.total >= 8 * 1048576)
        .sort((a, b) => b.total - a.total)
        .slice(0, 3)
        .map((v) => ({
          nombre: v.nombre, total: v.total, hechos: Math.min(v.hechos, v.total),
          fase: v.fase,
          porcentaje: v.total > 0 ? Math.min(100, (v.hechos / v.total) * 100) : 0,
        }));
    };

    /** Marca en qué anda un archivo y cuánto lleva hecho. */
    const marcarAvance = (ruta, nombre, total, hechos, fase) => {
      const previo = archivosEnVuelo.get(ruta);
      archivosEnVuelo.set(ruta, { nombre, total, hechos, fase });
      refrescarEnVuelo();
      // La velocidad se calculaba solo con los archivos terminados, así que en
      // un archivo grande no había muestras y quedaba en "—". Ahora el avance
      // parcial también cuenta.
      muestras.push({ t: Date.now(), b: progreso.bytesSubidos + progreso.bytesEnVuelo });

      // El limitador por tiempo descarta casi todos los avisos cuando el archivo
      // avanza rápido, y la barra parece no moverse justo en el archivo que más
      // tarda. Se fuerza el envío cuando el avance acumulado es apreciable.
      //
      // Ojo con contra qué se compara: tiene que ser contra el último valor
      // EMITIDO, no contra la actualización anterior. Comparando con la anterior,
      // con bloques de ~1 MB el salto nunca llegaba al umbral y no se emitía
      // nunca: la barra quedaba clavada en el primer valor.
      const APRECIABLE = 2 * 1048576;
      const entrada = archivosEnVuelo.get(ruta);
      const desdeUltimo = hechos - (previo ? (previo.emitidoEn || 0) : 0);
      const forzar = !previo || (previo.fase !== fase) || desdeUltimo >= APRECIABLE;
      entrada.emitidoEn = forzar ? hechos : (previo ? previo.emitidoEn || 0 : 0);
      emitirProgreso(forzar);
    };

    const soltarArchivo = (ruta) => {
      archivosEnVuelo.delete(ruta);
      refrescarEnVuelo();
    };
    let ultimoEnvio = 0;
    const muestras = [];     // para promediar la velocidad

    const emitirProgreso = (forzar = false) => {
      const ahora = Date.now();
      // ── Dos frenos, no uno ──
      //
      // El freno normal es de 400 ms. Pero `forzar` lo saltea, y se fuerza al
      // empezar y al terminar CADA archivo. Con archivos chicos —que son la
      // mayoría: 165.000 archivos de un estudio son casi todos Word y Excel—
      // eso son miles de avisos por segundo hacia la ventana. El motor sigue
      // trabajando, pero la pantalla no da abasto y queda muerta: es
      // exactamente lo que se veía como "se colgó".
      //
      // Por eso hay un piso que ni siquiera `forzar` saltea. 80 ms son doce
      // refrescos por segundo: más que suficiente para que se vea fluido, y
      // suficientemente poco como para no ahogar a la ventana.
      // "final" es el aviso de cierre: ese NO se puede descartar nunca, o la
      // pantalla se queda con el penúltimo estado y parece que faltó algo.
      const PISO_FORZADO = 80;
      if (forzar !== "final") {
        if (!forzar && ahora - ultimoEnvio < 400) return;
        if (forzar && ahora - ultimoEnvio < PISO_FORZADO) return;
      }
      ultimoEnvio = ahora;

      // Velocidad promediada de los últimos 5 segundos: más estable que
      // el promedio total, que se vuelve inútil en backups largos
      const corte = ahora - 5000;
      while (muestras.length && muestras[0].t < corte) muestras.shift();
      if (muestras.length > 1) {
        const dt = (muestras[muestras.length - 1].t - muestras[0].t) / 1000;
        const db = muestras[muestras.length - 1].b - muestras[0].b;
        progreso.velocidad = dt > 0 ? db / dt : 0;
      }

      progreso.transcurridoSeg = Math.round((ahora - progreso.inicio) / 1000);

      // ── Cuánto falta del TRABAJO COMPLETO ──
      //
      // Lo que había antes estimaba sobre `bytesTotales`, que son los bytes
      // encolados para subir en este momento — no el trabajo. En un
      // incremental donde casi todo se saltea daba un número minúsculo mientras
      // faltaban dos horas de recorrer 165.000 archivos, y en la primera
      // corrida crecía a medida que se descubrían archivos. Un tiempo restante
      // que se mueve para arriba no es un tiempo restante.
      //
      // Ahora se mide contra el total real: cuánto del trabajo se masticó por
      // segundo, y cuánto queda. "Masticado" incluye lo salteado, porque
      // revisar un archivo y decidir que no cambió también lleva tiempo y
      // también es avance.
      //
      // El promedio es de TODA la corrida, no de los últimos segundos. Con una
      // ventana corta un PST de 651 MB que se saltea entero en un milisegundo
      // dispara la tasa a miles de MB/s y el estimado se cae a cero; el
      // promedio largo se mueve despacio y no miente en cada archivo grande.
      const masticado = progreso.bytesRecorridos + progreso.bytesEnVuelo;
      const faltan = Math.max(0, progreso.trabajo.bytes - masticado);
      const tasa = progreso.transcurridoSeg > 0 ? masticado / progreso.transcurridoSeg : 0;

      // Tres condiciones, y las tres hacen falta:
      //   · el conteo terminó, o el total todavía está creciendo;
      //   · pasaron unos segundos, o la tasa es una foto de un instante;
      //   · se masticó algo, o no hay con qué dividir.
      progreso.restanteSeg =
        (progreso.trabajo.listo && progreso.transcurridoSeg >= 3 && tasa > 0 && faltan > 0)
          ? Math.round(faltan / tasa)
          : null;

      // El porcentaje sale del mismo lugar que el tiempo: de los bytes, no de
      // los archivos. Con 165.000 archivos chicos y un PST de 651 MB, contar
      // por archivo deja la barra en 99% durante los veinte minutos que tarda
      // el archivo grande.
      progreso.porcentaje = (progreso.trabajo.listo && progreso.trabajo.bytes > 0)
        ? Math.min(100, Math.max(0, (masticado / progreso.trabajo.bytes) * 100))
        : null;
      const { pendientes, ...paraUI } = progreso;
      this.emit("progreso", paraUI);
    };

    // ── Contar el trabajo, en paralelo con el respaldo ──────────────────────
    //
    // Por qué un segundo recorrido y no reusar el primero: el recorrido que
    // alimenta a los trabajadores tiene una reserva de 500 archivos y se frena
    // cuando se llena, así que nunca va más de 500 archivos adelante. Como
    // total no sirve para nada: siempre diría "procesados + 500".
    //
    // Este recorrido no lee ni sube nada —solo mira el tamaño de cada archivo—
    // y va por su cuenta hasta el final. Medido con 50.000 archivos y seis
    // trabajadores: el respaldo tardó 9.593 ms sin conteo y 9.476 ms con
    // conteo en paralelo (la diferencia es ruido), y el total quedó listo a los
    // 1.849 ms, o sea al 19% de la corrida. En un respaldo real, donde cada
    // archivo cuesta red y no medio milisegundo, el total está listo mucho
    // antes todavía.
    //
    // Usa el MISMO `walkDir` que el respaldo, a propósito: si el conteo
    // filtrara distinto que el motor, el total no sería el total de este
    // trabajo y el porcentaje nunca llegaría a 100 (o lo pasaría).
    let abortarConteo = false;
    const tareaConteo = (async () => {
      let archivos = 0, bytes = 0;
      try {
        for (const root of includedPaths) {
          if (this._cancelado || abortarConteo) return;
          let esArchivo = false;
          try { esArchivo = fs.statSync(root).isFile(); } catch { continue; }
          if (esArchivo) {
            if (isExcluded(root, excluded)) continue;
            try {
              const st = fs.statSync(root);
              archivos++; bytes += st.size;
            } catch { continue; }
            continue;
          }
          // ── Por qué esto va por LOTES y no archivo por archivo ──
          //
          // La primera versión reusaba `walkDir` con un `for await`, que cede
          // el control del programa una vez por CADA archivo. Aislado no se
          // nota; con seis trabajadores subiendo al mismo tiempo, cada cesión
          // espera detrás de toda la cola de trabajo pendiente. Medido con
          // 6.000 archivos: el conteo tardaba 4.703 ms de una corrida de
          // 5.335 ms — o sea que el total quedaba listo cuando el respaldo ya
          // estaba por terminar, y el cliente no veía porcentaje ni tiempo
          // restante en casi toda la corrida. Justo lo que esto viene a
          // resolver.
          //
          // Con una vuelta por carpeta y los tamaños pedidos de a 500 juntos:
          // 167 ms. Veintiocho veces más rápido, mismo trabajo.
          //
          // (Se descartó por medición que fuera el pool de hilos: subirlo a 16
          // y a 64 no cambió nada.)
          const pila = [path.resolve(root)];
          while (pila.length) {
            if (this._cancelado || abortarConteo) return;
            const dir = pila.pop();
            let entradas;
            try { entradas = await fsp.readdir(dir, { withFileTypes: true }); }
            catch { continue; }
            const aMedir = [];
            for (const e of entradas) {
              const full = path.join(dir, e.name);
              // Los MISMOS filtros que usa `walkDir`. No es una copia por
              // comodidad: si el conteo descartara distinto que el motor, el
              // total no sería el total de este trabajo y el porcentaje no
              // llegaría a 100 o se pasaría. La prueba compara el total contra
              // los archivos que el respaldo procesó de verdad.
              if (isExcluded(full, excluded)) continue;
              if (e.isSymbolicLink()) continue;
              if (e.isDirectory()) {
                if (esCarpetaDescartable(e.name)) continue;
                pila.push(full);
              } else if (e.isFile()) {
                if (esArchivoDescartable(e.name)) continue;
                aMedir.push(full);
              }
            }
            for (let i = 0; i < aMedir.length; i += 500) {
              if (this._cancelado || abortarConteo) return;
              const tandas = await Promise.all(
                aMedir.slice(i, i + 500).map((f) => fsp.stat(f).catch(() => null)));
              for (const st of tandas) { if (st) { archivos++; bytes += st.size; } }
              progreso.trabajo.archivos = archivos;
              progreso.trabajo.bytes = bytes;
              emitirProgreso();
            }
          }
        }
        if (this._cancelado || abortarConteo) return;
        progreso.trabajo.archivos = archivos;
        progreso.trabajo.bytes = bytes;
        // Recién acá el total es exacto. Antes de esto la pantalla no muestra
        // ni porcentaje ni tiempo restante.
        progreso.trabajo.listo = true;
        this.log(`[info] El trabajo son ${archivos.toLocaleString("es-AR")} archivo(s), ` +
                 `${fmtSize(bytes)} en total.`);
        emitirProgreso(true);
      } catch (e) {
        // Que no se pueda contar no puede frenar el respaldo. Se pierde el
        // porcentaje y el tiempo restante, que es exactamente lo que había
        // hasta esta versión: se sigue mostrando lo copiado y la velocidad.
        this.log(`[aviso] No se pudo calcular el total del trabajo: ` +
                 `${friendlyError(e.message)}. El respaldo sigue normalmente, ` +
                 `pero sin porcentaje ni tiempo estimado.`);
        progreso.trabajo.listo = false;
      }
    })();

    // Guardamos los primeros errores y su tipo para el informe por email
    const errorSamples = [];
    const errorKinds = {};
    const noteError = (msg) => {
      const kind = classifyError(msg);
      errorKinds[kind] = (errorKinds[kind] || 0) + 1;
      if (errorSamples.length < 20) errorSamples.push(String(msg).slice(0, 160));
    };
    let localCopied = 0;

    // Estado del respaldo por bloques, compartido por todos los trabajadores de
    // esta corrida.
    const umbralBloques = Math.max(1, Number(cfg.umbralBloquesMB) || UMBRAL_BLOQUES_MB) * 1048576;

    /**
     * ¿Este archivo se va a guardar por bloques en algún destino?
     *
     * Importa porque si va por bloques NO hay que leerlo para calcular la
     * huella: `recorrerBloques` la devuelve en su única pasada. Leerlo antes era
     * una segunda apertura de un archivo de cientos de megas —y el punto exacto
     * donde fallaba con el PST que Outlook tiene tomado—.
     *
     * El respaldo por bloques solo existe en destinos S3, así que si el archivo
     * también va a un FTP o a una carpeta local, la huella se necesita igual.
     */
    const vaPorBloques = (file) => {
      if (file.size < umbralBloques) return false;
      const destinos = (cfg.destinations || []).filter((d) => d.enabled !== false);
      const hayS3 = destinos.some((d) => d.type === "s3");
      const hayOtros = destinos.some((d) => d.type !== "s3");
      // Con destinos mixtos hace falta la huella para los que no son S3.
      return hayS3 && !hayOtros;
    };
    const catalogoBloques = new Map();    // ruta → tamaño y fecha, para el listado

    // Qué bloques ya están guardados en cada destino.
    //
    // Antes se preguntaba bloque por bloque con HEAD. Dos problemas: son 128
    // viajes de ida y vuelta para un archivo de 650 MB, y —lo grave— varios
    // servicios compatibles con S3 contestan 403 en vez de 404 cuando el objeto
    // no existe. Con esa respuesta el programa concluía que NINGÚN bloque
    // estaba, y volvía a subir el archivo entero todos los días: exactamente el
    // problema que esto venía a resolver.
    //
    // Ahora se pide la lista completa una sola vez por corrida. Es una llamada
    // en lugar de ciento veintiocho, y no depende de cómo conteste el servidor.
    // Si esta corrida además verifica, el conjunto ya viene lleno desde el
    // inventario y acá no se pide nada.

    const bloquesYaGuardados = async (dest) => {
      const clave = destKey(dest);
      if (bloquesPorDestino.has(clave)) return bloquesPorDestino.get(clave);

      const conocidos = new Set();
      bloquesPorDestino.set(clave, conocidos);
      try {
        const { archivos } = await s3Listar({ ...dest, prefix: `${dest.prefix || ""}bloques/` });
        for (const a of archivos) conocidos.add(a.clave.split("/").pop());
        this.log(`[bloques] Ya hay ${conocidos.size} bloque(s) guardados en ${nombreDestino(dest)}.`);
      } catch (e) {
        this.log(`[aviso] No se pudo leer la lista de bloques: ${friendlyError(e.message)}. ` +
                 `Se van a subir de nuevo los que hagan falta.`);
      }
      return conocidos;
    };

    // ── Varios archivos en vuelo a la vez ────────────────────────────────────
    //
    // Antes se procesaba un archivo por vez: analizar, calcular el hash,
    // subirlo, esperar la confirmación del servidor y recién ahí empezar con
    // el siguiente. Contra una carpeta local eso alcanza, pero contra un
    // servidor remoto cada archivo cuesta varios viajes de ida y vuelta, y el
    // programa se pasaba esperando en vez de transferir: con 20 ms de latencia
    // y archivos chicos, más del 90% del tiempo era espera pura. El ancho de
    // banda no tenía nada que ver — por eso no cambiaba nada tener 400 Mbps.
    //
    // Ahora hay varias transferencias simultáneas. Es lo mismo que hacen los
    // clientes FTP de escritorio cuando abren varias conexiones a la vez.
    const concurrencia = Math.max(1, Math.min(32,
      Number(cfg.concurrencia) || CONCURRENCIA_POR_DEFECTO));

    const procesarArchivo = async (file) => {
        // De dónde se LEE el archivo. Con instantánea VSS activa se lee de la
        // copia sombra, que es la única forma de leer un archivo que otro
        // programa tiene abierto: un PST con Outlook prendido, una base de Tango
        // en uso. `sourcePath` se sigue usando para la clave en el destino y para
        // el estado incremental, así que las rutas del respaldo no cambian y lo
        // ya subido no se resube.
        file.rutaLectura = Vss.rutaDeLectura(file.sourcePath, instantaneas);
        try {
          progreso.fase = "analizando";
          progreso.archivoActual = path.basename(file.sourcePath);
          progreso.procesados++;
          progreso.totalEstimado = Math.max(progreso.totalEstimado, progreso.procesados);
          emitirProgreso();
          // Incremental check — ahora consciente de destinos: un archivo
          // solo se saltea si su contenido no cambió Y ya fue subido a
          // TODOS los destinos configurados actualmente. Si agregaste o
          // sacaste un destino, esto detecta qué falta y sube solo eso,
          // sin re-subir a destinos que ya lo tienen.
          const prev = state.get(file.sourcePath);
          const prevDestKeys = (prev && prev.destKeys) || [];

          // En destinos locales y de red se verifica el disco de verdad. El
          // registro interno dice a dónde se copió cada archivo, pero si el
          // usuario borró la carpeta o cambió el pendrive, ese registro miente
          // y el archivo quedaría salteado para siempre.
          const faltanEnDisco = otherDests
            .filter((d) => (d.type === "local" || d.type === "network")
                        && !existeEnDestinoLocal(d.path, file.sourcePath, file.size))
            .map(destKey);

          // Comprobación contra el destino S3: que la clave exista Y que el
          // tamaño coincida. Un archivo cortado a la mitad por un corte de luz
          // existe, pero está incompleto, y eso es lo peor que puede pasar:
          // figura como respaldado y no sirve.
          //
          // En verificación completa se miran todos. En la rotativa, solo los
          // que hace más de `revalidarMaxDias` que nadie mira: así el costo se
          // reparte y ningún archivo queda sin comprobar para siempre.
          const seRevalida = modoVerificar || aRevalidar.has(file.sourcePath);
          const faltanEnNube = [];

          // ── Qué cuenta como "comprobado contra el destino" ──
          //
          // Los destinos locales y de red se comprueban en TODA corrida, arriba:
          // se mira el disco de verdad, que el archivo esté y con el tamaño que
          // corresponde. Eso es una verificación tan válida como la del bucket,
          // y antes no se contaba: un cliente que respalda solo a un disco
          // externo tenía la pantalla en ámbar para siempre, avisándole de algo
          // que el programa comprobaba en cada corrida.
          const hayDestinoLocal = otherDests.some(
            (d) => d.type === "local" || d.type === "network");
          let comprobadoContraDestino = hayDestinoLocal;

          if (inventarioDestino && seRevalida) {
            for (const d of otherDests.filter((x) => x.type === "s3")) {
              const inv = inventarioDestino.get(destKey(d));
              if (!inv) continue;
              comprobadoContraDestino = true;
              const clave = `${d.prefix || ""}${rutaEnDestino(file.sourcePath)}`;
              const tam = inv.get(clave);
              // Los archivos guardados por bloques no están como una sola clave:
              // se verifican por su índice. Se acepta cualquiera de las dos
              // copias, y también la ubicación vieja: un respaldo hecho antes
              // de la 0.9.9 está igual de sano y no hay que resubirlo.
              const porBloques = file.size >= umbralBloques;
              const rel = rutaEnDestino(file.sourcePath);
              const presente = porBloques
                ? Bloques.clavesIndicePosibles(d.prefix || "", rel).some((k) => inv.has(k))
                : (tam !== undefined && tam === file.size);
              if (!presente) faltanEnNube.push(destKey(d));
            }
          }

          const missingDestKeys = currentDestKeys.filter(
            (k) => !prevDestKeys.includes(k) || faltanEnDisco.includes(k) ||
                   faltanEnNube.includes(k)
          );
          if (faltanEnNube.length) {
            faltantesVerificados++;
            this.log(`[verificar] Falta en el destino: ${rutaEnDestino(file.sourcePath)}`);
          }
          const quickMatch = prev && prev.size === file.size && Math.abs(prev.mtimeMs - file.mtimeMs) < 1000;
          let hash;
          let contentUnchanged = false;

          // Cuándo se comprobó por última vez que este archivo está de verdad en
          // el destino. Es lo que hace que la revalidación rotativa avance: sin
          // esta marca, cada corrida elegiría los mismos archivos y el resto no
          // se miraría nunca.
          //
          // Solo se anota si REALMENTE se miró el destino en esta corrida. Si el
          // listado falló, la marca vieja se conserva y el archivo sigue
          // apareciendo como pendiente: es preferible revisarlo de más que
          // anotar una tranquilidad que nadie comprobó.
          const marcaVerificado = comprobadoContraDestino && faltanEnNube.length === 0
            ? Date.now()
            : (prev && prev.verificadoEn) || undefined;

          // Se cuenta ACÁ, sobre el archivo que se está procesando: los que ya
          // no existen no pasan por este punto y no ensucian la cuenta.
          if (marcaVerificado) {
            verif.comprobados++;
            const dias = Math.floor((Date.now() - Number(marcaVerificado)) / 86400000);
            if (dias > verif.peorDias) verif.peorDias = dias;
          } else {
            verif.sinComprobar++;
          }

          if (quickMatch) {
            if (missingDestKeys.length === 0) {
              if (comprobadoContraDestino) {
                state.set(file.sourcePath, { ...prev, verificadoEn: marcaVerificado });
              }
              skipped++;
              progreso.salteados = skipped;
              return;
            }
            hash = prev.hash;
            contentUnchanged = true;
          } else if (vaPorBloques(file)) {
            // ── El archivo grande NO se lee acá ──
            //
            // Esto es la corrección de fondo del EBUSY del PST. La secuencia era:
            //   1) el motor llamaba a `hashFile`, que abría el archivo y lo leía
            //      completo, SIN reintentos, solo para calcular la huella;
            //   2) después `subirPorBloques` lo abría de nuevo —esa sí con
            //      `abrirConReintentos`— y lo recorría.
            //
            // Dos aperturas de un archivo de 651 MB que Outlook tiene tomado, y
            // la primera, la que revienta, era justo la única sin protección. El
            // arreglo anterior le sacó una lectura a `bloques.cjs` reutilizando
            // esta huella, pero dejó en pie la del motor: quedó a mitad de camino.
            //
            // `recorrerBloques` ya devuelve `huellaTotal` en su única pasada, así
            // que esta lectura era puro desperdicio: minutos de disco por archivo
            // y el punto exacto donde fallaba. Se calcula abajo, cuando se sube.
            hash = null;
          } else {
            // Archivos chicos: no van por bloques, así que la huella se calcula
            // acá. `hashFile` reintenta ante bloqueos pasajeros.
            hash = await hashFile(file.rutaLectura, 120000,
              file.size >= 8 * 1048576
                ? (leidos) => marcarAvance(file.sourcePath,
                    path.basename(file.sourcePath), file.size, leidos, "leyendo")
                : null);
            if (prev && prev.hash === hash) {
              contentUnchanged = true;
              if (missingDestKeys.length === 0) {
                state.set(file.sourcePath, { hash, size: file.size, mtimeMs: file.mtimeMs, destKeys: prevDestKeys, verificadoEn: marcaVerificado });
                skipped++;
                progreso.salteados = skipped;
                return;
              }
            }
          }

          // Si el contenido no cambió, solo hace falta subir a los destinos
          // que todavía no lo tienen. Si cambió (o es la primera vez), sube
          // a todos los destinos configurados.
          const targetDestKeys = contentUnchanged ? missingDestKeys : currentDestKeys;
          const uploadToCloud = hasCloud && targetDestKeys.includes("cloud");
          const targetOtherDests = otherDests.filter((d) => targetDestKeys.includes(destKey(d)));

          const name = path.basename(file.sourcePath);
          const contentType = guessContentType(file.sourcePath);

          progreso.fase = "subiendo";
          progreso.archivoActual = name;
          progreso.pendientes.push(file.size);
          progreso.bytesTotales = progreso.bytesSubidos
            + progreso.pendientes.reduce((a, b) => a + b, 0);
          emitirProgreso(true);

          let achievedDestKeys = new Set(prevDestKeys.filter((k) => currentDestKeys.includes(k)));

          // Un archivo al que solo le movieron la fecha no es un archivo
          // subido. Contarlo como tal infla "subidos" y los bytes del resumen,
          // y el cliente ve 650 MB de actividad que nunca viajaron: eso, en un
          // producto que se paga por almacenamiento, parece un cargo.
          let soloFechaMovida = false;

          // ── Cloud upload ──
          if (uploadToCloud) {
            try {
              const { uploadURL, objectPath } = await apiReq(server, token, "POST", "/agent/uploads/request-url", {
                name, size: file.size, contentType,
              });
              await uploadFileHTTP(uploadURL, file.rutaLectura, file.size, contentType);
              await apiReq(server, token, "POST", "/agent/files", {
                sourcePath: file.sourcePath, name, size: file.size,
                contentType, objectPath, hash, jobId: job?.id,
              });
              achievedDestKeys.add("cloud");
              // Prune old versions
              if (maxVersions && maxVersions > 0) {
                pruneVersions(server, token, file.sourcePath, maxVersions).catch(() => {});
              }
            } catch (e) {
              this.log(`[error] No se pudo subir "${name}": ${friendlyError(e.message)}`);
              noteError(`${name}: ${e.message}`);
              errors++;
              progreso.errores = errors;
            }
          }

          // ── Other destinations ──
          for (const dest of targetOtherDests) {
            // Detener corta también acá: con varios destinos por archivo, sin
            // esta comprobación había que esperar a que terminaran todos.
            if (this._cancelado) break;
            try {
              if (dest.type === "local" || dest.type === "network") {
                const r = await copyToLocalDest(file.sourcePath, dest.path,
                  { rutaLectura: file.rutaLectura });
                if (r.copiado) localCopied++;
              } else if (dest.type === "s3") {
                const rel = rutaEnDestino(file.sourcePath);
                const prefijo = dest.prefix || "";

                if (file.size >= umbralBloques) {
                  // Archivo grande: se guarda por bloques. Si mañana cambian dos
                  // páginas de un PST de 650 MB, se suben esos dos bloques y no
                  // los 650 MB. El usuario nunca ve esto: sigue viendo su archivo.
                  const conocidos = await bloquesYaGuardados(dest);
                  const r = await Bloques.subirPorBloques(almacenDeBloques(dest, claveCifrado), {
                    rutaArchivo: file.rutaLectura,
                    rutaRelativa: rel,
                    prefijo,
                    yaSubidos: conocidos,
                    // Si el motor ya la calculó (archivo mixto o chico), se
                    // reutiliza. Si viene en null —el caso del archivo grande—
                    // la calcula `recorrerBloques` en su única pasada, y así el
                    // archivo se abre UNA sola vez en todo el respaldo.
                    huella: hash || undefined,
                    // La huella que quedó guardada la última vez que este
                    // archivo se respaldó. Sirve para reconocer el caso más
                    // común del producto: el archivo al que solo le movieron la
                    // fecha. Outlook se la toca al PST todos los días sin
                    // cambiar nada. Sin esto, cada corrida escribe una versión
                    // nueva del índice y le come el historial al archivo.
                    huellaPrevia: (prev && prev.hash) || null,

                    // ── El plan de corte de la vez pasada ──
                    //
                    // Se guarda aunque la subida no haya terminado, que es el
                    // caso de las imágenes grandes: 25 GB a 14,5 MB/s son ocho
                    // horas y la máquina se apaga antes. Sin esto, la corrida
                    // de mañana vuelve a leer y trocear los 13 GB para
                    // descubrir exactamente los mismos cortes — cinco minutos
                    // de disco y CPU quemados todos los días para no aprender
                    // nada.
                    planPrevio: state.get(`__plan:${file.sourcePath}`) || null,
                    alGuardarPlan: async (plan) => {
                      state.set(`__plan:${file.sourcePath}`, plan);
                      state.flush();
                    },
                    // Cuántos bloques viajan a la vez. Con la lectura frenada
                    // esperando cada pedido, un archivo de 300 MB perdía varios
                    // segundos solo preguntando si cada bloque ya estaba —y los
                    // perdía también en el respaldo incremental, donde no sube
                    // nada—. Medido con 80 ms de latencia: 3 veces más rápido.
                    // Más de 8 no gana: ahí el límite pasa a ser el procesador.
                    paralelo: Math.min(8, Math.max(1, Number(cfg.bloquesEnParalelo) || 4)),
                    // Avance real mientras parte y sube el archivo. `posicion`
                    // es cuánto se leyó del archivo, que es la única medida que
                    // avanza de forma pareja: los bloques que se reutilizan no
                    // suben nada pero sí consumen tiempo de lectura.
                    alAvanzar: (cuantos, posicion) => marcarAvance(
                      file.sourcePath, name, file.size, posicion, "bloques"),
                  });
                  // ── La huella del archivo grande ──
                  //
                  // `recorrerBloques` la calcula en su única pasada y
                  // `subirPorBloques` la devuelve, pero el motor la tiraba: en
                  // `state.json` quedaba `hash: null` para TODO archivo que va
                  // por bloques. Con el hash en null no hay con qué comparar, y
                  // un archivo al que solo le movieron la fecha era
                  // indistinguible de uno que cambió de verdad.
                  if (r.huella) hash = r.huella;

                  catalogoBloques.set(rel, {
                    bytes: file.size, mtimeMs: file.mtimeMs,
                    actualizado: new Date().toISOString(),
                    // Si el contenido no cambió, la entrada que ya está en el
                    // catálogo sirve tal cual y no hay que pisarla. Se manda
                    // igual por si el catálogo se perdió o el archivo nunca
                    // llegó a anotarse.
                    ...(r.sinCambios ? { soloSiFalta: true } : {}),
                  });

                  if (r.sinCambios) {
                    this.log(`[bloques] ${name}: la fecha cambió pero el contenido no. ` +
                             `No se sube nada ni se gasta una versión.`);
                    soloFechaMovida = true;
                    achievedDestKeys.add(destKey(dest));
                    continue;
                  }

                  // Se avisa SIEMPRE, también la primera vez. Sin esto no había
                  // forma de saber si el archivo se guardó por bloques o entero,
                  // y el ahorro era invisible hasta mirar la factura.
                  const ahorro = r.bytesTotales > 0
                    ? Math.round((1 - r.bytesSubidos / r.bytesTotales) * 100) : 0;
                  this.log(
                    `[bloques] ${name}: ${r.bloques} bloques · ` +
                    `subió ${r.nuevos} nuevos (${fmtSize(r.bytesSubidos)} de ${fmtSize(r.bytesTotales)})` +
                    (r.reutilizados ? ` · reutilizó ${r.reutilizados}, ahorro del ${ahorro}%` : ""));
                } else {
                  // ── Guarda: nada sale en claro ──
                  //
                  // Si la cuenta tiene cifrado, este camino DEBE recibir la
                  // clave. Antes no la recibía y los archivos que van enteros
                  // subían tal cual sin que nada lo dijera: el cliente veía
                  // "respaldo terminado" y sus Excel estaban en el destino
                  // legibles. Un fallo silencioso en la única propiedad que el
                  // cliente no puede comprobar por su cuenta.
                  //
                  // Se detiene en vez de subir. Subir sin cifrar sería peor que
                  // fallar, porque el cliente creería que sus archivos están
                  // protegidos y no lo estarían.
                  if (claveCifrado && !(Buffer.isBuffer(claveCifrado) && claveCifrado.length === 32)) {
                    throw new Error(
                      `"${name}" no se subió: la cuenta tiene cifrado activo pero la ` +
                      `clave no está disponible. No se sube nada sin cifrar.`);
                  }
                  const key = `${prefijo}${rel}`;
                  await s3Upload(dest, key, file.rutaLectura, file.size, hash, contentType,
                    file.size >= 8 * 1048576
                      ? ({ bytes: enviados }) => marcarAvance(
                          file.sourcePath, name, file.size, enviados, "subiendo")
                      : null,
                    // La clave de la cuenta. Sin esto, los archivos que van
                    // enteros salen en claro: es el camino de los Excel, Word y
                    // PDF, o sea la mayoría de los archivos de un estudio.
                    claveCifrado);
                }
                localCopied++;
              } else if (dest.type === "ftp") {
                const remotePath = `${dest.remotePath || ""}/${rutaEnDestino(file.sourcePath)}`;
                const sesion = await tomarSesionFtp(dest);
                try { await sesion.subir(remotePath, file.rutaLectura); }
                finally { soltarSesionFtp(dest, sesion); }
                localCopied++;
              } else if (dest.type === "sftp") {
                const remotePath = `${dest.remotePath || ""}/${rutaEnDestino(file.sourcePath)}`;
                await sftpUpload(dest, remotePath, file.rutaLectura);
                localCopied++;
              }
              achievedDestKeys.add(destKey(dest));
            } catch (de) {
              this.log(`[error] "${name}" no llegó a ${nombreDestino(dest)}: ${friendlyError(de.message)}`);
              noteError(`${name} → ${dest.label||dest.type}: ${de.message}`);
              errors++;
              progreso.errores = errors;
            }
          }

          if (achievedDestKeys.size > 0) {
            // Un archivo que se acaba de subir con éxito está comprobado por
            // definición: la subida se confirmó contra el destino.
            state.set(file.sourcePath, { hash, size: file.size, mtimeMs: file.mtimeMs,
                                         destKeys: Array.from(achievedDestKeys),
                                         verificadoEn: soloFechaMovida ? marcaVerificado : Date.now() });
            state.flush();

            // Se guarda la fecha nueva igual —eso es lo que hace que mañana el
            // chequeo rápido acierte y el archivo ni se abra— pero no se cuenta
            // como subido, porque no viajó un solo byte.
            if (soloFechaMovida) {
              skipped++;
              progreso.salteados = skipped;
              progreso.pendientes.shift();
              soltarArchivo(file.sourcePath);
              emitirProgreso(true);
              return;
            }

            uploaded++;
            bytes += file.size;
            progreso.subidos = uploaded;
            progreso.bytesSubidos = bytes;
            progreso.pendientes.shift();
            soltarArchivo(file.sourcePath);
            // La misma base que el avance parcial: total terminado + lo que
            // está en vuelo. Si acá se usara solo `bytes`, al terminar un
            // archivo grande la serie retrocedería y la velocidad daría
            // negativa por unos segundos.
            muestras.push({ t: Date.now(), b: bytes + progreso.bytesEnVuelo });
            emitirProgreso(true);
            const kb = (file.size / 1024).toFixed(1);
            this.log(`[subido] ${name} · ${fmtSize(file.size)}`);
          }
        } catch (err) {
          // Un archivo que desapareció MIENTRAS corría el respaldo no es una
          // falla del respaldo: es un temporal que el sistema borró solo, o algo
          // que el usuario movió. Contarlo como error rojo hacía que la pantalla
          // dijera "fallaron 1 archivo(s)" en cada corrida, siempre por lo mismo,
          // y el cliente terminaba ignorando todos los avisos —incluidos los que
          // sí importan.
          //
          // Y se muestra la RUTA COMPLETA. Con solo el nombre, "app.asar" no le
          // dice nada a nadie: hay decenas en un equipo y el cliente no puede
          // saber cuál es ni si le importa.
          const desaparecido = classifyError(err.message) === "missing";
          if (desaparecido) {
            skipped++;
            this.log(`[aviso] Se salteó "${file.sourcePath}": ` +
                     `${friendlyError(err.message)}. Si es un archivo temporal, es normal.`);
          } else {
            errors++;
            this.log(`[error] No se pudo leer "${file.sourcePath}" (en tu equipo): ` +
                     `${friendlyError(err.message)}`);
          }
        } finally {
          // Pase lo que pase —salteado, error o cancelación— el archivo deja de
          // estar en vuelo. Sin esto un archivo que falla a mitad de camino
          // queda contado para siempre en `bytesEnVuelo`, y la barra muestra
          // más de lo que realmente se copió.
          //
          // Y por lo mismo el avance del trabajo se cuenta ACÁ y no en el
          // camino feliz: un archivo bloqueado o con error igual se revisó, y
          // si no se contara, el porcentaje no llegaría nunca a 100 y el tiempo
          // restante se quedaría clavado en un resto que ya nadie va a tocar.
          progreso.bytesRecorridos += file.size || 0;
          soltarArchivo(file.sourcePath);
        }
    };

    const motor = this;
    async function* recorrerTodo() {
      for (const root of includedPaths) {
        if (motor._cancelado) return;
        if (!fs.existsSync(root)) {
          motor.log(`[aviso] No se encontró la carpeta: ${root}. ¿Se movió o es un disco desconectado?`);
          continue;
        }
        // Un origen puede ser un ARCHIVO suelto, no solo una carpeta. Es lo que
        // pasa cuando alguien elige respaldar únicamente su PST o el certificado
        // de AFIP: `walkDir` da por sentado que recibe una carpeta y con un
        // archivo no devolvía nada, así que el archivo elegido simplemente no se
        // respaldaba y no había ningún aviso.
        let esArchivo = false;
        try { esArchivo = fs.statSync(root).isFile(); } catch {}

        if (esArchivo) {
          if (isExcluded(root, excluded)) {
            motor.log(`[aviso] ${path.basename(root)} está en la lista de exclusiones, así que se saltea.`);
            continue;
          }
          motor.log(`[buscando] Revisando ${path.basename(root)}…`);
          try {
            const st = fs.statSync(root);
            yield { sourcePath: root, size: st.size, mtimeMs: st.mtimeMs };
          } catch (e) {
            motor.log(`[error] No se pudo leer "${path.basename(root)}": ${friendlyError(e.message)}`);
          }
          continue;
        }

        motor.log(`[buscando] Revisando ${root}…`);
        for await (const file of walkDir(root, excluded, () => motor._cancelado)) {
          if (motor._cancelado) return;
          yield file;
        }
      }
    }

    // ── Cola con reserva ────────────────────────────────────────────────────
    //
    // Antes los trabajadores tiraban directo del recorrido de carpetas. El
    // problema: los generadores asíncronos serializan las llamadas, así que si
    // el recorrido se traba en un archivo o carpeta que el antivirus está
    // revisando, TODOS los trabajadores se quedan esperando y el respaldo
    // parece congelado en un archivo — que es exactamente lo que se veía.
    //
    // Ahora el recorrido va por su cuenta llenando una reserva, y los
    // trabajadores comen de ahí. Un archivo trabado frena solo al que lo tocó.
    const RESERVA = 500;
    const reserva = [];
    let recorridoTerminado = false;
    let avisarHayAlgo = null;

    const productor = (async () => {
      try {
        for await (const file of recorrerTodo()) {
          if (revisarConGuardia(guardia, file, this)) break;
          reserva.push(file);
          if (avisarHayAlgo) { const f = avisarHayAlgo; avisarHayAlgo = null; f(); }
          // Si la reserva está llena se espera: no tiene sentido acumular
          // cientos de miles de archivos en memoria.
          while (reserva.length >= RESERVA && !this._cancelado) {
            await new Promise((r) => setTimeout(r, 25));
          }
          if (this._cancelado) break;
        }
      } catch (e) {
        this.log(`[error] Falló el recorrido de carpetas: ${friendlyError(e.message)}`);
      } finally {
        recorridoTerminado = true;
        if (avisarHayAlgo) { const f = avisarHayAlgo; avisarHayAlgo = null; f(); }
      }
    })();

    const siguienteArchivo = async () => {
      for (;;) {
        if (reserva.length) return reserva.shift();
        if (recorridoTerminado) return null;
        await new Promise((r) => { avisarHayAlgo = r; setTimeout(r, 100); });
      }
    };

    const trabajador = async () => {
      for (;;) {
        if (this._cancelado) return;
        const file = await siguienteArchivo();
        if (!file) return;
        await procesarArchivo(file);
      }
    };

    this.log(`[info] Transfiriendo hasta ${concurrencia} archivos a la vez.`);
    await Promise.all([productor, ...Array.from({ length: concurrencia }, () => trabajador())]);

    if (this._cancelado) this.log("[stop] Respaldo interrumpido a pedido del usuario.");

    // Finish cloud job
    if (hasCloud && job) {
      // Los estados deben coincidir con los que espera el servidor:
      // "completed" | "completed_with_errors" | "failed"
      const status = errors > 0 && uploaded === 0
        ? "failed"
        : errors > 0 ? "completed_with_errors" : "completed";

      // Motivo predominante del fallo, para el informe al cliente
      const errorKind = Object.keys(errorKinds).length
        ? Object.entries(errorKinds).sort((a, b) => b[1] - a[1])[0][0]
        : undefined;

      try {
        await apiReq(server, token, "POST", `/agent/jobs/${job.id}/finish`, {
          status,
          filesCount: uploaded,
          bytesCount: bytes,
          errorsCount: errors,
          skippedCount: skipped,
          errorKind,
          errorSample: errorSamples.length ? errorSamples : undefined,
        });
      } catch (e) {
        this.log(`[aviso] No se pudo informar el cierre al servidor: ${friendlyError(e.message)}`);
      }
    }

    const mb = (bytes / 1024 / 1024).toFixed(2);
    const destSummary = [
      hasCloud ? "☁ Cloud" : "",
      ...otherDests.map(d => d.label || d.type),
    ].filter(Boolean).join(", ");
    this.log(`[fin] Respaldo terminado — ${uploaded} archivo(s) nuevos o modificados (${mb} MB), ${skipped} sin cambios${errors ? `, ${errors} con problemas` : ""}. Destino: ${destSummary || "ninguno"}`);
    // ── Catálogo de los archivos guardados por bloques ──────────────────────
    //
    // El listado del bucket muestra bloques e índices, no archivos. Para que la
    // pantalla de restaurar muestre "Outlook.pst" y no un montón de pedazos, se
    // publica un catálogo con los archivos lógicos y su tamaño.
    //
    // Vive en el destino, no en esta computadora: un cliente que reinstala
    // Windows tiene que poder ver su respaldo igual.
    if (catalogoBloques.size) {
      for (const dest of otherDests.filter((d) => d.type === "s3")) {
        try {
          const almacen = almacenDeBloques(dest, claveCifrado);
          const clave = `${dest.prefix || ""}indices/_catalogo.json`;
          let previo = {};
          try { previo = JSON.parse(await almacen.bajarTexto(clave)); } catch { previo = {}; }
          const antes = JSON.stringify(previo);
          for (const [rel, datos] of catalogoBloques) {
            // El archivo cuyo contenido no cambió no pisa lo que ya está: solo
            // se anota si falta. Pisarlo para refrescar la fecha haría que el
            // catálogo cambie en cada corrida sin que cambie nada, y con
            // versionado en el destino eso es una versión nueva por corrida.
            const { soloSiFalta, ...entrada } = datos;
            if (soloSiFalta && previo[rel]) continue;
            const p = previo[rel];
            if (p && p.bytes === entrada.bytes && p.mtimeMs === entrada.mtimeMs) continue;
            previo[rel] = entrada;
          }
          // ── Qué sigue cubriendo el trabajo de hoy ────────────────────────
          //
          // Lo que se sacó del respaldo NO se borra ni se mueve: se marca. Así
          // en Restaurar el cliente distingue lo que se sigue respaldando de lo
          // que quedó congelado, en vez de ver todo igual y creer que una
          // carpeta está protegida cuando hace meses que no se toca.
          const marcado = Cobertura.marcarCatalogo(previo, {
            // includedPaths y no localPaths: es lo que REALMENTE se respalda,
            // ya resuelto el respaldo de sistema y la política del servidor.
            // Con localPaths, un equipo con política del servidor marcaría todo
            // como fuera del respaldo.
            carpetas: (includedPaths || []).map(rutaEnDestino),
            excluidas: (excluded || []).map(rutaEnDestino),
          });
          previo = marcado.catalogo;
          this._cobertura = marcado.resumen;

          const aviso = Cobertura.explicarResumen(marcado.resumen, fmtSize);
          if (aviso) this.log(`[aviso] ${aviso}`);

          const texto = JSON.stringify(previo);

          // Si el catálogo quedó igual, no se reescribe. Con versionado en el
          // destino, subirlo por costumbre crea una versión nueva en cada
          // corrida: en un equipo que respalda cada hora son miles de versiones
          // de un archivo que nadie cambió, y ese historial se paga.
          if (texto !== antes) await almacen.subirTexto(clave, texto);
        } catch (e) {
          this.log(`[aviso] No se pudo actualizar el catálogo de archivos grandes: ${friendlyError(e.message)}`);
        }
      }
    }

    // Cerramos las conexiones FTP que quedaron abiertas durante la corrida
    for (const g of poolFtp.values()) {
      for (const sesion of g.todas) {
        await sesion.cerrar().catch(() => {});
      }
    }
    poolFtp.clear();

    // Última escritura del registro de estado, ahora sí a disco sí o sí.
    // Cuándo terminó este respaldo. Es lo que permite que al abrir el programa
    // se respete el horario en lugar de respaldar siempre.
    //
    // Solo se anota si el respaldo TERMINÓ. Un respaldo interrumpido —el usuario
    // apretó Detener, se cerró el programa, se cortó la luz— no dejó los archivos
    // a salvo, así que no puede contar como "al día": si contara, al volver a
    // abrir el programa se esperaría al próximo horario y el cliente quedaría sin
    // respaldo justo después de una corrida que no llegó a completarse.
    if (!this._cancelado) state.set("__ultimoRespaldo", Date.now());

    // La fecha de la última verificación COMPLETA. Solo se anota si la corrida
    // terminó y el inventario del destino se pudo leer: si el listado falló, no
    // se verificó nada, y anotarlo haría que la próxima recién sea en una
    // semana. Un cliente que se queda sin verificar durante semanas por un
    // error de red que nadie vio es exactamente el escenario a evitar.
    if (modoVerificar && !this._cancelado && inventarioDestino) {
      state.set("__ultimaVerificacion", Date.now());
    }

    // El primer respaldo cuenta como verificación, y no es una concesión: cada
    // archivo se acaba de escribir en el destino y la subida se confirmó una
    // por una. Sin esto, la corrida siguiente saldría a verificar todo de nuevo
    // al día siguiente de haber subido, que es gastar tiempo del cliente para
    // volver a comprobar lo que se comprobó ayer.
    //
    // Solo si no hubo errores: si algún archivo falló, no está todo, y decir
    // que sí sería la mentira que este producto no se puede permitir.
    if (isFirstRun && !this._cancelado && errors === 0 && uploaded > 0) {
      state.set("__ultimaVerificacion", Date.now());
    }
    state.flush(true);

    // El conteo casi siempre termina mucho antes que el respaldo, pero si la
    // corrida se cortó —cancelada, o un error temprano— puede seguir vivo. Se
    // corta y se espera: un recorrido colgado de la corrida anterior le pelea
    // el disco a la siguiente y nadie sabría por qué.
    abortarConteo = true;
    await tareaConteo.catch(() => {});

    progreso.fase = "terminado";
    progreso.archivoActual = "";
    emitirProgreso("final");

    if (modoVerificar) {
      if (!inventarioDestino) {
        this.log(`[aviso] No se pudo leer el destino, así que NO se verificó nada. ` +
                 `Se vuelve a intentar en el próximo respaldo.`);
      } else {
        this.log(faltantesVerificados === 0
          ? `[verificar] Todo en orden: los ${skipped + uploaded} archivo(s) del registro están en el destino.`
          : `[verificar] Faltaban ${faltantesVerificados} archivo(s) en el destino y se subieron. ` +
            `El resto ya estaba y no se volvió a subir.`);
      }
    } else if (revalidarRotativo && inventarioDestino) {
      this.log(faltantesVerificados === 0
        ? `[verificar] Se comprobaron contra el destino ${vencidos.length} archivo(s) ` +
          `que hacía más de ${revalidarMaxDias} días que no se revisaban. Están todos.`
        : `[verificar] De los ${vencidos.length} archivo(s) revisados, faltaban ` +
          `${faltantesVerificados} en el destino y se subieron.`);
    }

    this.emit("done", {
      uploaded, skipped, errors, bytes, backupMode, faltantesVerificados,
      verificacion: {
        modo: modoVerificar ? (verificacionProgramada ? "programada" : "manual")
              : (revalidarRotativo ? "rotativa" : "ninguna"),
        ultima: Number(state.get("__ultimaVerificacion")) || null,
        revisados: modoVerificar ? (skipped + uploaded) : vencidos.length,
        faltantes: faltantesVerificados,
        // Cuántos archivos de ESTA corrida quedaron sin comprobar contra el
        // destino, y cuánto hace que no se mira el más viejo de los que sí.
        sinComprobar: verif.sinComprobar,
        comprobados: verif.comprobados,
        diasSinVerificarElPeor: verif.comprobados > 0 ? verif.peorDias : null,
        proximaProgramada: (Number(state.get("__ultimaVerificacion")) || 0) + cadaDias * DIAS,
      },
    });
    } finally {
      Vss.liberar(instantaneas, (m, tipo) => this.log(`[${tipo || "info"}] ${m}`));
    }
  }
}

/**
 * Decide si el guardia acaba de disparar y, en ese caso, frena el respaldo.
 *
 * Vive afuera del bucle para poder probarse de verdad. La versión anterior de
 * esta lógica estaba escrita adentro del `for await`, y la prueba solo podía
 * leer el código y buscar la llamada — con eso, envolver la condición en un
 * `if (false && ...)` dejaba el guardia desenchufado y la prueba seguía en
 * verde. Una prueba que no puede fallar no prueba nada.
 *
 * @returns {boolean} true si hay que cortar el recorrido
 */
function revisarConGuardia(guardia, archivo, motor) {
  if (!guardia || !guardia.ver(archivo)) return false;

  motor._ransomware = guardia.informe();
  motor._cancelado = true;
  motor.log("[ALERTA] Se frenó el respaldo: parece un cifrado masivo.");
  for (const m of motor._ransomware.motivos) motor.log(`[ALERTA] ${m}`);
  motor.emit("ransomware", motor._ransomware);
  return true;
}

module.exports = { BackupEngine, probarDestino, getConfigDir, destKey, SesionFtp,
                   revisarConGuardia,
                   // Se exportan para probar los mensajes que ve el cliente:
                   // un texto confuso en la pantalla de Actividad es un problema
                   // de producto, no un detalle interno.
                   friendlyError, classifyError,
                   copyToLocalDest, rutaEnDestinoLocal, existeEnDestinoLocal,
                   s3Listar, s3Versiones, s3Descargar, sftpListar, sftpDescargar, sftpDescargarVarios,
                   s3Existe, s3SubirDatos, s3BajarDatos, s3Metadatos, s3Borrar,
                   almacenDeBloques, rutaEnDestino,
                   // Se exportan para poder probarlos: la firma y el manejo de
                   // archivos bloqueados son justamente lo que se rompió sin
                   // que ninguna prueba lo notara.
                   hashFile, s3Firmar, s3EncodeQuery, ordenarQuery, hostFirmable };
