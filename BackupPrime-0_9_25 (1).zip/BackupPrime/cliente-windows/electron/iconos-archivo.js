/* ═══════════════════════════════════════════════════════════════════════════
   Íconos por tipo de archivo.

   Para qué: al restaurar, una lista donde todos los archivos tienen el mismo
   ícono obliga a leer cada nombre. Con un ícono por tipo, encontrar "el Excel
   del balance" entre mil archivos pasa a ser un vistazo.

   Decisiones:

   · Son SVG dibujados acá, no imágenes descargadas ni una librería de íconos. El
     programa tiene que funcionar sin conexión y sin agregar peso al instalador,
     y el portal no debería pedirle nada a un servidor de terceros para mostrar
     una lista.

   · El mismo archivo lo usan el programa de escritorio y la web. Si cada uno
     tuviera su propia tabla, con el tiempo un .pst se vería distinto en cada
     lado y habría que arreglar el mismo detalle dos veces.

   · Los colores salen de las variables del tema, con un color propio por familia
     de archivo: los colores son la mitad del reconocimiento —el verde del Excel,
     el azul del Word— y en una lista larga se ven antes que la forma.

   Uso:
     iconoDeArchivo('balance.xlsx')      → el SVG como texto
     iconoDeArchivo('Documentos', true)  → el ícono de carpeta
     tipoDeArchivo('correo.pst')         → 'correo', para agrupar o filtrar
   ═══════════════════════════════════════════════════════════════════════════ */

(function (raiz) {
  'use strict';

  // Familia → color y extensiones. El orden no importa: se busca por extensión.
  const FAMILIAS = {
    documento:   { color: '#2b579a', ext: ['doc', 'docx', 'docm', 'dot', 'dotx', 'odt', 'rtf', 'pages', 'wpd'] },
    planilla:    { color: '#217346', ext: ['xls', 'xlsx', 'xlsm', 'xlsb', 'xlt', 'xltx', 'ods', 'csv', 'tsv', 'numbers'] },
    presentacion:{ color: '#d24726', ext: ['ppt', 'pptx', 'pptm', 'pot', 'potx', 'odp', 'key'] },
    pdf:         { color: '#c0392b', ext: ['pdf'] },
    imagen:      { color: '#8e44ad', ext: ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'tif', 'tiff', 'webp', 'heic', 'svg', 'ico', 'raw', 'cr2', 'nef'] },
    video:       { color: '#c2185b', ext: ['mp4', 'avi', 'mkv', 'mov', 'wmv', 'flv', 'webm', 'mpg', 'mpeg', 'm4v', '3gp'] },
    audio:       { color: '#00838f', ext: ['mp3', 'wav', 'flac', 'aac', 'ogg', 'wma', 'm4a', 'opus'] },
    comprimido:  { color: '#b8860b', ext: ['zip', 'rar', '7z', 'tar', 'gz', 'bz2', 'xz', 'cab', 'iso'] },
    // Los que más importan en un estudio contable: el correo, la base del
    // sistema de gestión y los certificados de facturación electrónica.
    correo:      { color: '#0072c6', ext: ['pst', 'ost', 'msg', 'eml', 'mbox', 'dbx', 'nst'] },
    base:        { color: '#5b2c6f', ext: ['mdb', 'accdb', 'db', 'sqlite', 'sqlite3', 'sql', 'dbf', 'mdf', 'ldf', 'bak', 'qbw', 'qbb'] },
    certificado: { color: '#1e8449', ext: ['pfx', 'p12', 'cer', 'crt', 'pem', 'key', 'kdbx', 'jks'] },
    codigo:      { color: '#37474f', ext: ['js', 'ts', 'py', 'java', 'c', 'cpp', 'cs', 'php', 'rb', 'go', 'rs', 'html', 'css', 'json', 'xml', 'yml', 'yaml', 'sh', 'bat', 'ps1', 'sql'] },
    texto:       { color: '#546e7a', ext: ['txt', 'md', 'log', 'ini', 'cfg', 'conf', 'nfo'] },
    fuente:      { color: '#6d4c41', ext: ['ttf', 'otf', 'woff', 'woff2', 'eot'] },
    plano:       { color: '#00695c', ext: ['dwg', 'dxf', 'skp', 'stl', 'step', 'stp', 'iges'] },
    ejecutable:  { color: '#78909c', ext: ['exe', 'msi', 'dll', 'apk', 'dmg', 'deb', 'rpm', 'appimage'] },
  };

  // Índice extensión → familia, armado una sola vez.
  const POREXT = {};
  for (const [familia, datos] of Object.entries(FAMILIAS)) {
    for (const e of datos.ext) POREXT[e] = familia;
  }

  /** La familia de un archivo por su nombre. 'otro' si no se reconoce. */
  function tipoDeArchivo(nombre) {
    const limpio = String(nombre || '').trim();
    // Los archivos temporales de Outlook son "~correo.pst.tmp": interesa el .pst
    // que está en el medio, no el .tmp.
    const sinTmp = limpio.replace(/\.(tmp|temp|part|crdownload)$/i, '');
    const punto = sinTmp.lastIndexOf('.');
    if (punto <= 0) return 'otro';
    const ext = sinTmp.slice(punto + 1).toLowerCase();
    return POREXT[ext] || 'otro';
  }

  const COLOR_OTRO = '#90a4ae';
  const COLOR_CARPETA = '#f5a623';

  /** El color de la familia, para usarlo en otro lado (una etiqueta, un filtro). */
  function colorDeArchivo(nombre) {
    const f = tipoDeArchivo(nombre);
    return f === 'otro' ? COLOR_OTRO : FAMILIAS[f].color;
  }

  // El contorno de hoja con la esquina doblada, común a todos los archivos.
  // Se dibuja una sola vez y cada familia le agrega su marca adentro.
  const HOJA =
    '<path d="M4 1.5h6.5L14 5v9.5a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-12a1 1 0 0 1 1-1z" ' +
    'fill="currentColor" opacity=".14"/>' +
    '<path d="M4 1.5h6.5L14 5v9.5a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-12a1 1 0 0 1 1-1z" ' +
    'fill="none" stroke="currentColor" stroke-width="1.1"/>' +
    '<path d="M10.5 1.5V5H14" fill="none" stroke="currentColor" stroke-width="1.1" ' +
    'stroke-linejoin="round"/>';

  // La marca de cada familia. Se busca que se distingan por SILUETA y no solo por
  // color: en una lista larga, y para quien no distingue bien los colores, la
  // forma es lo que realmente diferencia.
  const MARCAS = {
    // Las familias de Office se reconocen por su LETRA y su color, que es el
    // lenguaje visual que todo el mundo ya tiene aprendido. No se copian los
    // logos de Microsoft: son marcas registradas y reproducirlas dentro de un
    // producto que se vende es un problema legal, no un detalle. Es lo mismo que
    // hacen Dropbox y Google Drive con los archivos de Office.
    documento:    '<rect x="4.4" y="8.2" width="7.2" height="5.6" rx="1" fill="currentColor"/>' +
                  '<text x="8" y="12.6" font-family="system-ui,Segoe UI,sans-serif" font-size="4.8" ' +
                  'font-weight="700" text-anchor="middle" fill="#fff">W</text>',
    planilla:     '<rect x="4.4" y="8.2" width="7.2" height="5.6" rx="1" fill="currentColor"/>' +
                  '<text x="8" y="12.6" font-family="system-ui,Segoe UI,sans-serif" font-size="4.8" ' +
                  'font-weight="700" text-anchor="middle" fill="#fff">X</text>',
    presentacion: '<rect x="4.4" y="8.2" width="7.2" height="5.6" rx="1" fill="currentColor"/>' +
                  '<text x="8" y="12.6" font-family="system-ui,Segoe UI,sans-serif" font-size="4.8" ' +
                  'font-weight="700" text-anchor="middle" fill="#fff">P</text>',
    pdf:          '<rect x="3.6" y="8.2" width="8.8" height="5.6" rx="1" fill="currentColor"/>' +
                  '<text x="8" y="12.5" font-family="system-ui,Segoe UI,sans-serif" font-size="3.9" ' +
                  'font-weight="700" text-anchor="middle" fill="#fff">PDF</text>',
    imagen:       '<circle cx="6.4" cy="8.4" r="1" fill="currentColor"/>' +
                  '<path d="M5 12l2-2.2L8.6 11l1.4-1.6L11.5 12z" fill="currentColor"/>',
    video:        '<path d="M6.4 7.6l4.2 2.4-4.2 2.4z" fill="currentColor"/>',
    audio:        '<path d="M6 12V8l4-1v4" fill="none" stroke="currentColor" stroke-width="1.1" stroke-linecap="round"/>' +
                  '<circle cx="5.4" cy="12.1" r="1.1" fill="currentColor"/>' +
                  '<circle cx="9.4" cy="11.1" r="1.1" fill="currentColor"/>',
    comprimido:   '<path d="M8 6.5v1M8 8.5v1M8 10.5v1" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/>' +
                  '<rect x="7" y="11.6" width="2" height="2.2" rx=".5" fill="currentColor"/>',
    // El sobre del correo: es lo que la gente asocia con un archivo de mail.
    correo:       '<rect x="4.3" y="8.1" width="7.4" height="5.2" rx=".8" fill="currentColor"/>' +
                  '<path d="M4.6 8.6L8 11.1l3.4-2.5" fill="none" stroke="#fff" stroke-width="1" ' +
                  'stroke-linecap="round" stroke-linejoin="round"/>',
    base:         '<ellipse cx="8" cy="8.4" rx="3.1" ry="1.25" fill="currentColor"/>' +
                  '<path d="M4.9 8.4v3.9c0 .69 1.39 1.25 3.1 1.25s3.1-.56 3.1-1.25V8.4" fill="currentColor"/>' +
                  '<path d="M4.9 10.4c0 .69 1.39 1.25 3.1 1.25s3.1-.56 3.1-1.25" fill="none" ' +
                  'stroke="#fff" stroke-width=".8" opacity=".7"/>',
    // Un escudo: el certificado es lo que protege, y se lee al instante.
    certificado:  '<path d="M8 6.9l3 1.1v2.6c0 1.7-1.2 3-3 3.5-1.8-.5-3-1.8-3-3.5V8z" fill="currentColor"/>' +
                  '<path d="M6.7 10.3l.9.9 1.8-1.8" fill="none" stroke="#fff" stroke-width="1" ' +
                  'stroke-linecap="round" stroke-linejoin="round"/>',
    codigo:       '<path d="M6.4 8.2L4.9 9.9l1.5 1.7M9.6 8.2l1.5 1.7-1.5 1.7" fill="none" ' +
                  'stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>',
    texto:        '<path d="M5.5 8h5M5.5 10h5M5.5 12h2.5" stroke="currentColor" stroke-width="1.1" stroke-linecap="round"/>',
    fuente:       '<text x="8" y="12.8" font-family="Georgia,serif" font-size="6.6" ' +
                  'font-weight="700" text-anchor="middle" fill="currentColor">A</text>',
    plano:        '<path d="M4.6 12.4l2.2-3.4 1.6 2.2 1-1.3 2 2.5z" fill="none" stroke="currentColor" ' +
                  'stroke-width="1.05" stroke-linejoin="round"/>',
    ejecutable:   '<rect x="5.4" y="7.6" width="5.2" height="4.6" rx=".6" fill="none" stroke="currentColor" stroke-width="1.05"/>' +
                  '<path d="M7 7.6V6.6M9 7.6V6.6M7 12.2v1M9 12.2v1" stroke="currentColor" stroke-width="1.05" stroke-linecap="round"/>',
    otro:         '',
  };

  const CARPETA =
    '<path d="M2 4.2a1 1 0 0 1 1-1h3.4l1.2 1.4H13a1 1 0 0 1 1 1v7.2a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1z" ' +
    'fill="currentColor" opacity=".2"/>' +
    '<path d="M2 4.2a1 1 0 0 1 1-1h3.4l1.2 1.4H13a1 1 0 0 1 1 1v7.2a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1z" ' +
    'fill="none" stroke="currentColor" stroke-width="1.1" stroke-linejoin="round"/>';

  /**
   * Devuelve el SVG del ícono como texto, listo para insertar.
   *
   * `esCarpeta` va aparte del nombre porque una carpeta puede llamarse
   * "Balance.xlsx" —pasa— y no por eso es una planilla.
   */
  function iconoDeArchivo(nombre, esCarpeta) {
    const familia = esCarpeta ? 'carpeta' : tipoDeArchivo(nombre);
    const color = esCarpeta ? COLOR_CARPETA
                : familia === 'otro' ? COLOR_OTRO
                : FAMILIAS[familia].color;
    const cuerpo = esCarpeta ? CARPETA : HOJA + (MARCAS[familia] || '');

    // `aria-hidden` porque el nombre del archivo está al lado: un lector de
    // pantalla que además leyera "imagen" en cada fila sería ruido.
    return '<svg class="ficono" viewBox="0 0 16 16" width="15" height="15" ' +
           'aria-hidden="true" focusable="false" ' +
           'style="color:' + color + ';flex:none;vertical-align:-2px;">' + cuerpo + '</svg>';
  }

  const api = { iconoDeArchivo, tipoDeArchivo, colorDeArchivo, FAMILIAS };

  // Sirve igual en el navegador (agente y portal) y en Node (las pruebas).
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else raiz.IconosArchivo = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
