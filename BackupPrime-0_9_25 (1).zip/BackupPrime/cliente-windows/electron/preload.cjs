"use strict";
const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("backupprime", {
  // Agent control
  start:          () => ipcRenderer.invoke("agent:start"),
  stop:           () => ipcRenderer.invoke("agent:stop"),
  status:         () => ipcRenderer.invoke("agent:status"),
  logs:           () => ipcRenderer.invoke("agent:logs"),
  runNow:         () => ipcRenderer.invoke("agent:run-now"),
  runNowFull:     () => ipcRenderer.invoke("agent:run-now-full"),
  // Comprueba contra el destino y sube solo lo que falta. No duplica nada.
  verificar:      () => ipcRenderer.invoke("agent:verificar"),
  agentLogin:     (opts) => ipcRenderer.invoke("agent:login", opts),
  probarDestino:  (dest) => ipcRenderer.invoke("dest:probar", dest),
  onRestoreContando: (cb) => {
    const h = (_e, p) => cb(p);
    ipcRenderer.on("restore:contando", h);
    return () => ipcRenderer.removeListener("restore:contando", h);
  },
  onRestoreProgreso: (cb) => {
    const h = (_e, p) => cb(p);
    ipcRenderer.on("restore:progreso", h);
    return () => ipcRenderer.removeListener("restore:progreso", h);
  },
  onProgreso:     (cb) => {
    const h = (_e, p) => cb(p);
    ipcRenderer.on("agent:progreso", h);
    return () => ipcRenderer.removeListener("agent:progreso", h);
  },
  getAutoStart:   ()      => ipcRenderer.invoke("config:get-autostart"),

  // Consumo del plan. `consultarCuota` vuelve a medir contra el destino;
  // `ultimaCuota` devuelve lo último que se supo, sin ir a la red.
  consultarCuota: ()      => ipcRenderer.invoke("cuota:consultar"),
  ultimaCuota:    ()      => ipcRenderer.invoke("cuota:ultima"),
  onCuota:        (fn)    => ipcRenderer.on("cuota", (_e, d) => fn(d)),

  // Estado de la verificación del respaldo contra el destino.
  ultimaVerificacion: ()  => ipcRenderer.invoke("verificacion:ultima"),
  onVerificacion: (fn)    => ipcRenderer.on("verificacion", (_e, d) => fn(d)),
  setAutoStart:   (v)     => ipcRenderer.invoke("config:set-autostart", v),

  // Config
  readConfig:       ()             => ipcRenderer.invoke("config:read"),
  saveCredentials:  (token, srv)   => ipcRenderer.invoke("config:save-credentials", { token, server: srv }),
  setSchedule:      (s)            => ipcRenderer.invoke("config:set-schedule", s),
  setMaxVersions:   (n)            => ipcRenderer.invoke("config:set-max-versions", n),
  setCifrado:       (modo, frase)  => ipcRenderer.invoke("config:set-cifrado", { modo, frase }),
  getCifrado:       ()             => ipcRenderer.invoke("config:get-cifrado"),

  // Medición de UNA carpeta del perfil, con avance mientras cuenta.
  medirCarpeta:     (ruta)         => ipcRenderer.invoke("fs:medir-carpeta", ruta),
  onMedidaParcial:  (fn)           => ipcRenderer.on("fs:medida-parcial", (_e, d) => fn(d)),
  setConcurrencia:  (n)            => ipcRenderer.invoke("config:set-concurrencia", n),
  setAvisos:        (o)            => ipcRenderer.invoke("config:set-avisos", o),
  setUmbralBloques: (n)            => ipcRenderer.invoke("config:set-umbral-bloques", n),
  setLang:          (lang)         => ipcRenderer.invoke("config:set-lang", lang),
  setSystemBackup:  (enabled)      => ipcRenderer.invoke("config:set-system-backup", enabled),

  pickFolders:      ()             => ipcRenderer.invoke("config:pick-folders"),
  pickFolder:       ()             => ipcRenderer.invoke("config:pick-folder"),
  setPaths:         (paths)        => ipcRenderer.invoke("config:set-paths", paths),
  setExcludes:      (paths)        => ipcRenderer.invoke("config:set-excludes", paths),
  setDestinations:  (dests)        => ipcRenderer.invoke("config:set-destinations", dests),

  // Filesystem browsing
  listDir:          (p)            => ipcRenderer.invoke("fs:list-dir", p),
  accesosRapidos:   ()             => ipcRenderer.invoke("fs:accesos-rapidos"),
  medirRutas:       (rutas)        => ipcRenderer.invoke("fs:medir", rutas),
  systemDrives:     ()             => ipcRenderer.invoke("fs:system-drives"),
  userProfilePaths: ()             => ipcRenderer.invoke("fs:user-profile-paths"),

  // Restore
  restoreListFiles: (search, page)           => ipcRenderer.invoke("restore:list-files", { search, page }),
  restorePickFolder:()                       => ipcRenderer.invoke("restore:pick-folder"),
  restoreFile:      (fileId, versionId, dir) => ipcRenderer.invoke("restore:file", { fileId, versionId, destFolder: dir }),
  restoreFromLocal: (srcPath, destDir, base) => ipcRenderer.invoke("restore:from-local", { sourcePath: srcPath, destFolder: destDir, destBasePath: base }),

  // Restore desde destinos locales / de red
  restoreLocalDestinations: ()                       => ipcRenderer.invoke("restore:list-local-destinations"),
  restoreLocalFiles:        (destBasePath, search)   => ipcRenderer.invoke("restore:list-local-files", { destBasePath, search }),
  restoreLocalFolders:      (destBasePath, subPath)  => ipcRenderer.invoke("restore:list-local-folders", { destBasePath, subPath }),
  restoreLocalRun:          (opts)                   => ipcRenderer.invoke("restore:from-local-advanced", opts),
  restoreLocalTree:         (destBasePath, search)   => ipcRenderer.invoke("restore:local-tree", { destBasePath, search }),
  restoreLocalSelection:    (opts)                   => ipcRenderer.invoke("restore:local-selection", opts),
  restoreRemotoTree:        (id, tipo, search)       => ipcRenderer.invoke("restore:remoto-tree", { id, tipo, search }),
  // La misma papelera que se ve en el portal: vive en el servidor.
  papeleraListar:           ()                       => ipcRenderer.invoke("papelera:listar"),
  papeleraMandar:           (archivos, carpeta)      => ipcRenderer.invoke("papelera:mandar", { archivos, carpeta }),
  papeleraRecuperar:        (id)                     => ipcRenderer.invoke("papelera:recuperar", { id }),
  restoreAFecha:            (o)                      => ipcRenderer.invoke("restore:a-fecha", o),
  restoreFechas:            (id, carpeta)            => ipcRenderer.invoke("restore:fechas", { id, carpeta }),
  revisarBloques:           (id)                     => ipcRenderer.invoke("mantenimiento:revisar", { id }),
  reconstruirIndices:       (id, simular)            => ipcRenderer.invoke("mantenimiento:reconstruir", { id, simular }),
  restoreVersiones:         (id, relPath, porBloques) => ipcRenderer.invoke("restore:versiones", { id, relPath, porBloques }),
  restoreVersion:           (opts)                   => ipcRenderer.invoke("restore:version", opts),
  restoreCancelar:          ()                       => ipcRenderer.invoke("restore:cancelar"),
  restoreRemotoSelection:   (opts)                   => ipcRenderer.invoke("restore:remoto-selection", opts),

  // Events
  onLog: (cb) => {
    const fn = (_e, text) => cb(text);
    ipcRenderer.on("agent:log", fn);
    return () => ipcRenderer.removeListener("agent:log", fn);
  },
  onStatus: (cb) => {
    const fn = (_e, s) => cb(s);
    ipcRenderer.on("agent:status", fn);
    return () => ipcRenderer.removeListener("agent:status", fn);
  },
});
