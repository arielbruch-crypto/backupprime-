"use strict";
/**
 * Lógica de restauración desde destinos remotos (FTP, SFTP, S3 y la nube) que
 * no toca la red ni Electron.
 *
 * Vive aparte para poder probarla: el error de "no se encontró ningún archivo
 * para restaurar" no estaba ni en el motor ni en la interfaz, sino acá en el
 * medio — la pantalla mandaba la selección con un nombre de campo y esta parte
 * la buscaba con otro. Cada lado andaba bien por separado.
 */

function armarArbol(items) {
  const raiz = { type: "folder", name: "", relPath: "", children: [], fileCount: 0 };
  const carpetas = new Map([["", raiz]]);

  const asegurar = (rel) => {
    if (carpetas.has(rel)) return carpetas.get(rel);
    const corte = rel.lastIndexOf("/");
    const padre = asegurar(corte < 0 ? "" : rel.slice(0, corte));
    const nodo = {
      type: "folder",
      name: corte < 0 ? rel : rel.slice(corte + 1),
      relPath: rel,
      fullPath: rel,
      originalPath: rutaOriginalDesdeRel(rel),
      children: [],
      fileCount: 0,
    };
    carpetas.set(rel, nodo);
    padre.children.push(nodo);
    return nodo;
  };

  for (const it of items) {
    const corte = it.rel.lastIndexOf("/");
    const padre = asegurar(corte < 0 ? "" : it.rel.slice(0, corte));
    padre.children.push({
      type: "file",
      name: corte < 0 ? it.rel : it.rel.slice(corte + 1),
      relPath: it.rel,
      fullPath: it.ruta,
      originalPath: rutaOriginalDesdeRel(it.rel),
      size: it.size,
      mtimeMs: 0,
      // Viene marcado desde el inventario: la pantalla lo muestra distinto y el
      // cliente entiende que ese archivo está guardado pero ya no se actualiza.
      fueraDelRespaldo: !!it.fueraDelRespaldo,
      // Se arrastra hasta la selección: al restaurar hay que saber si el
      // archivo se rearma desde bloques o se baja directo.
      porBloques: !!it.porBloques,
    });
  }

  const ordenar = (nodo) => {
    nodo.children.sort((a, b) => {
      if (a.type !== b.type) return a.type === "folder" ? -1 : 1;
      return a.name.localeCompare(b.name);
    });
    let n = 0;
    let fuera = 0;
    for (const h of nodo.children) {
      if (h.type === "folder") { ordenar(h); n += h.fileCount; fuera += h.fileCount && h.fueraDelRespaldo ? h.fileCount : 0; }
      else { n++; if (h.fueraDelRespaldo) fuera++; }
    }
    nodo.fileCount = n;
    // Una carpeta se marca solo si TODO lo que tiene adentro quedó afuera. Si
    // tiene una parte cubierta, marcarla entera mentiría al revés.
    nodo.fueraDelRespaldo = n > 0 && fuera === n;
    return nodo;
  };
  return ordenar(raiz).children;
}

// C/Users/ana/x.txt  ->  C:\Users\ana\x.txt
function rutaOriginalDesdeRel(rel) {
  const partes = rel.split("/").filter(Boolean);
  if (partes.length > 1 && /^[A-Za-z]$/.test(partes[0])) {
    return `${partes[0].toUpperCase()}:\\${partes.slice(1).join("\\")}`;
  }
  return rel.replace(/\//g, "\\");
}


/**
 * Traduce lo que eligió el usuario en la pantalla a rutas relativas.
 * Acepta la ruta relativa (lo normal) o la ruta completa del servidor.
 */
function rutasElegidas(items, base) {
  return (items || []).map((sel) => {
    if (sel && typeof sel.relPath === "string" && sel.relPath) return sel.relPath;
    if (sel && typeof sel.fullPath === "string") {
      return sel.fullPath.startsWith(base)
        ? sel.fullPath.slice(base.length).replace(/^\/+/, "")
        : sel.fullPath.replace(/^\/+/, "");
    }
    return "";
  }).filter(Boolean);
}

/** Elegir una carpeta significa elegir todo lo que tiene adentro. */
function filtrarSeleccion(archivos, rutas) {
  return (archivos || []).filter((a) =>
    (rutas || []).some((rel) => a.rel === rel || a.rel.startsWith(rel + "/")));
}

/**
 * La nube guarda la ruta original del equipo (C:\\Users\\ana\\x.txt). Para poder
 * mostrarla en el mismo árbol que los otros destinos hay que convertirla a la
 * forma relativa que usan todos: C/Users/ana/x.txt.
 */
function relDesdeRutaOriginal(sourcePath) {
  return String(sourcePath || "")
    .replace(/^([A-Za-z]):[\\/]?/, (_m, letra) => `${letra.toUpperCase()}/`)
    .replace(/\\/g, "/")
    .replace(/^\/+/, "");
}

module.exports = { armarArbol, rutaOriginalDesdeRel, rutasElegidas, filtrarSeleccion,
                   relDesdeRutaOriginal };
