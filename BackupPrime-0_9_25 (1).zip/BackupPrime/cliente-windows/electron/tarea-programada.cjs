'use strict';

const { execFile } = require('node:child_process');
const path = require('node:path');

// ---------------------------------------------------------------------------
// Arranque automático con privilegios.
//
// El problema que resuelve: las instantáneas de volumen (VSS) son lo único que
// permite respaldar un archivo que otro programa tiene abierto —el PST con
// Outlook prendido, la base del sistema de gestión— y Windows exige permisos de
// administrador para crearlas. No hay forma de evitarlo.
//
// Hasta ahora el arranque automático se registraba en
// HKCU\Software\Microsoft\Windows\CurrentVersion\Run, que arranca el programa
// SIN elevación. Resultado: en la máquina de un cliente el PST no se respaldaba
// nunca, y el cliente no se enteraba hasta el día que lo necesitaba. Depender de
// que el usuario sepa hacer clic derecho → "Ejecutar como administrador" no es
// una solución: no lo va a hacer, y no tiene por qué saberlo.
//
// La solución es una tarea programada con "ejecutar con los privilegios más
// altos", disparada al iniciar sesión. Eso arranca el programa elevado y, a
// diferencia de la entrada Run, SIN mostrar el cartel de UAC en cada arranque.
// La tarea se crea durante la instalación, que ya corre elevada, así que el
// usuario no ve ningún pedido de permisos extra.
// ---------------------------------------------------------------------------

const NOMBRE_TAREA = "BackupPrime";
const ARGS = ["--hidden"];

function esWindows() {
  return process.platform === "win32";
}

function correr(args, timeout = 20000) {
  return new Promise((resolve) => {
    execFile("schtasks.exe", args, { timeout, windowsHide: true },
      (err, stdout, stderr) => {
        resolve({
          ok: !err,
          salida: String(stdout || ""),
          error: err ? String((stderr || err.message) || "").trim() : null,
        });
      });
  });
}

/**
 * Los argumentos para crear la tarea.
 *
 * Se expone aparte de la ejecución para poder probar que se armen bien sin
 * necesidad de Windows: es la parte donde un error se paga caro y en silencio.
 */
function argumentosCrear(rutaExe, nombre = NOMBRE_TAREA) {
  // La ruta va entre comillas dentro del valor de /TR porque casi siempre tiene
  // espacios ("C:\Program Files\BackupPrime\BackupPrime.exe"). Sin las comillas,
  // schtasks parte el comando en el primer espacio y la tarea queda apuntando a
  // "C:\Program".
  const comando = `"${rutaExe}" ${ARGS.join(" ")}`.trim();
  return [
    "/Create",
    "/TN", nombre,
    "/TR", comando,
    "/SC", "ONLOGON",
    // El punto de todo esto: privilegios altos, que es lo que habilita VSS.
    "/RL", "HIGHEST",
    // Reemplaza una tarea anterior en lugar de fallar. Hace que reinstalar y
    // actualizar sean idempotentes.
    "/F",
  ];
}

async function crear(rutaExe = process.execPath) {
  if (!esWindows()) return { ok: false, motivo: "Solo aplica a Windows." };
  const r = await correr(argumentosCrear(rutaExe));
  if (!r.ok) {
    // El caso más común: crear una tarea con /RL HIGHEST requiere ser
    // administrador. Desde el instalador esto no falla; desde la app sí.
    return {
      ok: false,
      motivo: r.error || "No se pudo crear la tarea programada.",
      necesitaAdmin: /denied|denegado|acceso/i.test(r.error || ""),
    };
  }
  return { ok: true };
}

async function eliminar(nombre = NOMBRE_TAREA) {
  if (!esWindows()) return { ok: false };
  const r = await correr(["/Delete", "/TN", nombre, "/F"]);
  return { ok: r.ok };
}

/**
 * Lee cómo está configurado el arranque automático.
 *
 * Devuelve `{ existe, privilegiada }`. La distinción importa: una tarea sin
 * privilegios altos arranca el programa igual, pero VSS no va a funcionar, así
 * que hay que poder detectarla y avisar en lugar de dar por buena la
 * configuración.
 */
function interpretarConsulta(salidaCsv) {
  const lineas = String(salidaCsv || "").split(/\r?\n/).filter((l) => l.trim());
  if (lineas.length < 2) return { existe: false, privilegiada: false };
  // La salida en formato LIST es más estable entre idiomas de Windows que la CSV
  // con encabezados traducidos, pero igual conviene no depender del nombre del
  // campo: se busca la marca de privilegios altos en todo el texto.
  const texto = lineas.join("\n");
  if (/^ERROR/im.test(texto)) return { existe: false, privilegiada: false };

  // Ojo con cómo se detecta: buscar "más altos" en todo el texto da un falso
  // positivo, porque esa frase está en la ETIQUETA del campo
  // ("Ejecutar con los privilegios más altos: LIMITED") y aparece igual cuando la
  // tarea NO es privilegiada. Un falso positivo acá es de los peores que hay:
  // daría por bueno un arranque sin permisos y el PST quedaría sin respaldar sin
  // que nadie avise.
  //
  // Se mira el VALOR, no la etiqueta. HIGHEST y LIMITED son las dos únicas
  // posibilidades y schtasks NO las traduce, así que sirve en cualquier idioma
  // de Windows.
  const valores = lineas
    .map((l) => l.slice(l.indexOf(":") + 1).trim().toUpperCase())
    .filter(Boolean);
  return {
    existe: true,
    privilegiada: valores.includes("HIGHEST"),
  };
}

async function estado(nombre = NOMBRE_TAREA) {
  if (!esWindows()) return { existe: false, privilegiada: false, soportado: false };
  const r = await correr(["/Query", "/TN", nombre, "/V", "/FO", "LIST"]);
  if (!r.ok) return { existe: false, privilegiada: false, soportado: true };
  return { ...interpretarConsulta(r.salida), soportado: true };
}

module.exports = {
  NOMBRE_TAREA,
  ARGS,
  argumentosCrear,
  interpretarConsulta,
  crear,
  eliminar,
  estado,
};
