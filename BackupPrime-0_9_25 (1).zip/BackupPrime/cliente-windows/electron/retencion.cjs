'use strict';
// ---------------------------------------------------------------------------
// Política de retención de versiones.
//
// Antes esto era "conservar las últimas 10 versiones". El problema no era el
// número: era la unidad. Un PST que Outlook toca diez veces por día gasta 30
// versiones en tres días. Cuando un estudio detecta un ransomware el lunes de
// la semana siguiente —que es lo normal, se detecta entre 3 y 20 días después—
// las 30 versiones son todas versiones cifradas. La copia sana se pisó sola,
// sin que ningún atacante borrara nada.
//
// Contar versiones protege del archivo que cambia poco. Cubrir VENTANAS DE
// TIEMPO protege del que cambia mucho, que es justo el que más importa.
//
//   últimos 7 días   → todas          (el error humano: "borré el balance ayer")
//   hasta 30 días    → una por día    (el ransomware detectado tarde)
//   hasta 6 meses    → una por semana (la corrupción que nadie vio)
//   hasta 2 años     → una por mes    (un balance viejo, y sale barato)
//
// Con deduplicación esto ocupa MENOS que 30 versiones sueltas de un archivo que
// cambia seguido, y da un año y medio más de alcance.
//
// Este módulo NO BORRA NADA. Decide qué sobra. Quién borra, y con qué cuidado,
// es otro problema —los bloques se comparten entre versiones y entre archivos,
// y borrar uno todavía referenciado deja un archivo vivo sin un pedazo, que no
// se nota hasta que alguien restaura.
// ---------------------------------------------------------------------------

const DIA = 86400000;

const POLITICA_POR_DEFECTO = {
  todasHastaDias: 7,
  unaPorDiaHastaDias: 30,
  unaPorSemanaHastaDias: 180,
  unaPorMesHastaDias: 730,
};

/** Clave de agrupamiento en hora local: el cliente piensa en SUS días. */
function claveDia(d) {
  return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
}
function claveSemana(d) {
  // Lunes de esa semana. Evita que el corte de año parta una semana en dos.
  const copia = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  const dia = (copia.getDay() + 6) % 7;   // lunes = 0
  copia.setDate(copia.getDate() - dia);
  return `${copia.getFullYear()}-${copia.getMonth()}-${copia.getDate()}`;
}
function claveMes(d) {
  return `${d.getFullYear()}-${d.getMonth()}`;
}

/**
 * Decide qué versiones conservar y cuáles sobran.
 *
 * @param {Array} versiones  [{ id, fechaMs }]
 * @param {Object} opciones  { ahora, politica }
 * @returns {{conservar: Array, sobrantes: Array, avisos: Array}}
 *
 * Regla que manda sobre todas las demás: **ante la duda, no se borra.** Un
 * cliente enojado porque le sobra un giga se arregla con una llamada. Un
 * cliente sin su archivo, no.
 */
function clasificarVersiones(versiones, opciones = {}) {
  const politica = { ...POLITICA_POR_DEFECTO, ...(opciones.politica || {}) };
  const ahora = opciones.ahora == null ? Date.now() : Number(opciones.ahora);
  const avisos = [];

  if (!Array.isArray(versiones) || versiones.length === 0) {
    return { conservar: [], sobrantes: [], avisos };
  }

  // Una sola versión no se toca nunca: es el archivo.
  if (versiones.length === 1) {
    return { conservar: versiones.slice(), sobrantes: [], avisos };
  }

  // Fechas ilegibles: se conservan y se avisa. Una versión que no se puede
  // fechar es exactamente la que no hay que borrar a ciegas.
  const validas = [], invalidas = [];
  for (const v of versiones) {
    const ms = Number(v && v.fechaMs);
    if (!isFinite(ms) || ms <= 0) invalidas.push(v);
    else validas.push({ ...v, fechaMs: ms });
  }
  if (invalidas.length) {
    avisos.push(`${invalidas.length} versión(es) sin fecha legible: se conservan.`);
  }

  // De la más nueva a la más vieja.
  validas.sort((a, b) => b.fechaMs - a.fechaMs);

  const conservar = [...invalidas];
  const sobrantes = [];
  const vistos = { dia: new Set(), semana: new Set(), mes: new Set() };
  let primera = true;

  for (const v of validas) {
    // La más nueva siempre se conserva: es el estado actual del archivo.
    if (primera) { primera = false; conservar.push(v); continue; }

    // Una fecha futura es un reloj mal puesto, no una versión vieja.
    if (v.fechaMs > ahora) {
      conservar.push(v);
      avisos.push('Hay una versión con fecha futura: se conserva.');
      continue;
    }

    const dias = (ahora - v.fechaMs) / DIA;
    const d = new Date(v.fechaMs);

    if (dias <= politica.todasHastaDias) {
      conservar.push(v);
    } else if (dias <= politica.unaPorDiaHastaDias) {
      const k = claveDia(d);
      if (vistos.dia.has(k)) sobrantes.push(v);
      else { vistos.dia.add(k); conservar.push(v); }
    } else if (dias <= politica.unaPorSemanaHastaDias) {
      const k = claveSemana(d);
      if (vistos.semana.has(k)) sobrantes.push(v);
      else { vistos.semana.add(k); conservar.push(v); }
    } else if (dias <= politica.unaPorMesHastaDias) {
      const k = claveMes(d);
      if (vistos.mes.has(k)) sobrantes.push(v);
      else { vistos.mes.add(k); conservar.push(v); }
    } else {
      sobrantes.push(v);
    }
  }

  return { conservar, sobrantes, avisos };
}

/** Texto para la pantalla, sin números sueltos que nadie entiende. */
function explicarPolitica(politica = POLITICA_POR_DEFECTO) {
  const p = { ...POLITICA_POR_DEFECTO, ...politica };
  const meses = (d) => Math.round(d / 30);
  return [
    `Todas las versiones de los últimos ${p.todasHastaDias} días`,
    `Una por día hasta los ${p.unaPorDiaHastaDias} días`,
    `Una por semana hasta los ${meses(p.unaPorSemanaHastaDias)} meses`,
    `Una por mes hasta los ${Math.round(p.unaPorMesHastaDias / 365)} años`,
  ];
}

module.exports = { clasificarVersiones, explicarPolitica, POLITICA_POR_DEFECTO, DIA };
