'use strict';

const { execFileSync, execFile } = require('node:child_process');
const path = require('node:path');

// ---------------------------------------------------------------------------
// Instantáneas de volumen (Volume Shadow Copy).
//
// Sirven para copiar archivos que están abiertos y bloqueados: bases de Tango,
// Access, SQL Express. Sin esto, esos archivos quedan afuera del respaldo — que
// es justo lo que más le importa a un estudio contable.
//
// Requiere permisos de administrador. Si no los hay, el módulo lo informa y el
// respaldo sigue sin instantánea: los archivos bloqueados se saltan con aviso,
// pero el respaldo no se cae.
// ---------------------------------------------------------------------------

const TIEMPO_MAXIMO_MS = 90000;

function esWindows() {
  return process.platform === 'win32';
}

function ejecutarPS(script, timeout = TIEMPO_MAXIMO_MS) {
  return execFileSync(
    'powershell.exe',
    ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script],
    { encoding: 'utf8', timeout, windowsHide: true }
  ).trim();
}

/**
 * ¿Corremos como administrador? Sin esto, Win32_ShadowCopy.Create devuelve
 * código de retorno 2 (acceso denegado).
 */
function esAdministrador() {
  if (!esWindows()) return false;
  try {
    const r = ejecutarPS(
      '([Security.Principal.WindowsPrincipal]' +
      '[Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(' +
      '[Security.Principal.WindowsBuiltInRole]::Administrator)',
      10000
    );
    return r.toLowerCase() === 'true';
  } catch (_) {
    return false;
  }
}

function disponible() {
  if (!esWindows()) {
    return { ok: false, motivo: 'Las instantáneas solo existen en Windows.' };
  }
  if (!esAdministrador()) {
    return {
      ok: false,
      // Antes decía "los archivos abiertos se van a saltear", que era falso y
      // alarmante: la lectura directa funciona para casi todo, incluido el PST de
      // Outlook. La instantánea es un refuerzo para bases de datos en uso, no un
      // requisito para respaldar.
      motivo: 'sin permisos de administrador no se pueden crear instantáneas.',
      necesitaAdmin: true
    };
  }
  try {
    ejecutarPS('Get-Service VSS | Select-Object -ExpandProperty Status', 10000);
    return { ok: true };
  } catch (_) {
    return { ok: false, motivo: 'El servicio VSS de Windows no responde.' };
  }
}

/**
 * Crea una instantánea del volumen (ej: "C:") y devuelve la ruta del
 * dispositivo sombra para leer desde ahí.
 */
function crear(volumen) {
  const letra = volumen.slice(0, 1).toUpperCase();
  const raiz = `${letra}:\\`;

  const script = `
    $r = (Get-WmiObject -List Win32_ShadowCopy).Create("${raiz}", "ClientAccessible")
    if ($r.ReturnValue -ne 0) { Write-Output "ERROR:$($r.ReturnValue)"; exit 1 }
    $s = Get-WmiObject Win32_ShadowCopy | Where-Object { $_.ID -eq $r.ShadowID }
    Write-Output "$($s.ID)|$($s.DeviceObject)"
  `;

  let salida;
  try {
    salida = ejecutarPS(script);
  } catch (err) {
    throw new Error(`No se pudo crear la instantánea de ${letra}: (${err.message})`);
  }

  if (salida.startsWith('ERROR:')) {
    const codigo = salida.split(':')[1];
    const explicacion = {
      '1': 'acceso denegado',
      '2': 'argumento inválido',
      '3': 'el volumen no soporta instantáneas',
      '5': 'ya hay una instantánea en curso',
      '12': 'el volumen no está en NTFS'
    }[codigo] || `código ${codigo}`;
    throw new Error(`Windows rechazó la instantánea: ${explicacion}`);
  }

  const [id, dispositivo] = salida.split('|');
  if (!id || !dispositivo) {
    throw new Error('Windows no devolvió una instantánea utilizable.');
  }

  return { id, dispositivo, volumen: letra };
}

function eliminar(id) {
  if (!id) return false;
  try {
    ejecutarPS(`(Get-WmiObject Win32_ShadowCopy | Where-Object { $_.ID -eq "${id}" }).Delete()`, 30000);
    return true;
  } catch (_) {
    return false;
  }
}

/**
 * Limpia instantáneas huérfanas que hayan quedado de una corrida anterior que
 * se cerró mal. Sin esto se acumulan y comen disco.
 */
function limpiarHuerfanas(prefijoId = null) {
  if (!esWindows() || !esAdministrador()) return 0;
  try {
    const salida = ejecutarPS(
      'Get-WmiObject Win32_ShadowCopy | Where-Object { $_.ClientAccessible -eq $true } | ' +
      'Select-Object -ExpandProperty ID'
    );
    const ids = salida.split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
    let borradas = 0;
    for (const id of ids) {
      if (prefijoId && !id.startsWith(prefijoId)) continue;
      if (eliminar(id)) borradas++;
    }
    return borradas;
  } catch (_) {
    return 0;
  }
}

/**
 * Traduce una ruta normal a su equivalente dentro de la instantánea.
 *   C:\Tango\Bases\Padron.mdb
 *   → \\?\GLOBALROOT\Device\HarddiskVolumeShadowCopy7\Tango\Bases\Padron.mdb
 */
function traducirRuta(rutaOriginal, instantanea) {
  const letra = rutaOriginal.slice(0, 1).toUpperCase();
  if (letra !== instantanea.volumen) return null;
  const resto = rutaOriginal.slice(3);
  return path.join(instantanea.dispositivo, resto);
}

/**
 * Agrupa las carpetas por letra de volumen. Se crea una instantánea por
 * volumen, no una por carpeta.
 */
function volumenesDe(carpetas) {
  const set = new Set();
  for (const c of carpetas) {
    const letra = c.slice(0, 1).toUpperCase();
    if (/[A-Z]/.test(letra)) set.add(letra);
  }
  return [...set];
}

/**
 * Crea instantáneas para todos los volúmenes involucrados.
 * Devuelve siempre un objeto usable: si falla, viene vacío y el respaldo sigue.
 */
function crearParaCarpetas(carpetas, log = () => {}) {
  const estado = { activas: [], porVolumen: new Map(), degradado: false, motivo: null };

  const chequeo = disponible();
  if (!chequeo.ok) {
    estado.degradado = true;
    estado.motivo = chequeo.motivo;
    // Nota informativa, no advertencia: el respaldo funciona igual. Se degrada a
    // 'info' para no teñir de naranja un respaldo que salió bien.
    log(`Respaldo sin instantáneas: ${chequeo.motivo} Los archivos se leen ` +
        `directamente, que es lo que funciona para casi todo. Solo una base de ` +
        `datos con escritura activa podría requerirlas.`, 'info');
    return estado;
  }

  for (const volumen of volumenesDe(carpetas)) {
    try {
      const inst = crear(volumen);
      estado.activas.push(inst);
      estado.porVolumen.set(volumen, inst);
      log(`Instantánea VSS creada para ${volumen}:`, 'exito');
    } catch (err) {
      estado.degradado = true;
      estado.motivo = err.message;
      log(`No se pudo crear la instantánea de ${volumen}: ${err.message}`, 'aviso');
    }
  }

  return estado;
}

/**
 * Devuelve la ruta desde donde conviene leer un archivo: la de la instantánea
 * si existe, o la original si no.
 */
function rutaDeLectura(rutaOriginal, estado) {
  if (!estado || estado.activas.length === 0) return rutaOriginal;
  const letra = rutaOriginal.slice(0, 1).toUpperCase();
  const inst = estado.porVolumen.get(letra);
  if (!inst) return rutaOriginal;
  return traducirRuta(rutaOriginal, inst) || rutaOriginal;
}

function liberar(estado, log = () => {}) {
  if (!estado || estado.activas.length === 0) return;
  for (const inst of estado.activas) {
    if (eliminar(inst.id)) {
      log(`Instantánea de ${inst.volumen}: liberada`);
    } else {
      log(`Quedó una instantánea sin liberar en ${inst.volumen}:`, 'aviso');
    }
  }
  estado.activas = [];
  estado.porVolumen.clear();
}

module.exports = {
  disponible,
  esAdministrador,
  crear,
  eliminar,
  limpiarHuerfanas,
  crearParaCarpetas,
  rutaDeLectura,
  traducirRuta,
  volumenesDe,
  liberar
};
