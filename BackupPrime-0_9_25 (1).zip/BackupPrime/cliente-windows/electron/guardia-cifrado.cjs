'use strict';

const fs = require('node:fs');
const path = require('node:path');

// ---------------------------------------------------------------------------
// Guardia anti-cifrado.
//
// Diseñado para el bucle en streaming de `_doBackup`: no arma una lista
// completa de archivos en memoria. Se le pasa cada archivo a medida que
// `walkDir` lo entrega, y va acumulando señales.
//
// Cuando se cruzan dos señales, corta. Una sola no alcanza: exportar un lote
// desde Tango dispara la señal de tasa por sí sola, e instalar un programa
// nuevo dispara la de extensiones.
// ---------------------------------------------------------------------------

const UMBRALES = {
  archivosPorMinuto: 150,
  entropiaMinima: 7.6,
  proporcionAltaEntropia: 0.6,
  minimoParaMedir: 8,
  extensionesNuevasEnLote: 20,
  muestraMaxima: 40,
  bytesPorMuestra: 65536,
  ventanaMinimaMs: 5000
};

// Formatos que ya vienen comprimidos: miden ~7.9 de entropía estando sanos.
// Contarlos como sospechosos daría un falso positivo en cada respaldo de un
// estudio contable, que trabaja con xlsx y pdf todo el día.
const YA_COMPRIMIDOS = new Set([
  '.zip', '.rar', '.7z', '.gz', '.bz2', '.xz', '.cab', '.jpg', '.jpeg', '.png',
  '.gif', '.webp', '.bmp', '.mp4', '.mkv', '.avi', '.mov', '.mp3', '.ogg',
  '.flac', '.pdf', '.docx', '.xlsx', '.pptx', '.odt', '.ods', '.odp', '.epub'
]);

function entropia(ruta, bytes = UMBRALES.bytesPorMuestra) {
  let fd;
  try {
    fd = fs.openSync(ruta, 'r');
    const buffer = Buffer.alloc(bytes);
    const leidos = fs.readSync(fd, buffer, 0, bytes, 0);
    if (leidos < 256) return 0;

    const frecuencias = new Array(256).fill(0);
    for (let i = 0; i < leidos; i++) frecuencias[buffer[i]]++;

    let h = 0;
    for (const f of frecuencias) {
      if (f === 0) continue;
      const p = f / leidos;
      h -= p * Math.log2(p);
    }
    return h;
  } catch (_) {
    return 0;
  } finally {
    if (fd !== undefined) { try { fs.closeSync(fd); } catch (_) {} }
  }
}

class GuardiaCifrado {
  /**
   * @param {Object} opciones
   *   umbrales      — sobrescribe UMBRALES
   *   referenciaMs  — momento del último respaldo; los cambios posteriores cuentan
   *   extensionesConocidas — Set de extensiones que ya existían (del StateStore)
   *   primerRespaldo — si es true, el guardia no dispara nunca
   */
  constructor(opciones = {}) {
    this.u = { ...UMBRALES, ...(opciones.umbrales || {}) };
    this.referenciaMs = opciones.referenciaMs || 0;
    this.extensionesConocidas = opciones.extensionesConocidas || new Set();
    this.primerRespaldo = Boolean(opciones.primerRespaldo);

    this.cambiados = 0;
    this.primerCambioMs = null;
    this.ultimoCambioMs = null;

    this.medidos = 0;
    this.altaEntropia = 0;

    this.extensionesNuevas = new Map();

    this.disparo = false;
    this.motivos = [];
  }

  /**
   * Se llama con cada archivo que entrega walkDir.
   * @returns {boolean} true si el guardia acaba de disparar
   */
  ver(archivo) {
    if (this.primerRespaldo || this.disparo) return false;

    const ruta = archivo.sourcePath || archivo.ruta;
    const mtime = archivo.mtimeMs != null ? archivo.mtimeMs : archivo.modificado;
    if (!ruta || mtime == null) return false;

    // ------------------------------------------------------------ señal 3
    const ext = path.extname(ruta).toLowerCase();
    if (ext && !this.extensionesConocidas.has(ext)) {
      this.extensionesNuevas.set(ext, (this.extensionesNuevas.get(ext) || 0) + 1);
    }

    // Solo interesan los archivos tocados después del último respaldo.
    if (this.referenciaMs && mtime <= this.referenciaMs) return false;

    // ------------------------------------------------------------ señal 1
    this.cambiados++;
    if (this.primerCambioMs === null || mtime < this.primerCambioMs) this.primerCambioMs = mtime;
    if (this.ultimoCambioMs === null || mtime > this.ultimoCambioMs) this.ultimoCambioMs = mtime;

    // ------------------------------------------------------------ señal 2
    if (this.medidos < this.u.muestraMaxima && !YA_COMPRIMIDOS.has(ext)) {
      const h = entropia(ruta, this.u.bytesPorMuestra);
      if (h > 0) {
        this.medidos++;
        if (h >= this.u.entropiaMinima) this.altaEntropia++;
      }
    }

    return this.evaluar();
  }

  tasaPorMinuto() {
    if (this.cambiados < 2 || this.primerCambioMs === null) return 0;
    const ventanaMs = Math.max(this.ultimoCambioMs - this.primerCambioMs, this.u.ventanaMinimaMs);
    return Math.round(this.cambiados / (ventanaMs / 60000));
  }

  proporcionAlta() {
    if (this.medidos < this.u.minimoParaMedir) return 0;
    return this.altaEntropia / this.medidos;
  }

  /** Recalcula las señales y decide si corresponde cortar. */
  evaluar() {
    if (this.primerRespaldo || this.disparo) return false;

    const motivos = [];

    const tasa = this.tasaPorMinuto();
    if (tasa > this.u.archivosPorMinuto) {
      const minutos = ((this.ultimoCambioMs - this.primerCambioMs) / 60000).toFixed(2);
      motivos.push(
        `${this.cambiados} archivos modificados en ${minutos} minutos ` +
        `(${tasa}/min, umbral ${this.u.archivosPorMinuto})`
      );
    }

    const prop = this.proporcionAlta();
    if (prop >= this.u.proporcionAltaEntropia) {
      motivos.push(
        `${this.altaEntropia} de ${this.medidos} archivos medidos tienen entropía de cifrado ` +
        `(${Math.round(prop * 100)}%, umbral ${Math.round(this.u.proporcionAltaEntropia * 100)}%)`
      );
    }

    for (const [ext, cantidad] of this.extensionesNuevas) {
      if (cantidad >= this.u.extensionesNuevasEnLote) {
        motivos.push(`${cantidad} archivos con la extensión nueva ${ext}`);
      }
    }

    this.motivos = motivos;

    // Dos señales o más: es ransomware.
    if (motivos.length >= 2) {
      this.disparo = true;
      return true;
    }
    return false;
  }

  /** Estado final para el log, la alerta y el reporte al portal. */
  informe() {
    this.evaluar();
    return {
      disparo: this.disparo,
      motivos: this.motivos,
      señales: {
        cambiados: this.cambiados,
        archivosPorMinuto: this.tasaPorMinuto(),
        medidos: this.medidos,
        altaEntropia: this.altaEntropia,
        proporcionAltaEntropia: Number(this.proporcionAlta().toFixed(2)),
        extensionesNuevas: [...this.extensionesNuevas]
          .filter(([, c]) => c >= this.u.extensionesNuevasEnLote)
          .map(([extension, cantidad]) => ({ extension, cantidad }))
      }
    };
  }
}

/**
 * Extensiones que ya aparecían en el StateStore. Sirve como línea de base para
 * la señal 3 sin tener que leer el manifiesto entero.
 */
function extensionesDelEstado(stateData) {
  const set = new Set();
  for (const ruta of Object.keys(stateData || {})) {
    const ext = path.extname(ruta).toLowerCase();
    if (ext) set.add(ext);
  }
  return set;
}

module.exports = { GuardiaCifrado, entropia, extensionesDelEstado, UMBRALES, YA_COMPRIMIDOS };
