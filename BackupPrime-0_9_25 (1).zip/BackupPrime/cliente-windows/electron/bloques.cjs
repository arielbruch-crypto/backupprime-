'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Respaldo por bloques.
 
   El problema: un PST de 650 MB al que Outlook le toca dos páginas se sube
   entero, todos los días. Con 30 días de versiones eso son 19,5 GB de un solo
   archivo, y 650 MB de tráfico diarios.
 
   La solución: partir el archivo en pedazos, guardar cada pedazo una sola vez, y
   guardar por versión solo la LISTA de pedazos. Si cambian dos páginas, se
   suben los dos bloques que las contienen y la lista nueva. El resto ya está.
 
   ── Por qué los cortes no son de tamaño fijo ────────────────────────────────
 
   Si cortáramos cada 4 MB exactos, insertar un byte al principio del archivo
   correría todo el contenido y TODOS los bloques cambiarían: volveríamos a subir
   los 650 MB. Por eso el corte se decide mirando el contenido: se recorre el
   archivo con una huella móvil y se corta donde esa huella cumple una condición.
   Insertar un byte mueve un solo límite; el resto de los bloques queda igual.
 
   ── Qué queda guardado ──────────────────────────────────────────────────────
 
     bloques/ab/abcdef…        cada pedazo, una sola vez, con su huella de nombre
     indices/C/Users/…/x.pst   la lista ordenada de huellas de ese archivo
 
   El índice es lo que se versiona. Pesa unos pocos kilobytes, así que guardar
   30 versiones de un archivo de 650 MB cuesta lo que pesan los bloques que de
   verdad cambiaron.
   ═══════════════════════════════════════════════════════════════════════════ */

const fs = require('node:fs');
const fsp = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');

// ─── Cortes según el contenido ───────────────────────────────────────────────

// Tabla de valores al azar, uno por byte posible. Es fija a propósito: si
// cambiara entre versiones del programa, los cortes cambiarían y habría que
// volver a subir todo.
const ENGRANAJE = (() => {
  const tabla = new Int32Array(256);
  // Generador propio y determinista: no se puede depender de Math.random acá.
  let semilla = 0x1f2e3d4c;
  for (let i = 0; i < 256; i++) {
    semilla ^= semilla << 13; semilla |= 0;
    semilla ^= semilla >>> 17;
    semilla ^= semilla << 5; semilla |= 0;
    tabla[i] = semilla;
  }
  return tabla;
})();

// La huella rodante solo depende de los últimos 32 bytes: más atrás, el
// desplazamiento a la izquierda ya sacó todo. Es lo que permite saltear la zona
// donde el corte está prohibido sin cambiar dónde caen los cortes.
const VENTANA_HUELLA = 32;

const MINIMO = 1 * 1024 * 1024;    // 1 MB: por debajo no se corta
const OBJETIVO = 4 * 1024 * 1024;  // 4 MB de promedio
const MAXIMO = 16 * 1024 * 1024;   // 16 MB: por arriba se corta igual
const MASCARA = (1 << 22) - 1;     // ~4 MB de promedio

/**
 * Recorre un archivo y devuelve los límites de cada bloque.
 * No carga el archivo en memoria: va leyendo de a pedazos.
 */
/**
 * Recorre el archivo cortándolo en bloques y avisando de cada uno.
 *
 * Lee el archivo UNA sola vez. Antes se lo recorría para calcular los cortes y
 * después se lo volvía a abrir para leer cada pedazo por posición: dos aperturas
 * del mismo archivo. En Windows eso choca con los programas que lo tienen
 * tomado —Outlook con su PST es el caso típico— y falla con EBUSY.
 *
 * `alCerrarBloque(datos, huella, desde)` recibe cada bloque completo. Si
 * devuelve una promesa, se espera: así se puede subir el bloque antes de seguir
 * leyendo, y nunca hay más de un bloque en memoria por archivo.
 */
async function recorrerBloques(rutaArchivo, alCerrarBloque, alAvanzar) {
  const lector = await abrirConReintentos(rutaArchivo);

  let huella = 0;
  let desde = 0;
  let largo = 0;
  let hash = crypto.createHash('sha256');
  const hashTotal = crypto.createHash('sha256');
  let piezas = [];
  let cuantos = 0;
  let posicion = 0;

  const cerrar = async () => {
    const datos = Buffer.concat(piezas, largo);
    const huellaBloque = hash.digest('hex');
    cuantos++;
    if (alCerrarBloque) await alCerrarBloque(datos, huellaBloque, desde);
    if (alAvanzar) alAvanzar(cuantos, posicion);
    desde += largo;
    largo = 0;
    huella = 0;
    piezas = [];
    hash = crypto.createHash('sha256');
  };

  for await (const trozo of lector) {
    hashTotal.update(trozo);
    let inicio = 0;

    let i = 0;
    while (i < trozo.length) {
      // ── Saltear la zona donde no se puede cortar ──
      //
      // Por debajo de MINIMO el corte está prohibido, así que calcular la huella
      // rodante ahí no sirve para nada: es trabajo puro. Con bloques de 5 MB
      // promedio y un mínimo de 1 MB, eso es cerca de un quinto de cada archivo
      // procesado byte por byte al pedo.
      //
      // Se avanza de una en la parte prohibida y la huella se reinicia: como la
      // huella rodante solo depende de los últimos ~32 bytes, alcanza con
      // recorrer esa ventana antes de volver a evaluar cortes. El resultado es
      // idéntico al de recorrer todo, porque los bytes anteriores ya no influyen.
      if (largo < MINIMO) {
        const faltan = MINIMO - largo;
        const salto = Math.min(faltan, trozo.length - i);
        // Se dejan los últimos 32 bytes sin saltear para que la huella llegue
        // "cargada" al primer byte donde el corte ya está permitido.
        const saltoReal = Math.max(0, salto - VENTANA_HUELLA);
        if (saltoReal > 0) {
          i += saltoReal; largo += saltoReal; posicion += saltoReal;
          continue;
        }
      }

      huella = (((huella << 1) | 0) + ENGRANAJE[trozo[i]]) | 0;
      largo++;
      posicion++;

      const cortar = largo >= MAXIMO || (largo >= MINIMO && (huella & MASCARA) === 0);
      if (cortar) {
        const parte = trozo.subarray(inicio, i + 1);
        hash.update(parte);
        piezas.push(Buffer.from(parte));
        inicio = i + 1;
        await cerrar();
      }
      i++;
    }

    if (inicio < trozo.length) {
      const parte = trozo.subarray(inicio);
      hash.update(parte);
      piezas.push(Buffer.from(parte));
    }
  }

  if (largo > 0) await cerrar();

  return { huellaTotal: hashTotal.digest('hex'), bloques: cuantos };
}

/** Solo calcula los cortes, sin guardar el contenido. Se usa para medir. */
async function partir(rutaArchivo, alAvanzar) {
  const bloques = [];
  const { huellaTotal } = await recorrerBloques(rutaArchivo, (datos, huella, desde) => {
    bloques.push({ desde, bytes: datos.length, huella });
  }, alAvanzar);
  return { bloques, huellaTotal };
}

/**
 * Abre el archivo para leerlo, reintentando si otro programa lo tiene tomado.
 *
 * En Windows, Outlook, los sistemas de gestión y los antivirus toman y sueltan
 * archivos todo el tiempo. Un EBUSY momentáneo no puede costar el respaldo del
 * archivo más importante del cliente: se espera un poco y se vuelve a intentar.
 */
async function abrirConReintentos(rutaArchivo, intentos = 4) {
  let ultimo;
  for (let i = 0; i < intentos; i++) {
    try {
      const lector = fs.createReadStream(rutaArchivo, { highWaterMark: 1024 * 1024 });
      await new Promise((resolver, rechazar) => {
        lector.once('open', resolver);
        lector.once('error', rechazar);
      });
      return lector;
    } catch (e) {
      ultimo = e;
      if (!/EBUSY|EPERM|EACCES/.test(String(e.code || e.message))) throw e;
      await new Promise((r) => setTimeout(r, 500 * (i + 1)));
    }
  }
  throw new Error(
    `"${path.basename(rutaArchivo)}" está tomado por otro programa y no se pudo leer ` +
    `después de varios intentos. Si es un archivo de correo o de un sistema de ` +
    `gestión, suele soltarse al cerrar ese programa. Detalle: ${ultimo && ultimo.message}`);
}

/** Huella del archivo completo, leyéndolo de a poco. */
function huellaDeArchivo(rutaArchivo) {
  return new Promise((resolver, rechazar) => {
    const h = crypto.createHash('sha256');
    const lector = fs.createReadStream(rutaArchivo);
    lector.on('data', (d) => h.update(d));
    lector.on('end', () => resolver(h.digest('hex')));
    lector.on('error', rechazar);
  });
}

// ─── El índice ───────────────────────────────────────────────────────────────

const VERSION_FORMATO = 1;

function armarIndice({ rutaOriginal, bytes, mtimeMs, huellaTotal, bloques }) {
  return {
    formato: VERSION_FORMATO,
    archivo: rutaOriginal,
    bytes,
    mtimeMs,
    huella: huellaTotal,
    creado: new Date().toISOString(),
    // Solo las huellas, en orden. Los tamaños se guardan para poder verificar
    // sin bajar nada.
    bloques: bloques.map((b) => ({ h: b.huella, n: b.bytes })),
  };
}

function leerIndice(texto) {
  const i = typeof texto === 'string' ? JSON.parse(texto) : texto;
  if (!i || i.formato !== VERSION_FORMATO) {
    throw new Error(`Índice de bloques con formato desconocido (${i && i.formato})`);
  }
  if (!Array.isArray(i.bloques) || !i.bloques.length) {
    throw new Error('El índice de bloques está vacío');
  }
  return i;
}

const claveBloque = (prefijo, huella) =>
  `${prefijo}bloques/${huella.slice(0, 2)}/${huella}`;

const claveIndice = (prefijo, rutaRelativa) =>
  `${prefijo}indices/${rutaRelativa}.bpi`;

// La SEGUNDA copia del índice.
//
// Antes se guardaba pegada al archivo original (`Documentos/Outlook.pst.bpi`),
// dentro del árbol del cliente. Eso tenía dos consecuencias feas:
//   · el destino se llenaba de archivitos de 3 KB mezclados con los archivos de
//     verdad, y el cliente que entra al bucket ve un desastre;
//   · y —lo grave— el listado de restaurar los mostraba al lado del archivo
//     real. Un cliente que elige `respaldo.zip.bpi` en vez de `respaldo.zip`
//     se lleva un JSON de 3 KB creyendo que restauró su respaldo.
//
// Ahora va a una rama propia, que se filtra igual que `bloques/` e `indices/`.
// La redundancia se mantiene: son dos objetos distintos, y perder la rama
// `indices/` entera no deja al cliente sin sus archivos.
const claveIndiceCopia = (prefijo, rutaRelativa) =>
  `${prefijo}indices-copia/${rutaRelativa}.bpi`;

/**
 * ¿Esta ruta es cocina del sistema y NO un archivo del cliente?
 *
 * Vive acá, y no suelta en la pantalla, porque la usan el listado de restaurar,
 * la máquina del tiempo y las pruebas. Cuando cada uno tenía su propia versión
 * del filtro, uno se olvidó de los `.bpi` pegados al archivo y el cliente los
 * veía mezclados con sus respaldos.
 *
 * `rel` es la ruta SIN el prefijo del destino.
 */
const esRutaDeServicio = (rel) =>
  !rel
  || rel.startsWith('bloques/')
  || rel.startsWith('indices/')
  || rel.startsWith('indices-copia/')
  // Los respaldos hechos hasta la 0.9.8 tienen la copia del índice pegada al
  // archivo. Esos objetos siguen en el destino del cliente, así que este filtro
  // no es temporal: se queda.
  || rel.endsWith('.bpi');

// Dónde buscar el índice al restaurar, en orden. La tercera es la ubicación
// vieja: los respaldos hechos antes de este cambio la tienen ahí y tienen que
// seguir restaurándose, hoy y dentro de cinco años.
const clavesIndicePosibles = (prefijo, rutaRelativa) => [
  claveIndice(prefijo, rutaRelativa),
  claveIndiceCopia(prefijo, rutaRelativa),
  `${prefijo}${rutaRelativa}.bpi`,
];

// ─── Subir ───────────────────────────────────────────────────────────────────

/**
 * Sube un archivo por bloques.
 *
 * `almacen` tiene que ofrecer:
 *   existe(clave)                → boolean
 *   subirDatos(clave, buffer)    → sube un bloque
 *   subirTexto(clave, texto)     → sube el índice
 *
 * Devuelve cuántos bloques hubo que subir y cuántos ya estaban, que es
 * exactamente el ahorro.
 */
/**
 * Sube un archivo usando un plan de corte YA CONOCIDO.
 *
 * Solo se leen del disco los tramos de los bloques que faltan en el destino.
 * Para un archivo de 13 GB al que le falta el último 3%, eso son 400 MB leídos
 * en vez de 13 GB — y sin recalcular un solo corte.
 *
 * La huella de cada bloque leído se VERIFICA contra el plan antes de subirla.
 * Si no coincide, el archivo cambió por debajo sin que la fecha lo delatara, y
 * entonces se abandona el atajo: se devuelve `replanificar` y el llamador
 * recorre el archivo como siempre. Subir un bloque cuya huella no es la que
 * dice el plan armaría un archivo que no se puede rearmar.
 */
async function subirSegunPlan(almacen, {
  rutaArchivo, rutaRelativa, prefijo, alAvanzar, conocidos, plan, paralelo, st,
}) {
  const EN_PARALELO = Math.max(1, Number(paralelo) || 4);
  let nuevos = 0, reutilizados = 0, bytesSubidos = 0, leidos = 0;
  const enVuelo = new Set();
  let primerError = null;

  const esperarLugar = async (tope) => {
    while (enVuelo.size >= tope) {
      await Promise.race(enVuelo);
      if (primerError) throw primerError;
    }
    if (primerError) throw primerError;
  };

  const fd = await fsp.open(rutaArchivo, 'r');
  try {
    let desde = 0;
    for (const b of plan.bloques) {
      const bytes = Number(b.n);
      const huellaBloque = b.h;
      const inicio = desde;
      desde += bytes;

      if (conocidos.has(huellaBloque)) { reutilizados++; continue; }

      const clave = claveBloque(prefijo, huellaBloque);
      if (await almacen.existe(clave)) {
        conocidos.add(huellaBloque);
        reutilizados++;
        continue;
      }

      // Recién acá se toca el disco, y solo este tramo.
      const buf = Buffer.allocUnsafe(bytes);
      const { bytesRead } = await fd.read(buf, 0, bytes, inicio);
      leidos += bytesRead;
      const datos = bytesRead === bytes ? buf : buf.subarray(0, bytesRead);

      const comprobada = crypto.createHash('sha256').update(datos).digest('hex');
      if (comprobada !== huellaBloque) {
        // El plan ya no describe este archivo. Se corta el atajo sin subir
        // nada: es preferible releer entero que guardar un archivo que después
        // no se rearma.
        await esperarLugar(1);
        return { replanificar: true };
      }

      await esperarLugar(EN_PARALELO);
      conocidos.add(huellaBloque);
      const tarea = (async () => {
        await almacen.subirDatos(clave, datos, {
          archivo: encodeURIComponent(rutaRelativa),
          desde: inicio, bytes, total: st.size,
          subido: new Date().toISOString(),
          ...(plan.huella ? { huella: plan.huella } : {}),
        });
        nuevos++;
        bytesSubidos += bytes;
        if (alAvanzar) alAvanzar({ bytes: desde, total: st.size });
      })();
      const seguimiento = tarea
        .catch((e) => { if (!primerError) primerError = e; })
        .finally(() => enVuelo.delete(seguimiento));
      enVuelo.add(seguimiento);
    }
    await esperarLugar(1);
    if (primerError) throw primerError;
  } finally {
    await fd.close();
  }

  const indice = {
    formato: VERSION_FORMATO,
    archivo: rutaRelativa,
    bytes: st.size,
    mtimeMs: st.mtimeMs,
    huella: plan.huella || null,
    creado: new Date().toISOString(),
    bloques: plan.bloques.map((b) => ({ h: b.h, n: Number(b.n) })),
  };
  const texto = JSON.stringify(indice);
  await almacen.subirTexto(claveIndice(prefijo, rutaRelativa), texto);
  await almacen.subirTexto(claveIndiceCopia(prefijo, rutaRelativa), texto);

  return {
    bloques: plan.bloques.length, nuevos, reutilizados, bytesSubidos,
    bytesTotales: st.size, huella: plan.huella || null,
    segunPlan: true, bytesLeidos: leidos,
  };
}

async function subirPorBloques(almacen, {
  rutaArchivo, rutaRelativa, prefijo = '', alAvanzar, yaSubidos, huella,
  paralelo, huellaPrevia = null, planPrevio = null, alGuardarPlan = null,
}) {
  const st = await fsp.stat(rutaArchivo);
  const conocidos = yaSubidos || new Set();

  // ── El archivo grande que quedó a medio subir ────────────────────────────
  //
  // Este es EL caso de las imágenes ISO y los .rar de decenas de gigas. Con
  // 14,5 MB/s, 25 GB son ocho horas: una máquina de estudio se apaga a la
  // noche, Windows reinicia, o alguien corta el respaldo porque "tarda". El
  // archivo queda a medias y NO se anota en el registro, así que el chequeo
  // rápido no puede saltearlo.
  //
  // Hasta acá, cada corrida volvía a LEER Y TROCEAR el archivo entero para
  // descubrir algo que ya sabía: cómo se corta. Trocear va a ~85 MB/s, así que
  // 25 GB son cinco minutos de disco y CPU quemados en cada intento, todos los
  // días, para volver a calcular exactamente los mismos cortes.
  //
  // Ahora el plan de corte se guarda apenas se conoce. Si el archivo tiene el
  // mismo tamaño y la misma fecha, los cortes son los mismos: se saltea el
  // recorrido completo y se leen ÚNICAMENTE los tramos de los bloques que
  // faltan. Un archivo al que solo le falta el último 3% lee ese 3%, no el
  // 100%.
  //
  // El nivel de confianza es el mismo que ya usa el chequeo rápido para
  // saltear un archivo entero: tamaño y fecha. No se agrega ningún riesgo
  // nuevo.
  if (planPrevio && Array.isArray(planPrevio.bloques) && planPrevio.bloques.length
      && Number(planPrevio.bytes) === st.size
      && Math.abs(Number(planPrevio.mtimeMs) - st.mtimeMs) < 1000) {
    const r = await subirSegunPlan(almacen, {
      rutaArchivo, rutaRelativa, prefijo, alAvanzar, conocidos,
      plan: planPrevio, paralelo, st,
    });
    // `replanificar` significa que el contenido no era el que decía el plan.
    // Se sigue de largo y se recorre el archivo como siempre.
    if (!r.replanificar) return r;
  }

  // ── Una sola lectura del archivo ──
  //
  // La huella del archivo completo se conoce recién al terminar de recorrerlo,
  // pero iba en el metadato de CADA bloque, o sea que había que tenerla antes de
  // subir el primero. Eso forzaba una segunda lectura completa
  // (`huellaDeArchivo`), y con un PST de 651 MB que Outlook tiene tomado esa
  // segunda apertura es justo donde el respaldo se caía con EBUSY.
  //
  // Ahora, si no llega calculada, NO se lee de nuevo: los bloques se suben sin
  // ese campo y la huella queda en el índice, que se guarda en dos copias.
  //
  // Lo que se pierde: si alguna vez se pierden las DOS copias del índice y hay
  // que reconstruirlo desde los bloques, el índice reconstruido no va a poder
  // verificar integridad. El archivo se rearma igual, porque cada bloque
  // conserva `archivo`, `desde` y `bytes`. Es un intercambio a conciencia:
  // leer el archivo una sola vez vale más que un campo redundante con el índice.
  const huellaTotal = huella || null;

  let nuevos = 0, reutilizados = 0, bytesSubidos = 0;
  const bloques = [];
  let cursor = 0;

  // ── Varios bloques a la vez ──
  //
  // Antes esto era estrictamente secuencial: por cada bloque se esperaba el
  // `existe()` —un pedido a la red— y después la subida, y mientras tanto la
  // LECTURA DEL ARCHIVO SE FRENABA.
  //
  // Con un archivo de 300 MB son unos 75 bloques. A 100 ms de ida y vuelta
  // contra el almacenamiento, eso son 7,5 segundos gastados solo en preguntar si
  // cada bloque ya está — y se pagan igual en el respaldo incremental, donde no
  // se sube nada. Es la razón por la que un cliente con archivos de 150 a 300 MB
  // ve demoras aunque el segundo respaldo "no suba nada".
  //
  // Ahora el archivo se sigue leyendo y cortando mientras los bloques viajan.
  // El tope existe por memoria: cada bloque en vuelo son hasta 16 MB, así que
  // con 4 el pico son 64 MB. Subirlo más no acelera —la red se satura— y sí
  // arriesga la memoria en un equipo modesto, que es donde suele correr esto.
  const EN_PARALELO = Math.max(1, Number(paralelo) || 4);
  const enVuelo = new Set();
  let primerError = null;

  /** Espera a que haya lugar en el pool, y propaga el primer error que aparezca. */
  const esperarLugar = async (tope) => {
    while (enVuelo.size >= tope) {
      await Promise.race(enVuelo);
      if (primerError) throw primerError;
    }
    if (primerError) throw primerError;
  };

  const { huellaTotal: huellaDelRecorrido } = await recorrerBloques(rutaArchivo, async (datos, huellaBloque) => {
    const desde = cursor;
    cursor += datos.length;
    bloques.push({ desde, bytes: datos.length, huella: huellaBloque });

    // Repetido dentro del mismo archivo: no hace falta ni preguntar.
    if (conocidos.has(huellaBloque)) { reutilizados++; return; }
    conocidos.add(huellaBloque);

    await esperarLugar(EN_PARALELO);

    const clave = claveBloque(prefijo, huellaBloque);
    const tarea = (async () => {
      if (await almacen.existe(clave)) { reutilizados++; return; }
      const meta = {
        archivo: encodeURIComponent(rutaRelativa),
        desde,
        bytes: datos.length,
        total: st.size,
        subido: new Date().toISOString(),
      };
      // Solo si se conoce de antemano. No se lee el archivo de nuevo para tenerla.
      if (huellaTotal) meta.huella = huellaTotal;
      await almacen.subirDatos(clave, datos, meta);
      nuevos++;
      bytesSubidos += datos.length;
    })();

    // El primer error se guarda y corta todo: si un bloque no se pudo subir, el
    // archivo NO está respaldado y seguir sería mentirle al cliente.
    const seguimiento = tarea
      .catch((e) => { if (!primerError) primerError = e; })
      .finally(() => enVuelo.delete(seguimiento));
    enVuelo.add(seguimiento);
  }, alAvanzar);

  // Que terminen los que quedaron viajando antes de escribir el índice: un
  // índice que apunta a bloques que todavía no llegaron es un archivo que no se
  // puede rearmar.
  await esperarLugar(1);
  if (primerError) throw primerError;

  // La huella que calculó el recorrido, que es la misma que habría dado una
  // segunda lectura. Si llegó de antes se conserva, para no cambiar el valor de
  // archivos ya respaldados.
  const huellaFinal = huellaTotal || huellaDelRecorrido;

  // El plan de corte se avisa apenas se conoce, aunque la subida todavía no
  // haya terminado. Ese es justo el caso que hay que cubrir: si el respaldo se
  // corta a mitad de una ISO de 13 GB, la corrida de mañana no tiene que volver
  // a trocearla para descubrir los mismos cortes.
  if (alGuardarPlan) {
    try {
      await alGuardarPlan({
        bytes: st.size, mtimeMs: st.mtimeMs, huella: huellaFinal,
        bloques: bloques.map((b) => ({ h: b.huella, n: b.bytes })),
      });
    } catch { /* no poder guardar el plan no puede voltear el respaldo */ }
  }

  // ── El archivo al que solo le movieron la fecha ──
  //
  // Es el caso más común del producto, no una rareza: Outlook le toca la fecha
  // al PST todos los días sin que el contenido cambie, y lo mismo hace
  // cualquier programa que abre y cierra un archivo. Ahí el chequeo rápido por
  // tamaño y fecha falla y hay que recorrer el archivo — eso es inevitable, sin
  // leerlo no hay forma de saber que es el mismo.
  //
  // Lo que NO es inevitable es lo que venía después: se reescribía el índice
  // igual. Con versionado en el destino eso crea una versión nueva por corrida,
  // y como la retención tiene tope, **las versiones de índice van corriendo a
  // las versiones reales del archivo**: el cliente pide "volvé al lunes" y
  // encuentra treinta versiones idénticas de esta semana y ninguna del lunes.
  // Un archivo quieto no puede gastar historial.
  //
  // Solo se saltea si se cumplen las dos cosas: el contenido dio la misma
  // huella Y no hubo ningún bloque nuevo. Si subió aunque sea uno, el índice se
  // escribe igual, porque puede ser la reparación de un bloque que faltaba.
  if (huellaPrevia && huellaFinal === huellaPrevia && nuevos === 0) {
    return {
      bloques: bloques.length, nuevos: 0, reutilizados, bytesSubidos: 0,
      bytesTotales: st.size, huella: huellaFinal, sinCambios: true,
    };
  }

  const indice = armarIndice({
    rutaOriginal: rutaRelativa, bytes: st.size, mtimeMs: st.mtimeMs,
    huellaTotal: huellaFinal, bloques,
  });
  const texto = JSON.stringify(indice);

  // El índice va a DOS lugares: sin él, los bloques son pedazos anónimos y el
  // archivo no se puede rearmar. Las dos copias viven en ramas de servicio, no
  // mezcladas con los archivos del cliente.
  await almacen.subirTexto(claveIndice(prefijo, rutaRelativa), texto);
  await almacen.subirTexto(claveIndiceCopia(prefijo, rutaRelativa), texto);

  return {
    bloques: bloques.length, nuevos, reutilizados, bytesSubidos,
    bytesTotales: st.size, huella: huellaFinal,
  };
}

// ─── Restaurar ───────────────────────────────────────────────────────────────

/**
 * Rearma un archivo a partir de su índice.
 *
 * Verifica la huella del resultado antes de dar el archivo por bueno: si faltara
 * un bloque o llegara corrupto, es mejor fallar que entregar un archivo roto que
 * parece entero. En un respaldo, un archivo silenciosamente incompleto es peor
 * que no tener nada.
 *
 * `almacen` tiene que ofrecer:
 *   bajarTexto(clave)          → contenido del índice
 *   bajarDatos(clave)          → buffer de un bloque
 */
async function restaurarPorBloques(almacen, {
  rutaRelativa, destinoLocal, prefijo = '', versionIndice, alAvanzar,
}) {
  // Se prueban las tres ubicaciones en orden: la principal, la copia, y la
  // ubicación vieja pegada al archivo. La tercera existe porque los respaldos
  // hechos antes de la 0.9.9 la usan, y tienen que seguir restaurándose.
  let texto;
  let ultimoError = null;
  for (const clave of clavesIndicePosibles(prefijo, rutaRelativa)) {
    try {
      texto = await almacen.bajarTexto(clave, versionIndice);
      break;
    } catch (e) { ultimoError = e; }
  }
  if (texto === undefined) {
    throw new Error(
      `No se encontró el índice de "${rutaRelativa}" en ninguna de sus copias` +
      (ultimoError ? ` (${ultimoError.message})` : '') + '. ' +
      `Se puede reconstruir desde los bloques con la herramienta de reconstrucción.`);
  }
  const indice = leerIndice(texto);

  await fsp.mkdir(path.dirname(destinoLocal), { recursive: true });
  const temporal = `${destinoLocal}.bp-tmp-${process.pid}-${Date.now()}`;
  const verificador = crypto.createHash('sha256');
  let escritos = 0;

  try {
    const salida = fs.createWriteStream(temporal);
    for (let i = 0; i < indice.bloques.length; i++) {
      const b = indice.bloques[i];
      const datos = await almacen.bajarDatos(claveBloque(prefijo, b.h));

      if (datos.length !== b.n) {
        throw new Error(
          `Un bloque de "${rutaRelativa}" llegó con otro tamaño ` +
          `(esperaba ${b.n}, llegó ${datos.length}). No se restaura un archivo incompleto.`);
      }
      verificador.update(datos);
      escritos += datos.length;

      if (!salida.write(datos)) {
        await new Promise((r) => salida.once('drain', r));
      }
      if (alAvanzar) alAvanzar(i + 1, indice.bloques.length, escritos, indice.bytes);
    }
    await new Promise((resolver, rechazar) => {
      salida.on('error', rechazar);
      salida.end(resolver);
    });

    const obtenida = verificador.digest('hex');
    if (!indice.huella) {
      // Índice reconstruido: no hay con qué comparar. Se entrega el archivo pero
      // se avisa, en lugar de decir que se verificó algo que no se verificó.
      await fsp.rename(temporal, destinoLocal);
      return {
        bytes: escritos, bloques: indice.bloques.length, huella: obtenida,
        sinVerificar: true,
      };
    }
    if (obtenida !== indice.huella) {
      throw new Error(
        `El archivo rearmado de "${rutaRelativa}" no coincide con el original. ` +
        `No se entrega un archivo que podría estar corrupto.`);
    }
    if (escritos !== indice.bytes) {
      throw new Error(`El archivo rearmado mide ${escritos} y debería medir ${indice.bytes}.`);
    }

    await fsp.rename(temporal, destinoLocal);
    return { bytes: escritos, bloques: indice.bloques.length, huella: obtenida };
  } catch (e) {
    try { await fsp.unlink(temporal); } catch {}
    throw e;
  }
}

// ─── Limpieza de bloques sueltos ─────────────────────────────────────────────

/**
 * Borra los bloques que ya no usa ningún índice.
 *
 * Es la operación más delicada de todo esto: borrar un bloque que todavía se
 * usa deja un archivo imposible de restaurar, y nadie se enteraría hasta el día
 * que haga falta. Por eso:
 *
 *   · Se juntan las huellas de TODOS los índices, incluidas las versiones
 *     anteriores que todavía están dentro del período de retención.
 *   · Solo se borra un bloque si no aparece en ninguno.
 *   · Y solo si es más viejo que `diasDeGracia`, para no borrar un bloque que
 *     acaba de subir un respaldo que todavía no terminó de escribir su índice.
 *
 * Devuelve qué se borraría o se borró, según `simular`.
 */
async function limpiarBloquesSueltos(almacen, {
  prefijo = '', diasDeGracia = 7, simular = true, alAvanzar,
} = {}) {
  const usados = new Set();

  const indices = await almacen.listarIndices(prefijo);
  for (const ind of indices) {
    for (const version of (ind.versiones || [null])) {
      try {
        const texto = await almacen.bajarTexto(ind.clave, version);
        for (const b of leerIndice(texto).bloques) usados.add(b.h);
      } catch {
        // Un índice que no se puede leer se trata como si usara todo: es mejor
        // no borrar nada que borrar de más.
        return {
          error: `No se pudo leer el índice ${ind.clave}. No se borra nada por precaución.`,
          borrados: 0, revisados: 0,
        };
      }
    }
  }

  const bloques = await almacen.listarBloques(prefijo);
  const corte = Date.now() - diasDeGracia * 86400000;

  let borrados = 0, liberados = 0, revisados = 0;
  for (const b of bloques) {
    revisados++;
    const huella = b.clave.split('/').pop();
    if (usados.has(huella)) continue;
    if (b.fecha && new Date(b.fecha).getTime() > corte) continue;

    if (!simular) await almacen.borrar(b.clave);
    borrados++;
    liberados += b.bytes || 0;
    if (alAvanzar) alAvanzar(borrados, liberados);
  }

  return { revisados, borrados, liberados, usados: usados.size, simulado: simular };
}


/**
 * Reconstruye los índices perdidos a partir de los metadatos de los bloques.
 *
 * Es el último recurso: se usa cuando se perdieron el índice y su copia. Puede
 * hacerlo porque cada bloque guarda a qué archivo pertenece, en qué posición,
 * cuántos son en total y la huella del archivo completo.
 *
 * Lo importante es que el resultado es **verificable**. Se rearma el archivo en
 * memoria, se calcula su huella y se compara con la que quedó anotada en los
 * bloques. Si no coincide, no se escribe nada: un índice inventado que produce
 * un archivo corrupto es peor que no tener índice, porque el cliente creería
 * que recuperó sus datos.
 *
 * Con `simular: true` informa qué se podría recuperar sin tocar nada.
 */
async function reconstruirIndices(almacen, { prefijo = '', simular = true, alAvanzar } = {}) {
  const bloques = await almacen.listarBloques(prefijo);
  const porArchivo = new Map();

  let revisados = 0;
  for (const b of bloques) {
    revisados++;
    if (alAvanzar) alAvanzar(revisados, bloques.length);

    let meta;
    try { meta = await almacen.leerMeta(b.clave); } catch { continue; }
    if (!meta || !meta.archivo) continue;

    let ruta;
    try { ruta = decodeURIComponent(meta.archivo); } catch { ruta = meta.archivo; }

    if (!porArchivo.has(ruta)) porArchivo.set(ruta, { total: 0, piezas: [] });
    const dato = porArchivo.get(ruta);
    const total = Number(meta.total) || 0;
    dato.total = Math.max(dato.total, total);
    dato.piezas.push({
      h: b.clave.split('/').pop(),
      desde: Number(meta.desde) || 0,
      n: Number(meta.bytes) || b.bytes || 0,
      total,
      huella: meta.huella || null,
    });
  }

  const recuperados = [];
  const incompletos = [];

  for (const [ruta, dato] of porArchivo) {
    // Un bloque puede haber sido escrito por una versión anterior del archivo y
    // reutilizado por la actual: en ese caso su "total" quedó viejo. Cuando dos
    // bloques reclaman la misma posición, gana el que corresponde a la versión
    // más grande, que es la última.
    const porPosicion = new Map();
    for (const p of dato.piezas) {
      const previo = porPosicion.get(p.desde);
      if (!previo || (p.total === dato.total && previo.total !== dato.total)) {
        porPosicion.set(p.desde, p);
      }
    }

    const ordenados = [...porPosicion.values()].sort((a, b) => a.desde - b.desde);

    // Los bloques tienen que cubrir el archivo entero, sin huecos ni solapes.
    let cursor = 0;
    let hueco = null;
    for (const p of ordenados) {
      if (p.desde !== cursor) { hueco = { esperaba: cursor, encontro: p.desde }; break; }
      cursor += p.n;
    }

    if (hueco || cursor !== dato.total) {
      incompletos.push({
        archivo: ruta,
        motivo: hueco
          ? `los bloques no encajan: en la posición ${hueco.esperaba} aparece uno que ` +
            `empieza en ${hueco.encontro}. Suele pasar cuando al archivo le insertaron ` +
            `contenido y los bloques reutilizados quedaron con la posición vieja.`
          : `los bloques cubren ${cursor} de ${dato.total} bytes`,
        encontrados: ordenados.length,
      });
      continue;
    }

    // Y tienen que reproducir exactamente el archivo original.
    const esperada = (ordenados.find((p) => p.total === dato.total) || {}).huella;
    const verificador = crypto.createHash('sha256');
    let error = null;
    try {
      for (const p of ordenados) {
        verificador.update(await almacen.bajarDatos(claveBloque(prefijo, p.h)));
      }
    } catch (e) { error = e.message; }

    if (error) {
      incompletos.push({ archivo: ruta, motivo: `no se pudieron leer los bloques: ${error}` });
      continue;
    }

    const obtenida = verificador.digest('hex');
    if (esperada && obtenida !== esperada) {
      incompletos.push({
        archivo: ruta,
        motivo: 'los bloques encontrados no reproducen el archivo original. ' +
                'No se escribe un índice que daría un archivo corrupto.',
      });
      continue;
    }

    if (!simular) {
      const texto = JSON.stringify({
        formato: VERSION_FORMATO,
        archivo: ruta,
        bytes: dato.total,
        mtimeMs: 0,
        huella: obtenida,
        creado: new Date().toISOString(),
        reconstruido: true,
        bloques: ordenados.map((p) => ({ h: p.h, n: p.n })),
      });
      await almacen.subirTexto(claveIndice(prefijo, ruta), texto);
      await almacen.subirTexto(claveIndiceCopia(prefijo, ruta), texto);
    }

    recuperados.push({ archivo: ruta, bloques: ordenados.length, bytes: dato.total });
  }

  return { recuperados, incompletos, simulado: simular, bloquesRevisados: revisados };
}

/**
 * Revisa que todos los archivos guardados por bloques se puedan restaurar.
 *
 * Es lo que detecta un problema ANTES de que el cliente lo necesite. Sin esto,
 * uno se entera el peor día posible: cuando alguien perdió sus datos y viene a
 * buscarlos.
 */
async function verificarIndices(almacen, { prefijo = '', alAvanzar } = {}) {
  const indices = await almacen.listarIndices(prefijo);
  const existentes = new Set(
    (await almacen.listarBloques(prefijo)).map((b) => b.clave.split('/').pop()));

  const conProblemas = [];
  let sanos = 0, revisados = 0;

  // Cada archivo tiene dos copias de su índice: se revisa una vez por archivo,
  // prefiriendo la de indices/ y usando la de al lado si esa falta.
  const porArchivo = new Map();
  for (const ind of indices) {
    if (ind.clave.endsWith('_catalogo.json')) continue;
    const logico = ind.clave
      .replace(new RegExp(`^${prefijo.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\\\$&')}`), '')
      .replace(/^indices-copia\//, '')
      .replace(/^indices\//, '')
      .replace(/\.bpi$/, '');
    const esPrincipal = ind.clave.includes('/indices/') || ind.clave.startsWith(`${prefijo}indices/`);
    if (!porArchivo.has(logico) || esPrincipal) porArchivo.set(logico, ind);
  }

  for (const ind of porArchivo.values()) {
    revisados++;
    if (alAvanzar) alAvanzar(revisados, porArchivo.size);

    let indice;
    try {
      indice = leerIndice(await almacen.bajarTexto(ind.clave));
    } catch (e) {
      conProblemas.push({ archivo: ind.clave, problema: `no se pudo leer el índice: ${e.message}` });
      continue;
    }

    const faltan = indice.bloques.filter((b) => !existentes.has(b.h));
    if (faltan.length) {
      conProblemas.push({
        archivo: indice.archivo,
        problema: `faltan ${faltan.length} de ${indice.bloques.length} bloques`,
      });
    } else {
      sanos++;
    }
  }

  return { sanos, revisados, conProblemas, todoBien: conProblemas.length === 0 };
}

module.exports = {
  partir, recorrerBloques, armarIndice, leerIndice, claveBloque, claveIndice,
  claveIndiceCopia, clavesIndicePosibles, esRutaDeServicio,
  subirPorBloques, restaurarPorBloques, limpiarBloquesSueltos,
  reconstruirIndices, verificarIndices,
  MINIMO, OBJETIVO, MAXIMO, VERSION_FORMATO,
};
