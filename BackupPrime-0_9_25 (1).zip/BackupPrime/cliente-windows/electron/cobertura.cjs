'use strict';
// ---------------------------------------------------------------------------
// Qué archivos guardados sigue cubriendo el trabajo de hoy.
//
// El problema: cuando alguien saca una carpeta del respaldo, o renombra un
// directorio, lo que ya se subió queda en la nube. Se puede restaurar —la
// pantalla de Restaurar lee el destino, no el trabajo— pero **no está marcado**.
// El cliente ve un archivo y no sabe si se sigue respaldando o si su última
// copia es de marzo. Esa confusión es la peor que puede tener un producto de
// respaldo: creer que algo está protegido cuando hace meses que no se toca.
//
// Este módulo no borra ni mueve nada. Solo marca.
//
// La comparación se hace en el espacio del DESTINO y no en rutas de Windows.
// `rutaEnDestino("C:\\Users\\ana\\x.pst")` da `C/Users/ana/x.pst`, es
// determinística, y así no hay que reconstruir barras invertidas ni letras de
// unidad al revés — que es donde se cometen los errores.
// ---------------------------------------------------------------------------

/** Normaliza para comparar: barras iguales, sin barra final, sin duplicados. */
function normalizar(rel) {
  return String(rel || '')
    .replace(/\\/g, '/')
    .replace(/\/+/g, '/')
    .replace(/^\/+|\/+$/g, '');
}

/** ¿`hijo` está dentro de `padre`? Compara por segmentos, no por texto. */
function estaDentroDe(hijo, padre) {
  const h = normalizar(hijo), p = normalizar(padre);
  if (!p) return false;
  if (h === p) return true;
  // Por segmentos a propósito: "C/Datos2" NO está dentro de "C/Datos", aunque
  // como texto empiece igual. Ese error borraría de la lista cosas que sí se
  // respaldan, o al revés.
  return h.startsWith(p + '/');
}

/**
 * ¿El trabajo actual cubre este archivo guardado?
 *
 * @param {string} rel        ruta en el destino, ej. "C/Users/ana/x.pst"
 * @param {string[]} carpetas carpetas del trabajo, ya en espacio de destino
 * @param {string[]} excluidas exclusiones, ya en espacio de destino
 */
function estaCubierto(rel, carpetas, excluidas) {
  const r = normalizar(rel);
  if (!r) return false;
  for (const ex of excluidas || []) {
    if (estaDentroDe(r, ex)) return false;
  }
  for (const c of carpetas || []) {
    if (estaDentroDe(r, c)) return true;
  }
  return false;
}

/**
 * Marca el catálogo y devuelve el resumen para la pantalla y el portal.
 *
 * Las entradas NO se borran ni se reordenan: se les agrega `cubierto` y, cuando
 * dejan de estarlo, `fueraDesde` con la fecha en que se notó. Esa fecha se
 * conserva entre corridas: sirve para decir "hace 3 meses que no se respalda".
 *
 * Baranda: si el trabajo no declara ninguna carpeta, NO se marca nada como
 * fuera. Un trabajo vacío es casi siempre una configuración que no cargó o un
 * disco que no montó, y marcar todo como fuera del respaldo asustaría al
 * cliente con un problema que no existe.
 */
function marcarCatalogo(catalogo, opciones = {}) {
  const carpetas = (opciones.carpetas || []).map(normalizar).filter(Boolean);
  const excluidas = (opciones.excluidas || []).map(normalizar).filter(Boolean);
  const ahora = opciones.ahora == null ? Date.now() : Number(opciones.ahora);

  const entradas = Object.entries(catalogo || {});
  const resumen = {
    total: entradas.length, cubiertos: 0, fuera: 0,
    bytesCubiertos: 0, bytesFuera: 0, masViejoFueraMs: null,
    sinCarpetas: carpetas.length === 0,
  };

  if (!entradas.length) return { catalogo: catalogo || {}, resumen };

  // Sin carpetas declaradas no se toca nada: se conserva la marca anterior.
  if (!carpetas.length) {
    for (const [, datos] of entradas) {
      const bytes = Number(datos && datos.bytes) || 0;
      if (datos && datos.cubierto === false) { resumen.fuera++; resumen.bytesFuera += bytes; }
      else { resumen.cubiertos++; resumen.bytesCubiertos += bytes; }
    }
    return { catalogo, resumen };
  }

  const salida = {};
  for (const [rel, datos] of entradas) {
    const bytes = Number(datos && datos.bytes) || 0;
    const cubierto = estaCubierto(rel, carpetas, excluidas);
    const entrada = { ...datos, cubierto };

    if (cubierto) {
      // Volvió al respaldo: se limpia la marca. Pasa cuando alguien vuelve a
      // agregar una carpeta que había sacado.
      delete entrada.fueraDesde;
      resumen.cubiertos++;
      resumen.bytesCubiertos += bytes;
    } else {
      // La fecha se conserva: la primera vez que se notó, no la de hoy.
      entrada.fueraDesde = datos && datos.fueraDesde ? datos.fueraDesde : ahora;
      resumen.fuera++;
      resumen.bytesFuera += bytes;
      if (resumen.masViejoFueraMs === null || entrada.fueraDesde < resumen.masViejoFueraMs) {
        resumen.masViejoFueraMs = entrada.fueraDesde;
      }
    }
    salida[rel] = entrada;
  }

  return { catalogo: salida, resumen };
}

/** Una línea para la pantalla. Sin números sueltos que nadie entiende. */
function explicarResumen(resumen, formatearBytes) {
  if (!resumen || !resumen.fuera) return null;
  const tam = formatearBytes ? formatearBytes(resumen.bytesFuera) : `${resumen.bytesFuera} bytes`;
  return `${resumen.fuera} archivo(s) guardados (${tam}) ya no están en el respaldo actual. ` +
         'Los podés restaurar, pero no se están actualizando.';
}

module.exports = { marcarCatalogo, estaCubierto, estaDentroDe, normalizar, explicarResumen };
