"use strict";

const { app, BrowserWindow, Tray, Menu, nativeImage, ipcMain, dialog, Notification, safeStorage, nativeTheme } = require("electron");
const path = require("node:path");
const fs = require("node:fs");
const fsp = require("node:fs/promises");
const os = require("node:os");
const https = require("node:https");
const http = require("node:http");

const { BackupEngine, getConfigDir } = require(path.join(__dirname, "backup-engine.cjs"));

// Evita que el usuario abra dos instancias de la app al mismo tiempo:
// dos instancias corriendo el mismo backup en paralelo pueden pisarse la
// escritura de state.json y duplicar subidas.
const gotSingleInstanceLock = app.requestSingleInstanceLock();
if (!gotSingleInstanceLock) {
  app.quit();
} else {
  app.on("second-instance", () => {
    // El usuario intentó abrir la app de nuevo: le mostramos la que ya corre
    showWindow();
  });
}

let mainWindow = null;
let tray = null;
const engine = new BackupEngine();
let logBuffer = [];

// ─── Config ───────────────────────────────────────────────────────────────────

function configFilePath() {
  const dir = getConfigDir();
  fs.mkdirSync(dir, { recursive: true });
  return path.join(dir, "config.json");
}

// El token de agente es la credencial más sensible que maneja el cliente:
// si config.json se filtra (backup mal configurado, malware, etc.) no debería
// quedar legible. safeStorage usa el llavero del SO (DPAPI en Windows,
// Keychain en macOS, kwallet/libsecret en Linux). Si no está disponible
// (ej. Linux sin keyring), avisamos por consola y caemos a texto plano
// en vez de romper la app.
function canEncrypt() {
  try { return safeStorage.isEncryptionAvailable(); } catch { return false; }
}

function encryptToken(token) {
  if (!token) return { tokenEncrypted: null, token: null };
  if (canEncrypt()) {
    return { tokenEncrypted: safeStorage.encryptString(token).toString("base64"), token: undefined };
  }
  console.warn("[BackupPrime] El cifrado seguro no está disponible en este sistema; el token se guardará en texto plano.");
  return { tokenEncrypted: null, token };
}

function decryptToken(c) {
  if (c.tokenEncrypted && canEncrypt()) {
    try { return safeStorage.decryptString(Buffer.from(c.tokenEncrypted, "base64")); }
    catch { return ""; }
  }
  return c.token || "";
}

// El servidor al que se conecta el programa. Viene puesto para que el cliente
// solo tenga que escribir su email y su contraseña: un campo menos donde
// equivocarse, y una llamada menos a soporte. Se puede cambiar desde
// Configuración avanzada para pruebas o instalaciones a medida.
const SERVIDOR_POR_DEFECTO = "https://backupprime.com";

function readConfig() {
  const p = configFilePath();
  if (!fs.existsSync(p)) return {};
  try { return JSON.parse(fs.readFileSync(p, "utf8")); } catch { return {}; }
}

// Escritura atómica: si el proceso muere a mitad de la escritura (crash,
// corte de luz, kill -9), el archivo original queda intacto en vez de
// quedar truncado/corrupto.
function writeConfig(patch) {
  const p = configFilePath();
  let next = { ...readConfig(), ...patch };

  if (Object.prototype.hasOwnProperty.call(patch, "token")) {
    const { tokenEncrypted, token } = encryptToken(patch.token);
    delete next.token;
    if (token !== undefined) next.token = token;
    next.tokenEncrypted = tokenEncrypted;
  }

  const tmp = `${p}.tmp-${process.pid}`;
  fs.writeFileSync(tmp, JSON.stringify(next, null, 2), { mode: 0o600 });
  fs.renameSync(tmp, p);
  return next;
}

function buildEngineConfig() {
  const c = readConfig();
  return {
    server: c.server || SERVIDOR_POR_DEFECTO,
    token: decryptToken(c),
    localPaths: Array.isArray(c.localPaths) ? c.localPaths : [],
    excludedPaths: Array.isArray(c.excludedPaths) ? c.excludedPaths : [],
    destinations: Array.isArray(c.destinations) ? c.destinations : [],
    schedule: c.schedule || { mode: "interval", intervalMins: 60 },
    maxVersions: Math.min(30, Number(c.maxVersions) || 10),
    concurrencia: Math.min(32, Math.max(1, Number(c.concurrencia) || 6)),
    umbralBloquesMB: Math.min(2048, Math.max(1, Number(c.umbralBloquesMB) || 25)),
    forceFullBackup: false,
    systemBackup: !!c.systemBackup,
  };
}

// ─── Engine event forwarding ──────────────────────────────────────────────────

// La ventana puede estar liberada (cerrada a la bandeja): en ese caso no
// hay a quién avisar, pero el log se sigue guardando en memoria para
// mostrarlo cuando el usuario vuelva a abrirla.
function enviarAlRenderer(canal, dato) {
  if (mainWindow && !mainWindow.isDestroyed()) {
    try { mainWindow.webContents.send(canal, dato); } catch {}
  }
}

function logLine(texto) {
  const linea = texto.endsWith("\n") ? texto : texto + "\n";
  logBuffer.push(linea);
  if (logBuffer.length > 500) logBuffer = logBuffer.slice(-500);
  enviarAlRenderer("agent:log", linea);
}

engine.on("log", (text) => logLine(text));


// ─── Blindaje de la comunicación con la ventana ───────────────────────────────
//
// Cuando la pantalla le pide algo al proceso principal y ese pedido no
// contesta, Electron muestra "reply was never sent": un mensaje que no dice
// nada del problema real y deja el cartel de progreso girando para siempre.
//
// Pasa por tres motivos, y los tres se tapan acá:
//   · el manejador lanza algo que no es un Error y Electron no puede mandarlo;
//   · devuelve un objeto que no se puede serializar (una función, un socket);
//   · o algo revienta fuera del try y la promesa queda colgada.
//
// Ahora todo manejador contesta siempre, y el error de verdad queda en la
// pestaña Actividad en vez de perderse.

const manejarOriginal = ipcMain.handle.bind(ipcMain);

/** Deja el valor en algo que se pueda mandar a la ventana. */
function serializable(valor) {
  if (valor === undefined) return null;
  try {
    return JSON.parse(JSON.stringify(valor));
  } catch {
    return { ok: false, error: "La respuesta no se pudo transmitir a la pantalla." };
  }
}

ipcMain.handle = (canal, manejador) => manejarOriginal(canal, async (evento, ...args) => {
  try {
    return serializable(await manejador(evento, ...args));
  } catch (e) {
    const mensaje = (e && e.message) ? e.message : String(e);
    logLine(`[error] Falló "${canal}": ${mensaje}`);
    if (e && e.stack) console.error(`[${canal}]`, e.stack);
    return { ok: false, error: mensaje };
  }
});

// ─── Que un error suelto no mate el programa ──────────────────────────────────
//
// Este programa está prendido todo el día. Si algo revienta fuera de un try
// —un socket que emite un error tarde, una promesa que nadie atendió— Node
// termina el proceso, y el usuario se queda sin respaldo sin enterarse. Para un
// programa de backup, seguir vivo y dejar constancia es mejor que desaparecer
// en silencio.

process.on("uncaughtException", (e) => {
  console.error("[excepción sin atrapar]", e && e.stack);
  try {
    logLine(`[error] Error inesperado: ${e && e.message}. El programa sigue andando.`);
  } catch {}
});

process.on("unhandledRejection", (e) => {
  console.error("[promesa sin atender]", e);
  try {
    logLine(`[error] Operación fallida sin atender: ${(e && e.message) || e}`);
  } catch {}
});

/* ── El guardia anti-ransomware disparó ────────────────────────────────────
   Esto NO es un aviso más. El respaldo ya se frenó solo; lo que falta es que el
   cliente se entere ya mismo y que quede registrado del lado del servidor, para
   que Ariel lo vea aunque el cliente ignore la notificación.

   Se avisa siempre, sin respetar el modo de avisos ni el horario de silencio:
   un cifrado masivo a las tres de la mañana es exactamente cuando hay que
   despertar a alguien. */
engine.on("ransomware", async (informe) => {
  const motivos = (informe.motivos || []).join(" · ");
  logLine(`[ALERTA] Respaldo frenado por sospecha de cifrado masivo: ${motivos}`);

  if (Notification.isSupported()) {
    new Notification({
      title: "BackupPrime frenó el respaldo",
      body: "Muchos archivos cambiaron de golpe y parecen cifrados. Puede ser " +
            "ransomware. Tus copias anteriores están a salvo: no vamos a subir " +
            "nada más hasta que revises el equipo.",
      urgency: "critical",
      silent: false,
    }).show();
  }

  enviarAlRenderer("ransomware", informe);

  try {
    await pedirAlServidor("POST", "/api/agent/alerta", {
      deviceName: readConfig().deviceName || os.hostname(),
      tipo: "ransomware",
      motivos: informe.motivos || [],
      señales: informe.señales || {},
    });
  } catch (e) {
    // Que no se pueda avisar al servidor no puede tapar la alerta local.
    logLine(`[error] No se pudo avisar al servidor: ${e.message}`);
  }
});

engine.on("status", (s) => {
  enviarAlRenderer("agent:status", s);
});

// Progreso en vivo del backup: qué archivo va, cuántos faltan, a qué velocidad
engine.on("progreso", (p) => {
  enviarAlRenderer("agent:progreso", p);
});

// ─── Avisos del sistema ───────────────────────────────────────────────────────
//
// Antes avisaba de cada respaldo terminado. Si respalda cada hora y el usuario
// deja la máquina prendida el fin de semana, el lunes se encuentra con treinta
// carteles apilados que hay que cerrar de a uno. Un aviso que aparece siempre
// deja de ser un aviso: se vuelve ruido, y el día que aparece uno importante
// nadie lo mira.
//
// Ahora hay tres modos, y el que viene puesto de fábrica es "solo problemas".

const MODOS_AVISO = ["todos", "problemas", "ninguno"];
const avisosRecientes = new Map();   // clave -> cuándo se avisó
const HORAS_SIN_REPETIR = 6;

function enSilencio(cfg) {
  const desde = cfg.silencioDesde, hasta = cfg.silencioHasta;
  if (!desde || !hasta) return false;
  const ahora = new Date();
  const minutos = ahora.getHours() * 60 + ahora.getMinutes();
  const aMin = (t) => {
    const [h, m] = String(t).split(":").map(Number);
    return (h || 0) * 60 + (m || 0);
  };
  const d = aMin(desde), h = aMin(hasta);
  // El rango puede cruzar la medianoche (22:00 a 08:00).
  return d <= h ? (minutos >= d && minutos < h) : (minutos >= d || minutos < h);
}

/**
 * Muestra un aviso, salvo que corresponda callarse.
 *
 * `clave` sirve para no repetir el mismo problema una y otra vez: si el disco
 * externo está desenchufado y el respaldo corre cada hora, alcanza con avisar
 * una vez cada seis horas, no veinticuatro veces por día.
 */
function avisar({ titulo, cuerpo, urgente = false, clave = null }) {
  if (!Notification.isSupported()) return;

  const cfg = readConfig();
  const modo = MODOS_AVISO.includes(cfg.avisos) ? cfg.avisos : "problemas";

  if (modo === "ninguno") return;
  if (modo === "problemas" && !urgente) return;
  if (enSilencio(cfg)) return;

  if (clave) {
    const ultimo = avisosRecientes.get(clave) || 0;
    if (Date.now() - ultimo < HORAS_SIN_REPETIR * 3600e3) return;
    avisosRecientes.set(clave, Date.now());
  }

  new Notification({
    title: titulo,
    body: cuerpo,
    urgency: urgente ? "critical" : "low",
    silent: !urgente,   // los avisos comunes no hacen ruido
  }).show();
}

/**
 * Llamada al servidor de BackupPrime con el token del equipo.
 *
 * Existía la lógica suelta dentro de `agent:login`; esto la deja disponible para
 * el resto de las llamadas (consumo del plan, y lo que venga) sin repetirla.
 */
function pedirAlServidor(metodo, ruta, cuerpo) {
  const c = readConfig();
  const base = String(c.server || SERVIDOR_POR_DEFECTO).replace(/\/+$/, "");
  const token = decryptToken(c);
  const parsed = new URL(base + ruta);
  const mod = parsed.protocol === "https:" ? https : http;
  const datos = cuerpo === undefined ? null : JSON.stringify(cuerpo);

  return new Promise((resolve, reject) => {
    const req = mod.request({
      hostname: parsed.hostname,
      port: parsed.port || (parsed.protocol === "https:" ? 443 : 80),
      path: parsed.pathname + parsed.search,
      method: metodo,
      headers: {
        ...(datos ? {
          "Content-Type": "application/json",
          "Content-Length": Buffer.byteLength(datos),
        } : {}),
        ...(token ? { Authorization: "Bearer " + token } : {}),
      },
      timeout: 20000,
    }, (res) => {
      const partes = [];
      res.on("data", (c) => partes.push(c));
      res.on("end", () => {
        let body = {};
        try { body = JSON.parse(Buffer.concat(partes).toString("utf8")); } catch {}
        if (res.statusCode >= 200 && res.statusCode < 300) return resolve(body);
        reject(new Error(body.error || body.mensaje || `El servidor respondió ${res.statusCode}`));
      });
    });
    req.on("timeout", () => { req.destroy(); reject(new Error("El servidor no respondió a tiempo")); });
    req.on("error", reject);
    if (datos) req.write(datos);
    req.end();
  });
}

const {
  destKey: claveDestino, SesionFtp,
  s3Listar, s3Versiones, s3Descargar, sftpListar, sftpDescargarVarios, rutaEnDestino,
  almacenDeBloques,
} = require(path.join(__dirname, "backup-engine.cjs"));

// ─── Consumo del plan ────────────────────────────────────────────────────────
//
// Se mide el tamaño LÓGICO: lo que suman los archivos del cliente MÁS sus
// versiones, como si no existiera la deduplicación. Es la decisión de producto:
// el cliente entiende ese número y lo puede verificar mirando sus carpetas,
// mientras que "lo que ocupa realmente" cambia solo según cuánto se repitan los
// datos y no se puede explicar por teléfono.
//
// Se lee del destino, no del registro local, por dos razones: el registro no
// sabe de versiones, y el destino es la única fuente que dice qué hay guardado
// de verdad. Son dos o tres pedidos por respaldo, así que el costo es menor.
async function medirConsumo(dest) {
  const versiones = await s3Versiones(dest, dest.prefix || "");
  let bytes = 0;
  let archivos = 0;
  for (const [, lista] of versiones) {
    // Cada versión ocupa. Es lo que se le cobra al cliente y es lo que dice el
    // texto del plan: "hasta 30 versiones por archivo".
    const vivas = lista.filter((v) => !v.borrado);
    if (!vivas.length) continue;
    archivos++;
    for (const v of vivas) bytes += Number(v.bytes) || 0;
  }
  return { bytes, archivos };
}

/**
 * Le informa al servidor cuánto ocupa este equipo y devuelve el estado del plan.
 *
 * Se manda el total ABSOLUTO, no la diferencia: con diferencias, un aviso
 * perdido o repetido desajusta la cuenta para siempre y nadie se entera hasta
 * que el número no cierra con la factura.
 */
async function informarConsumo() {
  const c = readConfig();
  const token = decryptToken(c);
  if (!c.server || !token) return null;

  const dest = (c.destinations || []).find((d) => d.type === "s3" && d.enabled !== false);
  if (!dest) return null;

  try {
    const { bytes, archivos } = await medirConsumo(dest);
    // Va también cuánto de lo guardado ya no cubre el trabajo actual. Sin
    // esto, el programa mostraría un número y el portal otro, y el cliente
    // dejaría de creerle a los dos.
    const cobertura = engine._cobertura || null;
    const respuesta = await pedirAlServidor("POST", "/api/agent/uso", {
      deviceName: c.deviceName || os.hostname(), bytes, archivos,
      fueraDelRespaldo: cobertura ? {
        archivos: cobertura.fuera,
        bytes: cobertura.bytesFuera,
        desdeMs: cobertura.masViejoFueraMs,
      } : null,
    });
    if (respuesta && respuesta.cuota) {
      ultimaCuota = { ...respuesta.cuota, mensaje: respuesta.mensaje || null,
                      plan: c.plan || null, planEspacioGB: c.planEspacioGB || null };
      enviarAlRenderer("cuota", ultimaCuota);
      // Si el respaldo quedó frenado por falta de espacio, hay que avisar de
      // verdad: es lo único que evita que el cliente se entere el día que
      // necesita restaurar algo que nunca se subió.
      if (ultimaCuota.estado === "frenado") {
        avisar({
          titulo: "BackupPrime — se llenó tu espacio",
          cuerpo: respuesta.mensaje || "Los respaldos nuevos están en pausa.",
          urgente: true, clave: "cuota-llena",
        });
      }
    }
    return ultimaCuota;
  } catch (e) {
    logLine(`[aviso] No se pudo consultar el espacio de tu plan: ${e.message}\n`);
    return null;
  }
}

let ultimaCuota = null;

ipcMain.handle("cuota:consultar", async () => {
  // El botón "consultar" de la pantalla. Vuelve a medir y a preguntar, para que
  // el cliente pueda verificar en el momento en lugar de esperar al próximo
  // respaldo.
  const r = await informarConsumo();
  return r || ultimaCuota || { estado: "desconocido" };
});

/* La cuota se consulta AL ARRANCAR, no solo después de un respaldo.
 *
 * Antes `ultimaCuota` arrancaba en null y la tarjeta de espacio quedaba oculta
 * hasta que corriera un respaldo. Un cliente abría el programa y no tenía forma
 * de saber cuánto espacio usaba ni qué plan tenía. */
async function refrescarCuota() {
  const c = readConfig();
  if (!c.token || !c.server) return null;
  try {
    const r = await pedirAlServidor("GET", "/api/agent/cuota");
    if (r && r.cuota) {
      ultimaCuota = { ...r.cuota, mensaje: r.mensaje || null,
                      plan: c.plan || null, planEspacioGB: c.planEspacioGB || null };
      enviarAlRenderer("cuota", ultimaCuota);
    }
  } catch { /* sin conexión: la tarjeta muestra lo último que se supo */ }
  return ultimaCuota;
}

ipcMain.handle("cuota:ultima", async () => ultimaCuota || await refrescarCuota());

// Lo último que se supo de la verificación. La ventana se cierra a la bandeja y
// se vuelve a crear: sin esto, al reabrirla el cliente vería la franja vacía
// aunque el respaldo hubiera verificado hace cinco minutos.
let ultimaVerificacion = null;
ipcMain.handle("verificacion:ultima", () => ultimaVerificacion);

engine.on("done", ({ uploaded, skipped, errors, bytes, backupMode, verificacion }) => {
  const mb = (bytes / 1048576).toFixed(1);

  // El estado de la verificación va a la pantalla siempre, salga bien o mal.
  // Es la tercera regla del producto: el cliente tiene que poder verificar. La
  // tranquilidad no viene de que el programa ande, viene de poder ver qué se
  // respaldó, cuándo, y qué falló.
  if (verificacion) {
    ultimaVerificacion = verificacion;
    enviarAlRenderer("verificacion", verificacion);
  }

  // Se informa el consumo después de cada respaldo, sin bloquear el aviso de
  // "terminado": si el servidor no contesta, el respaldo ya está hecho igual.
  informarConsumo().catch(() => {});

  if (errors > 0 && uploaded === 0) {
    return avisar({
      titulo: "BackupPrime — no se pudo respaldar",
      cuerpo: `${errors} archivo(s) quedaron sin copiar. Mirá la pestaña Actividad.`,
      urgente: true,
      clave: "respaldo-fallido",
    });
  }

  if (errors > 0) {
    return avisar({
      titulo: "BackupPrime — respaldo con problemas",
      cuerpo: `Se copiaron ${uploaded} archivo(s), pero ${errors} quedaron afuera.`,
      urgente: true,
      clave: "respaldo-parcial",
    });
  }

  // Todo salió bien: esto es lo que llenaba la pantalla de carteles.
  const partes = [];
  if (uploaded > 0) partes.push(`${uploaded} archivo(s) · ${mb} MB`);
  if (skipped > 0) partes.push(`${skipped} sin cambios`);
  avisar({
    titulo: `BackupPrime — ${backupMode || "respaldo"} listo`,
    cuerpo: partes.length ? partes.join(" · ") : "No había nada nuevo para respaldar.",
  });
});

// ─── Window ───────────────────────────────────────────────────────────────────

// Al cerrar la ventana, en vez de solo ocultarla, la destruimos y liberamos
// su proceso de render. El motor de backup vive en el proceso principal, así
// que sigue funcionando igual — pero el consumo de memoria baja mucho, que
// importa porque este programa está prendido todo el día.
// Se vuelve a crear al instante cuando el usuario la abre desde la bandeja.
function createWindow(oculta = false) {
  mainWindow = new BrowserWindow({
    width: 920, height: 960, title: "BackupPrime",
    backgroundColor: "#fafaf8",
    show: !oculta,
    icon: path.join(__dirname, "icon.png"),
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      contextIsolation: true, nodeIntegration: false,
      // Al quedar oculta, dejamos que Chromium libere recursos en vez de
      // seguir animando y renderizando una ventana que nadie ve.
      backgroundThrottling: true,
    },
  });
  mainWindow.loadFile(path.join(__dirname, "renderer.html"));

  mainWindow.on("close", (e) => {
    if (app.isQuiting) return;
    e.preventDefault();
    // Destruir libera ~60-90 MB frente a solo ocultar
    mainWindow.destroy();
    mainWindow = null;
  });

  return mainWindow;
}

// Abre la ventana, recreándola si fue liberada
function showWindow() {
  if (mainWindow && !mainWindow.isDestroyed()) {
    if (mainWindow.isMinimized()) mainWindow.restore();
    mainWindow.show();
    mainWindow.focus();
    return;
  }
  createWindow(false);
}

// ─── IPC: Agent ──────────────────────────────────────────────────────────────

ipcMain.handle("agent:start", () => {
  engine.start(buildEngineConfig());
  return true;
});

ipcMain.handle("agent:stop", () => {
  engine.stop();
  return true;
});

ipcMain.handle("agent:status", () => ({ running: engine.isActive }));
ipcMain.handle("agent:logs", () => logBuffer.join(""));

ipcMain.handle("agent:run-now", async () => {
  // Se devuelve el resultado para que la pantalla pueda decir si el pedido
  // quedó anotado por haber otro respaldo en curso.
  const r = await engine.runOnce(buildEngineConfig());
  return r || { corrio: true };
});

ipcMain.handle("agent:run-now-full", async () => {
  const cfg = buildEngineConfig();
  cfg.forceFullBackup = true;
  await engine.runOnce(cfg);
  return true;
});

// Verificar es lo que la gente suele querer cuando dice "respaldo completo":
// comprobar que lo respaldado esté de verdad en el destino. A diferencia de
// forzar un completo, NO borra el registro ni vuelve a subir lo que ya está, así
// que no duplica el consumo del cliente. Sube únicamente lo que falta.
ipcMain.handle("agent:verificar", async () => {
  const cfg = buildEngineConfig();
  cfg.verificar = true;
  await engine.runOnce(cfg);
  return true;
});

// ─── IPC: Config ─────────────────────────────────────────────────────────────

ipcMain.handle("config:read", () => {
  const c = readConfig();
  return {
    server: c.server || SERVIDOR_POR_DEFECTO,
    token: decryptToken(c),
    localPaths: Array.isArray(c.localPaths) ? c.localPaths : [],
    excludedPaths: Array.isArray(c.excludedPaths) ? c.excludedPaths : [],
    destinations: Array.isArray(c.destinations) ? c.destinations : [],
    schedule: c.schedule || { mode: "interval", intervalMins: 60 },
    maxVersions: Math.min(30, Number(c.maxVersions) || 10),
    concurrencia: Math.min(32, Math.max(1, Number(c.concurrencia) || 6)),
    umbralBloquesMB: Math.min(2048, Math.max(1, Number(c.umbralBloquesMB) || 25)),
    avisos: ["todos", "problemas", "ninguno"].includes(c.avisos) ? c.avisos : "problemas",
    silencioDesde: c.silencioDesde || "",
    silencioHasta: c.silencioHasta || "",
    lang: c.lang || "en",
    systemBackup: !!c.systemBackup,
    configPath: configFilePath(),
    appVersion: app.getVersion(),
  };
});

// Alta automática del equipo con email y contraseña del cliente.
// El usuario no tiene que copiar ningún token: el servidor valida su
// suscripción, registra este equipo y devuelve el token ya listo, que
// guardamos cifrado. Tampoco recibe nunca credenciales del almacenamiento.
ipcMain.handle("agent:login", async (_e, { server, email, password, deviceName }) => {
  try {
    const base = String(server || "").replace(/\/+$/, "");
    if (!base) return { ok: false, error: "Falta la dirección del servidor" };

    const url = `${base}/api/agent-auth/login`;
    const payload = JSON.stringify({
      email,
      password,
      deviceName: deviceName || os.hostname(),
      os: process.platform === "win32" ? "windows"
        : process.platform === "darwin" ? "macos" : "linux",
      agentVersion: require(path.join(__dirname, "..", "package.json")).version,
    });

    const parsed = new URL(url);
    const mod = parsed.protocol === "https:" ? https : http;

    const result = await new Promise((resolve, reject) => {
      const req = mod.request({
        hostname: parsed.hostname,
        port: parsed.port || (parsed.protocol === "https:" ? 443 : 80),
        path: parsed.pathname,
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Content-Length": Buffer.byteLength(payload),
        },
        timeout: 20000,
      }, (res) => {
        const chunks = [];
        res.on("data", (c) => chunks.push(c));
        res.on("end", () => {
          const text = Buffer.concat(chunks).toString("utf8");
          let body = {};
          try { body = JSON.parse(text); } catch {}
          resolve({ status: res.statusCode, body });
        });
      });
      req.on("timeout", () => { req.destroy(); reject(new Error("El servidor no respondió a tiempo")); });
      req.on("error", reject);
      req.write(payload);
      req.end();
    });

    if (result.status !== 200) {
      return { ok: false, error: result.body?.error || `El servidor respondió ${result.status}` };
    }

    const { agentToken, device, account } = result.body;
    // El plan se guarda: el cliente tiene que poder ver QUÉ contrató sin entrar
    // a la web. Antes venía en la respuesta y se tiraba.
    writeConfig({
      server: base, token: agentToken, deviceName: device?.name,
      plan: account?.plan || null,
      planEspacioGB: account?.espacioGB || null,
    });

    return { ok: true, device, account };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

ipcMain.handle("config:save-credentials", (_e, { token, server }) => {
  writeConfig({ token, server: String(server || "").replace(/\/+$/, "") });
  return true;
});

ipcMain.handle("config:set-lang", (_e, lang) => {
  writeConfig({ lang });
  return lang;
});

ipcMain.handle("config:pick-folders", async () => {
  if (!mainWindow) return [];
  const r = await dialog.showOpenDialog(mainWindow, {
    title: "Choose folders to back up",
    properties: ["openDirectory", "multiSelections", "createDirectory", "dontAddToRecent"],
  });
  if (r.canceled) return [];
  return r.filePaths;
});

ipcMain.handle("config:pick-folder", async () => {
  if (!mainWindow) return null;
  const r = await dialog.showOpenDialog(mainWindow, {
    title: "Choose folder",
    properties: ["openDirectory", "createDirectory", "dontAddToRecent"],
  });
  if (r.canceled || !r.filePaths.length) return null;
  return r.filePaths[0];
});

ipcMain.handle("config:set-paths", (_e, paths) => {
  const clean = Array.isArray(paths) ? paths.filter((p) => typeof p === "string" && p.trim()) : [];
  writeConfig({ localPaths: clean });
  return clean;
});

ipcMain.handle("config:set-excludes", (_e, paths) => {
  const clean = Array.isArray(paths) ? paths.filter((p) => typeof p === "string" && p.trim()) : [];
  writeConfig({ excludedPaths: clean });
  return clean;
});

// Prueba real del destino: escribe un archivo, lo verifica y lo borra.
// Conectarse no alcanza — puede faltar permiso de escritura o espacio.
ipcMain.handle("dest:probar", async (_e, dest) => {
  try {
    const { probarDestino } = require(path.join(__dirname, "backup-engine.cjs"));
    return await probarDestino(dest);
  } catch (e) {
    return { ok: false, mensaje: e.message };
  }
});

ipcMain.handle("config:set-destinations", (_e, destinations) => {
  const clean = Array.isArray(destinations) ? destinations : [];
  writeConfig({ destinations: clean });
  engine.reconfigure(buildEngineConfig());
  return clean;
});

ipcMain.handle("config:set-schedule", (_e, schedule) => {
  writeConfig({ schedule });
  engine.reconfigure(buildEngineConfig());
  return schedule;
});

// Cuántas versiones anteriores se conservan de cada archivo.
// Por defecto 10: alcanza para volver a como estaba hace una o dos semanas,
// que es el caso real (te diste cuenta tarde de que rompiste el archivo).
// Tope de 30: más que eso multiplica el consumo del plan sin que el cliente
// lo note, y termina llenándole el espacio.
const VERSIONES_POR_DEFECTO = 10;
const VERSIONES_MAXIMO = 30;

ipcMain.handle("config:set-umbral-bloques", (_e, n) => {
  const limpio = Math.min(2048, Math.max(1, Number(n) || 25));
  writeConfig({ umbralBloquesMB: limpio });
  engine.reconfigure(buildEngineConfig());
  return limpio;
});

ipcMain.handle("config:set-avisos", (_e, opciones) => {
  const modo = ["todos", "problemas", "ninguno"].includes(opciones && opciones.avisos)
    ? opciones.avisos : "problemas";
  const hora = (v) => (/^\d{1,2}:\d{2}$/.test(String(v || "")) ? v : "");
  writeConfig({
    avisos: modo,
    silencioDesde: hora(opciones && opciones.silencioDesde),
    silencioHasta: hora(opciones && opciones.silencioHasta),
  });
  // Al cambiar la configuración se olvida lo ya avisado: si el usuario acaba
  // de arreglar algo, que el próximo aviso no quede tapado por el anterior.
  avisosRecientes.clear();
  return { avisos: modo };
});

ipcMain.handle("config:set-concurrencia", (_e, n) => {
  const limpio = Math.min(32, Math.max(1, Number(n) || 6));
  writeConfig({ concurrencia: limpio });
  engine.reconfigure(buildEngineConfig());
  return limpio;
});

ipcMain.handle("config:set-max-versions", (_e, n) => {
  const pedido = Number(n);
  const v = (!Number.isFinite(pedido) || pedido < 1)
    ? VERSIONES_POR_DEFECTO
    : Math.min(VERSIONES_MAXIMO, Math.floor(pedido));
  writeConfig({ maxVersions: v });
  return { valor: v, ajustado: v !== pedido, maximo: VERSIONES_MAXIMO };
});

// ─── Cifrado: elegir el modo y fijar la frase ────────────────────────────────
//
// La frase NO se guarda: se guarda la sal y un comprobante. El comprobante
// permite avisar "esa no es tu frase" ANTES de bajar gigabytes, sin que la frase
// quede escrita en ningún lado.
//
// Cambiar de frase con respaldos ya hechos dejaría ilegible todo lo anterior, y
// por eso no se permite en silencio: hay que decirlo.
ipcMain.handle("config:set-cifrado", async (_e, { modo, frase }) => {
  try {
    const cfg = readConfig();
    const yaHabia = !!cfg.cifradoComprobante;

    if (modo === "privada") {
      if (!frase || String(frase).length < 8) {
        return { ok: false, error: "La frase tiene que tener al menos 8 caracteres." };
      }
      // Si ya había una frase y la nueva es distinta, se avisa: los respaldos
      // hechos con la anterior no se van a poder leer con esta.
      if (yaHabia && cfg.cifradoModo === "privada" && cfg.cifradoSal) {
        const salVieja = Buffer.from(cfg.cifradoSal, "base64");
        const claveVieja = Cifrado.claveDesdeFrase(frase, salVieja);
        if (!Cifrado.comprobanteValido(cfg.cifradoComprobante, claveVieja)) {
          return {
            ok: false,
            error: "Ya hay respaldos hechos con otra frase. Si cambiás la frase, " +
                   "esos respaldos quedan ilegibles para siempre. Para cambiarla hay " +
                   "que empezar un respaldo nuevo desde cero.",
          };
        }
        return { ok: true, modo: "privada", sinCambios: true };
      }
      const sal = Cifrado.salNueva();
      const clave = Cifrado.claveDesdeFrase(frase, sal);
      writeConfig({
        cifradoModo: "privada",
        cifradoSal: sal.toString("base64"),
        cifradoComprobante: Cifrado.crearComprobante(clave),
        cifradoClave: null,
        // La frase se guarda con la protección de credenciales del sistema, igual
        // que el resto de los secretos. Sin esto, el respaldo programado no podría
        // correr solo: le haría falta que alguien escriba la frase cada vez.
        cifradoFrase: frase,
      });
      engine.reconfigure(buildEngineConfig());
      return { ok: true, modo: "privada" };
    }

    if (yaHabia && cfg.cifradoModo === "privada") {
      return {
        ok: false,
        error: "Ya hay respaldos cifrados con tu frase privada. Pasar a clave " +
               "administrada no los vuelve legibles para nosotros, y mezclaría dos " +
               "esquemas en el mismo respaldo. Para cambiar hay que empezar de cero.",
      };
    }

    // Modo gestionado: la clave la tiene que entregar el servidor. Todavía no
    // existe ese circuito, así que NO se activa a medias: activar un cifrado que
    // el servidor no puede sostener sería prometer algo que no se cumple.
    return {
      ok: false,
      error: "La clave administrada todavía no está disponible: falta el circuito " +
             "del servidor. Por ahora está la frase propia, que no depende de nada externo.",
    };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

ipcMain.handle("config:get-cifrado", () => {
  const cfg = readConfig();
  return {
    modo: cfg.cifradoModo || null,
    configurado: !!cfg.cifradoComprobante,
  };
});

ipcMain.handle("config:set-system-backup", (_e, enabled) => {
  writeConfig({ systemBackup: !!enabled });
  return !!enabled;
});

// ─── IPC: Filesystem browsing ─────────────────────────────────────────────────

// ── Lo que nunca tiene sentido ofrecerle al cliente ─────────────────────────
//
// En el selector aparecían cosas como
// `snx_rhive{a59635f9-…}.TMContainer0000…0001.regtrans-ms`: archivos de
// transacción del registro de Windows. No son datos del cliente, están siempre
// abiertos por el sistema, cambian todo el tiempo y no sirven de nada
// restaurados. Ofrecerlos es peor que inútil: llenan la lista de ruido, hacen
// que el cliente no encuentre lo que busca, y si los elige generan errores de
// archivo bloqueado en cada respaldo.
const BASURA_DEL_SISTEMA = [
  /\.regtrans-ms$/i,          // transacciones del registro
  /\.blf$/i,                  // registro de transacciones comunes
  /^ntuser\.dat/i,            // perfil de usuario, siempre abierto
  /^usrclass\.dat/i,
  /\.lnk$/i,                  // accesos directos: apuntan, no contienen
  /^thumbs\.db$/i,
  /^desktop\.ini$/i,
  /^\.ds_store$/i,
  /^hiberfil\.sys$/i,         // hibernación: gigas de nada
  /^pagefile\.sys$/i,         // memoria virtual
  /^swapfile\.sys$/i,
  /^\$recycle\.bin$/i,
];

// Carpetas que tampoco: son del sistema o se regeneran solas.
const CARPETAS_DEL_SISTEMA = [
  /^\$/,                      // $Recycle.Bin, $WinREAgent y compañía
  /^System Volume Information$/i,
  /^Recovery$/i,
  /^node_modules$/i,          // se reinstala con un comando
];

const esBasuraDelSistema = (nombre) => BASURA_DEL_SISTEMA.some((r) => r.test(nombre));
const esCarpetaDelSistema = (nombre) => CARPETAS_DEL_SISTEMA.some((r) => r.test(nombre));

ipcMain.handle("fs:list-dir", async (_e, dirPath) => {
  try {
    const entries = await fsp.readdir(dirPath, { withFileTypes: true });
    const dirs = [];
    const files = [];
    let ocultos = 0;
    for (const e of entries) {
      const name = e.name;

      if (e.isDirectory() || e.isSymbolicLink()) {
        if (esCarpetaDelSistema(name)) { ocultos++; continue; }
        dirs.push({ name, full: path.join(dirPath, name) });
        continue;
      }

      // Los archivos también se listan. Antes solo se mostraban carpetas, así que
      // para respaldar UN archivo suelto —el PST, una planilla, un certificado—
      // había que agregar la carpeta entera y después excluir todo lo demás a
      // mano. Un contador que solo quiere su libro IVA no tiene por qué respaldar
      // la carpeta Documentos completa.
      if (!e.isFile()) continue;
      if (esBasuraDelSistema(name)) { ocultos++; continue; }
      const full = path.join(dirPath, name);
      let size = null;
      try { size = (await fsp.stat(full)).size; } catch { /* sin permiso: se lista igual */ }
      files.push({ name, full, size, esArchivo: true });
    }
    dirs.sort((a, b) => a.name.localeCompare(b.name, "es"));
    files.sort((a, b) => a.name.localeCompare(b.name, "es"));
    return { ok: true, dirs, files, ocultos, parent: path.dirname(dirPath) };
  } catch (e) {
    return { ok: false, error: e.message, dirs: [], files: [], ocultos: 0, parent: path.dirname(dirPath) };
  }
});

// ── Accesos rápidos: lo que un cliente real quiere respaldar ────────────────
//
// Nadie que no sea técnico sabe que Outlook guarda el correo en
// `AppData\Local\Microsoft\Outlook`. Obligarlo a navegar hasta ahí es
// garantizar que su PST no se respalde nunca, que es justo el archivo que más
// le va a doler perder.
//
// Solo se devuelven las carpetas que existen de verdad: ofrecer una que no está
// es peor que no ofrecerla.
ipcMain.handle("fs:accesos-rapidos", async () => {
  const casa = os.homedir();
  const candidatos = [
    { clave: "documentos", icono: "📄", ruta: path.join(casa, "Documents") },
    { clave: "documentos", icono: "📄", ruta: path.join(casa, "Documentos") },
    { clave: "escritorio", icono: "🖥️", ruta: path.join(casa, "Desktop") },
    { clave: "escritorio", icono: "🖥️", ruta: path.join(casa, "Escritorio") },
    { clave: "imagenes",   icono: "🖼️", ruta: path.join(casa, "Pictures") },
    { clave: "imagenes",   icono: "🖼️", ruta: path.join(casa, "Imágenes") },
    { clave: "descargas",  icono: "⬇️", ruta: path.join(casa, "Downloads") },
    { clave: "descargas",  icono: "⬇️", ruta: path.join(casa, "Descargas") },
    // El correo de Outlook, que es el archivo que más duele perder en un
    // estudio y el que nadie encuentra solo.
    { clave: "outlook", icono: "📧",
      ruta: path.join(casa, "AppData", "Local", "Microsoft", "Outlook") },
    { clave: "outlook", icono: "📧", ruta: path.join(casa, "Documents", "Outlook Files") },
    { clave: "outlook", icono: "📧", ruta: path.join(casa, "Documentos", "Archivos de Outlook") },
  ];

  const vistos = new Set();
  const salida = [];
  for (const c of candidatos) {
    if (vistos.has(c.clave)) continue;
    try {
      const st = await fsp.stat(c.ruta);
      if (!st.isDirectory()) continue;
      vistos.add(c.clave);
      salida.push({ clave: c.clave, icono: c.icono, ruta: c.ruta });
    } catch { /* no existe en este equipo */ }
  }
  return { accesos: salida };
});

// ── Cuánto pesa lo que el cliente está por elegir ───────────────────────────
//
// Sin este número, elegir carpetas es a ciegas: el cliente marca "Descargas"
// sin saber que son 80 GB, y se entera cuando el respaldo se pasa del plan.
//
// Se cancela solo: si el cliente marca y desmarca rápido, el recorrido anterior
// se abandona en vez de seguir gastando disco al pedo. Y hay un tope de
// archivos para que una carpeta enorme no deje la ventana esperando: se informa
// lo que se alcanzó a contar y se avisa que es un piso, no el total.
let cancelarMedicion = 0;
ipcMain.handle("fs:medir", async (evt, rutas) => {
  const miMedicion = ++cancelarMedicion;
  const TOPE = 60000;
  let bytes = 0, archivos = 0, incompleto = false;

  const recorrer = async (ruta) => {
    if (miMedicion !== cancelarMedicion || incompleto) return;
    let st;
    try { st = await fsp.stat(ruta); } catch { return; }
    if (st.isFile()) {
      if (esBasuraDelSistema(path.basename(ruta))) return;
      bytes += st.size; archivos++;
      if (archivos >= TOPE) incompleto = true;
      return;
    }
    if (!st.isDirectory()) return;
    if (esCarpetaDelSistema(path.basename(ruta))) return;
    let entradas;
    try { entradas = await fsp.readdir(ruta, { withFileTypes: true }); } catch { return; }
    for (const e of entradas) {
      if (miMedicion !== cancelarMedicion || incompleto) return;
      if (e.isSymbolicLink()) continue;   // no seguir enlaces: se cuenta dos veces o se cicla
      await recorrer(path.join(ruta, e.name));
    }
  };

  for (const r of (rutas || [])) await recorrer(r);
  if (miMedicion !== cancelarMedicion) return { cancelado: true };
  return { bytes, archivos, incompleto };
});

ipcMain.handle("fs:system-drives", () => {
  if (process.platform !== "win32") {
    return { drives: [os.homedir()] };
  }
  // On Windows, check common drive letters
  const drives = [];
  for (let i = 67; i <= 90; i++) { // C to Z
    const d = String.fromCharCode(i) + ":\\";
    if (fs.existsSync(d)) drives.push(d);
  }
  return { drives };
});

// ─── Las carpetas del perfil, para elegir de a una ──────────────────────────
//
// ── Por qué NO va AppData\Roaming ──
//
// Antes esta lista incluía `AppData\Roaming` entera. Ahí adentro viven las
// configuraciones de todos los programas instalados: decenas de miles de
// archivos que cambian todo el tiempo, cachés que no se llaman "cache", bases
// de datos de aplicaciones abiertas, y credenciales guardadas.
//
// Respaldarla es caro y sirve para poco: no se puede "restaurar" la
// configuración de un programa copiando esos archivos a otra máquina, porque
// muchos están atados a la instalación y al usuario de Windows. Lo que el
// cliente necesita de ahí adentro son cosas concretas —el PST de Outlook, las
// firmas de correo— y esas se ofrecen por su propio acceso rápido, por ruta
// exacta.
//
// Se devuelve cada carpeta con su cuenta y su tamaño para que el cliente elija
// de a una, viendo lo que va a respaldar. Elegir a ciegas es como alguien marca
// "Descargas" sin enterarse de que son 54 GB.
ipcMain.handle("fs:user-profile-paths", async () => {
  const home = os.homedir();

  // El orden importa: primero lo que casi siempre se quiere.
  const candidatas = [
    { clave: "documentos", icono: "📄", ruta: path.join(home, "Documents"),  sugerida: true },
    { clave: "documentos", icono: "📄", ruta: path.join(home, "Documentos"), sugerida: true },
    { clave: "escritorio", icono: "🖥️", ruta: path.join(home, "Desktop"),    sugerida: true },
    { clave: "escritorio", icono: "🖥️", ruta: path.join(home, "Escritorio"), sugerida: true },
    { clave: "imagenes",   icono: "🖼️", ruta: path.join(home, "Pictures"),   sugerida: true },
    { clave: "imagenes",   icono: "🖼️", ruta: path.join(home, "Imágenes"),   sugerida: true },
    // ── Videos SÍ viene marcado ──
    //
    // Una versión anterior lo dejaba desmarcado "porque pesa mucho y rara vez es
    // trabajo del estudio". Ese criterio estaba mal: **un video de un cumpleaños
    // no se vuelve a grabar**. Es exactamente lo que la gente no quiere perder, y
    // desmarcarlo por defecto es decidir por el cliente que sus recuerdos valen
    // menos que su cuota.
    { clave: "videos",     icono: "🎬", ruta: path.join(home, "Videos"),     sugerida: true },
    // Descargas es lo único genuinamente descartable de esta lista: son archivos
    // que ya vinieron de algún lado y se pueden volver a bajar.
    { clave: "descargas",  icono: "⬇️", ruta: path.join(home, "Downloads"),  sugerida: false },
    { clave: "descargas",  icono: "⬇️", ruta: path.join(home, "Descargas"),  sugerida: false },
    // Música tampoco viene marcada: hoy casi todo se escucha en streaming, y lo
    // que hay suele ser comprado o descargado, no irremplazable. Pero se ofrece
    // con su tamaño para que el cliente decida.
    { clave: "musica",     icono: "🎵", ruta: path.join(home, "Music"),      sugerida: false },
    { clave: "musica",     icono: "🎵", ruta: path.join(home, "Música"),     sugerida: false },
  ];

  const vistas = new Set();
  const carpetas = [];
  for (const c of candidatas) {
    if (vistas.has(c.clave)) continue;          // Documents o Documentos, no las dos
    try {
      const st = await fsp.stat(c.ruta);
      if (!st.isDirectory()) continue;
    } catch { continue; }                        // no existe: no se ofrece
    vistas.add(c.clave);
    carpetas.push(c);
  }

  // ── Se devuelve la lista SIN medir ──
  //
  // Antes se medía acá, con un tope de 1,2 segundos por carpeta, y se devolvía
  // todo junto. Dos problemas graves:
  //
  //   · Con el tope, una carpeta de 12 GB mostraba "más de 3,94 GB". El cliente
  //     decide con un número que parece exacto y está muy por debajo del real.
  //     Peor que no mostrar nada.
  //   · Y no se veía nada hasta que terminaban TODAS.
  //
  // Ahora la pantalla recibe la lista al instante y pide la medición de cada
  // carpeta por separado, mostrando el número mientras sube. Sin tope: el
  // número que se muestra es el de verdad.
  return { carpetas };
});

/**
 * Mide UNA carpeta y avisa el avance mientras cuenta.
 *
 * Sin tope de tiempo: el número tiene que ser el real. Se informa el parcial
 * cada 400 ms para que la pantalla lo muestre subiendo, que es lo que hace que
 * la espera se entienda en lugar de parecer que se colgó.
 */
ipcMain.handle("fs:medir-carpeta", async (evt, ruta) => {
  const m = await medirRuta(ruta, 0, (parcial) => {
    try { evt.sender.send("fs:medida-parcial", { ruta, ...parcial }); } catch {}
  });
  return { ruta, archivos: m.archivos, bytes: m.bytes, vacia: m.archivos === 0 };
});

/**
 * Cuenta archivos y bytes de una carpeta, con tope de tiempo.
 *
 * Se corta a los `tope` milisegundos y avisa que quedó incompleto. Medir
 * `Descargas` con 40.000 archivos puede tardar; hacer esperar al cliente para
 * mostrarle un número exacto que no necesita es peor que mostrarle "más de".
 */
async function medirRuta(raiz, tope = 0, alAvanzar = null) {
  // `tope` en 0 significa sin límite: el número que se le muestra al cliente
  // tiene que ser el real. Un "más de 3,94 GB" en una carpeta de 12 GB es peor
  // que no mostrar nada, porque parece exacto.
  const limite = tope > 0 ? Date.now() + tope : Infinity;
  let archivos = 0, bytes = 0, incompleto = false;
  let ultimoAviso = Date.now();
  const pila = [raiz];
  const vistas = new Set();

  while (pila.length) {
    if (Date.now() > limite) { incompleto = true; break; }
    if (alAvanzar && Date.now() - ultimoAviso > 400) {
      ultimoAviso = Date.now();
      alAvanzar({ archivos, bytes, parcial: true });
    }
    const dir = pila.pop();
    let real;
    try { real = await fsp.realpath(dir); } catch { continue; }
    if (vistas.has(real)) continue;      // un enlace que apunta arriba no termina nunca
    vistas.add(real);

    let entradas;
    try { entradas = await fsp.readdir(dir, { withFileTypes: true }); }
    catch { continue; }                  // sin permiso: se saltea, no se rompe

    for (const e of entradas) {
      if (Date.now() > limite) { incompleto = true; break; }
      if (e.isSymbolicLink()) continue;
      const completa = path.join(dir, e.name);
      if (e.isDirectory()) {
        // Lo que el respaldo no va a copiar tampoco se cuenta acá: mostrar
        // 54 GB y respaldar 20 sería mentirle al cliente en la cara.
        if (esBasuraDelSistema(e.name)) continue;
        pila.push(completa);
      } else if (e.isFile()) {
        if (esBasuraDelSistema(e.name)) continue;
        try { const st = await fsp.stat(completa); archivos++; bytes += st.size; } catch {}
      }
    }
  }
  return { archivos, bytes, incompleto };
}

// ─── IPC: Restore ─────────────────────────────────────────────────────────────

function fetchJson(url, token) {
  return new Promise((resolve, reject) => {
    const parsed = new URL(url);
    const mod = parsed.protocol === "https:" ? https : http;
    const req = mod.request({
      hostname: parsed.hostname,
      port: parsed.port || (parsed.protocol === "https:" ? 443 : 80),
      path: parsed.pathname + parsed.search,
      method: "GET",
      headers: { Authorization: `Bearer ${token}`, Accept: "application/json" },
    }, (res) => {
      let data = "";
      res.on("data", (c) => (data += c));
      res.on("end", () => {
        try { resolve({ status: res.statusCode, body: JSON.parse(data) }); }
        catch { resolve({ status: res.statusCode, body: data }); }
      });
    });
    req.on("error", reject);
    req.end();
  });
}

function downloadToPath(url, token, destPath) {
  return new Promise((resolve, reject) => {
    function doRequest(reqUrl) {
      const p2 = new URL(reqUrl);
      const m2 = p2.protocol === "https:" ? https : http;
      const hdrs = token ? { Authorization: `Bearer ${token}` } : {};
      const req = m2.request({
        hostname: p2.hostname,
        port: p2.port || (p2.protocol === "https:" ? 443 : 80),
        path: p2.pathname + p2.search,
        method: "GET", headers: hdrs,
      }, (res) => {
        if (res.statusCode === 301 || res.statusCode === 302) {
          doRequest(res.headers.location); return;
        }
        if (res.statusCode !== 200) { reject(new Error(`HTTP ${res.statusCode}`)); return; }
        fs.mkdirSync(path.dirname(destPath), { recursive: true });
        const out = fs.createWriteStream(destPath);
        res.pipe(out);
        out.on("finish", resolve);
        out.on("error", reject);
      });
      req.on("error", reject);
      req.end();
    }
    doRequest(url);
  });
}

ipcMain.handle("restore:list-files", async (_e, { search = "", page = 1 }) => {
  const c = readConfig();
  const token = decryptToken(c);
  if (!token || !c.server) {
    return { files: [], total: 0, error: "cloud_not_configured" };
  }
  const url = `${c.server}/api/agent/files?search=${encodeURIComponent(search)}&page=${page}&limit=50`;
  try {
    const r = await fetchJson(url, token);
    if (r.status !== 200) return { files: [], total: 0, error: `Server returned ${r.status}` };
    return r.body;
  } catch (e) {
    return { files: [], total: 0, error: e.message };
  }
});

ipcMain.handle("restore:pick-folder", async () => {
  if (!mainWindow) return null;
  const r = await dialog.showOpenDialog(mainWindow, {
    title: "Restore files to this folder",
    properties: ["openDirectory", "createDirectory", "dontAddToRecent"],
  });
  if (r.canceled || !r.filePaths.length) return null;
  return r.filePaths[0];
});

ipcMain.handle("restore:file", async (_e, { fileId, versionId, destFolder }) => {
  const c = readConfig();
  const token = decryptToken(c);
  if (!token || !c.server) return { ok: false, error: "not_configured" };
  const id = versionId || fileId;
  try {
    // First get the download URL/redirect from the server
    const url = `${c.server}/api/agent/files/${encodeURIComponent(id)}/download`;
    const r = await fetchJson(url, token);
    if (r.status === 404) return { ok: false, error: "file_not_found" };
    if (r.status !== 200) return { ok: false, error: `Server error ${r.status}` };

    const meta = r.body;
    const fname = meta.name || id;
    const destPath = path.join(destFolder, fname);

    if (meta.url) {
      // Got a signed/presigned URL
      await downloadToPath(meta.url, null, destPath);
    } else {
      // Fallback: direct download via API with auth token
      await downloadToPath(url, token, destPath);
    }
    return { ok: true, path: destPath };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

// Restore from local/network destination — scan and copy file back
ipcMain.handle("restore:from-local", async (_e, { sourcePath, destFolder, destBasePath }) => {
  try {
    // destBasePath = the local/network backup destination root
    // sourcePath   = original file path (e.g. C:\Users\foo\Documents\file.txt)
    // We reconstruct the relative path in the backup
    // Una sola función decide la ruta en el destino, la misma que usa el
    // respaldo. Tener dos copias de esta lógica es lo que hizo que los archivos
    // grandes terminaran en otra rama del árbol.
    const backupFilePath = path.join(destBasePath,
      ...rutaEnDestino(sourcePath).split("/"));
    if (!fs.existsSync(backupFilePath)) {
      return { ok: false, error: "File not found in backup destination" };
    }
    const fname = path.basename(sourcePath);
    const destPath = path.join(destFolder, fname);
    await fsp.mkdir(destFolder, { recursive: true });
    await fsp.copyFile(backupFilePath, destPath);
    return { ok: true, path: destPath };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

// ─── Restore desde destinos locales / de red ─────────────────────────────────
//
// El motor copia cada archivo a <destino>/<LETRA_DISCO>/<ruta original>.
// Ej: C:\Users\ana\doc.txt  ->  D:\Backups\C\Users\ana\doc.txt
// Estas funciones recorren esa estructura para poder listar y devolver
// archivos sin depender del servidor en la nube.

// Convierte la ruta dentro del backup a la ruta original en la PC.
function backupPathToOriginal(destBasePath, backupFilePath) {
  const rel = path.relative(destBasePath, backupFilePath);
  const parts = rel.split(path.sep);
  // Si el primer segmento es una sola letra, es la letra de disco de Windows
  if (parts.length > 1 && /^[A-Za-z]$/.test(parts[0])) {
    return `${parts[0].toUpperCase()}:\\${parts.slice(1).join("\\")}`;
  }
  return rel;
}

async function walkBackupDir(root, onFile, limit = Infinity) {
  const stack = [root];
  let count = 0;
  while (stack.length && count < limit) {
    const dir = stack.pop();
    let entries;
    try { entries = await fsp.readdir(dir, { withFileTypes: true }); }
    catch { continue; }
    for (const e of entries) {
      if (count >= limit) break;
      const full = path.join(dir, e.name);
      try {
        if (e.isDirectory()) stack.push(full);
        else if (e.isFile()) {
          const st = await fsp.stat(full);
          onFile({ backupPath: full, size: st.size, mtimeMs: st.mtimeMs });
          count++;
        }
      } catch { continue; }
    }
  }
  return count;
}

// Devuelve los destinos locales/de red configurados, para que la UI
// pueda ofrecerle al usuario desde cuál restaurar.
ipcMain.handle("restore:list-local-destinations", () => {
  const c = readConfig();
  const dests = Array.isArray(c.destinations) ? c.destinations : [];
  return dests
    .filter((d) => ["local", "network", "ftp", "sftp", "s3"].includes(d.type))
    .map((d) => {
      if (d.type === "ftp" || d.type === "sftp") {
        return {
          type: d.type,
          id: claveDestino(d),
          path: `${d.host}${d.remotePath || "/"}`,
          label: d.label || d.host,
          available: true,   // solo se sabe al conectarse
        };
      }
      if (d.type === "s3") {
        return {
          type: "s3",
          id: claveDestino(d),
          path: `${d.bucket}${d.prefix ? "/" + d.prefix : ""}`,
          label: d.label || d.bucket,
          available: true,
        };
      }
      return {
        type: d.type,
        path: d.path,
        label: d.label || d.path,
        available: (() => { try { return fs.existsSync(d.path); } catch { return false; } })(),
      };
    });
});

// Lista los archivos disponibles dentro de un destino local/red.
ipcMain.handle("restore:list-local-files", async (_e, { destBasePath, search = "" }) => {
  try {
    if (!destBasePath || !fs.existsSync(destBasePath)) {
      return { files: [], total: 0, error: "El destino de backup no está disponible" };
    }
    const all = [];
    const coincideAqui = armarBusqueda(search);
    await walkBackupDir(destBasePath, (f) => {
      const originalPath = backupPathToOriginal(destBasePath, f.backupPath);
      const name = path.basename(f.backupPath);
      if (coincideAqui && !coincideAqui(name) && !coincideAqui(originalPath)) return;
      all.push({
        id: f.backupPath,          // la propia ruta identifica al archivo
        name,
        sourcePath: originalPath,
        backupPath: f.backupPath,
        size: f.size,
        backedUpAt: new Date(f.mtimeMs).toISOString(),
        version: 1,
      });
    }, 20000); // tope de seguridad para no colgar la UI con backups enormes

    all.sort((a, b) => a.sourcePath.localeCompare(b.sourcePath));
    return { files: all, total: all.length };
  } catch (e) {
    return { files: [], total: 0, error: e.message };
  }
});

// Lista las carpetas de primer nivel del backup, para restaurar por carpeta.
ipcMain.handle("restore:list-local-folders", async (_e, { destBasePath, subPath = "" }) => {
  try {
    const base = subPath ? path.join(destBasePath, subPath) : destBasePath;
    if (!fs.existsSync(base)) return { folders: [], error: "Ruta no encontrada" };
    const entries = await fsp.readdir(base, { withFileTypes: true });
    const folders = entries
      .filter((e) => e.isDirectory())
      .map((e) => ({
        name: e.name,
        relPath: subPath ? path.join(subPath, e.name) : e.name,
        originalPath: backupPathToOriginal(destBasePath, path.join(base, e.name)),
      }));
    return { folders, parent: subPath ? path.dirname(subPath) : null };
  } catch (e) {
    return { folders: [], error: e.message };
  }
});

// Restaura desde un destino local/red. mode: "file" | "folder" | "full"
// preserveStructure: si es true, recrea el árbol de carpetas original
// dentro de la carpeta de destino elegida por el usuario.
ipcMain.handle("restore:from-local-advanced", async (_e, opts) => {
  const { mode, destBasePath, destFolder, backupPath, relPath, preserveStructure = true } = opts || {};
  try {
    if (!destFolder) return { ok: false, error: "No se eligió carpeta de destino" };
    if (!destBasePath || !fs.existsSync(destBasePath)) {
      return { ok: false, error: "El destino de backup no está disponible" };
    }

    // ── Un solo archivo ──
    if (mode === "file") {
      if (!backupPath || !fs.existsSync(backupPath)) {
        return { ok: false, error: "El archivo no existe en el backup" };
      }
      let outPath;
      if (preserveStructure) {
        const rel = path.relative(destBasePath, backupPath);
        outPath = path.join(destFolder, rel);
      } else {
        outPath = path.join(destFolder, path.basename(backupPath));
      }
      await fsp.mkdir(path.dirname(outPath), { recursive: true });
      await fsp.copyFile(backupPath, outPath);
      return { ok: true, path: outPath, count: 1 };
    }

    // ── Carpeta completa o backup entero ──
    const sourceRoot = mode === "full"
      ? destBasePath
      : path.join(destBasePath, relPath || "");

    if (!fs.existsSync(sourceRoot)) {
      return { ok: false, error: "La carpeta no existe en el backup" };
    }

    let count = 0, failed = 0, bytes = 0;

    const stack = [sourceRoot];
    while (stack.length) {
      const dir = stack.pop();
      let entries;
      try { entries = await fsp.readdir(dir, { withFileTypes: true }); }
      catch { failed++; continue; }
      for (const e of entries) {
        const full = path.join(dir, e.name);
        try {
          if (e.isDirectory()) { stack.push(full); continue; }
          if (!e.isFile()) continue;
          const rel = preserveStructure
            ? path.relative(destBasePath, full)
            : path.relative(sourceRoot, full);
          const outPath = path.join(destFolder, rel);
          await fsp.mkdir(path.dirname(outPath), { recursive: true });
          await fsp.copyFile(full, outPath);
          const st = await fsp.stat(full);
          bytes += st.size;
          count++;
        } catch { failed++; }
      }
    }

    return { ok: true, path: destFolder, count, failed, bytes };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

// Arma el árbol jerárquico completo de un destino local/red.
// Devuelve nodos anidados (carpetas con hijos) para que la UI pueda
// mostrar un explorador tipo árbol en vez de listas planas separadas.
// ─── Cómo se busca dentro de un respaldo ────────────────────────────────────
//
// Antes era `ruta.includes(texto)`, a secas. Eso hace que la búsqueda más obvia
// del mundo no encuentre nada: escribir `*.pst` pide rutas que CONTENGAN los
// caracteres `*.pst`, y ningún archivo se llama así. El cliente ve
// "0 archivos" teniendo el PST ahí adentro, y concluye que su correo no está
// respaldado. En un producto de respaldo, hacerle creer eso es grave.
//
// Ahora se entienden las tres formas en que una persona busca de verdad:
//
//   `*.pst`  o  `.pst`   → todo lo que termine en .pst
//   `balance`            → cualquier ruta que contenga "balance"
//   `bal*2026*.xlsx`     → comodines en cualquier posición
//
// Se compara contra la ruta completa Y contra el nombre del archivo: buscar
// `.pst` no puede fallar porque la carpeta que lo contiene se llame distinto.
function armarBusqueda(texto) {
  const q = String(texto || "").trim();
  if (!q) return null;

  const bajo = q.toLowerCase();

  // Solo una extensión: `.pst`, `*.pst`, `*.PST`. Es el caso más común y merece
  // el camino más directo.
  const soloExtension = /^\*?(\.[a-z0-9]+)$/i.exec(bajo);
  if (soloExtension) {
    const ext = soloExtension[1];
    return (rel) => rel.toLowerCase().endsWith(ext);
  }

  if (bajo.includes("*") || bajo.includes("?")) {
    // Se escapa todo lo que sea especial en una expresión y después se
    // reemplazan los comodines. Sin escapar, un nombre con paréntesis
    // —"backup (1).zip"— rompería la búsqueda.
    const patron = bajo
      .replace(/[.+^${}()|[\]\\]/g, "\\$&")
      .replace(/\*/g, ".*")
      .replace(/\?/g, ".");
    let re;
    try { re = new RegExp(patron); } catch { return (rel) => rel.toLowerCase().includes(bajo); }
    return (rel) => {
      const r = rel.toLowerCase();
      return re.test(r) || re.test(r.split(/[\\/]/).pop());
    };
  }

  return (rel) => rel.toLowerCase().includes(bajo);
}

ipcMain.handle("restore:local-tree", async (_e, { destBasePath, search = "" }) => {
  try {
    if (!destBasePath || !fs.existsSync(destBasePath)) {
      return { tree: [], error: "El destino de backup no está disponible" };
    }

    // El mismo comparador que el árbol remoto: si la búsqueda funciona en un
    // destino y no en el otro, es peor que no funcionar en ninguno.
    const coincide = armarBusqueda(search);
    const q = search.trim().toLowerCase();
    let totalFiles = 0;
    let truncated = false;
  // Sin tope de archivos: ocultar parte del respaldo es peor que tardar.
    let nodeCount = 0;

    async function buildNode(dirPath, relPath) {
      let entries;
      try { entries = await fsp.readdir(dirPath, { withFileTypes: true }); }
      catch { return null; }

      const children = [];
      for (const e of entries) {
        const full = path.join(dirPath, e.name);
        const childRel = relPath ? path.join(relPath, e.name) : e.name;

        if (e.isDirectory()) {
          const sub = await buildNode(full, childRel);
          // Con búsqueda activa, solo conservamos carpetas que tengan
          // coincidencias adentro (así el árbol se poda solo).
          if (sub && (!coincide || sub.children.length > 0 || coincide(sub.name))) {
            children.push(sub);
          }
        } else if (e.isFile()) {
          if (coincide && !coincide(e.name) && !coincide(childRel)) continue;
          let st;
          try { st = await fsp.stat(full); } catch { continue; }
          nodeCount++;
          totalFiles++;
          children.push({
            type: "file",
            name: e.name,
            relPath: childRel,
            fullPath: full,
            originalPath: backupPathToOriginal(destBasePath, full),
            size: st.size,
            mtimeMs: st.mtimeMs,
          });
        }
      }

      // Carpetas primero, después archivos; alfabético dentro de cada grupo
      children.sort((a, b) => {
        if (a.type !== b.type) return a.type === "folder" ? -1 : 1;
        return a.name.localeCompare(b.name);
      });

      nodeCount++;
      return {
        type: "folder",
        name: path.basename(dirPath),
        relPath,
        fullPath: dirPath,
        originalPath: relPath ? backupPathToOriginal(destBasePath, dirPath) : "",
        children,
        fileCount: children.reduce((n, c) => n + (c.type === "file" ? 1 : c.fileCount || 0), 0),
      };
    }

    const root = await buildNode(destBasePath, "");
    return {
      tree: root ? root.children : [],
      totalFiles,
      truncated,
    };
  } catch (e) {
    return { tree: [], error: e.message };
  }
});

// Restaura varios elementos seleccionados a la vez (archivos y/o carpetas).

// ─── Progreso de la restauración ──────────────────────────────────────────────
//
// Restaurar puede tardar horas. Con solo un cartel girando, el usuario no sabe
// si va bien, si falta mucho o si se colgó, y termina cerrando el programa en
// la mitad. Se informa lo mismo que en el respaldo: cuántos archivos van, qué
// tan rápido, y cuánto falta.

// Cancelar una restauración: la pantalla la pide y las funciones de descarga
// la miran entre archivo y archivo. Sin esto, la única salida era cerrar el
// programa, que deja archivos a medio bajar.
let restauracionCancelada = false;

ipcMain.handle("restore:cancelar", () => {
  restauracionCancelada = true;
  logLine("[stop] Restauración cancelada por el usuario.");
  return { ok: true };
});

function crearSeguidor(totalArchivos, totalBytesInicial) {
  let totalBytes = totalBytesInicial || 0;
  // Con un solo archivo grande, el total se conoce al leer el índice: se puede
  // ajustar sobre la marcha para que el porcentaje tenga sentido.
  restauracionCancelada = false;
  const inicio = Date.now();
  const muestras = [{ t: inicio, b: 0 }];
  let archivos = 0, bytes = 0, fallados = 0, actual = "";
  let ultimoEnvio = 0;

  const velocidad = () => {
    // Promedio de los últimos diez segundos: el promedio total no refleja lo
    // que está pasando ahora y hace que la estimación se quede pegada.
    const corte = Date.now() - 10000;
    while (muestras.length > 2 && muestras[0].t < corte) muestras.shift();
    const a = muestras[0], z = muestras[muestras.length - 1];
    const seg = (z.t - a.t) / 1000;
    return seg > 0.5 ? (z.b - a.b) / seg : 0;
  };

  function emitir(forzar) {
    const ahora = Date.now();
    // Como mucho tres veces por segundo: más que eso solo hace trabajar a la
    // interfaz sin que el usuario perciba diferencia.
    if (!forzar && ahora - ultimoEnvio < 350) return;
    ultimoEnvio = ahora;

    const bps = velocidad();
    const faltan = Math.max(0, totalBytes - bytes);
    enviarAlRenderer("restore:progreso", {
      archivos, totalArchivos, bytes, totalBytes, fallados, actual,
      porcentaje: totalBytes > 0 ? Math.min(100, (bytes / totalBytes) * 100)
                : (totalArchivos ? (archivos / totalArchivos) * 100 : 0),
      bytesPorSegundo: bps,
      segundosRestantes: bps > 0 ? Math.round(faltan / bps) : null,
      transcurrido: Math.round((ahora - inicio) / 1000),
    });
  }

  return {
    empezar(nombre) { actual = nombre; emitir(); },
    sumar(n) {
      archivos++; bytes += n || 0;
      muestras.push({ t: Date.now(), b: bytes });
      emitir();
    },
    fallar() { fallados++; emitir(); },
    // Durante un archivo grande el avance se informa igual, para que la barra
    // no se quede quieta media hora en un archivo de 4 GB.
    // Fija el total acumulado. Al rearmar un archivo por bloques se conoce
    // cuánto se escribió hasta el momento, no el incremento.
    reemplazar(total) {
      bytes = total || 0;
      muestras.push({ t: Date.now(), b: bytes });
      emitir();
    },
    parcial(n) {
      bytes += n || 0;
      muestras.push({ t: Date.now(), b: bytes });
      emitir();
    },
    fijarTotal(n) { if (n > 0) totalBytes = n; },
    terminar() { actual = ""; emitir(true); },
    get cancelado() { return restauracionCancelada; },
  };
}

/** Copia un archivo informando el avance, para los que son grandes. */
async function copiarConAvance(origen, destino, seguidor, tamano) {
  await fsp.mkdir(path.dirname(destino), { recursive: true });
  if (tamano < 8 * 1048576) {
    await fsp.copyFile(origen, destino);
    seguidor.sumar(tamano);
    return;
  }
  await new Promise((resolver, rechazar) => {
    const rs = fs.createReadStream(origen);
    const ws = fs.createWriteStream(destino);
    rs.on("data", (b) => seguidor.parcial(b.length));
    rs.on("error", rechazar);
    ws.on("error", rechazar);
    ws.on("close", resolver);
    rs.pipe(ws);
  });
  seguidor.sumar(0);
}

ipcMain.handle("restore:local-selection", async (_e, opts) => {
  const { destBasePath, destFolder, items = [], preserveStructure = true } = opts || {};
  try {
    if (!destFolder) return { ok: false, error: "No se eligió carpeta de destino" };
    if (!destBasePath || !fs.existsSync(destBasePath)) {
      return { ok: false, error: "El destino de backup no está disponible" };
    }
    if (!items.length) return { ok: false, error: "No seleccionaste nada para restaurar" };

    // Primero se cuenta todo lo que hay que copiar. Sin el total no hay barra
    // de progreso posible, solo un cartel girando.
    const planificados = [];
    for (const item of items) {
      try {
        const st = await fsp.stat(item.fullPath);
        if (st.isFile()) {
          planificados.push({ ruta: item.fullPath, raiz: path.dirname(item.fullPath), bytes: st.size });
        } else if (st.isDirectory()) {
          const pila = [item.fullPath];
          while (pila.length) {
            const dir = pila.pop();
            let entradas;
            try { entradas = await fsp.readdir(dir, { withFileTypes: true }); } catch { continue; }
            for (const e of entradas) {
              const completa = path.join(dir, e.name);
              if (e.isDirectory()) pila.push(completa);
              else if (e.isFile()) {
                try {
                  planificados.push({ ruta: completa, raiz: path.dirname(item.fullPath),
                                      bytes: (await fsp.stat(completa)).size });
                } catch { /* se contará como fallado al copiarlo */ }
              }
            }
          }
        }
      } catch { /* lo informa el bucle de copia */ }
    }

    const seguidor = crearSeguidor(
      planificados.length,
      planificados.reduce((n, a) => n + a.bytes, 0));

    let count = 0, failed = 0, bytes = 0;

    async function copyOne(fullPath, rootForRelative, tamano) {
      const rel = preserveStructure
        ? path.relative(destBasePath, fullPath)
        : path.relative(rootForRelative, fullPath);
      const outPath = path.join(destFolder, rel);
      seguidor.empezar(path.basename(fullPath));
      await copiarConAvance(fullPath, outPath, seguidor, tamano);
      bytes += tamano;
      count++;
    }

    for (const plan of planificados) {
      if (seguidor.cancelado) break;
      try {
        await copyOne(plan.ruta, plan.raiz, plan.bytes);
      } catch {
        failed++;
        seguidor.fallar();
      }
    }
    seguidor.terminar();

    return { ok: true, path: destFolder, count, failed, bytes };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});


// ─── La clave de cifrado de la cuenta, en un solo lugar ─────────────────────
//
// Antes no existía: la restauración llamaba al almacén de bloques y a la
// descarga directa SIN clave, en los cuatro caminos. Con el cifrado activo eso
// significaba que un respaldo cifrado no se podía restaurar — el producto
// guardaba bien y no devolvía nada, que es la peor combinación posible.
//
// Se resuelve una vez por operación y no por archivo: derivar la clave de una
// frase cuesta cerca de un segundo a propósito, para que probar frases al azar
// salga caro. Hacerlo por archivo dejaría la restauración inutilizable.
function claveDeCuenta() {
  const cfg = readConfig();
  if (!cfg.cifradoModo && !cfg.cifradoFrase && !cfg.cifradoClave) return null;
  try {
    return Cifrado.abrirClave({
      modo: cfg.cifradoModo || "gestionada",
      claveServidor: cfg.cifradoClave,
      frase: cfg.cifradoFrase,
      salBase64: cfg.cifradoSal,
      comprobante: cfg.cifradoComprobante,
    });
  } catch (e) {
    // Se propaga con el mensaje del módulo de cifrado, que ya explica qué pasa
    // en castellano. Devolver null acá haría que la restauración siga y entregue
    // archivos ilegibles con nombre definitivo.
    throw new Error(`No se puede restaurar: ${e.message}`);
  }
}

// ─── Restaurar desde destinos remotos: FTP, SFTP, S3 y la nube ───────────────
//
// Hasta ahora la pestaña Restaurar solo servía para carpetas locales y de red.
// Un respaldo hecho contra FTP, SFTP o S3 se subía bien pero no había forma de
// recuperarlo desde el programa, y al elegir la nube la pantalla mostraba un
// cartel y nada más. Para un producto de backup eso es la mitad que importa.


const Bloques = require(path.join(__dirname, "bloques.cjs"));
const Cifrado = require(path.join(__dirname, "cifrado.cjs"));

const { marcarFueraDelRespaldo, textoAviso } = require("./fuera-del-respaldo.cjs");
const { armarArbol, rutasElegidas, filtrarSeleccion, relDesdeRutaOriginal } =
  require(path.join(__dirname, "restore-remoto.cjs"));

const TIPOS_REMOTOS = ["ftp", "sftp", "s3"];

function buscarDestinoRemoto(id) {
  const c = readConfig();
  const dests = Array.isArray(c.destinations) ? c.destinations : [];
  return dests.find((d) => TIPOS_REMOTOS.includes(d.type) && claveDestino(d) === id);
}

const baseFtp = (dest) => (dest.remotePath || "/").replace(/\/+$/, "");
const relDesde = (base, ruta) =>
  (ruta.startsWith(base) ? ruta.slice(base.length) : ruta).replace(/^\/+/, "");

/** Devuelve todo lo que hay en el destino, con la ruta relativa de cada archivo. */
async function inventarioRemoto(dest) {
  // Con un respaldo grande, recorrer el destino lleva su tiempo. Se informa el
  // avance para que la pantalla no parezca colgada en "Contando archivos…".
  const avisarConteo = (n, pendientes) => {
    enviarAlRenderer("restore:contando", { archivos: n, carpetas: pendientes || 0 });
  };

  if (dest.type === "ftp") {
    const sesion = new SesionFtp(dest);
    // Conexiones extra para repartir el recorrido de carpetas: es lo que hace
    // que "Contando archivos…" tarde en un destino con muchas carpetas.
    const extras = [];
    try {
      await sesion.conectar();
      const cuantas = Math.max(0, Math.min(5,
        (Number(readConfig().concurrencia) || 6) - 1));
      for (let i = 0; i < cuantas; i++) {
        try {
          const s = new SesionFtp(dest, sesion.carpetasCreadas);
          await s.conectar();
          extras.push(s);
        } catch { break; }   // el servidor no acepta más: seguimos con las que hay
      }

      const base = baseFtp(dest);
      const { archivos, truncado } = await sesion.listarTodo(base || "/", extras, (n) => avisarConteo(n));
      return {
        items: archivos.map((a) => ({ ruta: a.ruta, size: a.size, rel: relDesde(base, a.ruta) })),
        truncado,
      };
    } finally {
      await sesion.cerrar().catch(() => {});
      for (const s of extras) await s.cerrar().catch(() => {});
    }
  }

  if (dest.type === "sftp") {
    const { archivos, truncado, base } = await sftpListar(dest, (n) => avisarConteo(n));
    return {
      items: archivos.map((a) => ({ ruta: a.ruta, size: a.size, rel: relDesde(base, a.ruta) })),
      truncado,
    };
  }

  if (dest.type === "s3") {
    const { archivos, truncado } = await s3Listar(dest, (n) => avisarConteo(n));
    const prefijo = (dest.prefix || "").replace(/^\/+/, "");
    const quitarPrefijo = (clave) =>
      (clave.startsWith(prefijo) ? clave.slice(prefijo.length) : clave).replace(/^\/+/, "");

    // Los bloques y los índices son la cocina del sistema: el usuario nunca los
    // ve. En su lugar se muestran los archivos lógicos, que salen del catálogo.
    //
    // El filtro por rama NO alcanza: hasta la 0.9.8 la segunda copia del índice
    // se guardaba pegada al archivo original, así que en el listado aparecía
    // `respaldo.zip` y al lado `respaldo.zip.bpi` de 3 KB. Un cliente que elige
    // el segundo se lleva un JSON creyendo que restauró su respaldo — la peor
    // clase de error que puede tener un producto de backup. Los respaldos ya
    // hechos siguen teniendo esos objetos en el destino, así que el filtro por
    // extensión se queda para siempre, no solo hasta la migración.
    const items = archivos
      .map((a) => ({ ruta: a.clave, size: a.size, rel: quitarPrefijo(a.clave) }))
      .filter((a) => !Bloques.esRutaDeServicio(a.rel));

    try {
      const almacen = almacenDeBloques(dest, claveDeCuenta());
      const catalogo = JSON.parse(
        await almacen.bajarTexto(`${prefijo}indices/_catalogo.json`));
      for (const [rel, datos] of Object.entries(catalogo)) {
        items.push({
          ruta: `${prefijo}${rel}`, rel,
          size: datos.bytes || 0,
          porBloques: true,
          // Se marca lo que el respaldo actual ya no cubre. El archivo se sigue
          // viendo y se sigue pudiendo restaurar: lo único que cambia es que el
          // cliente sabe que su última copia es vieja, en vez de creer que esa
          // carpeta se sigue respaldando.
          fueraDelRespaldo: datos.cubierto === false,
          fueraDesde: datos.fueraDesde || null,
        });
      }
    } catch {
      // Sin catálogo simplemente no hay archivos guardados por bloques todavía.
    }

    return { items, truncado };
  }

  throw new Error(`No se puede explorar un destino de tipo ${dest.type}`);
}

/** Baja los archivos elegidos a una carpeta local. */
async function bajarRemoto(dest, elegidos, destFolder, preserveStructure) {
  const destinoDe = (a) => preserveStructure
    ? path.join(destFolder, ...a.rel.split("/"))
    : path.join(destFolder, path.basename(a.rel));

  // Los archivos guardados por bloques no traen su tamaño en el listado del
  // bucket: sale del catálogo, y si falta se ajusta al leer cada índice.
  const seguidor = crearSeguidor(
    elegidos.length, elegidos.reduce((n, a) => n + (a.size || 0), 0));

  // Cuántas descargas simultáneas. El respaldo se paralelizó en la 0.5.5 pero
  // la restauración quedó bajando de a un archivo por vez por una sola
  // conexión, y eso contra un servidor remoto es casi todo tiempo de espera.
  const simultaneas = Math.max(1, Math.min(16,
    Number(readConfig().concurrencia) || 6, elegidos.length));

  if (dest.type === "ftp") {
    // FTP no deja bajar dos archivos por la misma conexión al mismo tiempo:
    // cada trabajador abre la suya.
    const cola = [...elegidos];
    let count = 0, failed = 0, bytes = 0;

    await Promise.all(Array.from({ length: simultaneas }, async () => {
      let sesion;
      try {
        sesion = new SesionFtp(dest);
        await sesion.conectar();
      } catch {
        // Si el servidor no acepta otra conexión, este trabajador se retira y
        // los demás siguen: es mejor bajar más lento que fallar entero.
        return;
      }
      try {
        for (;;) {
          const a = cola.shift();
          if (!a || seguidor.cancelado) return;
          seguidor.empezar(path.basename(a.rel));
          try {
            const r = await sesion.descargar(a.ruta, destinoDe(a));
            count++; bytes += r.bytes; seguidor.sumar(r.bytes || a.size);
          } catch { failed++; seguidor.fallar(); }
        }
      } finally { await sesion.cerrar().catch(() => {}); }
    }));

    // Si todos los trabajadores se cayeron al conectar, no quedó nada bajado.
    if (!count && !failed && elegidos.length) {
      throw new Error("No se pudo conectar al servidor FTP para descargar.");
    }
    seguidor.terminar();
    return { count, failed, bytes };
  }

  if (dest.type === "sftp") {
    // Se reparte la lista entre varias conexiones. Cada una baja sus archivos
    // en orden, reutilizando la conexión.
    const lotes = Array.from({ length: simultaneas }, () => []);
    elegidos.forEach((a, i) => lotes[i % simultaneas].push(a));

    const resultados = await Promise.all(lotes.filter((l) => l.length).map((lote) =>
      sftpDescargarVarios(dest,
        lote.map((a) => ({ remotePath: a.ruta, destinoLocal: destinoDe(a) })),
        (hechos) => {
          const a = lote[hechos - 1];
          if (a) { seguidor.empezar(path.basename(a.rel)); seguidor.sumar(a.size); }
        })));

    seguidor.terminar();
    return {
      count: resultados.reduce((n, r) => n + r.ok, 0),
      failed: resultados.reduce((n, r) => n + r.fallados, 0),
      bytes: resultados.reduce((n, r) => n + r.bytes, 0),
    };
  }

  if (dest.type === "s3") {
    // S3 es HTTP suelto: se pueden bajar varios a la vez.
    let count = 0, failed = 0, bytes = 0;
    const cola = [...elegidos];
    // Una sola vez para toda la restauración, no una por archivo.
    const claveRestauracion = claveDeCuenta();
    const almacenBloques = almacenDeBloques(dest, claveRestauracion);
    const prefijo = (dest.prefix || "").replace(/^\/+/, "");
    const trabajador = async () => {
      for (;;) {
        const a = cola.shift();
        if (!a || seguidor.cancelado) return;
        seguidor.empezar(path.basename(a.rel));
        try {
          // Un archivo guardado por bloques se rearma desde su índice. Para el
          // usuario es exactamente igual: pidió un archivo y recibe el archivo.
          // Con varios archivos bajando a la vez no se puede fijar el total
          // acumulado: cada uno informa cuánto avanzó DESDE la última vez.
          let yaContado = 0;
          const r = a.porBloques
            ? await Bloques.restaurarPorBloques(almacenBloques, {
                rutaRelativa: a.rel, destinoLocal: destinoDe(a), prefijo,
                versionIndice: a.versionId || undefined,
                alAvanzar: (hechos, cuantos, escritos, totalDelArchivo) => {
                  seguidor.parcial(escritos - yaContado);
                  yaContado = escritos;
                },
              })
            // El versionId es obligatorio acá: sin él, S3 devuelve la versión
            // ACTUAL del objeto. Al volver una carpeta a una fecha eso significa
            // restaurar los archivos de hoy —los cifrados por el ransomware—
            // creyendo que se restauró el estado del día anterior. Los archivos
            // por bloques sí lo pasaban (`versionIndice`), los guardados enteros
            // no: el resultado era una carpeta mezclada, sin ningún aviso.
            : await s3Descargar(dest, a.ruta, destinoDe(a), a.versionId || undefined,
                // Ojo: acá NO se toca el total. `fijarTotal` reemplaza el total
                // acumulado de toda la restauración, y con varios archivos
                // bajando a la vez eso lo dejaría en el tamaño del último.
                ({ delta }) => { seguidor.parcial(delta); yaContado += delta; },
                claveRestauracion);
          count++; bytes += r.bytes;
          seguidor.sumar(Math.max(0, (r.bytes || a.size || 0) - yaContado));
        } catch { failed++; seguidor.fallar(); }
      }
    };
    await Promise.all(Array.from({ length: simultaneas }, trabajador));
    seguidor.terminar();
    return { count, failed, bytes };
  }

  throw new Error(`No se puede restaurar desde un destino de tipo ${dest.type}`);
}

// ── Inventario de la nube ────────────────────────────────────────────────────
// El servidor devuelve los archivos paginados; se piden todas las páginas para
// poder armar el árbol completo.
async function inventarioNube() {
  const c = readConfig();
  const token = decryptToken(c);
  if (!token || !c.server) throw new Error("Todavía no conectaste este equipo a tu cuenta");

  const items = [];
  let page = 1, total = null;
  while (page <= 200) {
    const url = `${c.server}/api/agent/files?page=${page}&limit=200`;
    const r = await fetchJson(url, token);
    if (r.status !== 200) throw new Error(`El servidor respondió ${r.status}`);
    const lote = (r.body && (r.body.files || r.body.items)) || [];
    if (total === null) total = Number(r.body && r.body.total) || 0;
    for (const f of lote) {
      const origen = f.sourcePath || f.path || f.name || "";
      if (!origen) continue;
      items.push({
        ruta: String(f.id || f.fileId || ""),
        versionId: f.latestVersionId || f.versionId || null,
        size: Number(f.size) || 0,
        rel: relDesdeRutaOriginal(origen),
      });
    }
    if (!lote.length || items.length >= total) break;
    page++;
  }
  return { items, truncado: page > 200 };
}

ipcMain.handle("mantenimiento:revisar", async (_e, { id }) => {
  const dest = buscarDestinoRemoto(id);
  if (!dest || dest.type !== "s3") {
    return { ok: false, error: "La revisión funciona sobre destinos S3." };
  }
  const prefijo = (dest.prefix || "").replace(/^\/+/, "");
  const r = await Bloques.verificarIndices(almacenDeBloques(dest, claveDeCuenta()), { prefijo });
  logLine(`[revisión] ${r.sanos} archivo(s) grandes en orden` +
          (r.conProblemas.length ? `, ${r.conProblemas.length} con problemas` : ""));
  for (const p of r.conProblemas) logLine(`[revisión] ${p.archivo}: ${p.problema}`);
  return { ok: true, ...r };
});

ipcMain.handle("mantenimiento:reconstruir", async (_e, { id, simular = true }) => {
  const dest = buscarDestinoRemoto(id);
  if (!dest || dest.type !== "s3") {
    return { ok: false, error: "La reconstrucción funciona sobre destinos S3." };
  }
  const prefijo = (dest.prefix || "").replace(/^\/+/, "");
  const r = await Bloques.reconstruirIndices(almacenDeBloques(dest, claveDeCuenta()), { prefijo, simular });
  logLine(`[reconstrucción] ${simular ? "Simulación: " : ""}` +
          `${r.recuperados.length} archivo(s) recuperables, ${r.incompletos.length} no`);
  for (const p of r.incompletos) logLine(`[reconstrucción] ${p.archivo}: ${p.motivo}`);
  return { ok: true, ...r };
});

/**
 * La máquina del tiempo de verdad: una carpeta —o todo el respaldo— como estaba
 * en un momento dado.
 *
 * Es distinto de restaurar versiones archivo por archivo, y es el caso que
 * importa: cuando entra un ransomware nadie quiere recuperar un archivo, quiere
 * la carpeta entera como estaba antes del ataque.
 *
 * Para cada archivo se elige la última versión anterior a la fecha pedida. Los
 * archivos que en ese momento todavía no existían simplemente no se traen: la
 * carpeta queda como estaba, no como una mezcla de épocas.
 */
ipcMain.handle("restore:a-fecha", async (_e, { id, carpeta, fecha, destFolder }) => {
  try {
    // La bandera se limpia ACÁ, al empezar. Antes solo se limpiaba al crear el
    // seguidor de la bajada, o sea DESPUÉS de la búsqueda: un cancelar de una
    // operación anterior dejaba la bandera prendida y cortaba la búsqueda
    // siguiente antes de empezar. El cliente apretaba "Restaurar" y no pasaba
    // nada, sin ninguna explicación.
    restauracionCancelada = false;
    const dest = buscarDestinoRemoto(id);
    if (!dest) return { ok: false, error: "No se encontró ese destino." };
    if (dest.type !== "s3") {
      return { ok: false, error: "Volver a una fecha necesita un destino con versionado (S3)." };
    }
    if (!destFolder) return { ok: false, error: "No se eligió carpeta de destino." };

    // Se toma el final del día elegido: si alguien pide "como estaba el martes",
    // quiere el estado al terminar el martes, no a las 00:00.
    const corte = new Date(fecha);
    if (!isNaN(corte) && /^\d{4}-\d{2}-\d{2}$/.test(String(fecha))) {
      corte.setHours(23, 59, 59, 999);
    }
    if (isNaN(corte)) return { ok: false, error: "La fecha no es válida." };

    const prefijo = (dest.prefix || "").replace(/^\/+/, "");
    const rama = (carpeta || "").replace(/^\/+/, "");

    enviarAlRenderer("restore:contando", { archivos: 0, carpetas: 0 });

    // Dos consultas nada más: los archivos guardados enteros, y los índices de
    // los guardados por bloques. Cada una devuelve todas las versiones de todos
    // los objetos de esa rama.
    const [directos, indices] = await Promise.all([
      // Las dos búsquedas se pueden abandonar: con 148.000 archivos son cientos
      // de viajes al servidor, y el cliente tiene que poder cortar.
      s3Versiones(dest, `${prefijo}${rama}`,
        (n) => enviarAlRenderer("restore:contando", { archivos: n }),
        () => restauracionCancelada),
      s3Versiones(dest, `${prefijo}indices/${rama}`, null,
        () => restauracionCancelada),
    ]);

    const elegidos = [];
    const sinVersion = [];

    const aLaFecha = (lista) => {
      const validas = lista
        .filter((v) => !v.borrado && v.fecha && new Date(v.fecha) <= corte)
        .sort((a, b) => new Date(b.fecha) - new Date(a.fecha));
      return validas[0] || null;
    };

    for (const [clave, lista] of directos) {
      const rel = clave.startsWith(prefijo) ? clave.slice(prefijo.length) : clave;
      if (Bloques.esRutaDeServicio(rel)) continue;
      const v = aLaFecha(lista);
      if (!v) { sinVersion.push(rel); continue; }
      elegidos.push({ rel, ruta: clave, versionId: v.versionId, size: v.bytes || 0 });
    }

    for (const [clave, lista] of indices) {
      // Dentro de indices/ también vive el catálogo, que no es el índice de
      // ningún archivo: si se cuela, el programa intenta restaurar un archivo
      // llamado "_catalogo.json" que no existe.
      if (!clave.endsWith(".bpi")) continue;
      const rel = clave
        .replace(new RegExp(`^${prefijo}indices/`), "")
        .replace(/\.bpi$/, "");
      if (!rel) continue;
      const v = aLaFecha(lista);
      if (!v) { sinVersion.push(rel); continue; }
      elegidos.push({ rel, ruta: `${prefijo}${rel}`, versionId: v.versionId, size: 0, porBloques: true });
    }

    if (!elegidos.length) {
      return {
        ok: false,
        error: `No hay ninguna versión anterior a esa fecha en ${rama || "el respaldo"}. ` +
               `Probá con una fecha posterior.`,
      };
    }

    const r = await bajarRemoto(dest, elegidos, destFolder, true);
    logLine(`[máquina del tiempo] ${rama || "todo"} al ${corte.toLocaleString("es-AR")}: ` +
            `${r.count} archivo(s) restaurados` +
            (sinVersion.length ? `, ${sinVersion.length} no existían todavía` : "") +
            (r.failed ? `, ${r.failed} con error` : ""));

    return {
      ok: true, path: destFolder, restaurados: r.count, fallados: r.failed,
      bytes: r.bytes, noExistian: sinVersion.length,
      cancelado: r.cancelado || false,
    };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

/**
 * Qué fechas tienen algo guardado en esta rama. Sirve para no ofrecerle al
 * usuario un calendario vacío donde tenga que adivinar.
 */
ipcMain.handle("restore:fechas", async (_e, { id, carpeta }) => {
  try {
    const dest = buscarDestinoRemoto(id);
    if (!dest || dest.type !== "s3") return { fechas: [] };
    const prefijo = (dest.prefix || "").replace(/^\/+/, "");
    const rama = (carpeta || "").replace(/^\/+/, "");

    const [directos, indices] = await Promise.all([
      s3Versiones(dest, `${prefijo}${rama}`),
      s3Versiones(dest, `${prefijo}indices/${rama}`),
    ]);

    const dias = new Map();
    for (const mapa of [directos, indices]) {
      for (const [clave, lista] of mapa) {
        if (clave.endsWith("_catalogo.json")) continue;
        for (const v of lista) {
          if (!v.fecha || v.borrado) continue;
          const dia = v.fecha.slice(0, 10);
          dias.set(dia, (dias.get(dia) || 0) + 1);
        }
      }
    }
    const fechas = [...dias.entries()]
      .map(([dia, cambios]) => ({ dia, cambios }))
      .sort((a, b) => b.dia.localeCompare(a.dia));

    // El calendario tiene que saber hasta dónde llega el respaldo. Sin esto el
    // usuario podía elegir una fecha anterior al primer respaldo y solo recibía
    // "no hay ninguna versión anterior a esa fecha", sin ninguna pista de qué
    // fecha sí servía.
    return {
      fechas,
      primera: fechas.length ? fechas[fechas.length - 1].dia : null,
      ultima: fechas.length ? fechas[0].dia : null,
      totalDias: fechas.length,
    };
  } catch (e) {
    return { fechas: [], primera: null, ultima: null, error: e.message };
  }
});

ipcMain.handle("restore:versiones", async (_e, { id, relPath, porBloques }) => {
  try {
    const dest = buscarDestinoRemoto(id);
    restauracionCancelada = false;
    if (!dest) return { versiones: [], error: "No se encontró ese destino." };
    if (dest.type !== "s3") {
      // El versionado lo guarda el proveedor de almacenamiento. En FTP, SFTP y
      // carpetas locales el archivo se sobrescribe: no hay historial que pedir.
      return { versiones: [], sinSoporte: true };
    }

    const prefijo = (dest.prefix || "").replace(/^\/+/, "");

    // Un archivo guardado por bloques NO existe como objeto con su nombre: vive
    // repartido en pedazos, y lo que se versiona es su índice. Buscar las
    // versiones por el nombre del archivo devolvía siempre vacío, y la pantalla
    // decía "no hay versiones anteriores" — que era mentira, y justamente en los
    // archivos más importantes del cliente.
    // La última de cada lista es la ubicación vieja, pegada al archivo: los
    // respaldos hechos antes de la 0.9.9 tienen el índice ahí y su historial de
    // versiones también.
    const candidatos = porBloques
      ? [`${prefijo}indices/${relPath}.bpi`, `${prefijo}indices-copia/${relPath}.bpi`,
         `${prefijo}${relPath}.bpi`]
      : [`${prefijo}${relPath}`, `${prefijo}indices/${relPath}.bpi`,
         `${prefijo}indices-copia/${relPath}.bpi`, `${prefijo}${relPath}.bpi`];

    // Se guarda qué se consultó y qué contestó el servidor. Cuando la pantalla
    // dice "no hay versiones", esto permite saber si el archivo realmente tiene
    // una sola o si estamos preguntando por la clave equivocada — que ya nos
    // pasó, y sin este detalle no había forma de distinguirlo.
    const intentos = [];

    for (const clave of candidatos) {
      if (restauracionCancelada) break;
      const mapa = await s3Versiones(dest, clave, null, () => restauracionCancelada);
      const todas = mapa.get(clave) || [];
      const lista = todas.filter((v) => !v.borrado);
      intentos.push({
        clave,
        encontradas: todas.length,
        utiles: lista.length,
        // Si el listado devolvió algo pero con otra clave, es un problema de
        // prefijo y conviene verlo.
        otrasClaves: [...mapa.keys()].filter((k) => k !== clave).slice(0, 3),
      });
      if (!lista.length) continue;

      const esIndice = clave.endsWith(".bpi");
      return {
        versiones: lista.map((v) => ({
          versionId: v.versionId,
          fecha: v.fecha,
          // El índice pesa unos kilobytes; el tamaño que le importa al usuario es
          // el del archivo, que está escrito adentro del índice.
          bytes: esIndice ? null : v.bytes,
          actual: v.actual,
        })),
        porBloques: esIndice,
        diagnostico: intentos,
      };
    }

    return { versiones: [], unaSola: true, diagnostico: intentos };
  } catch (e) {
    return { versiones: [], error: e.message };
  }
});

ipcMain.handle("restore:version", async (_e, { id, relPath, versionId, destFolder, porBloques, bytesEsperados }) => {
  try {
    const dest = buscarDestinoRemoto(id);
    if (!dest) return { ok: false, error: "No se encontró ese destino." };
    if (!destFolder) return { ok: false, error: "No se eligió carpeta de destino." };

    const prefijo = (dest.prefix || "").replace(/^\/+/, "");

    // La versión anterior se guarda con el momento en el nombre, para que no
    // pise el archivo actual. Nadie quiere descubrir que "restauré la versión de
    // ayer" borró la de hoy.
    const partes = relPath.split("/");
    const nombre = partes.pop();
    const punto = nombre.lastIndexOf(".");
    const marca = new Date().toISOString().slice(0, 16).replace(/[-:T]/g, "")
      .replace(/(\d{8})(\d{4})/, "$1-$2");
    const conMarca = punto > 0
      ? `${nombre.slice(0, punto)} (versión ${marca})${nombre.slice(punto)}`
      : `${nombre} (versión ${marca})`;

    const destino = path.join(destFolder, ...partes, conMarca);

    // Aunque sea un solo archivo, se informa el avance: un PST de 651 MB tarda
    // minutos y sin nada en pantalla el usuario no sabe si está pasando algo.
    //
    // El tamaño se pasa desde la pantalla (la lista de versiones ya lo conoce) y
    // se corrige con el Content-Length real. Sin un total, `crearSeguidor` cae
    // en el porcentaje por cantidad de archivos: con un solo archivo eso daba
    // 0% durante toda la descarga y 100% al final. La barra estaba, pero no se
    // movía nunca, y para el usuario es lo mismo que no tenerla.
    const seguidor = crearSeguidor(1, Number(bytesEsperados) || 0);
    seguidor.empezar(nombre);

    const claveRestauracion = claveDeCuenta();
    const r = porBloques
      ? await Bloques.restaurarPorBloques(almacenDeBloques(dest, claveRestauracion), {
          rutaRelativa: relPath, destinoLocal: destino, prefijo,
          versionIndice: versionId,
          alAvanzar: (hechos, cuantos, escritos, totalBytes) => {
            seguidor.fijarTotal(totalBytes);
            seguidor.reemplazar(escritos);
          },
        })
      : await s3Descargar(dest, `${prefijo}${relPath}`, destino, versionId,
          ({ total, bytes }) => {
            // Con un solo archivo sí conviene fijar el total: es el total de
            // toda la restauración.
            if (total > 0) seguidor.fijarTotal(total);
            seguidor.reemplazar(bytes);
          },
          claveRestauracion);

    seguidor.sumar(r.bytes || 0);
    seguidor.terminar();

    logLine(`[restaurado] Versión anterior de ${relPath} → ${destino}`);
    return { ok: true, path: destino, bytes: r.bytes };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

/* ── Papelera ──────────────────────────────────────────────────────────────
   Es la MISMA papelera que se ve en el portal: vive en el servidor. Si cada
   equipo tuviera la suya, un estudio con cuatro PCs vería cuatro listas
   distintas y lo borrado desde la web no aparecería acá. */
ipcMain.handle("papelera:listar", async () => {
  try { return await pedirAlServidor("GET", "/api/portal/papelera"); }
  catch (e) { return { error: e.message }; }
});

ipcMain.handle("papelera:mandar", async (_e, { archivos, carpeta }) => {
  try {
    // Va la lista completa con el tamaño de cada archivo: al mandar una carpeta
    // entera, la papelera tiene que poder decir cuánto espacio se liberó.
    return await pedirAlServidor("POST", "/api/portal/papelera/mandar", {
      archivos, carpeta: carpeta || null,
      equipo: readConfig().deviceName || os.hostname(),
    });
  } catch (e) { return { error: e.message }; }
});

ipcMain.handle("papelera:recuperar", async (_e, { id }) => {
  try { return await pedirAlServidor("POST", "/api/portal/papelera/recuperar", { id }); }
  catch (e) { return { error: e.message }; }
});

ipcMain.handle("restore:remoto-tree", async (_e, { id, tipo, search = "" }) => {
  try {
    const { items, truncado } = tipo === "cloud"
      ? await inventarioNube()
      : await (async () => {
          const dest = buscarDestinoRemoto(id);
          if (!dest) throw new Error("No se encontró ese destino en la configuración");
          return inventarioRemoto(dest);
        })();

    // Se marca ANTES de filtrar por búsqueda: el resumen tiene que contar todo
    // lo que hay guardado fuera del respaldo, no solo lo que coincide con lo que
    // el cliente escribió en el buscador.
    const { items: marcados, resumen } =
      marcarFueraDelRespaldo(items, readConfig().localPaths || []);

    const coincide = armarBusqueda(search);
    const filtrados = coincide ? marcados.filter((a) => coincide(a.rel)) : marcados;
    return {
      tree: armarArbol(filtrados),
      totalFiles: filtrados.length,
      truncated: truncado,
      fueraDelRespaldo: resumen,
      avisoFueraDelRespaldo: textoAviso(resumen),
    };
  } catch (e) {
    return { tree: [], error: e.message };
  }
});

ipcMain.handle("restore:remoto-selection", async (_e, opts) => {
  const { id, tipo, destFolder, items = [], preserveStructure = true, todo = false } = opts || {};
  try {
    if (!destFolder) return { ok: false, error: "No se eligió carpeta de destino" };
    if (!todo && !items.length) return { ok: false, error: "No seleccionaste nada para restaurar" };

    const dest = tipo === "cloud" ? null : buscarDestinoRemoto(id);
    if (tipo !== "cloud" && !dest) {
      return { ok: false, error: "No se encontró ese destino en la configuración" };
    }

    // Solo se recorre el destino entero cuando se pide restaurar TODO. Para una
    // selección, la pantalla ya sabe qué archivos son: volver a listar 148.000
    // objetos para encontrar los tres que eligió el usuario dejaba el cartel de
    // "Restaurando…" girando varios minutos sin que pasara nada visible.
    let elegidos;
    if (todo) {
      const { items: inventario } = tipo === "cloud" ? await inventarioNube() : await inventarioRemoto(dest);
      elegidos = inventario;
    } else {
      elegidos = items
        .filter((x) => x && x.type === "file" && x.relPath)
        .map((x) => ({
          rel: x.relPath,
          ruta: x.fullPath || x.relPath,
          size: x.size || 0,
          porBloques: !!x.porBloques,
        }));
    }

    if (!elegidos.length) {
      // `inventario` solo existe dentro del `if (todo)`, así que en la rama de
      // selección esta línea tiraba un ReferenceError y el usuario recibía
      // "Cannot access 'inventario'" en lugar de una explicación. Los dos casos
      // ahora se distinguen por lo que sí se sabe acá.
      return { ok: false, error: todo
        ? "No se encontró ningún archivo en el destino."
        : "Lo seleccionado ya no está en el destino. Actualizá el listado y probá de nuevo." };
    }

    const r = tipo === "cloud"
      ? await bajarDeLaNube(elegidos, destFolder, preserveStructure)
      : await bajarRemoto(dest, elegidos, destFolder, preserveStructure);

    return { ok: true, cancelado: restauracionCancelada, path: destFolder,
             count: r.count, failed: r.failed, bytes: r.bytes };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

async function bajarDeLaNube(elegidos, destFolder, preserveStructure) {
  const c = readConfig();
  const token = decryptToken(c);
  let count = 0, failed = 0, bytes = 0;

  // Los archivos guardados por bloques no traen su tamaño en el listado del
  // bucket: sale del catálogo, y si falta se ajusta al leer cada índice.
  const seguidor = crearSeguidor(
    elegidos.length, elegidos.reduce((n, a) => n + (a.size || 0), 0));

  for (const a of elegidos) {
    if (seguidor.cancelado) break;
    seguidor.empezar(path.basename(a.rel));
    const salida = preserveStructure
      ? path.join(destFolder, ...a.rel.split("/"))
      : path.join(destFolder, path.basename(a.rel));
    try {
      const id = a.versionId || a.ruta;
      const url = `${c.server}/api/agent/files/${encodeURIComponent(id)}/download`;
      const r = await fetchJson(url, token);
      if (r.status !== 200) { failed++; continue; }
      await fsp.mkdir(path.dirname(salida), { recursive: true });
      if (r.body && r.body.url) await downloadToPath(r.body.url, null, salida);
      else await downloadToPath(url, token, salida);
      count++;
      bytes += a.size || 0;
      seguidor.sumar(a.size);
    } catch { failed++; seguidor.fallar(); }
  }
  seguidor.terminar();
  return { count, failed, bytes };
}

// ─── Autoarranque con el sistema ──────────────────────────────────────────────
//
// Crítico para un producto de backup: si el programa no arranca solo, el
// usuario asume que está respaldando cuando en realidad no corre nada.
// Se activa por defecto en la primera ejecución, y arranca minimizado en la
// bandeja para no molestar al prender la PC.

// --hidden: al iniciar con Windows arranca directo a la bandeja, sin abrir
// la ventana en la cara del usuario.
//
// IMPORTANTE: en Windows, getLoginItemSettings() compara el comando guardado
// en el registro contra el ejecutable y los argumentos que se le pasan. Si se
// escribe con args y después se lee sin ellos, devuelve openAtLogin: false
// aunque el arranque automático esté perfectamente configurado. Por eso los
// dos usan exactamente las mismas opciones: leer y escribir tienen que hablar
// el mismo idioma, si no la tilde de la pantalla se destildaba sola.
const Tarea = require("./tarea-programada.cjs");
const Vss = require("./vss.cjs");

const ARGS_AUTOARRANQUE = ["--hidden"];

function opcionesAutoarranque(enabled) {
  return {
    path: process.execPath,
    args: enabled ? ARGS_AUTOARRANQUE : [],
  };
}

/**
 * Configura el arranque automático.
 *
 * Se prefiere la tarea programada con privilegios altos, porque es la única
 * forma de que el programa arranque elevado —y por lo tanto de que VSS funcione,
 * y por lo tanto de que el PST de Outlook se respalde— sin pedirle permisos al
 * usuario en cada arranque.
 *
 * La entrada en el registro Run queda como respaldo: arranca el programa sin
 * elevación, así que los archivos abiertos se saltean, pero es mejor que no
 * arrancar. Se usa solo si la tarea no se pudo crear.
 *
 * Importante: nunca las dos a la vez, o el programa se abre dos veces.
 */
async function setAutoStart(enabled) {
  const registroRun = (activar) => {
    try {
      app.setLoginItemSettings({
        openAtLogin: !!activar,
        ...opcionesAutoarranque(!!activar),
      });
      return true;
    } catch (e) {
      console.error("No se pudo configurar el autoarranque:", e.message);
      return false;
    }
  };

  if (!enabled) {
    await Tarea.eliminar().catch(() => {});
    registroRun(false);
    writeConfig({ autoStart: false });
    return { ok: true, enabled: false };
  }

  if (process.platform === "win32") {
    const r = await Tarea.crear(process.execPath).catch(() => ({ ok: false }));
    if (r.ok) {
      // Con la tarea activa, la entrada del registro sobra y duplicaría el
      // arranque.
      registroRun(false);
      writeConfig({ autoStart: true });
      return { ok: true, enabled: true, privilegiada: true };
    }
    // No se pudo crear la tarea (falta elevación). Se cae al registro para que
    // al menos arranque, y se informa que va sin privilegios.
    const okRun = registroRun(true);
    writeConfig({ autoStart: okRun });
    return {
      ok: okRun, enabled: okRun, privilegiada: false,
      motivo: r.motivo || null, necesitaAdmin: !!r.necesitaAdmin,
    };
  }

  const ok = registroRun(true);
  writeConfig({ autoStart: ok });
  return { ok, enabled: ok, privilegiada: false };
}

async function getAutoStart() {
  let porRegistro = false;
  try {
    porRegistro = !!app.getLoginItemSettings(opcionesAutoarranque(true)).openAtLogin;
  } catch {}
  const tarea = await Tarea.estado().catch(() => ({ existe: false, privilegiada: false }));
  return {
    enabled: tarea.existe || porRegistro,
    // Si arranca sin privilegios, los archivos abiertos van a quedar afuera y el
    // usuario tiene que saberlo antes de descubrirlo en una restauración.
    privilegiada: !!tarea.privilegiada,
    metodo: tarea.existe ? "tarea" : (porRegistro ? "registro" : null),
  };
}

ipcMain.handle("config:get-autostart", async () => {
  const a = await getAutoStart();
  return {
    ...a,
    soportado: process.platform === "win32" || process.platform === "darwin",
    // Si el programa está corriendo elevado AHORA, las instantáneas funcionan en
    // esta sesión aunque el arranque automático esté mal configurado.
    elevadoAhora: Vss.esAdministrador(),
  };
});

ipcMain.handle("config:set-autostart", async (_e, enabled) => {
  const r = await setAutoStart(enabled);
  const estado = await getAutoStart();
  return { ...r, ...estado, ok: r.ok };
});

// ─── App lifecycle ────────────────────────────────────────────────────────────

app.whenReady().then(() => {
  // Si arrancó con Windows, no abrimos ventana: queda corriendo en la bandeja
  const arrancoOculto = process.argv.includes("--hidden");
  createWindow(arrancoOculto);

  // Icono de bandeja: monocromo y adaptado al tema del sistema.
  // Antes se usaba icon.png (que además no existía en el paquete), por eso
  // no aparecía nada en la bandeja.
  let trayIcon;
  try {
    const oscuro = nativeTheme.shouldUseDarkColors;
    const archivo = oscuro ? "tray-light.png" : "tray-dark.png";
    trayIcon = nativeImage.createFromPath(path.join(__dirname, archivo));
    if (trayIcon.isEmpty()) {
      // Reserva: el icono de la app, redimensionado
      trayIcon = nativeImage
        .createFromPath(path.join(__dirname, "icon.png"))
        .resize({ width: 16, height: 16 });
    }
  } catch {
    trayIcon = nativeImage.createEmpty();
  }

  try {
    tray = new Tray(trayIcon);
    const refrescarTray = () => {
      const corriendo = engine.isActive;
      tray.setToolTip(corriendo
        ? "BackupPrime — vigilancia activa"
        : "BackupPrime — detenido");
      tray.setContextMenu(Menu.buildFromTemplate([
        { label: corriendo ? "● Vigilancia activa" : "○ Detenido", enabled: false },
        { type: "separator" },
        { label: "Abrir BackupPrime", click: () => showWindow() },
        { label: "Respaldar ahora", click: () => engine.runOnce(buildEngineConfig()) },
        { type: "separator" },
        {
          label: "Iniciar con Windows",
          type: "checkbox",
          checked: getAutoStart(),
          click: (item) => { setAutoStart(item.checked).finally(refrescarTray); },
        },
        { type: "separator" },
        { label: "Salir", click: () => { app.isQuiting = true; engine.stop(); app.quit(); } },
      ]));
    };
    refrescarTray();
    engine.on("status", refrescarTray);
    tray.on("double-click", () => showWindow());
    tray.on("click", () => { if (process.platform === "win32") showWindow(); });

    // Si cambia el tema del sistema, cambiamos el icono para que siga visible
    nativeTheme.on("updated", () => {
      try {
        const archivo = nativeTheme.shouldUseDarkColors ? "tray-light.png" : "tray-dark.png";
        tray.setImage(nativeImage.createFromPath(path.join(__dirname, archivo)));
      } catch {}
    });
  } catch (e) {
    console.error("Tray init failed:", e.message);
  }

  // Primera ejecución: activamos el autoarranque por defecto. Es lo que el
  // usuario espera de un backup, y si no lo quiere lo apaga en Configuración.
  const cfg = readConfig();
  if (cfg.autoStart === undefined) {
    // Sin await a propósito: no vale la pena demorar el arranque de la ventana
    // por esto. El .catch evita una promesa rechazada sin manejar.
    setAutoStart(true).catch(() => {});
  }

  const c = readConfig();
  const hasToken = !!(c.tokenEncrypted || c.token);
  const hasDests = Array.isArray(c.destinations) && c.destinations.length > 0;
  const hasPaths = Array.isArray(c.localPaths) && c.localPaths.length > 0;
  if ((hasToken && c.server) || (hasDests && hasPaths)) {
    engine.start(buildEngineConfig());
  }
});

app.on("window-all-closed", (e) => { e.preventDefault(); });
app.on("before-quit", () => { engine.stop(); });
