"use strict";
/**
 * ¿Qué de lo guardado ya no lo cubre el respaldo actual?
 *
 * Cuando el cliente saca una carpeta del trabajo, mueve un directorio o cambia
 * una letra de unidad, lo que ya se subió **queda en la nube**. Eso está bien:
 * el archivo sigue ahí y se puede restaurar.
 *
 * El problema es que hasta ahora no se distinguía. En la pantalla de Restaurar,
 * un archivo cuya última copia es de marzo se veía igual que uno de esta
 * mañana. Y esa confusión es la peor que puede tener un producto de respaldo:
 * el cliente cree que una carpeta se sigue respaldando y hace tres meses que no.
 *
 * Este módulo no borra, no mueve y no toca nada. Solo marca.
 *
 * Vive aparte de main.cjs y no toca Electron ni la red, para poder probarlo.
 */

/** Normaliza para comparar rutas de Windows sin sorpresas. */
function normalizar(ruta) {
  return String(ruta || "")
    .replace(/\\/g, "/")
    .replace(/\/+$/, "")
    .toLowerCase();
}

/**
 * ¿La ruta está dentro de alguna de las carpetas del trabajo?
 *
 * Compara por segmento y no por prefijo de texto: `C:/Datos2` NO está dentro de
 * `C:/Datos`, aunque empiece igual. Con `startsWith` pelado, sacar "Datos" del
 * trabajo dejaba a "Datos2" marcado como cubierto, o al revés.
 */
function estaCubierta(rutaArchivo, carpetas) {
  const a = normalizar(rutaArchivo);
  if (!a) return false;
  for (const carpeta of carpetas || []) {
    const c = normalizar(carpeta);
    if (!c) continue;
    if (a === c) return true;
    if (a.startsWith(c + "/")) return true;
  }
  return false;
}

/**
 * Marca cada archivo del inventario con `fueraDelRespaldo`.
 *
 * @param {Array} items  [{ rel, ruta, size, originalPath }]
 * @param {Array} carpetasDelTrabajo  las que hoy respalda el cliente
 * @returns {{items, resumen}}
 *
 * Si no se conocen las carpetas del trabajo —configuración vacía o todavía no
 * leída— NO se marca nada. Marcar todo como "fuera del respaldo" porque no
 * pudimos leer la configuración sería el peor aviso posible: le diría al cliente
 * que nada se está respaldando cuando en realidad no sabemos.
 */
function marcarFueraDelRespaldo(items, carpetasDelTrabajo) {
  const carpetas = (carpetasDelTrabajo || []).filter(Boolean);
  const sinDatos = carpetas.length === 0;

  let fuera = 0, bytesFuera = 0;
  const marcados = (items || []).map((it) => {
    const original = it.originalPath || it.rutaOriginal || "";
    const afuera = !sinDatos && !!original && !estaCubierta(original, carpetas);
    if (afuera) { fuera++; bytesFuera += Number(it.size) || 0; }
    return { ...it, fueraDelRespaldo: afuera };
  });

  return {
    items: marcados,
    resumen: {
      // `desconocido` es distinto de "no hay ninguno": una pantalla no puede
      // afirmar que está todo cubierto cuando no pudo comprobarlo.
      desconocido: sinDatos,
      archivosFuera: fuera,
      bytesFuera,
      archivosTotales: marcados.length,
      hayFuera: fuera > 0,
    },
  };
}

/** Texto del cartel. Uno solo, para que el cliente y el portal digan lo mismo. */
function textoAviso(resumen) {
  if (!resumen || resumen.desconocido || !resumen.hayFuera) return null;
  const n = resumen.archivosFuera;
  return {
    titulo: n === 1
      ? "Hay 1 archivo guardado que el respaldo actual ya no cubre"
      : `Hay ${n.toLocaleString("es-AR")} archivos guardados que el respaldo actual ya no cubre`,
    // Lo primero que tiene que leer es que NO los perdió.
    cuerpo: "Los podés restaurar como siempre, pero no se están actualizando: " +
            "quedaron de carpetas que sacaste del respaldo o que se movieron.",
  };
}

module.exports = { marcarFueraDelRespaldo, estaCubierta, normalizar, textoAviso };
