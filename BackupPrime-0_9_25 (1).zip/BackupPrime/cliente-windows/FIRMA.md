# El cartel de "Editor desconocido"

## Por qué no se puede simplemente poner "BackupPrime"

Ya lo pusimos. El instalador declara `BackupPrime` como empresa, con su
copyright, y si le hacés clic derecho → Propiedades lo vas a ver ahí.

Windows lo ignora para decidir si confía, y el motivo es obvio si te ponés del
otro lado: si alcanzara con escribir un nombre adentro del archivo, cualquiera
pondría "Microsoft" o "Banco Nación". El nombre que Windows muestra en el cartel
azul no sale del archivo: sale de un **certificado**, que emite una autoridad
certificante después de verificar que la empresa existe, que vos la representás,
y que el domicilio y el teléfono son reales.

O sea: no es un ajuste de compilación, es un trámite. Lo bueno es que cuando lo
tenés, el cartel desaparece solo.

## Qué cambia exactamente

| Sin certificado | Con certificado |
|---|---|
| Pantalla azul: "Windows protegió tu PC" | Se abre el instalador |
| "Editor: desconocido" | "Editor: BackupPrime SRL" |
| Hay que hacer "Más información → Ejecutar de todas formas" | No hay que hacer nada |
| Algunos antivirus lo ponen en cuarentena | Mucho menos frecuente |

## Las opciones, con precios de 2026

Desde 2023 **ningún certificado se entrega como archivo**: la clave privada
tiene que vivir en un token USB o en un HSM en la nube. Y desde febrero de 2026
la validez máxima de los certificados nuevos es de un año, así que es un gasto
anual, no una compra.

### Certum en la nube — la más conveniente para Argentina

Alrededor de **108 dólares por año** a través de revendedores. Autoridad
certificante polaca, emite a empresas y personas de cualquier país, sin token
físico, y se firma con `signtool` desde Windows.

Es por la que arrancaría. Pedí el tipo **Standard** (también llamado OV) a
nombre de tu SRL.

### Azure de Microsoft — la más barata, pero no te sirve

Unos 10 dólares por mes, y es la primera que aparece cuando buscás. Está
limitada a empresas y trabajadores independientes verificados de Estados Unidos,
Canadá, la Unión Europea y el Reino Unido. **Argentina no está en la lista.** La
menciono para que no pierdas el tiempo intentándolo.

### EV — la versión caché

Entre 400 y 700 dólares por año. La diferencia práctica está en la reputación de
SmartScreen: con un certificado Standard, Windows deja de decir "editor
desconocido", pero puede seguir mostrando la pantalla azul hasta que tu
instalador acumule descargas. Con EV eso se resuelve más rápido.

Arrancá con Standard. Si a los tres meses la pantalla azul sigue apareciendo y te
está costando ventas, pasás a EV.

## El trámite

Lo que van a pedir:

1. **Constancia de inscripción** de la empresa (CUIT).
2. **Comprobante de domicilio** a nombre de la empresa.
3. **Un teléfono verificable**: te llaman, o tiene que figurar en un registro
   público. Este es el que más demora a las empresas argentinas.
4. **Documento del firmante.**

Tarda entre tres días y dos semanas, casi siempre por el punto 3. Si la empresa
está dada de alta hace poco, preguntá antes de pagar.

## Cuando llegue, firmar es un comando

El proyecto ya está preparado. En una PC con Windows, con el certificado
instalado o con la sesión del servicio en la nube abierta:

```
set BP_FIRMA=certum
set BP_FIRMA_SUJETO=BackupPrime SRL
npm run build:firmado
```

`build:firmado` primero verifica que la firma esté bien configurada y recién
después compila. Si falta algo, corta antes de compilar en vez de dejarte un
instalador sin firmar que parece bueno.

Para comprobar el resultado:

```
signtool verify /pa /v dist\BackupPrime-Setup-0.5.7.exe
```

Sin las variables, la compilación sigue funcionando y sale sin firmar, avisando
por pantalla: el build de todos los días no depende de que el token esté puesto.

**El sello de tiempo ya quedó configurado.** Es importante: sin él, la firma deja
de valer el día que vence el certificado y todos los instaladores que tus
clientes ya bajaron vuelven a mostrar la advertencia. Con sello de tiempo, la
firma vale para siempre.

## Mientras no lo tengas

Lo que ya está hecho:

- La página de descargas explica el cartel y cómo pasarlo, paso a paso.
- Publica el código SHA-256, para que un cliente desconfiado pueda verificar que
  el archivo es el nuestro.
- El instalador lleva el nombre, el ícono y el copyright correctos, así que en
  Propiedades se ve de quién es.

Dos cosas más que ayudan y no cuestan plata:

**Mandá el instalador a Microsoft para análisis.** En el portal de Microsoft
Security Intelligence se puede enviar un archivo como falso positivo. Reduce las
cuarentenas de Defender.

**No cambies el nombre del archivo en cada versión.** La reputación de SmartScreen
se acumula por firma y por nombre de archivo. Un `BackupPrime-Setup.exe` estable,
con la versión adentro del archivo, acumula mejor que un nombre distinto cada vez.

Y para los primeros clientes: **instalalo vos**. Un estudio al que le instalás el
sistema en persona no ve ningún cartel raro, y de paso te enterás de cómo
trabajan y qué carpetas les importan.
