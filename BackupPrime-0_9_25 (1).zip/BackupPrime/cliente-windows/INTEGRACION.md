# Integrar guardia anti-cifrado y VSS en BackupPrime 0.5.3

Los dos módulos nuevos (`electron/guardia-cifrado.cjs` y `electron/vss.cjs`) son
**archivos sueltos**. No modifican nada. Podés tenerlos en el proyecto sin
enchufarlos y todo sigue funcionando igual.

Para que actúen hay que agregar **cinco fragmentos** a `backup-engine.cjs`.
Ninguno reemplaza código existente: los cinco son inserciones.

**Antes de empezar:**

```
copy electron\backup-engine.cjs electron\backup-engine.cjs.original
node pruebas\guardia-y-vss.cjs      ← tiene que dar 22 de 22
npm start                            ← tiene que abrir la ventana
```

Si `npm start` no abre **antes** de tocar nada, pará acá: el problema es otro y
agregar cosas encima lo va a tapar.

Después de cada fragmento, `npm start` de nuevo. Si deja de abrir, sabés cuál
fue y lo sacás.

---

## Fragmento 1 — los requires

**Buscá** (arriba de todo, alrededor de la línea 17):

```js
const https = require("node:https");
const http = require("node:http");
```

**Agregá abajo:**

```js
const { GuardiaCifrado, extensionesDelEstado } = require(path.join(__dirname, "guardia-cifrado.cjs"));
const vss = require(path.join(__dirname, "vss.cjs"));
```

Probá que abre. Si abre, los módulos cargan bien.

---

## Fragmento 2 — arrancar el guardia y las instantáneas

**Buscá** (dentro de `_doBackup`, justo antes del bucle de carpetas):

```js
    let localCopied = 0;

    for (const root of includedPaths) {
```

**Insertá entre las dos líneas:**

```js
    // ── Guardia anti-cifrado ──
    const ultimoRespaldoMs = state.get("__ultimoRespaldo__") || 0;
    const guardia = new GuardiaCifrado({
      umbrales: cfg.guardia || {},
      referenciaMs: ultimoRespaldoMs,
      extensionesConocidas: extensionesDelEstado(state._data),
      primerRespaldo: isFirstRun,
    });
    let cortadoPorGuardia = false;

    // ── Instantáneas de volumen ──
    // Permiten copiar bases abiertas (Tango, Access, SQL Express). Si no hay
    // permisos de administrador, devuelve un objeto vacío y el respaldo sigue.
    let instantaneas = null;
    if (cfg.usarVSS !== false && process.platform === "win32") {
      instantaneas = vss.crearParaCarpetas(includedPaths, (msg, tipo) => {
        this.log(`[${tipo === "exito" ? "ok" : "aviso"}] ${msg}`);
      });
    }
```

---

## Fragmento 3 — alimentar el guardia en cada archivo

**Buscá** (adentro del `for await (const file of walkDir(...))`):

```js
          progreso.fase = "analizando";
          progreso.archivoActual = path.basename(file.sourcePath);
```

**Insertá justo arriba:**

```js
          if (guardia.ver(file)) {
            cortadoPorGuardia = true;
            const inf = guardia.informe();
            this.log("[error] Guardia anti-cifrado: actividad compatible con ransomware.");
            for (const m of inf.motivos) this.log(`[error]   · ${m}`);
            this.log("[error] Respaldo detenido para no sobrescribir las versiones sanas.");
            this.emit("alerta-seguridad", inf);
            break;
          }
```

El `break` corta el recorrido de esa carpeta. El fragmento 5 corta el resto.

---

## Fragmento 4 — leer desde la instantánea

Este es el que hace que las bases abiertas se puedan copiar.

**Buscá** la línea donde se calcula el hash del archivo:

```js
          let hash;
```

**Insertá justo arriba:**

```js
          const rutaLectura = instantaneas
            ? vss.rutaDeLectura(file.sourcePath, instantaneas)
            : file.sourcePath;
```

Después, **en las llamadas que leen el archivo** (`hashFile`, `uploadFileHTTP`,
`s3Upload`, `sftpUpload`, `ftpUpload`, y la copia a destinos locales), cambiá
`file.sourcePath` por `rutaLectura`.

> **Ojo:** solo en las llamadas que **leen bytes del disco**. La ruta que se
> guarda en el `state`, la que se manda al servidor y la que arma la clave del
> destino tienen que seguir siendo `file.sourcePath` — si no, el manifiesto
> queda apuntando a un dispositivo sombra que ya no existe y la restauración se
> rompe.
>
> Este es el fragmento con más riesgo de los cinco. Si preferís, salteálo: sin
> él tenés el guardia funcionando y VSS queda para después.

---

## Fragmento 5 — cortar el bucle y liberar

**Buscá** el cierre del bucle de carpetas y **agregá el corte**:

```js
      for await (const file of walkDir(root, excluded)) {
        ...
      }
      if (cortadoPorGuardia) break;      ← esta línea
    }
```

**Y al final de `_doBackup`**, buscá:

```js
    for (const sesion of sesionesFtp.values()) {
      await sesion.cerrar().catch(() => {});
    }
    sesionesFtp.clear();
```

**Insertá abajo:**

```js
    if (instantaneas) vss.liberar(instantaneas, (msg) => this.log(`[info] ${msg}`));
    if (!cortadoPorGuardia) state.set("__ultimoRespaldo__", Date.now());
```

El `state.set` es lo que le da al guardia su punto de comparación la próxima
vez. Sin eso, `referenciaMs` queda en 0 y el guardia cuenta **todos** los
archivos como recién modificados.

---

## Conectar la alerta a la interfaz

El motor emite `alerta-seguridad`. Para que llegue a la ventana, en `main.cjs`,
donde ya se escuchan los otros eventos del engine (`progreso`, `done`, `log`):

```js
engine.on("alerta-seguridad", (inf) => {
  if (win && !win.isDestroyed()) win.webContents.send("alerta-seguridad", inf);
  if (Notification.isSupported()) {
    new Notification({
      title: "BackupPrime detuvo el respaldo",
      body: "Se detectó actividad compatible con ransomware. Abrí la app para revisar.",
      urgency: "critical",
    }).show();
  }
});
```

Y en `preload.cjs`, junto a los otros listeners:

```js
onAlertaSeguridad: (f) => ipcRenderer.on("alerta-seguridad", (_e, d) => f(d)),
```

---

## Orden que recomiendo

| Paso | Qué agrega | Riesgo |
|---|---|---|
| 1 | Fragmentos 1, 2, 3, 5 (sin el 4) | Bajo — el guardia funciona solo |
| 2 | Notificación y aviso en la interfaz | Bajo |
| 3 | Fragmento 4 (VSS de verdad) | **Medio** — toca las rutas de lectura |
| 4 | Servicio de Windows | Alto — cambia el instalador entero |

**Parate después del paso 2 y usalo unos días** con el guardia activo antes de
tocar el 4. Si en ese tiempo no tuviste ningún falso positivo, los umbrales
están bien calibrados para tu uso real.

VSS sin el Servicio de Windows solo funciona si ejecutás como administrador a
mano. El paso 4 es la solución de verdad, pero no lo encares hasta que el resto
esté firme.
