'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Por qué el bucket contesta 403 SignatureDoesNotMatch al pedir las versiones.

   El listado normal de objetos funciona (el árbol trae los archivos) y usa el
   MISMO firmador, la misma clave y la misma ruta. Así que el problema no es la
   credencial: es algo puntual de cómo se arma la consulta `?versions`.

   Este script prueba las variantes una por una contra el bucket real y dice
   cuál contesta 200. No escribe ni borra nada: solo hace GET.

   Uso, en la carpeta cliente-windows:

     node herramientas/diagnostico-versiones.cjs

   Toma el destino S3 de la configuración del programa. Si hay varios, se elige
   con --destino "etiqueta". También se puede pasar todo a mano:

     node herramientas/diagnostico-versiones.cjs \
       --endpoint https://xxxx.la12.idrivee2-99.com \
       --bucket bucket2test --region us-west-1 \
       --clave AKIA... --secreto ...
   ═══════════════════════════════════════════════════════════════════════════ */

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const http = require('node:http');
const https = require('node:https');

const { getConfigDir } = require('../electron/backup-engine.cjs');

// ── Argumentos ──────────────────────────────────────────────────────────────
const args = {};
for (let i = 2; i < process.argv.length; i++) {
  const t = String(process.argv[i]);
  if (!t.startsWith('--')) continue;
  const nombre = t.replace(/^--/, '');
  const sig = process.argv[i + 1];
  if (sig === undefined || String(sig).startsWith('--')) args[nombre] = true;
  else { args[nombre] = sig; i++; }
}

// ── De dónde sale el destino ────────────────────────────────────────────────
function destinoDeLaConfig() {
  const archivo = path.join(getConfigDir(), 'config.json');
  if (!fs.existsSync(archivo)) return null;
  let cfg;
  try { cfg = JSON.parse(fs.readFileSync(archivo, 'utf8')); } catch { return null; }
  const s3 = (cfg.destinations || cfg.destinos || []).filter((d) => d && d.type === 's3');
  if (!s3.length) return null;
  if (args.destino && args.destino !== true) {
    return s3.find((d) => String(d.label || '').toLowerCase() ===
      String(args.destino).toLowerCase()) || null;
  }
  if (s3.length > 1) {
    console.log('\nHay varios destinos S3. Elegí uno con --destino "etiqueta":');
    s3.forEach((d) => console.log(`  · ${d.label || '(sin etiqueta)'} → ${d.bucket}`));
    process.exit(1);
  }
  return s3[0];
}

let dest;
if (args.endpoint && args.bucket && args.clave && args.secreto) {
  dest = {
    type: 's3', endpoint: args.endpoint, bucket: args.bucket,
    region: args.region || 'us-east-1',
    accessKey: args.clave, secretKey: args.secreto,
    prefix: args.prefijo && args.prefijo !== true ? args.prefijo : '',
    label: 'pasado por parámetro',
  };
} else {
  dest = destinoDeLaConfig();
  if (!dest) {
    console.log('\nNo se encontró ningún destino S3 en la configuración.');
    console.log('Pasalo a mano: --endpoint … --bucket … --region … --clave … --secreto …\n');
    process.exit(1);
  }
}

// La configuración puede guardar la clave secreta ofuscada. Si es así, este
// script no puede firmar y hay que pasar --secreto a mano.
if (!dest.secretKey || String(dest.secretKey).length < 8) {
  console.log('\nEl destino no trae la clave secreta en claro (está guardada cifrada).');
  console.log('Pasala a mano con --secreto, junto con --endpoint --bucket --region --clave.\n');
  process.exit(1);
}

// ── Firma SigV4, con la ruta y la query como parámetros para poder variarlas ─
const HASH_VACIO = 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855';
const sha256hex = (s) => crypto.createHash('sha256').update(s, 'utf8').digest('hex');
const hmac = (k, s) => crypto.createHmac('sha256', k).update(s, 'utf8').digest();

function endpointDe(d) {
  let e = String(d.endpoint || '').trim();
  if (!/^https?:\/\//i.test(e)) e = 'https://' + e;
  return e.replace(/\/+$/, '');
}

function firmar(d, metodo, urlPath, queryCanonica, queryEnviada) {
  const region = d.region || 'us-east-1';
  const now = new Date();
  const amzDate = now.toISOString().replace(/[:-]|\.\d{3}/g, '').slice(0, 15) + 'Z';
  const dateStamp = amzDate.slice(0, 8);
  const endpoint = endpointDe(d);
  const host = new URL(endpoint).hostname;

  const nombres = ['host', 'x-amz-content-sha256', 'x-amz-date'];
  const valores = { host, 'x-amz-content-sha256': HASH_VACIO, 'x-amz-date': amzDate };
  const canonicalHeaders = nombres.map((n) => `${n}:${valores[n]}\n`).join('');
  const signedHeaders = nombres.join(';');

  const canonicalRequest = [
    metodo, urlPath, queryCanonica || '', canonicalHeaders, signedHeaders, HASH_VACIO,
  ].join('\n');

  const credScope = `${dateStamp}/${region}/s3/aws4_request`;
  const strToSign = ['AWS4-HMAC-SHA256', amzDate, credScope, sha256hex(canonicalRequest)].join('\n');
  let k = hmac('AWS4' + d.secretKey, dateStamp);
  k = hmac(k, region); k = hmac(k, 's3'); k = hmac(k, 'aws4_request');
  const sig = crypto.createHmac('sha256', k).update(strToSign, 'utf8').digest('hex');

  const qs = queryEnviada !== undefined ? queryEnviada : queryCanonica;
  return {
    url: `${endpoint}${urlPath}${qs ? '?' + qs : ''}`,
    canonicalRequest,
    headers: {
      'x-amz-date': amzDate,
      'x-amz-content-sha256': HASH_VACIO,
      Authorization: `AWS4-HMAC-SHA256 Credential=${d.accessKey}/${credScope},` +
                     `SignedHeaders=${signedHeaders},Signature=${sig}`,
    },
  };
}

function pedir(url, headers) {
  return new Promise((resolve, reject) => {
    const p = new URL(url);
    const mod = p.protocol === 'https:' ? https : http;
    const req = mod.request({
      hostname: p.hostname,
      port: p.port || (p.protocol === 'https:' ? 443 : 80),
      path: p.pathname + p.search,
      method: 'GET', headers, timeout: 45000,
    }, (res) => {
      const trozos = [];
      res.on('data', (c) => trozos.push(c));
      res.on('end', () => resolve({
        status: res.statusCode,
        body: Buffer.concat(trozos).toString('utf8'),
      }));
    });
    req.on('timeout', () => { req.destroy(); reject(new Error('se agotó el tiempo')); });
    req.on('error', reject);
    req.end();
  });
}

// ── Las variantes a probar ──────────────────────────────────────────────────
const bucket = dest.bucket;
const prefijo = (dest.prefix || '').replace(/^\/+/, '');
const conPrefijo = (partes) => {
  if (prefijo) partes.push(`prefix=${encodeURIComponent(prefijo)}`);
  return partes;
};

const variantes = [
  {
    nombre: 'CONTROL — listar objetos (lo que hoy funciona)',
    path: `/${bucket}`,
    canonica: conPrefijo(['list-type=2', 'max-keys=1000']).sort().join('&'),
  },
  {
    nombre: 'A — versions como lo hace el programa hoy',
    path: `/${bucket}`,
    canonica: conPrefijo(['versions=', 'max-keys=1000']).sort().join('&'),
  },
  {
    nombre: 'B — versions sin max-keys',
    path: `/${bucket}`,
    canonica: conPrefijo(['versions=']).sort().join('&'),
  },
  {
    nombre: 'C — versions con barra final en la ruta (/bucket/)',
    path: `/${bucket}/`,
    canonica: conPrefijo(['versions=', 'max-keys=1000']).sort().join('&'),
  },
  {
    nombre: 'D — versions solo, con barra final y sin prefijo ni max-keys',
    path: `/${bucket}/`,
    canonica: 'versions=',
  },
  {
    nombre: 'E — firmado "versions=" pero enviado "versions" sin el igual',
    path: `/${bucket}`,
    canonica: conPrefijo(['versions=', 'max-keys=1000']).sort().join('&'),
    enviada: conPrefijo(['versions=', 'max-keys=1000']).sort().join('&')
      .replace(/versions=(?=&|$)/, 'versions'),
  },
  {
    nombre: 'F — versions con max-keys chico (10)',
    path: `/${bucket}`,
    canonica: conPrefijo(['versions=', 'max-keys=10']).sort().join('&'),
  },
];

// ── Correr ──────────────────────────────────────────────────────────────────
(async () => {
  console.log('\nBackupPrime — diagnóstico de "SignatureDoesNotMatch" al pedir versiones\n');
  console.log(`  destino  : ${dest.label || '(sin etiqueta)'}`);
  console.log(`  endpoint : ${endpointDe(dest)}`);
  console.log(`  bucket   : ${bucket}`);
  console.log(`  region   : ${dest.region || 'us-east-1'}`);
  console.log(`  prefijo  : ${prefijo || '(ninguno)'}`);
  console.log(`  clave    : ${String(dest.accessKey).slice(0, 6)}…\n`);

  const exitos = [];

  for (const v of variantes) {
    const f = firmar(dest, 'GET', v.path, v.canonica, v.enviada);
    let r;
    try { r = await pedir(f.url, f.headers); }
    catch (e) { console.log(`  ${v.nombre}\n     ERROR de red: ${e.message}\n`); continue; }

    const codigo = (r.body.match(/<Code>([^<]+)<\/Code>/) || [])[1] || '';
    const ok = r.status >= 200 && r.status < 300;
    if (ok) exitos.push(v);

    console.log(`  ${ok ? '✓' : '✗'} ${v.nombre}`);
    console.log(`     ${v.path}?${v.enviada || v.canonica}`);
    console.log(`     HTTP ${r.status}${codigo ? ' · ' + codigo : ''}`);

    if (ok) {
      const versiones = (r.body.match(/<Version>/g) || []).length;
      const marcadores = (r.body.match(/<DeleteMarker>/g) || []).length;
      const contenidos = (r.body.match(/<Contents>/g) || []).length;
      const estado = (r.body.match(/<VersionIdMarker>|<IsTruncated>([^<]*)</) || [])[1];
      if (versiones || marcadores) {
        console.log(`     ${versiones} <Version>, ${marcadores} <DeleteMarker>`);
      } else if (contenidos) {
        console.log(`     ${contenidos} <Contents> (respuesta de listado normal)`);
      } else {
        console.log('     respuesta 200 pero SIN versiones ni objetos — ojo acá:');
        console.log('     puede ser que el bucket NO tenga el versionado activado.');
      }
      if (estado !== undefined) console.log(`     IsTruncated: ${estado}`);
    } else if (codigo === 'SignatureDoesNotMatch') {
      // Muchos servidores devuelven la cadena que ELLOS armaron. Comparar los
      // dos textos dice exactamente en qué carácter difiere.
      const suya = (r.body.match(/<CanonicalRequest>([\s\S]*?)<\/CanonicalRequest>/) || [])[1];
      if (suya) {
        const mia = f.canonicalRequest;
        const decod = suya.replace(/&#(\d+);/g, (_m, n) => String.fromCharCode(n))
                          .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
        console.log('     el servidor devolvió SU canonical request. Diferencias:');
        const a = mia.split('\n'), b = decod.split('\n');
        for (let i = 0; i < Math.max(a.length, b.length); i++) {
          if (a[i] !== b[i]) {
            console.log(`       línea ${i + 1}`);
            console.log(`         nosotros: ${JSON.stringify(a[i])}`);
            console.log(`         servidor: ${JSON.stringify(b[i])}`);
          }
        }
      } else {
        console.log('     (el servidor no devolvió su canonical request)');
      }
    } else {
      console.log(`     ${r.body.replace(/\s+/g, ' ').slice(0, 220)}`);
    }
    console.log('');
  }

  console.log('─────────────────────────────────────────────────────────────');
  const control = exitos.find((v) => v.nombre.startsWith('CONTROL'));
  const versionOk = exitos.filter((v) => !v.nombre.startsWith('CONTROL'));

  if (!control) {
    console.log('El CONTROL también falló: el problema no es la consulta de versiones,');
    console.log('es la credencial, el endpoint o la región. Revisá esos tres primero.');
  } else if (!versionOk.length) {
    console.log('El listado funciona y NINGUNA variante de ?versions pasa.');
    console.log('Eso apunta a que la clave de acceso no tiene permiso para');
    console.log('ListBucketVersions, o a que el bucket no tiene versionado activado');
    console.log('y e2 contesta con un error engañoso. Dos cosas para chequear en la');
    console.log('consola de e2: que el versionado del bucket esté ENCENDIDO, y qué');
    console.log('permisos tiene esa access key.');
  } else {
    console.log('Variante(s) que SÍ funcionan:');
    versionOk.forEach((v) => console.log(`  · ${v.nombre}`));
    console.log('\nEsa es la forma que hay que dejar en s3Versiones().');
  }
  console.log('');
})().catch((e) => { console.error('\n' + e.stack + '\n'); process.exit(1); });
