'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   ¿Cuánto va a tardar el primer respaldo?
 
   Escanea una carpeta y estima el tiempo. No es una regla de tres sobre los
   gigabytes: con archivos chicos manda la cantidad de idas y vueltas al
   servidor, y con archivos grandes manda el ancho de banda. El modelo tiene las
   dos cosas y está calibrado contra mediciones reales:
 
     costo de un archivo  =  demora fija  +  tamaño / velocidad por conexión
     tiempo total         =  suma de los costos / transferencias simultáneas
 
   Con 120 archivos de 50 KB y 6 simultáneas el modelo predice 10,3 s y la
   medición dio 10,4 s. Con archivos de 4 MB predice 3,7 s y midió 2,8 s.
 
   Uso:
     node herramientas/estimar.cjs "C:\\Users\\usuario\\Desktop"
     node herramientas/estimar.cjs "C:\\Users" --demora 0.5 --por-conexion 3
 
   Los dos parámetros se pueden ajustar con lo que midas vos:
     --demora        segundos que cuesta cada archivo, más allá de su tamaño
     --por-conexion  MB por segundo que logra una sola transferencia
   ═══════════════════════════════════════════════════════════════════════════ */

const fs = require('node:fs');
const path = require('node:path');

const args = {};
const libres = [];
for (let i = 2; i < process.argv.length; i++) {
  const t = process.argv[i];
  if (t.startsWith('--')) { args[t.slice(2)] = process.argv[i + 1]; i++; }
  else libres.push(t);
}

const raiz = libres[0];
if (!raiz) {
  console.log('\nIndicá la carpeta a medir:\n  node herramientas/estimar.cjs "C:\\Users\\usuario\\Desktop"\n');
  process.exit(1);
}

// Calibrados contra el banco de pruebas con 150 ms de latencia.
const DEMORA = Number(args.demora) || 0.5;          // segundos por archivo
const POR_CONEXION = Number(args['por-conexion']) || 3;  // MB/s por transferencia

const EXCLUIDAS = new Set(['node_modules', '$RECYCLE.BIN', 'System Volume Information',
                           'Windows', 'AppData']);

const TRAMOS = [
  ['hasta 10 KB', 10 * 1024],
  ['10 a 100 KB', 100 * 1024],
  ['100 KB a 1 MB', 1024 * 1024],
  ['1 a 10 MB', 10 * 1024 * 1024],
  ['10 a 100 MB', 100 * 1024 * 1024],
  ['más de 100 MB', Infinity],
];

const cuenta = TRAMOS.map(() => ({ archivos: 0, bytes: 0 }));
let total = 0, bytes = 0, saltados = 0, carpetas = 0;

function recorrer(dir) {
  carpetas++;
  let entradas;
  try { entradas = fs.readdirSync(dir, { withFileTypes: true }); }
  catch { saltados++; return; }

  for (const e of entradas) {
    const completa = path.join(dir, e.name);
    if (e.isDirectory()) {
      if (EXCLUIDAS.has(e.name)) continue;
      recorrer(completa);
    } else if (e.isFile()) {
      let st;
      try { st = fs.statSync(completa); } catch { saltados++; continue; }
      total++;
      bytes += st.size;
      const i = TRAMOS.findIndex(([, tope]) => st.size <= tope);
      cuenta[i].archivos++;
      cuenta[i].bytes += st.size;
    }
  }
  if (carpetas % 500 === 0) process.stdout.write(`\r  Recorriendo… ${total.toLocaleString('es-AR')} archivos`);
}

const fmt = (b) => {
  const u = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.min(u.length - 1, Math.floor(Math.log(Math.max(b, 1)) / Math.log(1024)));
  return `${(b / Math.pow(1024, i)).toFixed(i ? 1 : 0)} ${u[i]}`;
};

const tiempo = (seg) => {
  if (seg < 90) return `${Math.round(seg)} segundos`;
  const m = seg / 60;
  if (m < 90) return `${Math.round(m)} minutos`;
  const h = m / 60;
  if (h < 40) return `${h.toFixed(1)} horas`;
  return `${(h / 24).toFixed(1)} días`;
};

/** Suma el costo de cada tramo y lo reparte entre las transferencias simultáneas. */
function estimar(simultaneas) {
  let seg = 0;
  cuenta.forEach((c, i) => {
    if (!c.archivos) return;
    const promedio = c.bytes / c.archivos / 1048576;   // MB
    seg += c.archivos * (DEMORA + promedio / POR_CONEXION);
  });
  return seg / simultaneas;
}

console.log(`\nBackupPrime — cuánto va a tardar\n\n  Carpeta: ${raiz}`);
console.log(`  Demora por archivo: ${DEMORA} s · Velocidad por conexión: ${POR_CONEXION} MB/s\n`);

const t0 = Date.now();
recorrer(raiz);
process.stdout.write('\r');

console.log(`  ${total.toLocaleString('es-AR')} archivos · ${fmt(bytes)} · ` +
            `${carpetas.toLocaleString('es-AR')} carpetas` +
            (saltados ? ` · ${saltados} sin permiso` : ''));
console.log(`  (el escaneo tardó ${((Date.now() - t0) / 1000).toFixed(1)} s)\n`);

console.log('  Cómo se reparten:');
console.log('  ' + '─'.repeat(58));
cuenta.forEach((c, i) => {
  if (!c.archivos) return;
  const pArch = (c.archivos / total * 100).toFixed(1);
  const pBytes = (c.bytes / bytes * 100).toFixed(1);
  console.log(`  ${TRAMOS[i][0].padEnd(16)} ${String(c.archivos.toLocaleString('es-AR')).padStart(10)} archivos ` +
              `(${pArch.padStart(5)}%)  ${fmt(c.bytes).padStart(9)} (${pBytes.padStart(5)}%)`);
});

console.log('\n  Primer respaldo, según cuántas transferencias simultáneas uses:');
console.log('  ' + '─'.repeat(58));
for (const c of [6, 12, 16, 24, 32]) {
  const seg = estimar(c);
  const mbps = (bytes * 8 / seg / 1e6);
  console.log(`  ${String(c).padStart(2)} simultáneas   ${tiempo(seg).padStart(14)}   ` +
              `${mbps.toFixed(0).padStart(4)} Mbps efectivos`);
}

// ¿Qué manda: la cantidad de archivos o el volumen?
const porArchivos = cuenta.reduce((n, c) => n + c.archivos * DEMORA, 0);
const porVolumen = bytes / 1048576 / POR_CONEXION;
console.log('\n  Dónde se va el tiempo:');
console.log(`    Idas y vueltas por archivo: ${(porArchivos / (porArchivos + porVolumen) * 100).toFixed(0)}%`);
console.log(`    Transferencia de datos:     ${(porVolumen / (porArchivos + porVolumen) * 100).toFixed(0)}%`);
console.log(porArchivos > porVolumen
  ? '\n  Manda la cantidad de archivos: subir las simultáneas es lo que más ayuda.'
  : '\n  Manda el volumen: subir las simultáneas ayuda poco, ya estás usando el ancho de banda.');

console.log('\n  Después del primero, solo sube lo que cambió. En un equipo de trabajo');
console.log('  típico eso son entre 200 MB y 2 GB por día, o sea minutos.\n');
