# BackupPrime — documento para auditoría

Este documento existe para que alguien de afuera —una persona o otra IA— pueda
revisar el sistema con criterio, sin tener que reconstruir el contexto leyendo
todo el código. Dice qué hay, por qué está hecho así, qué falta, y dónde están
los riesgos que ya conocemos.

**Si estás auditando esto: lo más útil que podés hacer es cuestionar la sección
"Riesgos conocidos" y la sección "Qué NO está resuelto". Lo que está listado ahí
ya lo sabemos; lo valioso es lo que se nos pasó.**

---

## 1. Qué es el producto

Respaldo automático en la nube para casas, estudios contables y jurídicos, y
pymes en Argentina. Tres partes:

| Parte | Qué es | Estado |
|---|---|---|
| Cliente de escritorio | Programa Windows (Electron) que respalda y restaura | v0.8.4, funcionando |
| Sitio y portal | Registro, pago, panel del cliente | Funcionando, sin publicar |
| Backend | API, base de datos, panel de administración | Funcionando, sin publicar |

Nada está en producción todavía. El dominio `backupprime.com` está registrado.

---

## 2. Decisiones de arquitectura y por qué

### Cero dependencias en el backend

Node 22 con `node:sqlite` incorporado. Sin framework, sin ORM, sin bibliotecas
de autenticación. Motivos: cada dependencia en el camino de la autenticación es
alguien más que puede equivocarse por vos; y el despliegue es copiar una carpeta
y correr un comando.

**Costo asumido:** hay código propio de criptografía (scrypt, TOTP, firma AWS
SigV4) que normalmente se delega. Está todo con pruebas, pero es el primer lugar
donde miraría un auditor.

### La base de datos es un archivo

`datos/backupprime.db`. Respaldarla es copiarla. **Es el punto único de falla más
serio del sistema:** sin ella, los archivos de los clientes siguen en el
almacenamiento pero no se sabe de quién es cada uno. Hay un procedimiento de
respaldo horario documentado en `PUESTA-EN-MARCHA.md`.

### El almacenamiento está detrás de una interfaz

`almacenamiento/` define un contrato y hay seis implementaciones: iDrive e2, B2,
Wasabi, S3, MinIO y disco local. Las mismas 51 pruebas corren contra todas.
Cambiar de proveedor es cambiar una pantalla del panel.

### El correo también

`correo/` con el mismo criterio: DonWeb, Brevo, Postmark, Amazon SES, Google
Workspace o cualquier SMTP. El cliente SMTP es propio (200 líneas) y **se niega a
enviar si el servidor no ofrece cifrado**.

### Sesiones en cookie HttpOnly

El JavaScript de la página no puede leer la sesión, así que un agujero de tipo
XSS no alcanza para robarla. El programa de escritorio usa el encabezado
`Authorization`, que es el mismo mecanismo por detrás.

### Volver a una fecha, no solo a una versión

Las versiones se pueden pedir por archivo, y también **por carpeta a una fecha**:
para cada archivo se elige la última versión anterior a ese momento, y los que en
esa fecha no existían no se traen. Es el caso que importa después de un
ransomware: nadie quiere un archivo, quiere la carpeta como estaba el día antes.

### Respaldo por bloques para archivos grandes

Desde 25 MB, un archivo se parte en pedazos con cortes definidos por contenido
(no de tamaño fijo, para que insertar un byte no invalide todo) y se sube solo lo
que cambió. Medido sobre un PST real de 651 MB: **de 651 MB por día a 18 MB, y de
19,7 GB de versiones mensuales a 0,75 GB**.

Los archivos por debajo del umbral se guardan enteros, con su nombre y su
estructura de carpetas, para que el bucket siga siendo navegable y recuperable a
mano.

---

## 3. Cómo verificarlo

```bash
npm start          # backend + sitio en http://localhost:4000
npm run pruebas    # 332 pruebas
```

El panel de administración arranca con **admin / admin** y avisa hasta que se
cambie la contraseña. Se cambia en Administración → Mi cuenta.

Las pruebas del backend (`pruebas/servidor.cjs`, 89 casos) corren **solo por
HTTP**, sin mirar por dentro: hacen exactamente lo que hace el sitio. También se
pueden correr contra un servidor ya desplegado:

```bash
BASE=https://backupprime.com node pruebas/servidor.cjs
```

Del cliente de escritorio (paquete aparte, 332 pruebas):

```bash
npm run pruebas       # todo
npm run probar-e2     # conexión real con iDrive e2, paso por paso
npm run estimar -- "C:\ruta"   # cuánto va a tardar el primer respaldo
```

---

## 4. Seguridad: qué está hecho

| Qué | Cómo |
|---|---|
| Contraseñas | scrypt con sal por usuario, comparación en tiempo constante |
| Sesiones | Cookie HttpOnly, SameSite=Lax, Secure, con vencimiento |
| Segundo factor | TOTP propio, compatible con Google Authenticator |
| Fuerza bruta | Límite por email+IP, bloqueo temporal (no permanente, para no dejar afuera al cliente legítimo) |
| Enumeración de usuarios | El mensaje de error es idéntico exista o no la cuenta |
| Recuperación de contraseña | Enlace que vence en una hora, respuesta idéntica exista o no la cuenta |
| Webhook de pagos | Firma HMAC verificada + idempotencia por identificador de evento |
| Panel de administración | Sesión separada de la del cliente; una no sirve como la otra |
| Auditoría | Tabla con quién, qué, cuándo y desde dónde |
| Encabezados | `no-store`, `nosniff`, `X-Frame-Options: DENY`, `Referrer-Policy` |
| Configuración de almacenamiento y correo | No se guarda una configuración que no funcione |

## 5. Riesgos conocidos, en orden de gravedad

**1. La contraseña del panel es `admin` hasta que se cambie.** Es deliberado para
poder recorrerlo, y el panel lo avisa. En producción es lo primero.

**2. El panel de administración vive en el mismo dominio que el sitio público.**
Debería estar en otro subdominio, con segundo factor obligatorio y, si se puede,
limitado a las direcciones IP de la oficina. Ese usuario ve los datos de todos
los clientes.

**3. Acceso del administrador a los archivos de los clientes.** Técnicamente
puede. Falta: motivo obligatorio antes de acceder, registro inmutable y aviso
automático al cliente. Está diseñado, no implementado.

**4. Toda la transferencia pasa por el servidor.** Cada gigabyte que respalda un
cliente cuenta dos veces (entra y sale). Con 1 TB de transferencia incluido, son
unos cinco clientes nuevos por mes. La solución es la API de revendedor de iDrive
e2 con una cuenta y clave por cliente, subiendo directo. **No implementado.**

**5. El instalador no está firmado.** Windows muestra "Editor desconocido" a cada
cliente. Es trámite, no código: ver `FIRMA.md`.

**6. Criptografía propia.** scrypt, TOTP y SigV4 escritos a mano. Con pruebas,
pero es código propio en el camino crítico.

**7. Un cliente con dos discos.** Resuelto en el cliente 0.6.2 (la letra de
unidad es la primera carpeta), pero cualquier respaldo hecho antes tiene la
convención vieja.

**8. Las pruebas pueden dar una falsa sensación de cobertura.** Se encontraron
tres casos donde una prueba pasaba sin verificar lo que decía verificar: el
servidor S3 de prueba no validaba firmas (un 403 real contra el bucket no se
detectó nunca), el listado de versiones nunca paginaba, y la prueba de
restauración a fecha reimplementaba el bucle de descarga en lugar de llamarlo.
Los tres están corregidos, pero la lección vale como riesgo estructural: **una
prueba que no falla con el bug presente no cubre nada.** Al escribir una prueba
nueva, reintroducir el bug a propósito y confirmar que falla.

**9. Bases de datos con escritura activa.** VSS da copia *crash-consistent*, no
*application-consistent*. Una base con transacciones a medio escribir se copia sin
error y después no abre — el peor modo de falla posible en un producto de backup.
Hace falta el VSS writer de la aplicación (SQL Server lo tiene, Access no) o un
hook pre-backup que haga el dump nativo. Sin resolver: por ahora conviene excluir
las extensiones de base de datos y avisar, antes que incluirlas y dar falsa
tranquilidad.

**10. Todo el código lo escribió una IA.** Ariel no puede auditarlo por su cuenta.
Para un producto que custodia datos que no se pueden perder, eso es un riesgo real
del proyecto y conviene tenerlo escrito.

---

## 6. Qué NO está resuelto

Ordenado por lo que más falta para vender.

Resueltos desde la versión anterior de este documento, para que no se rediscutan:
el PST con Outlook abierto (era una doble lectura del archivo, no VSS ni permisos
— corregido en 0.8.3 y verificado en la máquina de Ariel), el 403 al listar
versiones (tres errores de firma SigV4, corregidos en 0.8.4), la restauración a
fecha que traía los archivos de hoy (faltaba el `versionId`, 0.7.2), VSS enchufado
al motor (0.8.0), y los textos en inglés del cliente (0.8.0, auditoría en cero).

| Falta | Impacto |
|---|---|
| Firma del instalador | Bloquea la venta: el cliente ve una advertencia de Windows |
| Aprovisionamiento automático (API de revendedor) | Hoy las credenciales se cargan a mano; no escala más allá de unos pocos clientes |
| Facturación electrónica | Las facturas se anotan sin CAE |
| Envío real de correo | Los avisos se encolan; falta conectar el proveedor |
| Mercado Pago en producción | Funciona el circuito completo con firma e idempotencia, sin credenciales reales |
| Términos y política de privacidad | El registro los enlaza y no existen |
| Servicio de Windows | No existe. Es la arquitectura correcta para instantáneas sin pedirle permisos al usuario, y es lo que hace IDrive. No bloquea: el PST ya se respalda sin admin desde 0.8.3 |
| Guardia anti-ransomware | Construido y probado, **sin enchufar**. Detecta cambios masivos y frena el respaldo para no consumir la ventana de versiones sanas |
| Restauración por web vs cifrado de punta a punta | **Decisión pendiente, no técnica.** Si el portal restaura, la clave tiene que estar del lado del servidor. No se pueden tener las dos cosas; hay que decidirlo antes de prometer restauración por web |
| Aplicación móvil | Fase posterior |

---

## 7. Preguntas concretas para quien audite

Estas son las que a nosotros nos gustaría que alguien mire con ojos frescos:

1. **En el respaldo por bloques**, ¿hay algún escenario donde un archivo quede
   irrecuperable que no hayamos cubierto? Hay tres capas: dos copias del índice,
   metadatos en cada bloque, y reconstrucción verificable contra la huella del
   archivo. Ver `electron/bloques.cjs` y sus 34 pruebas.

2. **La limpieza de bloques sin usar** borra lo que no referencia ningún índice.
   ¿Hay una condición de carrera —un respaldo escribiendo mientras la limpieza
   corre— que pueda borrar un bloque en uso? Hay días de gracia y se niega a
   borrar si no puede leer un índice.

3. **El límite de intentos** es por email+IP. ¿Alcanza, o hace falta también por
   IP sola para un ataque distribuido sobre muchas cuentas?

4. **La firma del webhook** se verifica con HMAC sobre el cuerpo crudo. Falta
   volver a consultarle el estado a Mercado Pago antes de acreditar, que está
   marcado en el código. ¿Hay algo más?

5. **La convención de rutas** (`C/Users/...`) evita que dos discos se pisen.
   ¿Hay algún caso de Windows que rompa: rutas largas, enlaces simbólicos,
   nombres reservados como `CON` o `NUL`?

6. **El modelo de datos** está en `servidor/base.cjs`. ¿Falta algo para poder
   borrar por completo los datos de un cliente que lo pida?

---

## 8. Estructura de archivos

```
index.html, registro.html, ingreso.html,     El sitio público
descargas.html, portal.html, admin.html
css/, js/                                    Estilos y comportamiento
servidor/
  servidor.cjs      La API entera y el servidor de archivos
  base.cjs          Esquema de la base de datos
  seguridad.cjs     Contraseñas, sesiones, TOTP, límite de intentos
almacenamiento/     Un contrato, seis proveedores
correo/             Un contrato, cliente SMTP propio
pruebas/            interfaz, almacenamiento, correo, servidor, vista
docs/               Puesta en marcha, contrato de API, decisiones, esta auditoría
```

El cliente de escritorio va en un paquete aparte
(`backupprime-cliente-0.6.4.zip`), con su propio juego de 332 pruebas.

---

## 9. Números medidos, no estimados

Todo esto salió de mediciones reales, no de cálculos:

| Qué | Resultado |
|---|---|
| Subida sostenida a iDrive e2 | 46,6 GB/hora (≈103 Mbps) |
| Primer respaldo de 225 GB | ≈4 h 50 min |
| PST de 651 MB, respaldo diario | 18 MB en vez de 651 MB (97% menos) |
| PST de 651 MB, 30 días de versiones | 0,75 GB en vez de 19,7 GB |
| Restauración por FTP, 6 conexiones simultáneas | 4,7 Mbps con archivos de 50 KB |
| La misma, 32 conexiones | 15,8 Mbps |
| La misma, archivos de 4 MB y 6 conexiones | 144 Mbps |
| PST de 651 MB con Outlook ABIERTO, sin admin (0.8.4) | Leído completo a 14,1 MB/s |
| Segundo respaldo del mismo PST | 0 archivos subidos, sin errores |

La conclusión de las tres del medio: con muchos archivos chicos manda la cantidad
de idas y vueltas, no el ancho de banda.

Las dos últimas son las que cierran el caso del PST: se midieron en la máquina de
Ariel, con Outlook corriendo, sin permisos de administrador y sin instantáneas de
volumen. Es la evidencia de que el problema era la doble lectura del archivo y no
los permisos, que fue la hipótesis equivocada que costó más tiempo en el proyecto.
