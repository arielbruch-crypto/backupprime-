# BackupPrime — leeme primero

Respaldo automático en la nube para estudios contables, estudios jurídicos y
pymes en Argentina. Nada está publicado todavía. Cliente de escritorio en la
versión **0.9.21**.

---

## Los otros dos documentos

- **`FUNCIONES.md`** — todas las funciones del producto, con la prueba que cubre
  cada una. Lo que no está ahí, no existe todavía.
- **`FILOSOFIA.md`** — para qué existe el producto, cómo está armado, y con qué
  criterio se decide. Empezá por ahí si es tu primera vez.

Este archivo es el otro: los errores ya pagados y el estado real. Los tres se
mantienen al día juntos.

---

## El negocio, en una línea

**Ariel ya tiene 8 clientes pagando, hoy, sobre IDrive, sin problemas.** El modelo
está validado: no se está construyendo para ver si alguien compra. BackupPrime
reemplaza la infraestructura de IDrive por la propia, y esos 8 clientes son la
primera migración — margen que hoy se va afuera, y gente que ya confía.

**IDrive es la referencia explícita.** Ante cualquier duda de comportamiento, la
respuesta no es el criterio de quien programe: es mirar qué hace IDrive y por qué,
sea en su documentación pública o en las 8 instalaciones que Ariel ya opera. La
consigna es ser mejores que ellos en todo; donde no se pueda, igualar el piso.

## Para qué existe el producto

**La gente instala una cosa, se olvida, y el día del desastre sus datos están.**
Todo lo demás es medio para eso.

Nadie compra "deduplicación por bloques": compran no perder veinte años de
trabajo. El ejemplo que usa Ariel para explicarlo: si los estudios de Colombia
hubieran tenido BackupPrime, los datos de las miles de PC que se rompieron en el
terremoto estarían a salvo.

De esa idea salen tres reglas que no se negocian:

1. **Un respaldo que parece estar y no está es peor que no tener respaldo**,
   porque el cliente no toma ninguna otra precaución. Ante la duda, avisar.
2. **El cliente no tiene que saber nada técnico.** Si hace falta que entienda qué
   es UAC, un servicio de Windows o una instantánea de volumen, está mal hecho.
3. **El cliente tiene que poder verificar.** La tranquilidad no viene de que ande;
   viene de poder ver qué se respaldó, cuándo, y qué falló.

Referencia competitiva: **IDrive**. La consigna de Ariel es ser mejores que ellos
en todo — y donde no se pueda, al menos igualar el piso.

---

## Cómo trabajar con Ariel

- Escribe en español rioplatense, directo. Quiere salida accionable, no
  explicaciones largas.
- **Le molesta mucho perder tiempo y créditos**, y con razón: lleva muchos días
  en este proyecto. No repetir análisis ya hechos, no proponer cosas que ya se
  descartaron, no romper lo que funciona.
- **Antes de cambiar algo que ya andaba, verificar que realmente esté roto.** Si
  Ariel dice "esto antes funcionaba", tomarlo como dato, no como impresión: en
  esta sesión tuvo razón y el diagnóstico contrario costó horas.
- Todo el código del proyecto lo escribió Claude. Ariel no puede auditarlo por su
  cuenta, así que la calidad y la honestidad sobre lo que no se sabe son parte
  del trabajo, no un extra.

---

## Errores que ya se pagaron. No repetirlos.

Esta sección es la más importante del documento.

**El EBUSY del PST: era la DOBLE LECTURA, no VSS ni los permisos.**
El motor llamaba a `hashFile` —leía los 651 MB completos, sin reintentos— solo
para calcular la huella, y después `subirPorBloques` abría el archivo otra vez.
Con Outlook teniendo el archivo tomado, la primera apertura fallaba. Se arrastró
varias versiones porque un arreglo anterior sacó una de las tres lecturas y quedó
ahí. Resuelto en 0.8.3: los archivos que van por bloques no se leen en el motor,
`recorrerBloques` devuelve la huella en su única pasada. **Verificado en la
máquina de Ariel: PST de 651 MB con Outlook abierto, sin admin, a 14 MB/s.**
Guarda: `pruebas/una-sola-lectura.cjs` cuenta las aperturas reales y falla si
alguien vuelve a agregar una lectura previa.

**No pedirle admin al usuario nunca.** Se intentó resolver VSS con una tarea
programada privilegiada (0.8.2) y terminó en un programa que pedía "Ejecutar como
administrador". Eso es inaceptable para este producto. Si algún día hace falta
elevación de verdad, la forma correcta es un **servicio de Windows corriendo como
LocalSystem**, que es lo que hace IDrive: el usuario nunca ve un UAC.

**No asustar con problemas que no existen.** Hubo un cartel que decía "los
archivos abiertos pueden quedar afuera" siempre que no hubiera instantáneas. Es
falso: la lectura directa funciona para casi todo, incluido el PST. Solo una base
de datos escribiéndose en ese momento puede necesitar instantánea.

**El nombre del producto es BackupPrime, en todos los idiomas.** Se tradujo el
logo por error y el encabezado quedó como "Respaldo". Hay dos guardas: la
auditoría de idioma y una prueba de DOM.

**Una prueba que no falla con el bug presente no sirve.** Pasó tres veces en esta
sesión: el servidor S3 de prueba no validaba firmas (403 contra el bucket real que
nadie detectó), el listado de versiones nunca paginaba, y la prueba de máquina del
tiempo reimplementaba el bucle de descarga en vez de llamarlo. **Al escribir una
prueba, reintroducir el bug a propósito y confirmar que falla.**

**Los índices NO van pegados al archivo del cliente.** Hasta la 0.9.8 la
segunda copia del índice se guardaba junto al archivo original, así que el
bucket del cliente se llenaba de `.zip.bpi` de 3 KB Y el listado de restaurar
los mostraba al lado del archivo real. Quien elegía el equivocado se llevaba un
JSON de 3 KB creyendo que restauró su respaldo. Desde 0.9.9 va a
`indices-copia/`. El filtro es UNA sola función, `Bloques.esRutaDeServicio`:
estaba escrito dos veces y una copia se olvidó de los `.bpi`. Guarda:
`pruebas/destino-limpio.cjs`.

**El filtro por extensión `.bpi` no es temporal.** Los respaldos ya hechos
tienen esos objetos en el bucket y NO se borran: se limpia la vista, no los
datos. Un producto de backup no borra cosas del bucket del cliente por su
cuenta. Y la restauración busca el índice en tres ubicaciones, la tercera es la
vieja: un respaldo de 2026 tiene que restaurarse en 2031.

**Un archivo con la fecha movida no puede gastar historial.** Outlook le toca la
fecha al PST todos los días sin cambiar nada. Antes eso reescribía el índice y
creaba una versión por día; con la retención con tope, las versiones de índice
le corren el historial al archivo y el cliente pide "volvé al lunes" y no lo
encuentra. Guarda: `pruebas/fecha-movida.cjs`.

**`state.json` no es la verdad sobre el destino.** Saltear sin tocar la red es
correcto, pero si el destino perdió un objeto nadie se entera. Por eso hay dos
redes: verificación programada semanal Y revalidación rotativa cada corrida
(nada pasa más de 14 días sin comprobarse). La rotativa existe porque la
semanal depende de que la máquina esté prendida ese día. Y si el listado del
destino falla, NO se anota como verificado. Guarda:
`pruebas/verificacion-programada.cjs`.

**Nunca preguntar por bloque con HEAD.** Varios servicios compatibles con S3
contestan 403 en vez de 404 cuando el objeto no existe, y con esa respuesta el
programa concluye que no está nada y resube todo. Se pide la lista completa una
vez por corrida.

**Datos deterministas en las pruebas que tocan bloques.** Con `randomBytes` los
cortes por contenido caen distinto en cada corrida y la prueba falla sola una de
cada tantas. Ya pasó dos veces (0.9.8 y 0.9.9, esta última en
`una-sola-lectura.cjs`, que es una de las guardas del EBUSY del PST).

**Anotar un riesgo no lo administra.** Hasta la 0.9.9 los archivos que van
enteros —los menores a 25 MB, o sea la mayoría de los de un estudio— subían SIN
CIFRAR, y eso figuraba como "pendiente" en este mismo documento mientras se
dedicaban sesiones a rendimiento. Un pendiente escrito no protege a nadie.
Guarda: `pruebas/nada-en-claro.cjs`, que lee los BYTES del destino y busca ahí el
contenido original — es la única prueba que no se puede falsear leyendo código.

**Guardar bien y no devolver es peor que no guardar.** La restauración llamaba al
almacén de bloques y a la descarga directa sin la clave de cifrado, en los cuatro
caminos: un respaldo cifrado se guardaba y NO se podía restaurar. Hay una sola
función, `claveDeCuenta()` en `main.cjs`, y todos los caminos la usan. Si se
agrega un camino nuevo de restauración, tiene que pasar por ahí.

**Cualquier cosa que se entregue al cliente se descifra sobre el TEMPORAL, antes
de renombrar.** Si la clave no sirve, el archivo con su nombre definitivo no
puede llegar a existir: un archivo ilegible con nombre definitivo parece
restaurado.

**Nada de lo que se manda a la pantalla puede crecer sin límite.** Con 165.000
archivos el programa "se colgaba": el motor iba a 24 MB/s y la ventana estaba
muerta. Causa: `nodo.textContent += texto` relee y reescribe todo el nodo en
cada mensaje, y la lista se repintaba por mensaje. El texto se acumula en una
variable y el DOM se escribe una vez por cuadro. Guarda:
`pruebas/pantalla-muchos-archivos.cjs` — con el bug puesto, la prueba se cuelga.

**Un aviso que no se puede apagar deja de leerse.** Ámbar y rojo son SOLO para
cosas que están mal. Si el programa se encarga solo, va en verde. Y nunca calcular
estado a partir de `state.json` entero: guarda archivos que ya no existen y esos
nunca se marcan, así que cualquier aviso basado en eso queda encendido para
siempre.

**Electron NO implementa `prompt()`.** Usarlo deja el botón muerto sin ningún
error visible. Ya pasó dos veces: en las exclusiones y en la ruta de red del
selector. Siempre un campo propio. Guarda: `pruebas/selector-carpetas.cjs`.

**El selector es la pantalla que decide si el respaldo sirve.** Un selector malo
no da error: da un respaldo incompleto, y eso se descubre el día del desastre.
La basura del sistema se filtra por nombre COMPLETO, nunca por "contiene":
`Balance ntuser.xlsx` es del cliente. Guarda: `pruebas/basura-del-sistema.cjs`.

**Una prueba que simula el otro lado no puede detectar que el otro lado falta.**
`medirRutas` estaba en `preload.cjs`, la pantalla lo llamaba, y en `main.cjs` no
había handler: el pedido quedaba colgado y el `catch` lo tragaba. La prueba del
selector pasaba en verde porque simulaba `window.backupprime`. Hay un control en
`pruebas/selector-carpetas.cjs` que lee los tres archivos reales y verifica que
todo puente usado tenga handler. **Si se agrega un puente nuevo, tiene que pasar
por ahí.**

**Una prueba que LEE un archivo no puede saber si el programa arranca.** En la
0.9.12 se duplicó `ipcMain.handle("fs:medir")`: Electron explota, `main.cjs` se
corta ahí y mueren los 18 puentes que se registran más abajo — la pestaña
Restaurar entera. La prueba buscaba el texto `ipcMain.handle` y pasó en verde con
la aplicación rota. `pruebas/arranque-completo.cjs` CARGA `main.cjs` y cuenta los
handlers reales; va primera en la suite. **Antes de decir que un handler falta,
cargá el programa y comprobalo** — el canal casi nunca se llama igual que el
método del preload.

**Los bloques NO son para deduplicar una ISO: son para poder RETOMAR.** Un
cliente con 25 GB de imágenes y 14,5 MB/s necesita ocho horas de subida, y una
máquina de estudio se apaga a la noche. Sin bloques, esos archivos no se
respaldarían nunca. Guarda: `pruebas/retomar-subida.cjs`, que además controla
que se resuelva con POCAS operaciones (4 contra 46 medidas): preguntar bloque por
bloque es el camino que devuelve 403 en varios servicios y hace resubir todo.

**Antes de optimizar, medir.** La verificación parecía el cuello y no lo era:
2º respaldo de una ISO sin cambios = 0,10 s y cero bytes leídos; verificar 3.074
objetos = 0,24 s. Lo que se ve como lentitud es la subida. El troceo va a
85 MB/s y la red a 14,5: **la red es seis veces más lenta que el troceo**, así
que partir en bloques no frena nada.

**El plan de corte se guarda apenas se conoce, no al terminar.** Una ISO de 13 GB
tarda horas y la máquina se apaga antes; sin el plan, la corrida siguiente la
re-trocea entera (cinco minutos por cada 25 GB, todos los días). Con el plan:
4,05 s y 300 MB leídos pasan a 0,10 s y 0 MB. El plan se confía por tamaño+fecha
—el MISMO criterio del chequeo rápido, no uno nuevo— y cada bloque leído se
verifica contra su huella antes de subirse. Guarda: `pruebas/retomar-subida.cjs`.

**El motor y el selector tienen que descartar LO MISMO.** Estaban
desincronizados: el selector escondía la basura y el motor la respaldaba igual.
Y la caché de navegadores (`Cache_Data`, `GPUCache`, `cache2`…) no se respalda:
cambia todo el día, consume cuota y no le sirve a nadie. Se saltea la CARPETA,
nunca por nombre de archivo — un `8d26b1f1032e8a48_0` en Documentos es del
cliente. Guarda: `pruebas/sin-cache-navegadores.cjs`.

**Medido y descartado como causa de lentitud** (para no volver a mirar ahí):
`state.flush()` tiene limitador de 2 s (8 escrituras en 15.000 archivos, no
15.000); parsear un state.json de 27 MB son 450 ms; verificar 3.074 objetos son
0,24 s. Lo caro es **una consulta al disco por archivo**: la forma de acelerar
el arranque es sacar archivos del recorrido, no optimizar el recorrido.

**Una clave de idioma que se usa y no existe no da ningún error.** `t()`
devuelve la clave, así que la pantalla le muestra `prog-de-total` al cliente en
el cuadro donde tendría que decirle cuánto falta. No hay excepción, no hay nada
en el registro, y **`auditoria-idioma.cjs --estricto` pasa en verde**: busca
texto sin traducir en el HTML, no claves usadas que faltan en el diccionario.
Guarda: el control de claves huérfanas en `pruebas/total-del-trabajo.cjs`, que
además exige que estén en los TRES idiomas — con que falte en uno, ese idioma
muestra la clave cruda. Ojo al escribirlo: la pantalla también arma claves
concatenando (`t('perfil-' + nombre)`), y esos pedazos no son claves.

**Las ramas que cortan con `return` no pasan por el pintado normal.** El aviso
de "terminado" dejaba colgado el último tiempo restante: decía "✓ Respaldo
terminado" y al lado "restante: 3 h 25 min". Lo que esa rama no limpia a mano,
queda con el valor anterior. Y es el cuadro donde el cliente decide si puede
apagar la máquina.

**El tiempo restante viejo estimaba sobre los bytes ENCOLADOS, no sobre el
trabajo.** `bytesTotales` son los cinco o seis archivos en vuelo, así que en un
respaldo de 200 GB decía "falta menos de un minuto" durante horas. Ninguna
comprobación de coherencia lo detecta: el número es prolijo, positivo, baja, y
está mal. Se estima contra el total real del trabajo, y **lo salteado cuenta
como avance** —revisar un archivo y decidir que no cambió también lleva
tiempo—. Guarda: `pruebas/total-del-trabajo.cjs` compara el estimado contra lo
que faltaba de verdad, que es lo único que distingue un número coherente de uno
útil.

**Ceder el control una vez por archivo cuesta carísimo con trabajadores en
paralelo.** Un `for await` sobre `walkDir` cede en cada archivo, y con seis
trabajadores subiendo cada cesión espera detrás de toda la cola pendiente.
Medido con 6.000 archivos: 4.703 ms de una corrida de 5.335 ms. Por lotes —una
vuelta por carpeta, los tamaños pedidos de a 500 juntos— 167 ms. Veintiocho
veces. No era el pool de hilos: subirlo a 16 y a 64 no cambió nada.

**El evento de progreso se llama `progreso`, en castellano.** Emitirlo como
`progress` avisa a un nombre que no escucha nadie y la pantalla queda muda: no se
ve leyendo el código, solo corriendo el motor. Guarda: `pruebas/senal-de-vida.cjs`,
que exige ver las cuatro fases.

**Editar package.json con scripts es peligroso.** Dos veces se metió un escape
mal puesto y el zip quedó sin arrancar. `arranque-completo.cjs` lo valida como
primer control de la suite.

**La búsqueda del respaldo entiende comodines y extensiones, y hay UNA sola
función** (`armarBusqueda` en `main.cjs`) usada por el árbol remoto, el local y
las versiones. Antes era `includes` literal: buscar `*.pst` daba "0 archivos"
teniendo el PST guardado, y el cliente concluye que perdió el correo. Los
caracteres especiales se escapan: sin eso `*[final]*` devuelve medio respaldo.
Guarda: `pruebas/buscar-en-respaldo.cjs`.

**`stream.destroy()` sin argumento NO emite `error`: emite `close`.** Escuchar
solo `end` y `error` dejaba la promesa esperando el temporizador de 120 s, y
"Detener" tardaba dos minutos en hacerse notar. Guarda:
`pruebas/cancelar-de-verdad.cjs`.

**La cancelación hay que consultarla en las fases LARGAS**, no solo en el bucle de
subida: recorrido de carpetas, inventario del destino y búsqueda de versiones
paginada. Y la bandera se limpia al EMPEZAR cada operación, si no un cancelar
viejo corta la operación siguiente.

**AppData\Roaming NO se respalda** y no puede volver a la lista del perfil. Lo
que hace falta de ahí adentro (el PST) va por acceso rápido, por ruta exacta.

**Todo id que el JS usa con $('…') tiene que existir en el HTML.** Si falta, el
arranque de la pantalla se corta ahí y todo lo que viene después queda sin
conectar. La prueba del perfil lo verifica extrayendo los ids del propio código.

**Un número parcial mostrado como exacto es peor que no mostrar nada.** La
medición de carpetas tenía tope de 1,2 s y decía "más de 3,94 GB" en una carpeta
de 12 GB; y una carpeta grande podía aparecer como "0 B", con lo cual el cliente
la deja sin marcar y pierde sus recuerdos. Se mide sin tope, informando el
parcial para que el número suba en pantalla.

**Videos viene MARCADO.** Un video de un cumpleaños no se vuelve a grabar. Solo
se desmarca lo reemplazable de verdad: Descargas y Música.

**Cuidado con las claves de idioma duplicadas:** en un objeto JS gana la última,
así que agregar una clave que ya existía más abajo no cambia nada en pantalla y
no hay error a la vista.

**El portal era una MAQUETA: no llamaba a la API ni una vez.** Hasta la 0.9.20
`js/portal.js` no tenía un solo `fetch`. Los equipos ("PC-Ana", "PC-Recepción
hace 12 días"), el espacio usado ("412 GB de 1 TB"), la tarjeta "Visa terminada
en 4417", las facturas "todas con CAE", el segundo factor en "Activada" y el
árbol de archivos con botón de bajar estaban escritos a mano en el HTML. Un
cliente entraba y veía equipos que no tiene y un estado de respaldo inventado —
exactamente la falla que el producto existe para no cometer. No fallaba nunca
porque no estaba enchufado: **una pantalla que no pide nada no puede dar error.**
Conectado en 0.9.21. Guarda: `pruebas/portal.cjs`, que carga la pantalla contra
un servidor real y verifica que cada dato venga de la API, más una lista de
frases que no podemos sostener revisada **en las dos ramas** (con equipos y sin
equipos).

**Una guarda que mira una sola rama pasa con el bug puesto.** La primera versión
de esa lista de frases prohibidas solo revisaba la pantalla con equipos. Con
"100% protegido", "24/7" y "cifrado de extremo a extremo" puestos en la rama de
la cuenta vacía, **pasó en verde**.

**No asertar sobre `document.body.textContent` en la vista compuesta.** Incluye
el `<script type="application/json">` con los datos de la muestra, así que la
prueba da verde con la pantalla todavía en "Cargando…". Y la red simulada
contesta a los 340 ms: esperar 60 no alcanza.

**El id del menú del portal es `menuPortal`, no `menu`.** El panel de
administración ya usa `menu`, y `npm run muestra` junta todas las pantallas en un
documento: con el mismo id, `getElementById` devuelve el del otro panel.

**El sitio no se toca sin que Ariel lo pida.** El portal sí se modificó en la
0.9.21, a pedido.

---

## Las dos partes

### `cliente-windows/` — el agente de escritorio (Electron)

```bash
cd cliente-windows
npm install
npm run pruebas                  # 1055 pruebas
npm run probar-e2                # conexión real con iDrive e2
npm run estimar -- "C:\ruta"     # estima el primer respaldo
npm run build:win                # instalador (SOLO en Windows)
```

**El instalador no se puede generar en Linux.** El `.exe` de NSIS necesita
Windows. Para probar cambios sin compilar: `npm start`.

### `servidor-y-portal/` — sitio, portal del cliente, panel y backend

```bash
cd servidor-y-portal
npm start          # http://localhost:4000
npm run pruebas    # 831 pruebas
npm run muestra    # todas las pantallas en un archivo
```

Panel: **admin / admin**. La base es `datos/backupprime.db`; borrarla reinicia
todo. Los mails no salen: se encolan en la tabla `avisos` y se ven desde el panel
—ahí están los OTP para completar el ingreso—. Mercado Pago, la facturación
electrónica y el correo están simulados.

---

## Estado real

| | Estado |
|---|---|
| Respaldo y restauración | Funcionando contra servidores reales |
| PST con Outlook abierto | **Funcionando desde 0.8.3, sin admin** |
| Bloques desde 25 MB | 97-98% menos de subida, medido en un PST de 651 MB |
| Versiones por archivo | Funcionando, también por bloques |
| Volver una carpeta a una fecha | Funcionando. Es el diferencial del producto |
| Progreso por archivo, velocidad, cancelación | Funcionando |
| Total del trabajo, porcentaje y tiempo restante global | **Desde 0.9.21** |
| Firma SigV4 | Validada en las pruebas con implementación independiente |
| Idioma (es/en/pt) | Completo, 241 claves. Auditoría en cero |
| Sitio, portal y panel | Completos |
| VSS | Enchufado al motor, opcional. Refuerzo para bases de datos en uso |
| Verificación contra el destino | **Programada semanal + rotativa cada 14 días, desde 0.9.9** |
| Destino limpio (índices fuera del árbol del cliente) | **Desde 0.9.9** |
| Cifrado, modo privado (frase del cliente) | **Completo desde 0.9.10, todos los caminos** |
| Cifrado, modo gestionado | **No existe**: falta el circuito del servidor |
| Guardia anti-ransomware | Construido y probado, **sin enchufar** |
| Mercado Pago | Circuito completo con firma e idempotencia, sin credenciales |
| Facturación electrónica | Se anota sin CAE |
| Correo | Se encola; falta el proveedor |
| Firma del instalador | Pendiente. Ver `cliente-windows/FIRMA.md` |
| Aprovisionamiento automático de clientes | Pendiente |
| Servicio de Windows | No existe. Es la arquitectura correcta a futuro |

---

## Lo que sigue, en orden

**1. El circuito completo del portal.** Es lo que falta para que el producto sea
vendible de punta a punta: suscribirse → pagar → **subcuenta y bucket creados
solos** → bajar el agente → entrar con email y contraseña → respaldando. Y Ariel
supervisando todo desde su panel y desde el de iDrive e2.

Para el aprovisionamiento, lo que ya está averiguado de la API de reseller de e2:

- El modelo es por **subcuenta**, no por bucket: `create_user` →
  `enable_user_region` (devuelve `storage_dn`) → `create_access_key`.
- **El secret SÍ viene en la respuesta de la API.** El "se muestra una sola vez"
  es una limitación del panel web. Perder un secret no pierde datos: se borra la
  key con `remove_access_key` y se crea otra. Tener `rotate_credentials()` desde
  el día uno.
- Patrón **write-ahead**: fila del tenant en `provisioning` antes de llamar a la
  API, persistir el secret cifrado en la misma transacción que pasa a `active`,
  y verificar con un PUT+DELETE de objeto de prueba. No usar `bucket_stats` para
  verificar: devuelve 404 en buckets recién creados y datos cacheados de horas.
- **`remove_user` y `remove_user_region` DESTRUYEN los datos del cliente.** Nunca
  desde un flujo automático. Solo endpoint admin con doble confirmación y demora.
- Hay un **techo de subcuentas** (`maximum_limit_reached`). Averiguarlo con
  soporte antes de escribir el módulo: si es bajo, el diseño una-subcuenta-por-
  cliente no escala y hay que ir a prefijos.
- El único secreto crítico es el token de reseller, y es recuperable desde la
  consola web (Settings → API Access).
- **El agente no debería tener credenciales de storage nunca.** El backend firma
  URLs pre-firmadas por objeto. La ruta se construye server-side desde la sesión
  autenticada, nunca desde un path que manda el cliente.

**2. Agente sin interfaz (headless) + servicio de Windows.** Un solo trabajo
resuelve tres cosas que hoy están separadas:
- **Windows 7.** Electron 22 fue la última versión que lo soportó y llegó a fin de
  soporte en octubre de 2023: usarla sería meterle a un cliente un Chromium sin
  parches desde hace más de dos años, en un producto que maneja sus datos. No se
  hace. El motor (`backup-engine.cjs`, `bloques.cjs`, `vss.cjs`) es Node puro y no
  depende de Electron: un agente sin interfaz corre en Windows 7 sin arrastrar
  ninguna de esas vulnerabilidades. Ariel ya tiene un cliente en Windows 7.
- **Servidores y máquinas virtuales**, donde no hay nadie mirando una ventana.
- **El servicio de Windows**, que obliga a esa misma separación.

**2b. Servicio de Windows (detalle).** Para bases de datos que se están escribiendo. Ya no
bloquea nada. Dos decisiones pendientes: migración automática de credenciales
(hoy se cifran con la identidad del usuario y `LocalSystem` no las podría leer) y
named pipe en vez de HTTP local.

**3. Firma del instalador.** Certificado **IV (Individual Validation)** — sirve
para monotributista, no hace falta sociedad. EV ya no da bypass instantáneo de
SmartScreen desde marzo de 2024, así que no vale el premium. **Cloud HSM, no
token físico** (aduana, y la clave no es exportable). US$250-450 el primer año,
renovación anual: la validez máxima es 458 días desde marzo de 2026. El publisher
va a mostrar el nombre personal de Ariel, no "BackupPrime": el monotributo no
registra nombre de fantasía. Aparte y sin relación con la firma: hay que tramitar
whitelisting con los antivirus en cada release, porque el producto hace lo mismo
que un ransomware visto por una heurística.

**4. Guardia anti-ransomware.** Construido y probado, sin enchufar.

**5. Android.** Proyecto aparte, no una adaptación: nada del código actual corre
en el dispositivo, hay que escribirlo en Kotlin nativo. Límite que hay que saber
antes de prometer nada: desde Android 11 una app no puede leer los archivos de
otras apps. Se pueden respaldar fotos, videos, documentos y descargas; NO WhatsApp
ni datos de otras aplicaciones, sin root. Va después de que el backend esté firme.

**6. Bases de datos.** VSS solo da copia *crash-consistent*. Para una base con
transacciones a medio escribir hace falta *application-consistent*, y eso
necesita el VSS writer de la aplicación —SQL Server lo tiene, Access no—. La
solución profesional es un **hook pre-backup**: un script configurable que hace el
dump nativo a una carpeta y BackupPrime respalda ese archivo, que además dedupea
bien. Mientras no exista, **excluir las extensiones de base de datos y avisar**
antes que incluirlas y dar falsa tranquilidad.

---

## Decisiones tomadas, para no rediscutirlas

- **iDrive e2** como storage, una subcuenta por cliente. Aviso: e2 no tiene región
  en Argentina, así que para la ley 25.326 es transferencia internacional. Se
  resuelve con el contrato y avisando la región, pero hay que escribirlo antes de
  vender.
- **Hosting compartido no sirve**: SQLite necesita locking real (NFS lo rompe en
  silencio), los workers son procesos de larga duración que un hosting compartido
  mata, y la credencial maestra no puede vivir en una máquina que no controlás. El
  Cloud Server de DonWeb es un VPS con root: es la decisión correcta, y da
  latencia baja y factura con CUIT. Contra: las actualizaciones del sistema y el
  **backup de la propia base SQLite** quedan a cargo de Ariel. Dumpearla cifrada a
  un bucket aparte, en otra cuenta, por cron.
- **AppData**: excluido entero por defecto. Solo se atraviesa con una whitelist de
  extensiones (`.pst`, `.kdbx`, `.pfx`/`.p12`, `.qbw`, `.mdb`/`.accdb`), más
  `Roaming\Microsoft\Signatures` que pesa nada y es el primer reclamo post-restore.
  `.ost` excluido siempre: regenerable y de 5 a 50 GB. La razón de fondo es que
  AppData completo hace **impredecible** el consumo por puesto, y sin eso no se
  puede fijar precio. Los blobs DPAPI (`Protect`, `Credentials`) no se respaldan:
  no se descifran en otra máquina, así que serían pasivo sin beneficio.
- **Respaldo completo** (`systemBackup`) recorre todas las unidades **archivo por
  archivo**. No es imagen de disco, no permite arrancar la máquina. Falta una lista
  de exclusiones de sistema (`pagefile.sys`, `hiberfil.sys`, `WinSxS`,
  `$Recycle.Bin`) antes de habilitarlo, y conviene renombrarlo: "Respaldo
  completo" suena a imagen de disco.
- **CIFRADO (estado real al 0.9.10).** El modo **privado** está completo y es
  usable: la frase la escribe el cliente en Configuración, nunca viaja al
  servidor, y **todos** los caminos cifran —los archivos por bloques y los que
  van enteros—. La restauración descifra en los cuatro caminos. El modo
  **gestionado NO existe todavía** y la pantalla lo dice: falta que el servidor
  genere y guarde la clave de cada cuenta. Faltan también las tres puertas de
  rescate del panel.
- **CORRECCIÓN IMPORTANTE (0.9.6): hasta la 0.9.5 los archivos NO se cifraban.**
  Se subían tal cual, protegidos solo por TLS y por el cifrado en reposo del
  proveedor. Si en algún chat se afirma que "el agente cifra antes de subir",
  era falso. En 0.9.6 se construyó el cifrado; ver más abajo qué falta.
- **Cifrado y rescate de clientes: DECIDIDO — DOS MODOS, el cliente elige.**
  Por defecto la clave la guarda BackupPrime (gestionada); opcionalmente el
  cliente usa una frase propia que nunca viaja al servidor (privada), y en ese
  caso si la pierde, pierde todo. Es el esquema de IDrive. Con la gestionada: Consecuencias, todas asumidas a conciencia:
  · **No es cifrado de punta a punta y NO se puede decir que lo sea.** En el sitio
    y en los términos se dice la verdad: cifrado en tránsito y en reposo, con
    claves bajo control de BackupPrime. Bien redactado juega a favor: "si perdés
    tu contraseña, tus archivos no se pierden" es lo que un estudio contable
    quiere escuchar.
  · Habilita la **restauración por web**, que queda aprobada.
  · Ariel tiene que poder rescatar a un cliente. Tres puertas, todas desde el
    panel y todas con doble confirmación, motivo obligatorio, registro de quién y
    cuándo, y **aviso automático al cliente**: restablecer contraseña con enlace
    de un solo uso, desactivar el segundo factor, y descarga asistida de archivos.
  · Las contraseñas siguen guardadas con scrypt y **no se leen ni desde el
    servidor**: una clave perdida no se "recupera", se reemplaza. Si se pudiera
    leer, cualquiera que comprometa el servidor también podría.
  · El registro de auditoría no es burocracia: es lo que separa una función de
    soporte de una puerta trasera, y es lo primero que va a mirar el IT de un
    estudio.
- Retención server-side tope 30. Conviene retención **separada** para AppData
  (5-7): un archivo de configuración cambia a diario y se come el cupo.
- MFA por TOTP y OTP por mail, sin SMS. Rutas legibles, no hashes. Manifiestos con
  UUID dentro de la carpeta destino, para sobrevivir un cambio de letra de unidad.

---

## El panel de administración también era una maqueta (0.9.21)

Igual que el portal: la pantalla de Clientes tenía "Estudio Molina" y
"Contadores Ruiz" escritos a mano, e Integraciones mostraba «Responde» para
servicios que no existen, incluida una facturación electrónica con CAE que no
está implementada. Conectadas: **Clientes** (con ficha y buscador) e
**Integraciones**. **Siguen siendo maqueta: Resumen, Facturación y Auditoría** —
esta última es la peor, porque muestra eventos inventados justo donde caen los
rescates reales. Guarda: `pruebas/panel.cjs`.

**Las tres puertas de rescate ahora existen de verdad.** Antes la documentación
las daba por hechas y la única ruta de clientes era una lista de solo lectura:
el admin no podía ayudar a nadie sin tocar la base a mano. Están en la ficha del
cliente, piden la contraseña del administrador aparte de la sesión del panel, y
quedan auditadas. La contraseña provisoria se dicta por teléfono y no se manda
por mail: el mail puede estar en la máquina que no arranca.

**El circuito de pago cierra por primera vez.** La pantalla de Cobros permite
cargar el secreto del webhook, que antes solo entraba por variable de entorno.
Al destrabarlo apareció un bug tapado por el 503: un aviso sin `referencia`
hacía reventar a SQLite y el webhook devolvía **500**. Ahora pagar deja la
cuenta activa y emite la factura, comprobado de punta a punta.

**Autogestión del cliente en el portal:** cambiar la contraseña estando adentro
(cierra las demás sesiones), corregir los datos de facturación (el email no,
que es con el que entran los equipos), desvincular equipos y darse de baja.
Ninguna de las dos últimas borra archivos, y hay una prueba que se pone en rojo
si alguien lo cambia.

## `progreso-archivo-grande.cjs` es intermitente bajo carga (anotado 19-ago-2026)

Falló una vez con «se informó el avance del archivo grande mientras se
procesaba — avisos con el archivo en vuelo: 1» y volvió a pasar sola. Aislada
pasa 3 de 3; la suite completa pasó 923/923 en la corrida siguiente. **No es una
regresión**: con el runner en paralelo, el archivo entero se procesa entre dos
avisos de progreso y queda un solo evento en vuelo.

No se tocó la aserción: bajarle el umbral la volvería una prueba que pasa con el
bug puesto, y el avance por archivo es justo lo que se arregló en la 0.9.21. Lo
que corresponde es que la prueba controle su propio ritmo en vez de depender de
la máquina. Si vuelve a fallar, es esto y no el producto.

## Aislamiento entre clientes: `pruebas/aislamiento.cjs` (0.9.22)

**Hoy la separación entre clientes es LÓGICA, no física.** Todos viven en el
mismo bucket y lo único que los separa es que el código concatene bien el
prefijo. No hay red debajo: un error de filtro en un solo lugar mezcla dos
estudios contables. Por eso la prueba existe.

Se prueba con dos cuentas cuyos equipos se llaman **igual** (`PC-01`), que es el
caso real. Verifica que ninguna vea ni toque: equipos, cuota, facturas,
sesiones, prefijo, plan ni baja de la otra; que un cliente no entre a ninguna
ruta del panel; que un token de agente no sirva para el portal; y que no se
filtre quién es cliente ni cuál de los dos campos del ingreso está mal.

**La primera versión de esta prueba pasaba con la fuga puesta.** Con la consulta
buscando el equipo por nombre sin filtrar por cuenta, A borraba **su propio**
equipo por casualidad de orden y la aserción daba verde. El caso que sí la caza
es determinístico: A pide desvincular un equipo que **solo tiene B** — tiene que
dar 404. Cualquier aserción de aislamiento tiene que probar contra un recurso
que el atacante NO tenga.

**Cuando llegue el aprovisionamiento por subcuenta**, el aislamiento pasa a ser
del proveedor y no del cuidado al escribir una línea. Hasta entonces, esta
prueba es la única red.

## El instalador se publica dejando el .exe en `descargas/` (0.9.22)

Compilás con `npm run build:win`, copiás el archivo a
`servidor-y-portal/descargas/` con el nombre `BackupPrime-Setup-X.Y.Z.exe`, y
listo: el sitio toma versión, peso y SHA-256 **del archivo real**. Si hay
varias, publica la más alta comparando por número —ordenadas como texto,
"0.9.9" gana sobre "0.9.22"—. Si no hay ninguna, el botón se desactiva y dice
que no está publicado, en vez de llevar a un 404.

**Antes había un `0.7.1` escrito a mano en TRES lugares** —`servidor.cjs`,
`descargas.html` y `pruebas/vista.cjs`— y ninguno sabía de los otros. El sitio
anunció durante catorce versiones un instalador que ni siquiera estaba subido.

**Dos pruebas pasaban gracias al bug**, y las dos había que corregirlas al
contrato honesto, no debilitarlas:

- `servidor.cjs` #85 exigía que SIEMPRE se informara una versión, y se cumplía
  con el número inventado. Ahora acepta dos ramas: publica una versión real, o
  dice que no hay ninguna y no entrega URL.
- `vista.cjs` #20l buscaba "0.7.1" en el texto de la página, que estaba en el
  HTML. Nunca comprobó que el dato viniera del backend. Ahora mira el nodo y
  espera a que conteste la red simulada.

Guarda: `pruebas/instalador.cjs`, 18 comprobaciones, incluida la descarga real
del archivo y que la huella anunciada sea la del archivo que llega.

## El alta de clientes es automática (0.9.22)

En **Integraciones → Alta automática de espacio** se elige cómo se separa a cada
cliente:

- **carpeta** (por defecto, lo de siempre): un prefijo dentro del bucket común.
  Separación lógica: lo único que separa a dos estudios es que el código
  concatene bien la ruta.
- **bucket propio**: cada cliente recibe su bucket, creado por API, con
  versionado **comprobado** y bloqueo de objetos si el proveedor lo permite. La
  separación la garantiza e2, no nuestro cuidado al escribir una línea.

El nombre sale de la organización más un hash del id: `bp-estudio-perez-a7f3c1d2`.
Legible en el panel de e2 y **sin colisiones**: dos clientes que se llaman igual
reciben buckets distintos. Hay una prueba que se pone en rojo si alguien hace
que el sufijo dependa del nombre en vez del id.

**Si el alta falla, la cuenta NO queda marcada como aprovisionada** y el agente
recibe 503 con «estamos terminando de preparar tu espacio». Un espacio a medias
es peor que ninguno: el cliente respaldaría creyendo que tiene historial de
versiones y se enteraría el día que necesita volver a una fecha.

**El agente recibe su destino en la respuesta del login** (`almacenamiento`:
prefijo, bucket, región). Eso es lo que hace que el alta deje de ser manual.
**No recibe las claves del almacenamiento**, y hay una prueba que lo verifica.

El botón **Probar el alta completa** hace el recorrido entero contra un bucket
descartable, así se descubre que el proveedor no versiona **antes** de tener
clientes adentro y no el día del ransomware.

Guardas: `pruebas/alta-automatica.cjs` (21) y `pruebas/aprovisionamiento.cjs` (26).

**Modo de retención: gobernanza, no cumplimiento.** Cumplimiento ata también a
Ariel — no podría borrar ni si un cliente se va ni si pide supresión bajo la
25.326, y le seguiría pagando el espacio a iDrive.

## Electron 33 está fuera de soporte (anotado 19-ago-2026)

El proyecto usa **Electron 33**. La política de Electron es sostener solo las
tres últimas mayores; a agosto de 2026 la estable es la 43, así que lo soportado
es aproximadamente 41–43. Incluso la 39 quedó sin soporte en mayo de 2026 y la 40
el 30 de junio. Son unas diez mayores de atraso: Chromium sin parches de
seguridad desde hace alrededor de año y medio.

**Lo que reduce el riesgo:** la ventana está bien configurada —`contextIsolation:
true`, `nodeIntegration: false`, `loadFile` de un archivo local, sin `loadURL` ni
navegación externa—. El programa nunca renderiza contenido de internet, que es el
camino por el que un Chromium viejo se vuelve ejecución de código.

**Dónde igual duele:**

- **Comercial, y es lo más probable.** Se vende a estudios contables y de
  abogados: escáneres de vulnerabilidades, auditorías y cuestionarios de seguros
  van a listar CVEs de Chromium sobre el `.exe`. Esa conversación se pierde
  aunque técnicamente no sean explotables.
- **Una vía técnica real:** el renderer usa `innerHTML` en 57 lugares y ahí
  entran nombres de archivo del disco del cliente. Es la única forma en que una
  cadena controlada por un atacante llega a ese Chromium. **Sin verificar si se
  escapan** — mirarlo, es independiente de la versión de Electron.
- **El salto encarece cada mes**: cada versión suma un cambio de ruptura.

**Cuándo:** después de la firma del instalador y del aprovisionamiento, que son
los que hoy frenan ventas. Sesión propia, subiendo por etapas con las 923 pruebas
como red, nunca en el medio de otra cosa: toca VSS, archivos bloqueados y el
manejo de PST con Outlook abierto, que ya costó plata una vez.

## Herramientas de diagnóstico que ya existen

- `herramientas/probar-e2-versionado.cjs` (servidor) — contesta con datos, contra
  la cuenta real, si se puede aprovisionar solo: crear bucket por API, versionado
  activo **comprobado pisando un objeto y recuperando el anterior**, y Object Lock
  **comprobado pidiendo un borrado que tiene que ser rechazado**. No cree lo que
  contesta el proveedor: lo verifica. Crea un bucket nuevo al azar, nunca toca uno
  existente, y lo borra al terminar.

- `pruebas/auditoria-idioma.cjs [--estricto]` — lista todo texto sin traducir y
  marca si el nombre del producto se tradujo. Hoy en cero.
- `pruebas/firma-sigv4.cjs` — validador SigV4 independiente, escrito desde la
  especificación y **no copiado del cliente** a propósito: si lo copiara, los dos
  errores se cancelarían.
- `pruebas/una-sola-lectura.cjs` — cuenta aperturas reales de archivo.
- `npm run muestra` (servidor) — todas las pantallas en un archivo.
- "Ver detalle técnico" en el panel de versiones, y la petición canónica completa
  en cualquier error 403.

## Para producción

`servidor-y-portal/docs/PUESTA-EN-MARCHA.md` va desde "solo tengo el dominio"
hasta el sitio andando, con los comandos en orden.
