# Aprovisionamiento automático — lo que dice la API real de e2

Leído de `https://www.idrive.com/es/s3-storage-e2/reseller-api` el 20-ago-2026.
Esto reemplaza lo que se venía suponiendo. **Todo lo de acá sale de la
documentación, nada está probado todavía contra la cuenta real.**

## Lo primero: la API de reseller NO crea buckets

No existe un endpoint para crear buckets. La API de reseller administra
**subcuentas, regiones y claves**. El bucket se crea después, por **S3 normal**,
usando la clave de acceso de esa subcuenta.

Eso es una buena noticia para nosotros: el bucket lo crea el mismo módulo S3 que
ya existe y que ya está probado, y el `x-amz-bucket-object-lock-enabled` se pide
en ese PUT — que es el único momento en que se puede pedir.

## La estructura real de la cuenta de Ariel (confirmado 20-ago-2026)

Son **dos cosas distintas** y confundirlas hace perder tiempo:

- **`general@backupprime.com`** — la cuenta de **reseller**. Administra usuarios,
  facturación, marca blanca, y es de donde sale la **clave API de revendedor**.
  Su menú **no tiene Buckets**: un reseller no guarda archivos, administra a los
  que guardan. **No puede crear buckets.**

- **`itstandarsarg@gmail.com`** — un **usuario** colgado de ese reseller. Acá
  viven los buckets (`cai-burzaco`, `itstandarsarg`, `bucket2test`, en
  us-southeast-1 / Miami), las **llaves de acceso S3** y los 664 GB en uso. Es
  el único usuario que existe hoy.

**El almacenamiento cuelga del USUARIO, nunca del reseller.** De ahí:

- Las **claves S3** (Llaves de acceso del usuario) van en el panel de
  BackupPrime, en **Almacenamiento**. Son las que crean los buckets de cada
  cliente. Tienen que ser de acceso a **todos** los buckets: una clave acotada a
  buckets seleccionados no puede crear nuevos.
- La **clave API de revendedor** (Configuraciones → Acceso a la API, en la
  cuenta de reseller) va en **Integraciones → Alta automática**. Solo hace falta
  si se crean subcuentas por cliente, que **no** es el camino elegido.

Pendiente de decidir: bajo qué usuario van a vivir los buckets de los clientes.
Hoy irían dentro de `itstandarsarg`, mezclados con los datos de prueba y con una
cuenta que lleva el nombre de la empresa anterior. Conviene un usuario nuevo
(`clientes@backupprime.com`) creado desde el reseller, y usar SUS claves para el
aprovisionamiento.

## Autenticación

Todo va con la cabecera `token: <API KEY>`. La clave se genera desde el perfil de
la cuenta de e2. **Es distinta de las claves de S3**: una administra, la otra
guarda archivos.

Base: `https://api.idrivee2.com/api/reseller/v1/`

## La secuencia completa del alta

1. **`PUT /create_user`**
   `{ email, password, first_name, quota, email_notification }`
   - `password` va **en base64**.
   - `quota` en GB (0 = ilimitado). Acá se mapea el plan: Personal 200,
     Estudio 1000, Empresa 3000.
   - **`email_notification: false`** — sin esto, e2 le manda un mail al cliente y
     se entera de que existe iDrive. El cliente no tiene que saber nada de esto.

2. **`POST /enable_user_region`** `{ email, region }`
   - Devuelve **`storage_dn`**, que es el endpoint S3 de ESE cliente.
   - **Cada cliente tiene un endpoint distinto.** No es un endpoint global con
     buckets adentro: es un dominio por subcuenta. Eso cambia lo que hay que
     guardar en la base y lo que hay que mandarle al agente.
   - Las regiones se listan con `GET /regions`. Solo las `active` sirven.

3. **`POST /create_access_key`** `{ email, storage_dn, name, permissions, buckets }`
   - `permissions`: `0` lectura, `1` escritura, `2` lectura/escritura.
   - `buckets` es opcional: **limita la clave a esos buckets**.
   - Devuelve `access_key` y `secret_key`. **La secret solo se ve acá**, después
     no se recupera: hay que guardarla cifrada en la misma transacción.

4. **Crear el bucket por S3**, con la clave del paso 3, contra `storage_dn`.
   Acá va `x-amz-bucket-object-lock-enabled: true`.

5. **Prender el versionado por S3** y **verificarlo pisando un objeto y
   recuperando el anterior**. No alcanza con que el proveedor conteste que sí.

## El agujero que queda: la clave puede borrar

`create_access_key` permite acotar por bucket y por lectura/escritura, pero
**no tiene una opción de «escribir sin borrar»**. La única mención a eso en toda
la API es `disable_delete_object`, y aparece **solo en las operaciones de
subusuario**, no en las claves de acceso del reseller.

O sea: la clave que le demos al agente va a poder borrar dentro de su bucket.
Un ransomware que la robe puede destruir las copias, salvo que el **Object Lock**
esté activo. Eso convierte el paso 4 en lo más importante de todo el alta, y es
justo lo que hay que confirmar con `herramientas/probar-e2-versionado.cjs`.

Queda por investigar si un subusuario con `disable_delete_object: true` puede
generar claves S3 propias. Si se pudiera, sería el mejor de los dos mundos.

## Trampas concretas

**El email de la subcuenta no puede ser el del cliente.** Si el cliente ya tiene
una cuenta de iDrive con ese mail, `create_user` devuelve
`email_already_in_use` y el alta falla. Y si no la tiene, igual le llega
correspondencia de un proveedor que no contrató. Va un alias nuestro y
determinístico: `respaldos+<idCliente>@backupprime.com`. En la base se guarda de
qué cliente es.

**Antes de borrar hay que deshabilitar.** `remove_user` exige que la cuenta esté
deshabilitada, y **destruye los datos**. Nunca en un flujo automático: solo desde
el panel, con doble confirmación. Lo mismo `remove_user_region`, que además
falla con `storage_not_empty` si hay datos — esa negativa nos protege.

**El CNAME de marca blanca no es automático.** `POST /storage/cname/add` pide
`public_key` y `private_key`: hay que subir un certificado TLS propio para
`backup.backupprime.com`. Y ojo, que el host entra en la firma SigV4: si el
agente firma contra un host y pega contra otro, da **403** y parece un problema
de permisos cuando es de firma.

**`payment_failed`** es un error real de `enable_user_region`: si la cuenta de
reseller tiene un problema de pago, el alta de clientes nuevos se corta. Hay que
distinguirlo y avisar, no reintentar en silencio.

**Los errores vienen con `error.code`**, no solo con el HTTP. Hay que decidir por
el código: `user_signed_up` es idempotencia (seguir), `email_already_in_use` es
un choque (fallar y avisar), `payment_failed` es un problema tuyo (fallar y
avisarte a vos, no al cliente).

## Lo que hay que guardar por cliente

`email_alias`, `storage_dn`, `bucket`, `access_key`, `secret_key` (cifrada),
`region`, y el estado del alta. El `storage_dn` y el bucket son lo que el agente
necesita para saber contra dónde hablar, y eso viaja en la respuesta del login.

## NADIE poda las versiones viejas (encontrado 21-ago-2026)

Configuración elegida: **20 días de retención del bloqueo de objetos**, modo
**gobernanza**, y **30 versiones por archivo**.

**Pero el tope de versiones no lo aplica nadie.** Se buscó en el agente y en el
servidor: no hay código de poda en ninguno de los dos. Lo que dice
`cliente-windows/CAMBIOS.md` sobre que "la poda la ejecuta el servidor por su
cuenta" es de la etapa vieja en Python; en el stack actual no existe. **Las
versiones se acumulan para siempre y el espacio crece sin freno.**

Es independiente de la retención del bloqueo, y es más grave: la retención
solo *atrasaría* borrados que hoy directamente no ocurren.

**Por qué no se resolvió de apuro:** con deduplicación por bloques, borrar una
versión no es borrar un archivo. Los bloques se comparten entre versiones y
entre archivos distintos. Borrar el índice de una versión vieja es fácil; borrar
sus bloques exige saber que ningún otro índice los referencia. Equivocarse deja
un archivo vivo sin un pedazo, y **eso no se nota hasta que alguien restaura** —
la falla exacta que el producto existe para no cometer.

Lo que hace falta, en orden:

1. **Recolección de bloques con conteo de referencias.** Recorrer los índices
   vivos, marcar los bloques usados, y borrar solo los que no aparecen en
   ninguno. Nunca al revés.
2. **Poda de versiones** que respete el tope por archivo y las dos copias del
   índice.
3. **Que el borrado distinga el rechazo por retención** de un error real: con 20
   días, lo que se quiera borrar antes va a ser rechazado y hay que reintentarlo
   después, no contarlo como falla.
4. Recién con eso, subir la retención sin miedo.

Antes de escribir nada de esto hace falta una prueba que **reintroduzca el
error**: borrar un bloque todavía referenciado y verificar que la restauración
se rompe. Sin esa prueba en rojo, cualquier recolector es una apuesta.

Mientras tanto: mirar el consumo. La pantalla de Integraciones lo advierte.

## Capacidad: es asunto de Ariel, no del cliente

**El cliente NUNCA ve la capacidad contratada con e2.** Ve su plan y su
consumo. Nada más. El plan de reseller es información nuestra.

El plan es arrancar con 5 a 10 TB administrados y escalar según haga falta, así
que la capacidad **no frena un alta**. Lo que sí corresponde es un aviso en el
panel de administración cuando el uso se acerque al contratado: si se llena sin
que nadie se entere, la primera señal va a ser un error de escritura en la
máquina de un cliente, y eso es enterarse por el cliente.

## Lo que falta antes de escribir el módulo

1. Correr `herramientas/probar-e2-versionado.cjs`: dice si el Object Lock se
   puede pedir al crear el bucket. **Es lo único irreversible.**
2. La API key de reseller, desde el perfil de e2.
3. Confirmar si hay un tope de subcuentas. Para subusuarios existe
   `maximum_limit_reached`; para usuarios no aparece documentado.
