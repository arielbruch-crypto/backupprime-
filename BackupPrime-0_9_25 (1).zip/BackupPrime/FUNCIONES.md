# BackupPrime — todas las funciones

Versión **0.9.21** · 923 pruebas en el cliente, 514 en el servidor, cero fallas.

Este documento describe **qué hace el producto hoy**. Lo que no está acá, no
existe todavía. Para el porqué de cada decisión, ver `FILOSOFIA.md`. Para el
estado del proyecto y los errores ya pagados, ver `LEEME-PRIMERO.md`.

Cada función lleva entre paréntesis la prueba que la cubre. Si alguna función se
toca, esa prueba tiene que seguir en verde — y si se rompe a propósito, tiene que
ponerse en rojo.

---

## 1. Elegir qué se respalda

**Árbol de carpetas con casilla intermedia.** Se navega el disco como en el
explorador de Windows. Cuando hay algo elegido dentro de una carpeta pero no
toda, la casilla del padre queda en estado intermedio y se dice con palabras, no
solo con un color. Sin eso, quien eligió tres subcarpetas ve la casilla del padre
vacía y termina marcando la carpeta entera "por las dudas", respaldando 80 GB que
no quería. (`selector-carpetas.cjs`)

**Buscador dentro de la carpeta.** Encontrar una carpeta entre cientos sin
buscador es a mano.

**Carpetas del perfil, elegidas de a una.** Una tarjeta muestra cada carpeta
personal con su icono, cuántos archivos tiene y cuánto pesa, más el resumen de lo
elegido antes de confirmar. Documentos, Escritorio e Imágenes vienen marcadas;
Descargas, Videos y Música **no**, con el motivo al lado: son las más pesadas y
las que menos falta hacen. **`AppData\Roaming` no entra**: son decenas de miles
de archivos de configuración que no sirven restaurados en otra máquina.
(`carpetas-del-perfil.cjs`)

**Accesos rápidos.** Documentos, Escritorio, Imágenes, Descargas y el correo de
Outlook. Nadie que no sea técnico sabe que Outlook guarda el correo en
`AppData\Local\Microsoft\Outlook`; obligarlo a navegar hasta ahí es garantizar
que su PST no se respalde nunca. Solo se ofrecen las carpetas que existen de
verdad. (`fs:accesos-rapidos`)

**Total en vivo de lo elegido.** Cuántos archivos y cuánto pesan, calculado
mientras se elige, con tope de 2,5 segundos y cancelación de las mediciones
viejas. Elegir a ciegas es como un cliente marca "Descargas" sin enterarse de que
son 80 GB y después no entiende por qué el primer respaldo tarda dos días.

**Añadir ruta de red.** Con campo propio dentro del selector y el error al lado
si la ruta no responde. No usa `prompt()`, que en Electron no existe y deja el
botón aparentemente roto.

**Respaldo completo del sistema.** Una opción que recorre todas las unidades. Es
a nivel de archivos, no una imagen de disco, y se dice así.

**Exclusiones.** Rutas que el cliente decide no respaldar.

---

## 2. Lo que nunca se respalda

Estas listas las aplican **el motor y el selector por igual**. Estuvieron
desincronizadas y el cliente terminaba con archivos que la pantalla nunca le
mostró. (`sin-cache-navegadores.cjs`, `basura-del-sistema.cjs`)

**Caché de navegadores.** `Cache_Data`, `Code Cache`, `GPUCache`,
`Service Worker`, el `cache2` de Firefox, el `INetCache` de Windows y una docena
más. Chrome, Edge y Firefox guardan decenas de miles de archivitos con nombres
como `8d26b1f1032e8a48_0`: cambian todo el tiempo, así que se subirían en cada
respaldo consumiendo cuota, y no le sirven a nadie porque el navegador los vuelve
a bajar solo. Se saltea la **carpeta**, que es lo que ahorra el recorrido.

Medido: un perfil con 2.000 documentos y 24.000 archivos de caché pasó de 20,8 s
y 20.000 archivos subidos a **2,1 s y 2.000**.

**El filtro es por carpeta, nunca por nombre.** Un archivo del cliente que se
llame `8d26b1f1032e8a48_0` pero esté en Documentos **se respalda**. Filtrar por
nombre le borraría archivos propios.

**Basura del sistema.** `$Recycle.Bin`, `System Volume Information`,
`pagefile.sys`, `hiberfil.sys`, `swapfile.sys`, `ntuser.dat`, `usrclass.dat`,
`Thumbs.db`, `desktop.ini`, `.DS_Store`, `node_modules`, los `.regtrans-ms` y
`.blf` del registro de Windows.

---

## 3. Cómo se sube

**Archivos enteros hasta 25 MB.** Umbral configurable.

**Archivos grandes por bloques.** Cortes definidos por contenido, no por
posición. **Los bloques no están para deduplicar una ISO** —que no cambia
nunca— sino para poder **retomar**: 25 GB a 14,5 MB/s son ocho horas, y una
máquina de estudio se apaga a la noche. Sin bloques, esos archivos no se
respaldarían nunca. (`retomar-subida.cjs`)

**Deduplicación.** Un bloque que ya está en el destino no se vuelve a subir.
Medido en un PST real de 651 MB: **97% de ahorro**.

**Una sola lectura del archivo.** La huella completa y los cortes se calculan en
la misma pasada. Abrir dos veces un PST con Outlook prendido daba EBUSY.
(`una-sola-lectura.cjs`)

**Retomar una subida cortada.** El plan de corte se guarda **apenas se conoce**,
aunque la subida no haya terminado. Si el archivo tiene el mismo tamaño y la
misma fecha, los cortes son los mismos: se saltea el recorrido completo y se leen
únicamente los tramos de los bloques que faltan.

Medido con una imagen de 300 MB, corrida siguiente a un corte: **4,05 s leyendo
300 MB → 0,10 s leyendo 0 MB.** Cuarenta veces más rápido.

El atajo se confía por tamaño y fecha, el **mismo criterio** que usa el chequeo
rápido para saltear un archivo entero. Y cada bloque que se lee se verifica
contra la huella del plan antes de subirse: si no coincide, se abandona el atajo
sin subir nada y el archivo se recorre como siempre.

**Pocas operaciones, no una por bloque.** La lista de bloques del destino se pide
una vez por corrida. Preguntar de a uno es el camino que devuelve **403 en varios
servicios compatibles con S3**, y con un 403 el programa concluye que el bloque
no está y lo sube igual. Medido: 4 operaciones contra 46.

**Hasta 12 archivos a la vez** (configurable hasta 32) y **4 bloques en paralelo**
dentro de cada archivo grande (hasta 8). No hay límite de ancho de banda.

**Instantáneas de volumen (VSS).** Opcional. Refuerzo para bases de datos con
escritura activa. El respaldo funciona sin ellas y sin permisos de
administrador, y cuando no están se dice en pantalla.

---

## 4. Incremental: no volver a hacer lo hecho

**Chequeo rápido por tamaño y fecha.** Un archivo sin cambios **no se abre, no se
trocea y no toca la red**. Medido: una ISO de 400 MB sin cambios, segundo
respaldo, **0,10 s · 0 bytes leídos · 0 pedidos de red**. Con 20.000 archivos:
1,05 s.

**El archivo al que solo le movieron la fecha.** Es el caso más común del
producto: Outlook le toca la fecha al PST todos los días sin cambiar nada. Ahí
hay que recorrerlo —sin leerlo no hay forma de saber que es el mismo— pero **no
se sube ni un objeto y no se gasta una versión**. Antes se reescribía el índice y
con versionado en el destino eso le comía el historial al archivo: el cliente
pedía "volvé al lunes" y encontraba treinta versiones idénticas de esta semana.
(`fecha-movida.cjs`)

**El catálogo tampoco se reescribe si no cambió.**

---

## 5. Cifrado

**Modo frase propia — completo y usable.** La frase la escribe el cliente en
Configuración y **nunca sale de su computadora**. Se cifran **todos** los
caminos: los archivos por bloques y los que van enteros. (`nada-en-claro.cjs`)

La prueba que lo cubre **lee los bytes que llegaron al destino y busca ahí el
contenido original**. No lee código: lee bytes. Es la única que no se puede
falsear.

**La frase no se guarda en claro.** Se guarda la sal y un comprobante, que
permite avisar "esa no es tu frase" **antes** de bajar gigabytes.

**Guarda: nada sale sin cifrar.** Si la cuenta tiene cifrado y por cualquier
motivo la clave no está disponible, el respaldo **se detiene** en lugar de subir.
Subir sin cifrar sería peor que fallar, porque el cliente creería que sus
archivos están protegidos.

**Al restaurar se descifra sobre el temporal, antes de renombrar.** Si la clave
no sirve, el archivo con su nombre definitivo **nunca llega a existir**. Un
archivo ilegible con nombre definitivo parece restaurado.

**Los respaldos hechos antes del cifrado se siguen restaurando.** Un archivo sin
la marca se devuelve tal cual.

**Cambiar la frase con respaldos ya hechos se rechaza con una explicación**, en
lugar de dejar lo anterior ilegible en silencio.

**Modo clave administrada — NO existe todavía**, y la pantalla lo dice. Falta el
circuito del servidor que genere y guarde la clave de cada cuenta. Activarlo a
medias sería prometer algo que no se puede cumplir. (`pantalla-cifrado.cjs`)

---

## 6. Verificación: que el cliente pueda comprobar

Saltear un archivo sin tocar la red es correcto, pero deja al registro local como
única verdad sobre lo que hay en el destino. Si el destino perdió un objeto, sin
verificación **nadie se enteraría nunca**. Por eso hay dos redes, y son
distintas. (`verificacion-programada.cjs`)

**Verificación programada.** Cada 7 días revisa todo contra el destino, sola, sin
que nadie apriete nada.

**Revalidación rotativa.** En cada corrida revisa los archivos que llevan más de
14 días sin comprobarse. Existe porque la programada depende de que la máquina
esté prendida ese día, y en un estudio el domingo está apagada. Con la rotativa,
**ningún archivo pasa más de dos semanas sin que alguien lo mire de verdad.**

**Los destinos locales cuentan.** Se comprueban contra el disco en cada corrida.

**Si el destino no se puede listar, NO se anota como verificado.** Anotarlo haría
que la próxima recién sea en una semana sin haber comprobado nada.

**Lo que se le muestra al cliente** no es la fecha de la última revisión: es
**cuántos días hace que no se comprueba el archivo más olvidado**. "Verificado el
martes" puede ser cierto y engañoso a la vez. Ámbar y rojo son solo para cosas
que están mal; si el programa se encarga solo, va en verde como información.
(`pantalla-verificacion.cjs`)

**Verificar manualmente.** Un botón que comprueba contra el destino y sube solo
lo que falta. No duplica versiones. (`verificar-sin-duplicar.cjs`)

**Reconstruir índices y revisar la salud del destino.** Herramientas para el caso
en que se haya perdido una rama de índices.

---

## 7. Restaurar

**Explorar el respaldo como un árbol**, con los nombres reales de los archivos.
Los bloques y los índices no se ven nunca: el cliente ve `respaldo.zip`, no sus
1.400 pedazos. (`destino-limpio.cjs`)

Hasta la 0.9.8 aparecía el archivo real **y** un `.bpi` de 3 KB al lado. Quien
elegía el equivocado se llevaba un JSON creyendo que restauró su respaldo, y se
enteraba con el original ya borrado.

**Buscar dentro del respaldo.** Entiende `*.pst` y `.pst` (todo lo que termine
así, sin distinguir mayúsculas), texto suelto, y comodines en cualquier posición:
`Balance*.xlsx`, `*2026*`, `EMAIL-?.?.?.iso`. Los caracteres especiales se
escapan, así que un nombre con corchetes o paréntesis no rompe la búsqueda.
(`buscar-en-respaldo.cjs`)

**Versiones de cada archivo.** Clic en un archivo y se ven todas las versiones
guardadas, con fecha. Funciona también para archivos guardados por bloques.
(`bloques-e2e.cjs`, `restaurar-version-correcta.cjs`)

**Volver una carpeta a como estaba en una fecha.** Para cada archivo se trae la
última versión anterior a ese momento. **Es el diferencial del producto**: es lo
que se usa después de un ransomware, cuando no querés un archivo, querés la
carpeta como estaba el día antes.

**Restaurar a la ubicación original o a otra carpeta**, manteniendo o no la
estructura.

**El índice se busca en tres ubicaciones**, y la tercera es la que usaban los
respaldos anteriores a la 0.9.9. Un respaldo de 2026 tiene que restaurarse en
2031.

**Progreso y cancelación** durante la bajada **y durante la búsqueda**. Cancelar
corta el recorrido de carpetas, el inventario del destino y la búsqueda de
versiones paginada — las tres fases largas que antes no consultaban el pedido.
Medido: el respaldo cierra en 5 ms en lugar de 120 segundos.
(`cancelar-de-verdad.cjs`)

**Restaurar desde destinos remotos**: S3, FTP, SFTP y la nube del producto.

---

## 8. Destinos

**S3 y compatibles** (iDrive e2 es el que se usa), **FTP**, **SFTP**, **carpetas
locales** y **unidades de red**. Todos los destinos habilitados reciben cada
respaldo.

**El agente nunca recibe las credenciales del almacenamiento.** Recibe URLs
firmadas. Es una decisión de arquitectura, no un detalle.

**Firma SigV4 validada** en las pruebas con una implementación independiente. Sin
eso, una firma mal armada da 403 contra el servicio real y las pruebas propias no
lo detectan.

**Retención por cantidad de versiones**, configurable.

---

## 9. Programación y funcionamiento desatendido

**Cada X minutos** o **días y horas específicos**.

**Tarea programada de Windows con permisos elevados**, creada por el instalador.
No una entrada en el registro de arranque: así VSS funciona sin que el cliente se
entere de UAC.

**Iniciar y detener la vigilancia** desde la pantalla.

**No arranca un respaldo al abrir el programa** solo porque toca el horario.

---

## 10. Lo que se ve mientras trabaja

**Señal de vida inmediata.** Entre apretar "Respaldar ahora" y ver algo pasaban
treinta segundos —leer el registro, pedir el inventario, recorrer carpetas— y el
cliente apretaba el botón otra vez creyendo que no funcionaba. Ahora el primer
aviso llega en **1 ms**. (`senal-de-vida.cjs`)

**Los dos números: archivos y bytes.** Con 165.000 archivos chicos los GB se
mueven muy despacio y parece que no avanza; el contador de archivos sube todo el
tiempo. Con un archivo de 6 GB pasa lo contrario. Cada uno tapa el hueco del
otro.

**Avance por archivo grande**, con porcentaje real —de estos sí se conoce el
total— y la fase en la que está.

**El total del trabajo y cuánto falta.** Un segundo recorrido cuenta, en
paralelo, cuántos archivos hay y cuánto pesan — sin leerlos ni subirlos. Con
eso hay barra de porcentaje de verdad y tiempo restante **del trabajo
completo**, no de los cinco archivos que están en vuelo. Mientras cuenta, la
pantalla dice que está midiendo y no promete ningún número: un total que
todavía sube haría bajar el estimado solo porque crece el denominador. El
porcentaje va por bytes y no por archivos, porque ahí es donde se va el tiempo.
Lo salteado cuenta como avance: revisar un archivo y decidir que no cambió
también lleva tiempo. Si el conteo falla, el respaldo sigue sin porcentaje.
(`total-del-trabajo.cjs`)

**Velocidad.**

**Aviso de poco espacio en disco**, antes que cualquier otro: con el disco al
límite la máquina se puede trabar, y eso es más grave que cualquier detalle del
respaldo.

**Estado de la instantánea.** Si no se pudo crear, el cliente tiene que saber que
sus archivos abiertos pueden haber quedado afuera. Informativo, no advertencia:
leer los archivos directamente es el camino normal.

**Registro de actividad** con filtros —todo, solo problemas, archivos subidos— y
un modo de detalle técnico.

**Aguanta 165.000 archivos.** El registro se acumula en memoria y el DOM se
escribe una vez por cuadro; los repintados se agrupan. Antes
`logs.textContent += texto` releía y reescribía el nodo entero en cada mensaje:
25.000 líneas tardaban 13,3 segundos y la ventana quedaba muerta mientras el
motor seguía trabajando. (`pantalla-muchos-archivos.cjs`)

---

## 11. Idiomas

Castellano, inglés y portugués. **241 claves, auditoría en cero.** El `<html
lang>` se actualiza al cambiar. "BackupPrime" no se traduce.
(`auditoria-idioma.cjs`, `idioma-pantalla.cjs`)

---

## 12. Portal, sitio y panel

**Sitio público** con precios y contenido.

**Portal del cliente**: ingreso con segundo factor, ver el estado de sus
respaldos —espacio usado, equipos y cuánto hace que cada uno informó—, cambiar de
plan, facturas, segundo factor y sesiones abiertas. **Todo sale de la API**: hasta
la 0.9.20 el portal era una maqueta con datos escritos a mano. (`portal.cjs`)

**Bajar archivos desde el portal NO existe todavía.** La restauración se hace
desde el programa, y la pantalla lo dice en lugar de mostrar un árbol que no
puede descargar nada.

**Panel de administración**: clientes, cuotas, avisos, auditoría.

**Rescate del cliente** — tres caminos, todos con registro de auditoría
obligatorio y aviso automático al cliente: restablecer contraseña, desactivar el
segundo factor, descarga asistida.

**Cuotas**, con una regla que no se negocia: **la restauración nunca se bloquea,
ni con la cuota excedida.**

**Mercado Pago**: circuito completo con firma e idempotencia, **sin credenciales
reales**.

**Facturación electrónica**: se anota, **sin CAE**.

**Correo**: se encola en la tabla `avisos` y se ve desde el panel. **Falta el
proveedor.**

---

## 13. Diagnóstico

- `npm run pruebas` — la suite completa. **Es la autoridad.**
- `npm run probar-e2` — conexión real contra iDrive e2.
- `npm run estimar -- "C:\ruta"` — estima el primer respaldo antes de hacerlo.
- Reconstrucción de índices y revisión de salud del destino.

---

## Lo que NO hace, dicho claro

- **No respalda Microsoft 365 ni Exchange.** El correo de esas cuentas está en el
  servidor de Microsoft, no en el disco. Vender "respaldamos tu correo" a un
  estudio que está en 365 sería falso.
- **No respalda los archivos `.ost`.** Son copia de lo que está en el servidor y
  no se pueden abrir en otra computadora.
- **No es una imagen de disco.** Es respaldo a nivel de archivos: no restaura un
  sistema operativo arrancable.
- **El modo de clave administrada no existe todavía.**
- **La guardia anti-ransomware está construida y probada pero sin enchufar.**
- **El instalador no está firmado**: Windows le muestra una advertencia de
  SmartScreen al cliente.
- **No hay servicio de Windows.** Funciona con tarea programada. El servicio es
  la arquitectura correcta a futuro.
- **No existe aprovisionamiento automático de clientes**: cada alta es a mano.
- **No se bajan archivos desde el portal.** Falta el circuito del servidor. El
  sitio todavía lo promete: hay que corregirlo o construirlo antes de vender.
