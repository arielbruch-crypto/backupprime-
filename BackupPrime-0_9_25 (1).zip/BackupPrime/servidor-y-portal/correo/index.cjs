'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Correo — una sola puerta para todos los proveedores.
 
   Igual que con el almacenamiento: el sistema no sabe quién manda los mails.
   Cambiar de proveedor es cambiar una pantalla del panel, no tocar código.
 
   Todos hablan SMTP, así que el mismo cliente sirve para todos: lo único que
   cambia es el servidor, el puerto y las credenciales. Por eso el catálogo trae
   los datos ya cargados y vos solo completás usuario y clave.
   ═══════════════════════════════════════════════════════════════════════════ */

const smtp = require('./smtp.cjs');

const CATALOGO = [
  {
    id: 'donweb', nombre: 'DonWeb',
    nota: 'Una sola factura, en pesos y sin tarjeta internacional. Confirmá con ' +
          'ellos que el producto permita mandar de a un mail desde una aplicación ' +
          'y no solo campañas desde el panel.',
    host: 'smtp.donweb.com', puerto: 587, seguro: 'starttls',
  },
  {
    id: 'brevo', nombre: 'Brevo',
    nota: 'Tramo gratis amplio. Pensado para mails transaccionales.',
    host: 'smtp-relay.brevo.com', puerto: 587, seguro: 'starttls',
  },
  {
    id: 'postmark', nombre: 'Postmark',
    nota: 'El que mejor entrega de los tres, y el más caro. Solo transaccional.',
    host: 'smtp.postmarkapp.com', puerto: 587, seguro: 'starttls',
  },
  {
    id: 'ses', nombre: 'Amazon SES',
    nota: 'El más barato por volumen. Hay que pedir salir del entorno de pruebas.',
    host: 'email-smtp.us-east-1.amazonaws.com', puerto: 587, seguro: 'starttls',
  },
  {
    id: 'google', nombre: 'Google Workspace',
    nota: 'Sirve para arrancar con pocos clientes. Tiene límite diario y no está ' +
          'pensado para envíos automáticos: no lo dejes cuando crezcas.',
    host: 'smtp.gmail.com', puerto: 587, seguro: 'starttls',
  },
  {
    id: 'personalizado', nombre: 'Otro servidor SMTP',
    nota: 'Cualquier proveedor que dé SMTP autenticado.',
    host: '', puerto: 587, seguro: 'starttls',
  },
];

function crear(config) {
  const entrada = CATALOGO.find((p) => p.id === config.proveedor);
  if (!entrada) {
    throw new Error(
      `Proveedor de correo desconocido: "${config.proveedor}". ` +
      `Los disponibles son: ${CATALOGO.map((p) => p.id).join(', ')}.`);
  }

  const armado = {
    host: config.host || entrada.host,
    puerto: config.puerto || entrada.puerto,
    seguro: config.seguro || entrada.seguro,
    usuario: config.usuario,
    clave: config.clave,
    de: config.de,
    deNombre: config.deNombre || 'BackupPrime',
    responderA: config.responderA || null,
  };

  if (!armado.host) throw new Error('Falta el servidor SMTP.');
  if (!armado.de) throw new Error('Falta la dirección desde la que se envía.');

  return {
    proveedor: entrada.id,
    config: armado,

    /** Manda un mensaje de prueba al destinatario que se indique. */
    async probar(destinatario) {
      try {
        await smtp.enviar(armado, {
          para: destinatario || armado.de,
          asunto: 'Prueba de configuración de BackupPrime',
          texto: 'Si estás leyendo esto, el correo saliente quedó bien configurado.',
          html: '<p>Si estás leyendo esto, el correo saliente quedó bien configurado.</p>',
        });
        return { ok: true, detalle: `Mensaje entregado a ${destinatario || armado.de}.` };
      } catch (e) {
        return { ok: false, detalle: e.message };
      }
    },

    enviar(mensaje) { return smtp.enviar(armado, mensaje); },
  };
}

/**
 * Vacía la cola de avisos.
 *
 * Los mails se encolan al crearse y se mandan desde acá, aparte. Si el servidor
 * de correo está caído, el alta de un cliente no puede fallar por eso: se anota
 * y se reintenta. Un aviso que no salió es un problema; un cliente que no se
 * pudo registrar es uno mucho peor.
 */
async function despacharCola(db, correo, { tope = 50, reintentos = 5 } = {}) {
  // El estado de un reintento guarda el número de intento ("reintentar:2"), así
  // que hay que buscarlo por prefijo. Buscándolo por igualdad exacta, un aviso
  // que fallaba una vez no se reintentaba nunca más: quedaba tirado en la cola
  // hasta que alguien mirara la tabla.
  const pendientes = db.prepare(
    `SELECT * FROM avisos WHERE estado = 'encolado' OR estado LIKE 'reintentar:%'
     ORDER BY id LIMIT ?`).all(tope);

  let enviados = 0, fallados = 0;

  for (const aviso of pendientes) {
    try {
      await correo.enviar({
        para: aviso.para,
        asunto: aviso.asunto,
        texto: aviso.cuerpo,
        html: aviso.cuerpo.includes('<') ? aviso.cuerpo : null,
      });
      db.prepare("UPDATE avisos SET estado = 'enviado', enviado = ? WHERE id = ?")
        .run(new Date().toISOString(), aviso.id);
      enviados++;
    } catch (e) {
      fallados++;
      // El estado guarda el motivo para poder verlo desde el panel en lugar de
      // que el mail desaparezca sin explicación.
      const intentos = (String(aviso.estado).match(/^reintentar:(\d+)/) || [, '0'])[1];
      const siguiente = Number(intentos) + 1;
      db.prepare('UPDATE avisos SET estado = ? WHERE id = ?')
        .run(siguiente >= reintentos ? `fallado: ${e.message}` : `reintentar:${siguiente}`,
             aviso.id);
    }
  }

  return { enviados, fallados, pendientes: pendientes.length };
}

module.exports = { crear, despacharCola, CATALOGO };
