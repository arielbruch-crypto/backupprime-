'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Cliente SMTP.

   Escrito a mano por el mismo motivo que el resto: cero dependencias. Son
   doscientas líneas contra una biblioteca que hay que ir actualizando, y el
   protocolo no cambia desde hace décadas.

   Soporta lo que pide cualquier proveedor serio: STARTTLS, TLS directo,
   autenticación LOGIN y PLAIN, y encabezados en UTF-8.
   ═══════════════════════════════════════════════════════════════════════════ */

const net = require('node:net');
const tls = require('node:tls');
const crypto = require('node:crypto');

/** Lee una respuesta del servidor. Pueden venir en varias líneas: 250-… 250 … */
function leerRespuesta(sock, tiempoLimite = 30000) {
  return new Promise((resolver, rechazar) => {
    let buffer = '';
    let temporizador;

    const limpiar = () => {
      clearTimeout(temporizador);
      sock.removeListener('data', alRecibir);
      sock.removeListener('error', alFallar);
      sock.removeListener('close', alCerrar);
    };
    const alRecibir = (d) => {
      buffer += d.toString('utf8');
      for (const linea of buffer.split('\r\n')) {
        // La última línea de una respuesta lleva espacio, no guion.
        if (/^\d{3} /.test(linea)) {
          limpiar();
          return resolver({ codigo: Number(linea.slice(0, 3)), texto: buffer.trim() });
        }
      }
    };
    const alFallar = (e) => { limpiar(); rechazar(e); };
    const alCerrar = () => { limpiar(); rechazar(new Error('El servidor de correo cortó la conexión')); };

    temporizador = setTimeout(() => {
      limpiar();
      rechazar(new Error('El servidor de correo no respondió a tiempo'));
    }, tiempoLimite);

    sock.on('data', alRecibir);
    sock.on('error', alFallar);
    sock.on('close', alCerrar);
  });
}

function escribir(sock, texto) {
  return new Promise((resolver, rechazar) => {
    sock.write(texto + '\r\n', (e) => (e ? rechazar(e) : resolver()));
  });
}

async function decir(sock, comando, esperado) {
  await escribir(sock, comando);
  const r = await leerRespuesta(sock);
  if (esperado && !esperado.includes(r.codigo)) {
    // Nunca incluir la contraseña en el error: termina en un log.
    const seguro = /^AUTH|^[A-Za-z0-9+/=]{16,}$/.test(comando) ? '(credenciales)' : comando.split(' ')[0];
    throw new Error(`El servidor rechazó ${seguro}: ${r.texto.split('\n')[0]}`);
  }
  return r;
}

/** Codifica encabezados con acentos, como exige el estándar. */
function encabezado(texto) {
  return /^[\x20-\x7E]*$/.test(texto)
    ? texto
    : `=?UTF-8?B?${Buffer.from(texto, 'utf8').toString('base64')}?=`;
}

/** Arma el mensaje con texto plano y HTML, para que se vea bien en todos lados. */
function armarMensaje({ de, deNombre, para, asunto, texto, html, responderA }) {
  const limite = 'bp_' + crypto.randomBytes(12).toString('hex');
  const cabeceras = [
    `From: ${deNombre ? `${encabezado(deNombre)} <${de}>` : de}`,
    `To: ${para}`,
    `Subject: ${encabezado(asunto)}`,
    `Date: ${new Date().toUTCString()}`,
    `Message-ID: <${crypto.randomUUID()}@${de.split('@')[1]}>`,
    'MIME-Version: 1.0',
  ];
  if (responderA) cabeceras.push(`Reply-To: ${responderA}`);

  if (!html) {
    cabeceras.push('Content-Type: text/plain; charset=UTF-8',
                   'Content-Transfer-Encoding: base64', '');
    return cabeceras.join('\r\n') + '\r\n' +
      Buffer.from(texto || '', 'utf8').toString('base64').replace(/(.{76})/g, '$1\r\n');
  }

  cabeceras.push(`Content-Type: multipart/alternative; boundary="${limite}"`, '');
  const parte = (tipo, cuerpo) =>
    `--${limite}\r\nContent-Type: text/${tipo}; charset=UTF-8\r\n` +
    'Content-Transfer-Encoding: base64\r\n\r\n' +
    Buffer.from(cuerpo, 'utf8').toString('base64').replace(/(.{76})/g, '$1\r\n');

  return cabeceras.join('\r\n') + '\r\n' +
    parte('plain', texto || html.replace(/<[^>]+>/g, ' ')) + '\r\n' +
    parte('html', html) + '\r\n' +
    `--${limite}--\r\n`;
}

/**
 * Manda un mensaje.
 *
 * config: { host, puerto, usuario, clave, seguro, de, deNombre, responderA }
 *   seguro: "tls" conecta cifrado desde el arranque (puerto 465)
 *           "starttls" empieza en claro y pasa a cifrado (puerto 587)
 *           "ninguno" solo para pruebas locales
 */
async function enviar(config, mensaje) {
  const puerto = Number(config.puerto) || (config.seguro === 'tls' ? 465 : 587);
  const modo = config.seguro || (puerto === 465 ? 'tls' : 'starttls');

  let sock = modo === 'tls'
    ? tls.connect({ host: config.host, port: puerto, servername: config.host })
    : net.createConnection({ host: config.host, port: puerto });

  // Escucha permanente: un socket sin nadie escuchando los errores mata el
  // proceso entero. Ya nos pasó con el FTP.
  sock.on('error', () => {});

  try {
    await new Promise((r, e) => {
      sock.once(modo === 'tls' ? 'secureConnect' : 'connect', r);
      sock.once('error', e);
      sock.setTimeout(30000, () => e(new Error('No se pudo conectar al servidor de correo')));
    });
    sock.setTimeout(0);

    const saludo = await leerRespuesta(sock);
    if (saludo.codigo !== 220) throw new Error(`Saludo inesperado: ${saludo.texto}`);

    const yo = config.identidad || 'backupprime';
    let capacidades = (await decir(sock, `EHLO ${yo}`, [250])).texto;

    if (modo === 'starttls') {
      if (!/STARTTLS/i.test(capacidades)) {
        throw new Error('El servidor no ofrece cifrado. No se manda nada sin cifrar.');
      }
      await decir(sock, 'STARTTLS', [220]);
      sock = tls.connect({ socket: sock, servername: config.host });
      sock.on('error', () => {});
      await new Promise((r, e) => { sock.once('secureConnect', r); sock.once('error', e); });
      capacidades = (await decir(sock, `EHLO ${yo}`, [250])).texto;
    }

    if (config.usuario) {
      const b64 = (t) => Buffer.from(t, 'utf8').toString('base64');
      if (/AUTH[^\n]*PLAIN/i.test(capacidades)) {
        await decir(sock, `AUTH PLAIN ${b64('\0' + config.usuario + '\0' + config.clave)}`, [235]);
      } else if (/AUTH[^\n]*LOGIN/i.test(capacidades)) {
        await decir(sock, 'AUTH LOGIN', [334]);
        await decir(sock, b64(config.usuario), [334]);
        await decir(sock, b64(config.clave), [235]);
      } else {
        throw new Error('El servidor no acepta ninguna forma de autenticación conocida.');
      }
    }

    const de = mensaje.de || config.de;
    await decir(sock, `MAIL FROM:<${de}>`, [250]);
    await decir(sock, `RCPT TO:<${mensaje.para}>`, [250, 251]);
    await decir(sock, 'DATA', [354]);

    const cuerpo = armarMensaje({
      de, deNombre: mensaje.deNombre || config.deNombre,
      responderA: mensaje.responderA || config.responderA,
      para: mensaje.para, asunto: mensaje.asunto,
      texto: mensaje.texto, html: mensaje.html,
    });
    // Un punto solo al principio de una línea termina el mensaje: hay que
    // escaparlo o el mail se corta a la mitad.
    await escribir(sock, cuerpo.replace(/\r\n\./g, '\r\n..') + '\r\n.');
    const aceptado = await leerRespuesta(sock, 60000);
    if (aceptado.codigo !== 250) throw new Error(`No se aceptó el mensaje: ${aceptado.texto}`);

    await decir(sock, 'QUIT').catch(() => {});
    return { ok: true, respuesta: aceptado.texto.split('\n')[0] };
  } finally {
    try { sock.destroy(); } catch {}
  }
}

module.exports = { enviar, armarMensaje, encabezado };
