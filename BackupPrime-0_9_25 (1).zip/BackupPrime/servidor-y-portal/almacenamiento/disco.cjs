'use strict';
/* Almacén sobre una carpeta del servidor.

   Sirve para desarrollo, para un NAS montado por red y para el día que tengas
   equipos propios. Cumple exactamente el mismo contrato que el almacén S3, así
   que el resto del sistema no se entera de cuál está usando.

   Advertencia que el panel muestra al elegirlo: una carpeta en un servidor no
   es redundante. Si ese disco se rompe, se perdieron los respaldos de todos
   tus clientes a la vez. Para producción hace falta RAID, una segunda copia en
   otro edificio, y alguien mirando los discos. */

const fs = require('node:fs');
const fsp = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const { validarClave } = require('./clave.cjs');

function crear(config) {
  const raiz = path.resolve(config.raiz);
  const raizPrefijo = (config.prefijo || 'clientes/').replace(/^\/+/, '');
  // Los enlaces temporales se firman con este secreto; sin él, cualquiera que
  // adivine una ruta se baja los archivos de otro cliente.
  const secreto = config.secretoEnlaces || crypto.randomBytes(32).toString('hex');

  /** Traduce una clave a una ruta real, sin dejar salir de la carpeta raíz. */
  function real(clave) {
    const partes = validarClave(clave).split('/').filter((s) => s && s !== '.');
    const destino = path.join(raiz, ...partes);
    if (!destino.startsWith(raiz)) throw new Error('Ruta inválida');
    return destino;
  }

  const firmar = (clave, vence) =>
    crypto.createHmac('sha256', secreto).update(`${clave}|${vence}`).digest('hex');

  async function recorrer(dir, salida) {
    let entradas;
    try { entradas = await fsp.readdir(dir, { withFileTypes: true }); } catch { return; }
    for (const e of entradas) {
      const completa = path.join(dir, e.name);
      if (e.isDirectory()) await recorrer(completa, salida);
      else {
        const st = await fsp.stat(completa);
        salida.push({ clave: path.relative(raiz, completa).split(path.sep).join('/'), bytes: st.size });
      }
    }
  }

  return {
    tipo: 'disco',
    capacidades: {
      enlacesFirmados: true,       // los sirve el propio backend, no un tercero
      objectLock: false,           // no hay inmutabilidad real en un disco común
      credencialesAcotadas: false,
    },

    async probar() {
      try {
        await fsp.mkdir(raiz, { recursive: true });
        const testigo = path.join(raiz, '.bp-escritura');
        await fsp.writeFile(testigo, 'ok');
        await fsp.unlink(testigo);
        const st = await fsp.statfs ? await fsp.statfs(raiz).catch(() => null) : null;
        const libre = st ? ` Espacio libre: ${((st.bsize * st.bavail) / 1e9).toFixed(0)} GB.` : '';
        return { ok: true, detalle: `Carpeta ${raiz} accesible y con permiso de escritura.${libre}` };
      } catch (e) {
        return { ok: false, detalle: `No se puede escribir en ${raiz}: ${e.message}` };
      }
    },

    async espacioDeCliente(idCliente) {
      const prefijo = `${raizPrefijo}${idCliente}/`;
      await fsp.mkdir(real(prefijo), { recursive: true });
      return { prefijo };
    },

    async guardar(clave, origenLocal, opciones = {}) {
      const destino = real(clave);
      await fsp.mkdir(path.dirname(destino), { recursive: true });
      const st = await fsp.stat(origenLocal);
      const temporal = `${destino}.bp-tmp-${process.pid}-${Date.now()}`;
      try {
        await fsp.copyFile(origenLocal, temporal);
        await fsp.rename(temporal, destino);
      } catch (e) {
        try { await fsp.unlink(temporal); } catch {}
        throw e;
      }
      return { bytes: st.size };
    },

    async leer(clave, destinoLocal) {
      const origen = real(clave);
      await fsp.mkdir(path.dirname(destinoLocal), { recursive: true });
      const st = await fsp.stat(origen);
      const temporal = `${destinoLocal}.bp-tmp-${process.pid}-${Date.now()}`;
      try {
        await fsp.copyFile(origen, temporal);
        await fsp.rename(temporal, destinoLocal);
      } catch (e) {
        try { await fsp.unlink(temporal); } catch {}
        throw e;
      }
      return { bytes: st.size };
    },

    enlaceDescarga(clave, segundos = 900) {
      const vence = Math.floor(Date.now() / 1000) + segundos;
      const base = (config.urlPublica || '/descargas').replace(/\/+$/, '');
      return `${base}/${clave.split('/').map(encodeURIComponent).join('/')}` +
             `?vence=${vence}&firma=${firmar(clave, vence)}`;
    },

    /** La usa el backend al servir un enlace: valida firma y vencimiento. */
    validarEnlace(clave, vence, firma) {
      if (Number(vence) < Math.floor(Date.now() / 1000)) return false;
      const esperada = firmar(clave, vence);
      return firma.length === esperada.length &&
        crypto.timingSafeEqual(Buffer.from(firma), Buffer.from(esperada));
    },

    async borrar(clave) {
      try { await fsp.unlink(real(clave)); } catch (e) {
        if (e.code !== 'ENOENT') throw e;
      }
      return { borrado: true };
    },

    async listar(prefijo, opciones = {}) {
      const tope = opciones.tope || 50000;
      const todos = [];
      await recorrer(prefijo ? real(prefijo) : raiz, todos);
      const filtrados = prefijo ? todos.filter((a) => a.clave.startsWith(prefijo)) : todos;
      filtrados.sort((a, b) => a.clave.localeCompare(b.clave));
      return { archivos: filtrados.slice(0, tope), truncado: filtrados.length > tope };
    },

    async existe(clave, bytesEsperados) {
      try {
        const st = await fsp.stat(real(clave));
        return st.isFile() && (bytesEsperados == null || st.size === bytesEsperados);
      } catch { return false; }
    },

    async usoDe(prefijo) {
      const { archivos } = await this.listar(prefijo);
      return { bytes: archivos.reduce((n, a) => n + a.bytes, 0), archivos: archivos.length };
    },

    async aTemporal(clave) {
      // Ya está en disco: no hace falta copiar nada para migrar.
      return { ruta: real(clave), limpiar: async () => {} };
    },
  };
}

module.exports = { crear };
