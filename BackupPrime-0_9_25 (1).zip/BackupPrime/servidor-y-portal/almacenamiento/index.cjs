'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Almacenamiento — una sola puerta para todos los proveedores.

   El resto del sistema NUNCA habla con iDrive, ni con S3, ni con el disco.
   Habla con esta interfaz. Cambiar de proveedor es cambiar una configuración
   en el panel de administración, no reescribir código.

   Hoy hay dos implementaciones:

     s3     — sirve para iDrive e2, Backblaze B2, Wasabi, AWS S3, MinIO y
              cualquier otro compatible con S3. Cambian el endpoint y las
              claves, nada más.
     disco  — guarda en una carpeta del servidor. Sirve para desarrollo, para
              un NAS montado, y para el día que quieras tener tus propios
              equipos: el mismo código, otra configuración.

   Las dos pasan exactamente la misma batería de pruebas (pruebas/almacenamiento.cjs).
   Esa es la garantía de que son intercambiables: si una pasa y la otra no,
   no son equivalentes y el sistema se rompería al cambiar.

   ── Contrato ───────────────────────────────────────────────────────────────

   crear(config)                        → un almacén
   almacen.capacidades                  → qué sabe hacer este proveedor
   almacen.probar()                     → { ok, detalle }  para el botón "Probar"
   almacen.espacioDeCliente(idCliente)  → { prefijo }       idempotente
   almacen.guardar(clave, origen, opts) → { bytes }
   almacen.leer(clave, destinoLocal)    → { bytes }
   almacen.enlaceDescarga(clave, seg)   → URL temporal, o null si no aplica
   almacen.borrar(clave)
   almacen.listar(prefijo, opts)        → { archivos:[{clave,bytes}], truncado }
   almacen.usoDe(prefijo)               → { bytes, archivos }
   ═══════════════════════════════════════════════════════════════════════════ */

const PROVEEDORES = {
  s3: require('./s3.cjs'),
  disco: require('./disco.cjs'),
};

/**
 * Proveedores conocidos, con lo que hay que completar de cada uno. El panel de
 * administración dibuja el formulario a partir de esta lista, así que agregar
 * un proveedor nuevo no requiere tocar la interfaz.
 */
const CATALOGO = [
  {
    id: 'idrive-e2', motor: 's3', nombre: 'iDrive e2',
    nota: 'Barato y sin cargo por subida. Sin región en Sudamérica.',
    campos: ['endpoint', 'region', 'bucket', 'accessKey', 'secretKey'],
    endpointSugerido: 'https://<region>.idrivee2.com',
  },
  {
    id: 'backblaze-b2', motor: 's3', nombre: 'Backblaze B2',
    nota: 'Alternativa directa a e2, compatible con S3.',
    campos: ['endpoint', 'region', 'bucket', 'accessKey', 'secretKey'],
    endpointSugerido: 'https://s3.us-west-004.backblazeb2.com',
  },
  {
    id: 'wasabi', motor: 's3', nombre: 'Wasabi',
    nota: 'Precio plano, sin cargo por bajada.',
    campos: ['endpoint', 'region', 'bucket', 'accessKey', 'secretKey'],
    endpointSugerido: 'https://s3.us-east-1.wasabisys.com',
  },
  {
    id: 'aws-s3', motor: 's3', nombre: 'Amazon S3',
    nota: 'El más caro de la lista. Útil si un cliente lo exige.',
    campos: ['region', 'bucket', 'accessKey', 'secretKey'],
  },
  {
    id: 'minio', motor: 's3', nombre: 'MinIO (equipos propios)',
    nota: 'S3 sobre tus propios servidores. Requiere que vos manejes discos y redundancia.',
    campos: ['endpoint', 'region', 'bucket', 'accessKey', 'secretKey'],
    endpointSugerido: 'https://storage.backupprime.com',
  },
  {
    id: 'disco', motor: 'disco', nombre: 'Carpeta del servidor',
    nota: 'Para desarrollo y pruebas. No usar en producción sin redundancia propia.',
    campos: ['raiz', 'urlPublica'],
  },
];

function crear(config) {
  const entrada = CATALOGO.find((p) => p.id === config.proveedor);
  if (!entrada) {
    throw new Error(
      `Proveedor de almacenamiento desconocido: "${config.proveedor}". ` +
      `Los disponibles son: ${CATALOGO.map((p) => p.id).join(', ')}.`);
  }
  const faltan = entrada.campos.filter((c) => !config[c]);
  if (faltan.length) {
    throw new Error(`Falta completar ${faltan.join(', ')} para usar ${entrada.nombre}.`);
  }
  return PROVEEDORES[entrada.motor].crear(config, entrada);
}

/**
 * Recorre todo lo de un cliente en el proveedor viejo y lo copia al nuevo.
 * Devuelve el avance por cada archivo para poder mostrar una barra en el panel.
 *
 * Es reanudable: lo que ya está en destino con el mismo tamaño no se vuelve a
 * copiar, así que si se corta se vuelve a lanzar y sigue donde iba.
 */
async function migrar(origen, destino, prefijo, alAvanzar) {
  const { archivos } = await origen.listar(prefijo);
  let copiados = 0, salteados = 0, fallados = 0, bytes = 0;

  for (const a of archivos) {
    try {
      const yaEsta = await destino.existe(a.clave, a.bytes);
      if (yaEsta) { salteados++; }
      else {
        const temporal = await origen.aTemporal(a.clave);
        try {
          await destino.guardar(a.clave, temporal.ruta, { bytes: a.bytes });
          copiados++; bytes += a.bytes;
        } finally { await temporal.limpiar(); }
      }
    } catch { fallados++; }
    if (alAvanzar) alAvanzar({ copiados, salteados, fallados, total: archivos.length });
  }
  return { copiados, salteados, fallados, bytes, total: archivos.length };
}

module.exports = { crear, migrar, CATALOGO };
