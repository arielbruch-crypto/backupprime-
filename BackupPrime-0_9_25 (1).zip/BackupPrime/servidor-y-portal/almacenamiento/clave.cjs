'use strict';
/* Validación de claves, compartida por todos los proveedores.

   Se rechaza en vez de sanear. Sanear en silencio hace que dos claves
   distintas terminen en el mismo archivo y un cliente pise el respaldo de
   otro sin que nadie se entere. */

function validarClave(clave) {
  const texto = String(clave || '');
  if (!texto) throw new Error('La clave del archivo no puede estar vacía');
  if (texto.length > 1024) throw new Error('La clave del archivo es demasiado larga');
  if (texto.includes('\0')) throw new Error('La clave del archivo tiene caracteres inválidos');
  for (const parte of texto.split('/')) {
    if (parte === '..') throw new Error(`Clave inválida: "${texto}" intenta salir de su carpeta`);
  }
  if (texto.startsWith('/')) throw new Error(`Clave inválida: "${texto}" no puede empezar con /`);
  return texto;
}

module.exports = { validarClave };
