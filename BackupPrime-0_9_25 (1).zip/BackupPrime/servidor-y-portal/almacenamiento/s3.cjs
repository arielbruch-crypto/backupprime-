'use strict';
/* Almacén sobre cualquier servicio compatible con S3: iDrive e2, Backblaze B2,
   Wasabi, Amazon S3, MinIO. Lo único que cambia entre ellos es el endpoint.

   Se firma a mano con SigV4 en vez de traer el SDK de AWS: son doscientas
   líneas contra veinte megas de dependencias, y no hay que seguirle el ritmo a
   los cambios de versión de una biblioteca ajena. */

const fs = require('node:fs');
const fsp = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const http = require('node:http');
const https = require('node:https');
const crypto = require('node:crypto');

const { validarClave } = require('./clave.cjs');

const HASH_VACIO = crypto.createHash('sha256').update('').digest('hex');

const sha256 = (d) => crypto.createHash('sha256').update(d).digest('hex');
const hmac = (k, d) => crypto.createHmac('sha256', k).update(d).digest();

function claveDeFirma(secreto, fecha, region, servicio) {
  return hmac(hmac(hmac(hmac('AWS4' + secreto, fecha), region), servicio), 'aws4_request');
}

/** Cada segmento de la ruta va codificado, pero las barras se conservan. */
const rutaCodificada = (clave) =>
  '/' + validarClave(clave).split('/').map(encodeURIComponent).join('/');

function crear(config) {
  const region = config.region || 'us-east-1';
  const endpoint = (config.endpoint || `https://s3.${region}.amazonaws.com`).replace(/\/+$/, '');
  const host = new URL(endpoint).hostname;
  const protocolo = new URL(endpoint).protocol === 'https:' ? https : http;
  const bucket = config.bucket;
  const raizPrefijo = (config.prefijo || 'clientes/').replace(/^\/+/, '');

  function firmar(metodo, rutaUrl, consulta, hashCuerpo, extra = {}) {
    const ahora = new Date();
    const amzFecha = ahora.toISOString().replace(/[:-]|\.\d{3}/g, '').slice(0, 15) + 'Z';
    const dia = amzFecha.slice(0, 8);

    const cabeceras = { host, 'x-amz-content-sha256': hashCuerpo, 'x-amz-date': amzFecha, ...extra };
    const nombres = Object.keys(cabeceras).map((n) => n.toLowerCase()).sort();
    const canonicas = nombres.map((n) => {
      const clave = Object.keys(cabeceras).find((k) => k.toLowerCase() === n);
      return `${n}:${String(cabeceras[clave]).trim()}\n`;
    }).join('');
    const firmadas = nombres.join(';');

    const peticionCanonica = [metodo, rutaUrl, consulta || '', canonicas, firmadas, hashCuerpo].join('\n');
    const alcance = `${dia}/${region}/s3/aws4_request`;
    const aFirmar = ['AWS4-HMAC-SHA256', amzFecha, alcance, sha256(peticionCanonica)].join('\n');
    const firma = crypto.createHmac('sha256', claveDeFirma(config.secretKey, dia, region, 's3'))
      .update(aFirmar).digest('hex');

    return {
      ...cabeceras,
      Authorization: `AWS4-HMAC-SHA256 Credential=${config.accessKey}/${alcance},` +
                     `SignedHeaders=${firmadas},Signature=${firma}`,
    };
  }

  function pedir(metodo, rutaUrl, consulta, opciones = {}) {
    return new Promise((resolver, rechazar) => {
      const hashCuerpo = opciones.hashCuerpo || HASH_VACIO;
      const cabeceras = firmar(metodo, rutaUrl, consulta, hashCuerpo, opciones.extra || {});
      if (opciones.largo != null) cabeceras['Content-Length'] = opciones.largo;

      const url = new URL(endpoint + rutaUrl + (consulta ? '?' + consulta : ''));
      const req = protocolo.request({
        hostname: url.hostname,
        port: url.port || (url.protocol === 'https:' ? 443 : 80),
        path: url.pathname + url.search,
        method: metodo, headers: cabeceras, timeout: opciones.timeout || 120000,
      }, (res) => {
        if (opciones.aArchivo) {
          if (res.statusCode < 200 || res.statusCode >= 300) {
            res.resume();
            return rechazar(new Error(`El almacenamiento respondió ${res.statusCode}`));
          }
          let bytes = 0;
          const ws = fs.createWriteStream(opciones.aArchivo);
          res.on('data', (b) => { bytes += b.length; });
          res.on('error', rechazar);
          ws.on('error', rechazar);
          ws.on('close', () => resolver({ status: res.statusCode, bytes }));
          return res.pipe(ws);
        }
        const trozos = [];
        res.on('data', (c) => trozos.push(c));
        res.on('end', () => resolver({ status: res.statusCode, cuerpo: Buffer.concat(trozos).toString('utf8') }));
      });
      req.on('timeout', () => { req.destroy(); rechazar(new Error('Se agotó el tiempo de espera')); });
      req.on('error', rechazar);
      if (opciones.desdeArchivo) fs.createReadStream(opciones.desdeArchivo).pipe(req);
      else req.end(opciones.cuerpo);
    });
  }

  const desescapar = (t) => String(t).replace(/&amp;/g, '&').replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'");

  return {
    tipo: 's3',
    capacidades: {
      enlacesFirmados: true,     // el portal puede mandar al cliente directo al proveedor
      objectLock: true,          // hay que activarlo en el bucket desde el proveedor
      credencialesAcotadas: null, // depende del proveedor: preguntar antes de usarlo
    },

    async probar() {
      try {
        const r = await pedir('GET', `/${bucket}`, 'list-type=2&max-keys=1');
        if (r.status === 200) return { ok: true, detalle: `Conectado a ${host}, bucket ${bucket}.` };
        if (r.status === 403) return { ok: false, detalle: 'Las claves no tienen permiso sobre ese bucket.' };
        if (r.status === 404) return { ok: false, detalle: `El bucket "${bucket}" no existe en ${host}.` };
        return { ok: false, detalle: `El proveedor respondió ${r.status}.` };
      } catch (e) {
        return { ok: false, detalle: `No se pudo conectar con ${host}: ${e.message}` };
      }
    },

    async espacioDeCliente(idCliente) {
      // En S3 el prefijo no hay que crearlo: existe cuando se escribe el primer
      // objeto. Se devuelve igual para que el resto del sistema no distinga
      // entre proveedores que sí necesitan crear una carpeta.
      return { prefijo: `${raizPrefijo}${idCliente}/` };
    },

    async guardar(clave, origenLocal, opciones = {}) {
      const st = await fsp.stat(origenLocal);
      // El hash del contenido es obligatorio para firmar. Es una lectura extra
      // del archivo; en un backup grande conviene reutilizar el que ya calculó
      // el agente y pasarlo en opciones.hash.
      const hash = opciones.hash || await new Promise((r, e) => {
        const h = crypto.createHash('sha256');
        fs.createReadStream(origenLocal).on('data', (d) => h.update(d))
          .on('end', () => r(h.digest('hex'))).on('error', e);
      });
      const r = await pedir('PUT', `/${bucket}${rutaCodificada(clave)}`, '', {
        hashCuerpo: hash, largo: st.size, desdeArchivo: origenLocal,
        extra: opciones.tipo ? { 'content-type': opciones.tipo } : {},
      });
      if (r.status < 200 || r.status >= 300) {
        throw new Error(`No se pudo guardar ${clave}: el proveedor respondió ${r.status}`);
      }
      return { bytes: st.size };
    },

    async leer(clave, destinoLocal) {
      await fsp.mkdir(path.dirname(destinoLocal), { recursive: true });
      const temporal = `${destinoLocal}.bp-tmp-${process.pid}-${Date.now()}`;
      try {
        const r = await pedir('GET', `/${bucket}${rutaCodificada(clave)}`, '', { aArchivo: temporal });
        await fsp.rename(temporal, destinoLocal);
        return { bytes: r.bytes };
      } catch (e) {
        try { await fsp.unlink(temporal); } catch {}
        throw e;
      }
    },

    /** URL temporal para que el navegador baje directo del proveedor. */
    enlaceDescarga(clave, segundos = 900) {
      const ahora = new Date();
      const amzFecha = ahora.toISOString().replace(/[:-]|\.\d{3}/g, '').slice(0, 15) + 'Z';
      const dia = amzFecha.slice(0, 8);
      const alcance = `${dia}/${region}/s3/aws4_request`;
      const consulta = [
        'X-Amz-Algorithm=AWS4-HMAC-SHA256',
        `X-Amz-Credential=${encodeURIComponent(config.accessKey + '/' + alcance)}`,
        `X-Amz-Date=${amzFecha}`,
        `X-Amz-Expires=${segundos}`,
        'X-Amz-SignedHeaders=host',
      ].sort().join('&');

      const ruta = `/${bucket}${rutaCodificada(clave)}`;
      const peticion = ['GET', ruta, consulta, `host:${host}\n`, 'host', 'UNSIGNED-PAYLOAD'].join('\n');
      const aFirmar = ['AWS4-HMAC-SHA256', amzFecha, alcance, sha256(peticion)].join('\n');
      const firma = crypto.createHmac('sha256', claveDeFirma(config.secretKey, dia, region, 's3'))
        .update(aFirmar).digest('hex');

      return `${endpoint}${ruta}?${consulta}&X-Amz-Signature=${firma}`;
    },

    async borrar(clave) {
      const r = await pedir('DELETE', `/${bucket}${rutaCodificada(clave)}`, '');
      if (r.status >= 400 && r.status !== 404) {
        throw new Error(`No se pudo borrar ${clave}: ${r.status}`);
      }
      return { borrado: true };
    },

    async listar(prefijo, opciones = {}) {
      const tope = opciones.tope || 50000;
      const encontrados = [];
      let token = null;
      do {
        const partes = ['list-type=2', 'max-keys=1000'];
        if (prefijo) partes.push(`prefix=${encodeURIComponent(prefijo)}`);
        if (token) partes.push(`continuation-token=${encodeURIComponent(token)}`);
        const r = await pedir('GET', `/${bucket}`, partes.sort().join('&'));
        if (r.status !== 200) throw new Error(`No se pudo listar: ${r.status}`);
        for (const m of r.cuerpo.matchAll(/<Contents>([\s\S]*?)<\/Contents>/g)) {
          const clave = (m[1].match(/<Key>([\s\S]*?)<\/Key>/) || [])[1];
          const tam = (m[1].match(/<Size>(\d+)<\/Size>/) || [])[1];
          if (clave) encontrados.push({ clave: desescapar(clave), bytes: Number(tam) || 0 });
        }
        token = /<IsTruncated>true<\/IsTruncated>/.test(r.cuerpo)
          ? (r.cuerpo.match(/<NextContinuationToken>([\s\S]*?)<\/NextContinuationToken>/) || [])[1]
          : null;
      } while (token && encontrados.length < tope);
      return { archivos: encontrados, truncado: encontrados.length >= tope };
    },

    async existe(clave, bytesEsperados) {
      const r = await pedir('HEAD', `/${bucket}${rutaCodificada(clave)}`, '');
      if (r.status !== 200) return false;
      return bytesEsperados == null ? true : true;
    },

    async usoDe(prefijo) {
      const { archivos } = await this.listar(prefijo);
      return { bytes: archivos.reduce((n, a) => n + a.bytes, 0), archivos: archivos.length };
    },

    /** Baja un objeto a un archivo temporal, para migrar entre proveedores. */
    async aTemporal(clave) {
      const ruta = path.join(os.tmpdir(), `bp-mig-${process.pid}-${Date.now()}`);
      await this.leer(clave, ruta);
      return { ruta, limpiar: () => fsp.unlink(ruta).catch(() => {}) };
    },

    /**
     * Petición firmada cruda, SOLO para herramientas de diagnóstico.
     *
     * El producto no la usa: habla por el contrato de arriba. Existe para que
     * `herramientas/probar-e2-versionado.cjs` pueda pedir cosas que no están en
     * el contrato —crear un bucket, prender el versionado, listar versiones—
     * sin escribir una segunda implementación de SigV4. Si la escribiera, un
     * error de firma en las dos se cancelaría y la herramienta diría que todo
     * anda cuando no anda.
     */
    peticion: pedir,
  };
}

module.exports = { crear };
