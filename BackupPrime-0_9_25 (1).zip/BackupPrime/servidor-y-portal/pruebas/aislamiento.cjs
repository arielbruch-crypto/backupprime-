'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Aislamiento entre clientes.

   Un proveedor de respaldos guarda los papeles de estudios contables que
   compiten entre sí. Que un cliente vea algo del otro —aunque sea el nombre de
   una PC o cuánto espacio usa— no es un bug más: es el final del negocio.

   Hoy la separación es LÓGICA, no física: todos los clientes viven en el mismo
   bucket y lo único que los separa es que el código concatene bien el prefijo.
   No hay red debajo. Por eso esta prueba existe y por eso tiene que ponerse en
   rojo el día que alguien se olvide de filtrar por cuenta.

   Se prueba con dos cuentas cuyos equipos se llaman IGUAL. Es el caso real: la
   mitad de los estudios tiene una PC llamada "PC-01". Si alguna consulta busca
   por nombre sin filtrar por cuenta, acá se cae.
   ═══════════════════════════════════════════════════════════════════════════ */
const { crearAplicacion } = require('../servidor/servidor.cjs');

let ok = 0, mal = 0; const fallos = [];
function comprobar(q, cond, extra) {
  if (cond) { ok++; console.log('  ok   ' + q); }
  else { mal++; fallos.push(q); console.log('  MAL  ' + q + (extra ? ' — ' + extra : '')); }
}
const titulo = (t) => console.log(`\n${t}`);

(async () => {
  const app = crearAplicacion({ archivoBase: ':memory:' });
  await new Promise((r) => app.servidor.listen(0, '127.0.0.1', r));
  const BASE = `http://127.0.0.1:${app.servidor.address().port}`;

  const galletas = {};
  async function pedir(metodo, ruta, cuerpo, quien, bearer) {
    const r = await fetch(BASE + ruta, {
      method: metodo,
      headers: Object.assign(
        cuerpo ? { 'Content-Type': 'application/json' } : {},
        galletas[quien] ? { Cookie: galletas[quien] } : {},
        bearer ? { Authorization: 'Bearer ' + bearer } : {}),
      body: cuerpo ? JSON.stringify(cuerpo) : undefined,
    });
    const sc = r.headers.getSetCookie ? r.headers.getSetCookie() : [];
    if (sc.length && quien) galletas[quien] = sc[0].split(';')[0];
    let j = {}; try { j = await r.json(); } catch (e) {}
    return { codigo: r.status, cuerpo: j };
  }

  const CLAVE = 'UnaClaveLarga2026!';
  // Los dos equipos se llaman IGUAL a propósito.
  const EQUIPO = 'PC-01';

  async function crearCliente(email, organizacion, gb, quien) {
    await pedir('POST', '/api/registro',
      { email, organizacion, clave: CLAVE, nombre: 'X', planId: 'estudio' }, quien);
    await pedir('POST', '/api/sesion', { email, clave: CLAVE }, quien);
    const ag = await pedir('POST', '/api/agent-auth/login',
      { email, password: CLAVE, deviceName: EQUIPO, agentVersion: '0.9.21' }, quien + '-ag');
    const token = ag.cuerpo.agentToken;
    await pedir('POST', '/api/agent/uso',
      { deviceName: EQUIPO, bytes: gb * 1024 ** 3, archivos: gb * 10 }, null, token);
    // Una factura, para que haya algo que filtrar mal.
    const ck = await pedir('POST', '/api/suscripciones/checkout', { planId: 'estudio' }, quien);
    const referencia = ck.cuerpo.referencia ||
      (ck.cuerpo.checkoutUrl || '').split('referencia=')[1];
    return { email, token, referencia };
  }

  await pedir('POST', '/api/sesion', { email: 'admin', clave: 'admin', modo: 'admin' }, 'admin');
  await pedir('PUT', '/api/admin/mercadopago', { webhookSecret: 'x' }, 'admin');

  const A = await crearCliente('estudio.a@ejemplo.com', 'Estudio A', 100, 'A');
  const B = await crearCliente('estudio.b@ejemplo.com', 'Estudio B', 700, 'B');
  await pedir('POST', '/api/pago-simulado', { referencia: A.referencia, estado: 'approved' }, 'A');
  await pedir('POST', '/api/pago-simulado', { referencia: B.referencia, estado: 'approved' }, 'B');

  // ── Lo que ve cada uno ───────────────────────────────────────────────────
  titulo('Cada cliente ve SOLO lo suyo');
  const cuentaA = (await pedir('GET', '/api/cuenta', null, 'A')).cuerpo;
  const cuentaB = (await pedir('GET', '/api/cuenta', null, 'B')).cuerpo;

  comprobar('A ve su propia organización', cuentaA.organizacion === 'Estudio A', cuentaA.organizacion);
  comprobar('A no ve el email de B', JSON.stringify(cuentaA).indexOf(B.email) === -1);
  comprobar('A ve un solo equipo', (cuentaA.equipos || []).length === 1,
    JSON.stringify(cuentaA.equipos));
  comprobar('A ve SU consumo, no el de B',
    cuentaA.cuota.usadoBytes === 100 * 1024 ** 3,
    `A=${cuentaA.cuota.usadoBytes} esperado=${100 * 1024 ** 3}`);
  comprobar('B ve SU consumo, no el de A',
    cuentaB.cuota.usadoBytes === 700 * 1024 ** 3,
    `B=${cuentaB.cuota.usadoBytes}`);
  comprobar('El equipo homónimo NO se mezcló entre cuentas',
    cuentaA.cuota.usadoBytes !== cuentaB.cuota.usadoBytes);
  comprobar('A ve una sola factura', (cuentaA.facturas || []).length === 1,
    JSON.stringify(cuentaA.facturas));
  comprobar('Las facturas de A y B tienen números distintos',
    (cuentaA.facturas[0] || {}).numero !== (cuentaB.facturas[0] || {}).numero,
    JSON.stringify([cuentaA.facturas[0], cuentaB.facturas[0]]));
  comprobar('El prefijo de A y el de B son distintos',
    !cuentaA.prefijo || cuentaA.prefijo !== cuentaB.prefijo,
    `${cuentaA.prefijo} vs ${cuentaB.prefijo}`);

  titulo('Las sesiones no se cruzan');
  const sesA = (await pedir('GET', '/api/cuenta/sesiones', null, 'A')).cuerpo.sesiones || [];
  const sesB = (await pedir('GET', '/api/cuenta/sesiones', null, 'B')).cuerpo.sesiones || [];
  const idsB = sesB.map((s) => s.id);
  comprobar('A no ve ninguna sesión de B',
    sesA.every((s) => idsB.indexOf(s.id) === -1),
    JSON.stringify(sesA.map((s) => s.id)));

  // ── Lo que NO puede tocar ────────────────────────────────────────────────
  titulo('Un cliente no puede tocar lo del otro');
  let r = await pedir('POST', '/api/cuenta/sesiones/cerrar', { id: idsB[0] }, 'A');
  const sesBDespues = (await pedir('GET', '/api/cuenta/sesiones', null, 'B')).cuerpo.sesiones || [];
  comprobar('A no puede cerrar la sesión de B',
    sesBDespues.length === sesB.length,
    `antes ${sesB.length}, después ${sesBDespues.length}`);

  r = await pedir('POST', '/api/cuenta/equipos/desvincular', { nombre: EQUIPO }, 'A');
  const equiposB = ((await pedir('GET', '/api/cuenta', null, 'B')).cuerpo.equipos || []);
  comprobar('Desvincular un equipo homónimo NO le borra el de B',
    equiposB.length === 1, JSON.stringify(equiposB));

  // El caso anterior no alcanza: si la consulta busca por nombre sin filtrar
  // por cuenta, igual puede encontrar el de A primero y borrar el correcto de
  // casualidad. Este es determinístico: A pide desvincular un equipo que SOLO
  // tiene B. Tiene que dar 404 y B tiene que conservarlo.
  const SOLO_B = 'SERVIDOR-EXCLUSIVO-B';
  await pedir('POST', '/api/agent-auth/login',
    { email: B.email, password: CLAVE, deviceName: SOLO_B, agentVersion: '0.9.21' }, 'B-ag2');
  r = await pedir('POST', '/api/cuenta/equipos/desvincular', { nombre: SOLO_B }, 'A');
  comprobar('A pidiendo desvincular un equipo de B recibe 404', r.codigo === 404,
    `dio ${r.codigo} ${JSON.stringify(r.cuerpo)}`);
  const equiposB2 = ((await pedir('GET', '/api/cuenta', null, 'B')).cuerpo.equipos || []);
  comprobar('Y B conserva ese equipo',
    equiposB2.some((e) => e.nombre === SOLO_B), JSON.stringify(equiposB2));

  // El agente de A informa uso con el mismo nombre de equipo que usa B.
  await pedir('POST', '/api/agent/uso',
    { deviceName: EQUIPO, bytes: 5 * 1024 ** 3, archivos: 50 }, null, A.token);
  const cuotaB2 = (await pedir('GET', '/api/agent/cuota', null, null, B.token)).cuerpo.cuota;
  comprobar('El agente de A no puede pisar el consumo de B',
    cuotaB2.usadoBytes === 700 * 1024 ** 3, `B ahora=${cuotaB2.usadoBytes}`);

  r = await pedir('POST', '/api/suscripciones/cancelar', { clave: CLAVE }, 'A');
  const estadoB = (await pedir('GET', '/api/cuenta', null, 'B')).cuerpo.estado;
  comprobar('Que A se dé de baja no toca a B', estadoB === 'activa', estadoB);

  // ── El panel es del admin, no de los clientes ────────────────────────────
  titulo('Un cliente no entra al panel');
  for (const [metodo, ruta, cuerpo] of [
    ['GET', '/api/admin/clientes', null],
    ['GET', '/api/admin/auditoria', null],
    ['GET', '/api/admin/resumen', null],
    ['GET', '/api/admin/mercadopago', null],
    ['POST', '/api/admin/clientes/ficha', { id: 'x' }],
    ['POST', '/api/admin/clientes/clave', { id: 'x', claveAdmin: 'admin' }],
    ['POST', '/api/admin/clientes/mfa', { id: 'x', claveAdmin: 'admin' }],
    ['POST', '/api/admin/clientes/destrabar', { id: 'x' }],
    ['PUT', '/api/admin/mercadopago', { webhookSecret: 'y' }],
  ]) {
    const rr = await pedir(metodo, ruta, cuerpo, 'B');
    comprobar(`Con sesión de cliente, ${metodo} ${ruta} da 401`, rr.codigo === 401,
      `dio ${rr.codigo}`);
  }

  titulo('El token del agente no sirve para el portal');
  const conAgente = await pedir('GET', '/api/cuenta/sesiones', null, null, B.token);
  comprobar('Un token de agente no lee las sesiones del portal',
    conAgente.codigo === 401, `dio ${conAgente.codigo}`);

  titulo('Sin sesión no se ve nada');
  for (const ruta of ['/api/cuenta', '/api/cuenta/sesiones', '/api/agent/cuota']) {
    const rr = await pedir('GET', ruta, null, 'nadie');
    comprobar(`Sin sesión, ${ruta} da 401`, rr.codigo === 401, `dio ${rr.codigo}`);
  }

  titulo('No se filtra quién es cliente');
  const existe = await pedir('POST', '/api/clave/olvide', { email: B.email }, 'nadie');
  const noExiste = await pedir('POST', '/api/clave/olvide', { email: 'nadie@ejemplo.com' }, 'nadie');
  comprobar('Pedir la clave de un email que existe y de uno que no da la MISMA respuesta',
    existe.codigo === noExiste.codigo &&
    JSON.stringify(existe.cuerpo) === JSON.stringify(noExiste.cuerpo),
    `${existe.codigo} ${JSON.stringify(existe.cuerpo)} vs ${noExiste.codigo} ${JSON.stringify(noExiste.cuerpo)}`);

  const malaClave = await pedir('POST', '/api/sesion', { email: B.email, clave: 'incorrecta' }, 'nadie');
  const malEmail = await pedir('POST', '/api/sesion', { email: 'nadie@ejemplo.com', clave: 'incorrecta' }, 'nadie');
  comprobar('El ingreso no dice cuál de los dos campos está mal',
    JSON.stringify(malaClave.cuerpo) === JSON.stringify(malEmail.cuerpo),
    JSON.stringify([malaClave.cuerpo, malEmail.cuerpo]));

  console.log('\n──────────────────────────────');
  console.log(`  ${ok} de ${ok + mal} pasadas`);
  if (mal) { console.log('  Fallaron:'); fallos.forEach((f) => console.log('    · ' + f)); }
  app.servidor.close();
  process.exit(mal ? 1 : 0);
})().catch((e) => { console.error('error inesperado:', e); process.exit(1); });
