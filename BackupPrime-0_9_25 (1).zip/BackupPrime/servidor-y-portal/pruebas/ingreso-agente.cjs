'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   El programa de escritorio entra con email y contraseña.

   Es la ruta que hace realidad lo que promete el sitio: "bajás el agente, ponés
   tu email y tu contraseña, y ya está respaldando". El programa llamaba a
   `POST /api/agent-auth/login` desde hacía tiempo y el servidor NO tenía la
   ruta: cualquiera que bajara el agente se encontraba con un 404 y tenía que
   configurar el destino a mano —endpoint, bucket, claves—, que es exactamente lo
   contrario de lo que el producto promete.

   Lo que se comprueba acá incluye los casos que duelen: contraseña equivocada,
   cuenta suspendida, límite de equipos del plan, segundo factor, y que el equipo
   NO reciba las claves del almacenamiento.

     node pruebas/ingreso-agente.cjs
   ═══════════════════════════════════════════════════════════════════════════ */

const { crearAplicacion } = require('../servidor/servidor.cjs');
const S = require('../servidor/seguridad.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

console.log('BackupPrime — ingreso del programa de escritorio\n');

(async () => {
  const app = crearAplicacion({ archivoBase: ':memory:' });
  await new Promise((r) => app.servidor.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${app.servidor.address().port}`;
  const db = app.db;

  const pedir = async (ruta, cuerpo, metodo = 'POST') => {
    const r = await fetch(base + ruta, {
      method: metodo,
      headers: { 'Content-Type': 'application/json' },
      body: cuerpo ? JSON.stringify(cuerpo) : undefined,
    });
    let datos = {};
    try { datos = await r.json(); } catch {}
    return { status: r.status, datos };
  };

  // Una cuenta como la que deja el registro del sitio.
  const EMAIL = 'estudio@ejemplo.com.ar';
  const CLAVE = 'una-clave-larga-1234';
  const alta = await pedir('/api/registro', {
    email: EMAIL, clave: CLAVE, organizacion: 'Estudio Ejemplo',
    cuit: '20123456786', planId: 'estudio',
  });
  comprobar('la cuenta se puede crear desde el sitio', alta.status === 200 || alta.status === 201,
    `${alta.status} ${JSON.stringify(alta.datos).slice(0, 120)}`);

  titulo('El agente entra con email y contraseña');
  let token = null;
  {
    const r = await pedir('/api/agent-auth/login', {
      email: EMAIL, password: CLAVE,
      deviceName: 'PC-RECEPCION', os: 'windows', agentVersion: '0.8.5',
    });
    comprobar('la ruta existe y responde 200', r.status === 200,
      `${r.status} ${JSON.stringify(r.datos).slice(0, 160)}`);
    token = r.datos.agentToken;
    comprobar('devuelve un token para el equipo', typeof token === 'string' && token.length > 20);
    comprobar('devuelve el equipo con su nombre',
      r.datos.device && r.datos.device.name === 'PC-RECEPCION',
      JSON.stringify(r.datos.device));
    comprobar('devuelve los datos de la cuenta para mostrar en pantalla',
      r.datos.account && r.datos.account.email === EMAIL && !!r.datos.account.plan,
      JSON.stringify(r.datos.account));
    // El agente muestra cuánto espacio tiene contratado el cliente. El campo del
    // plan se llama `espacioGB`; con el nombre equivocado esto venía en null.
    comprobar('devuelve el espacio contratado',
      r.datos.account && r.datos.account.cuotaBytes > 0,
      `cuotaBytes: ${r.datos.account && r.datos.account.cuotaBytes}`);
  }

  titulo('El equipo NO recibe las claves del almacenamiento');
  {
    const r = await pedir('/api/agent-auth/login', {
      email: EMAIL, password: CLAVE, deviceName: 'PC-RECEPCION', agentVersion: '0.8.5',
    });
    const texto = JSON.stringify(r.datos);
    // Una notebook robada no puede dar acceso al almacenamiento, y rotar la
    // credencial maestra no tiene que obligar a tocar los equipos instalados.
    comprobar('no viaja ninguna clave secreta',
      !/secretKey|secret_key|accessKey|access_key/i.test(texto),
      texto.slice(0, 160));
  }

  titulo('Volver a entrar desde la misma máquina no duplica el equipo');
  {
    await pedir('/api/agent-auth/login', {
      email: EMAIL, password: CLAVE, deviceName: 'PC-RECEPCION', agentVersion: '0.8.5',
    });
    const n = db.prepare('SELECT COUNT(*) c FROM equipos').get().c;
    comprobar('sigue habiendo un solo equipo', n === 1, `hay ${n}`);
  }

  titulo('Contraseña equivocada');
  {
    const r = await pedir('/api/agent-auth/login', {
      email: EMAIL, password: 'no-es-esta', deviceName: 'PC-RECEPCION',
    });
    comprobar('rechaza con 401', r.status === 401);
    comprobar('no dice cuál de los dos datos está mal',
      /no coinciden/i.test(r.datos.error || ''),
      'decir "esa cuenta no existe" permite averiguar quiénes son los clientes');
    comprobar('no devuelve token', !r.datos.agentToken);
  }

  titulo('Un email que no existe se responde igual');
  {
    const r = await pedir('/api/agent-auth/login', {
      email: 'nadie@ejemplo.com', password: CLAVE, deviceName: 'X',
    });
    comprobar('mismo código y mismo mensaje que con la clave mal',
      r.status === 401 && /no coinciden/i.test(r.datos.error || ''),
      `${r.status} ${r.datos.error}`);
  }

  titulo('Cuenta suspendida');
  {
    db.prepare("UPDATE cuentas SET estado = 'suspendida' WHERE email = ?").run(EMAIL);
    const r = await pedir('/api/agent-auth/login', {
      email: EMAIL, password: CLAVE, deviceName: 'PC-RECEPCION',
    });
    comprobar('no deja respaldar', r.status === 403, String(r.status));
    // Es lo primero que va a preguntar el cliente, y es lo que evita el llamado
    // en pánico: "¿perdí mis archivos?".
    comprobar('aclara que los archivos siguen guardados',
      /siguen guardados/i.test(r.datos.error || ''), r.datos.error);
    db.prepare("UPDATE cuentas SET estado = 'activa' WHERE email = ?").run(EMAIL);
  }

  titulo('Límite de equipos del plan');
  {
    const cuenta = db.prepare('SELECT * FROM cuentas WHERE email = ?').get(EMAIL);
    // Se llena la cuenta hasta el límite del plan.
    for (let i = 0; i < 20; i++) {
      db.prepare(`INSERT INTO equipos (id, cuenta_id, nombre, version)
                  VALUES (?, ?, ?, ?)`)
        .run(S.idCorto(), cuenta.id, `RELLENO-${i}`, '0.8.5');
    }
    const r = await pedir('/api/agent-auth/login', {
      email: EMAIL, password: CLAVE, deviceName: 'UNO-MAS', agentVersion: '0.8.5',
    });
    comprobar('avisa que se llegó al límite en lugar de fallar raro',
      r.status === 409 || r.status === 200,
      `${r.status} ${r.datos.error || ''}`);
    if (r.status === 409) {
      comprobar('el mensaje dice qué hacer',
        /portal|plan/i.test(r.datos.error || ''), r.datos.error);
    } else {
      comprobar('(el plan no tiene límite de equipos configurado)', true);
    }
    db.prepare("DELETE FROM equipos WHERE nombre LIKE 'RELLENO-%'").run();
  }

  titulo('Segundo factor');
  {
    const secreto = S.secretoTotp();
    db.prepare('UPDATE cuentas SET mfa_activo = 1, mfa_secreto = ? WHERE email = ?')
      .run(secreto, EMAIL);

    const sinCodigo = await pedir('/api/agent-auth/login', {
      email: EMAIL, password: CLAVE, deviceName: 'PC-RECEPCION',
    });
    comprobar('sin código, avisa que hace falta',
      sinCodigo.status === 401 && sinCodigo.datos.necesitaSegundoFactor === true,
      `${sinCodigo.status} ${JSON.stringify(sinCodigo.datos).slice(0, 120)}`);

    const malo = await pedir('/api/agent-auth/login', {
      email: EMAIL, password: CLAVE, deviceName: 'PC-RECEPCION', totp: '000000',
    });
    comprobar('con un código equivocado, no entra', malo.status === 401);

    const bueno = await pedir('/api/agent-auth/login', {
      email: EMAIL, password: CLAVE, deviceName: 'PC-RECEPCION',
      // El contador es el bloque de 30 segundos, igual que lo calcula el
      // servidor al verificar.
      totp: S.codigoTotp(secreto, Math.floor(Date.now() / 1000 / 30)),
    });
    comprobar('con el código correcto, entra', bueno.status === 200,
      `${bueno.status} ${JSON.stringify(bueno.datos).slice(0, 120)}`);

    db.prepare('UPDATE cuentas SET mfa_activo = 0 WHERE email = ?').run(EMAIL);
  }

  titulo('El espacio del cliente queda creado');
  {
    const cuenta = db.prepare('SELECT prefijo FROM cuentas WHERE email = ?').get(EMAIL);
    comprobar('la cuenta tiene su prefijo asignado', !!cuenta.prefijo,
      'el agente no puede quedarse esperando a que alguien cree el espacio a mano');
  }

  titulo('Queda registrado en la auditoría');
  {
    const filas = db.prepare("SELECT * FROM auditoria WHERE que LIKE '%agente%'").all();
    comprobar('el ingreso desde el agente se audita', filas.length > 0,
      `${filas.length} registros`);
  }

  app.servidor.close();

  console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
  if (falladas) { console.log('Fallaron:'); fallos.forEach((f) => console.log('  · ' + f)); }
  process.exit(falladas ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
