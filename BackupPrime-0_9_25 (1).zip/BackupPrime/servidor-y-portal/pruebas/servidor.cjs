'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   El backend de verdad, probado solamente por HTTP.

   No mira por dentro: hace exactamente lo que va a hacer el sitio. Si estas
   pruebas pasan, el sitio funciona contra este servidor.

     node pruebas/servidor.cjs
     BASE=https://backupprime.com node pruebas/servidor.cjs
   ═══════════════════════════════════════════════════════════════════════════ */

const crypto = require('node:crypto');
const { crearAplicacion } = require('../servidor/servidor.cjs');
const { codigoTotp } = require('../servidor/seguridad.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
function comprobar(nombre, condicion, detalle = '') {
  if (condicion) { pasadas++; console.log(`  ok   ${nombre}`); }
  else { falladas++; fallos.push(nombre); console.log(`  FALLA ${nombre}${detalle ? ' — ' + detalle : ''}`); }
}
const titulo = (t) => console.log(`\n${t}`);

const SECRETO_WEBHOOK = 'secreto-de-prueba';

(async () => {
  const app = crearAplicacion({ archivoBase: ':memory:' });
  app.guardarAjuste('mercadopago', { webhookSecret: SECRETO_WEBHOOK });
  await new Promise((r) => app.servidor.listen(0, '127.0.0.1', r));
  const BASE = process.env.BASE || `http://127.0.0.1:${app.servidor.address().port}`;

  const pedir = async (metodo, ruta, cuerpo, token, cabecerasExtra = {}) => {
    const cabeceras = { 'Content-Type': 'application/json', ...cabecerasExtra };
    if (token) cabeceras.Authorization = 'Bearer ' + token;
    const r = await fetch(BASE + ruta, {
      method: metodo, headers: cabeceras,
      body: cuerpo === undefined ? undefined : JSON.stringify(cuerpo),
    });
    const texto = await r.text();
    let datos = {};
    try { datos = texto ? JSON.parse(texto) : {}; } catch { datos = { crudo: texto }; }
    return { status: r.status, datos, cabeceras: r.headers };
  };

  console.log('BackupPrime — el backend de verdad');
  console.log(`Contra: ${BASE}`);

  // ── Planes ────────────────────────────────────────────────────────────────
  titulo('Planes');

  const planes = await pedir('GET', '/api/planes');
  comprobar('1. Devuelve los planes', planes.status === 200 && planes.datos.planes.length === 3);
  comprobar('2. El primero es Personal a 16.000',
    planes.datos.planes[0].id === 'personal' && planes.datos.planes[0].precioMensual === 16000);
  comprobar('3. Hay uno destacado', planes.datos.planes.filter((p) => p.destacado).length === 1);

  // ── Alta ──────────────────────────────────────────────────────────────────
  titulo('Alta de cuenta');

  const email = `ana${Date.now()}@estudio.com.ar`;
  const CLAVE = 'una frase larga y mia';
  const alta = await pedir('POST', '/api/registro', {
    organizacion: 'Contadores del Sur', email, clave: CLAVE,
    celular: '11 5555 4444', telefono: '011 4444 5555',
    direccion: 'Av. Mitre 1234', localidad: 'Adrogué', provincia: 'Buenos Aires',
    cuit: '20123456786', planId: 'estudio',
  });
  comprobar('4. Crea la cuenta', alta.status === 201, JSON.stringify(alta.datos).slice(0, 120));
  comprobar('5. Devuelve sesión iniciada', !!alta.datos.token);
  comprobar('6. Arranca en prueba con fecha de fin',
    alta.datos.estado === 'prueba' && !!alta.datos.pruebaHasta);
  comprobar('7. No filtra la contraseña', !/scrypt|clave/i.test(JSON.stringify(alta.datos)));

  const token = alta.datos.token;

  const mia = await pedir('GET', '/api/cuenta', undefined, token);
  comprobar('8. Guardó los datos de contacto',
    mia.datos.celular === '11 5555 4444' && mia.datos.localidad === 'Adrogué' &&
    mia.datos.provincia === 'Buenos Aires');
  comprobar('9. Le asignó el espacio del plan', mia.datos.espacioGB === 1000,
    `espacio ${mia.datos.espacioGB}`);

  titulo('El servidor valida por su cuenta');

  const repetido = await pedir('POST', '/api/registro',
    { organizacion: 'Contadores del Sur', email, clave: CLAVE });
  comprobar('10. Rechaza un email repetido', repetido.status === 409);

  const corta = await pedir('POST', '/api/registro',
    { organizacion: 'Estudio Nuevo', email: `a${Date.now()}@b.com`, clave: '1234' });
  comprobar('11. Rechaza una clave corta', corta.status === 400 && corta.datos.campo === 'clave');

  const comun = await pedir('POST', '/api/registro',
    { organizacion: 'Estudio Nuevo', email: `b${Date.now()}@b.com`, clave: 'mi password 123' });
  comprobar('12. Rechaza una clave demasiado común', comun.status === 400);

  const sinNombre = await pedir('POST', '/api/registro',
    { organizacion: 'X', email: `d${Date.now()}@b.com`, clave: CLAVE });
  comprobar('12b. Rechaza un nombre de una sola letra',
    sinNombre.status === 400 && sinNombre.datos.campo === 'estudio');

  const cuitMal = await pedir('POST', '/api/registro',
    { organizacion: 'Estudio Nuevo', email: `c${Date.now()}@b.com`, clave: CLAVE, cuit: '20123456780' });
  comprobar('13. Rechaza un CUIT con dígito verificador mal',
    cuitMal.status === 400 && cuitMal.datos.campo === 'cuit');

  // ── Ingreso ───────────────────────────────────────────────────────────────
  titulo('Ingreso');

  const mal = await pedir('POST', '/api/sesion', { email, clave: 'otra cosa' });
  comprobar('14. Rechaza la clave equivocada', mal.status === 401);
  comprobar('15. No revela si el email existe',
    /email o la contraseña/i.test(mal.datos.mensaje),
    mal.datos.mensaje);

  const inexistente = await pedir('POST', '/api/sesion',
    { email: 'nadie@ninguna.com', clave: 'x'.repeat(12) });
  comprobar('16. Da el mismo mensaje para un email que no existe',
    inexistente.datos.mensaje === mal.datos.mensaje);

  const bien = await pedir('POST', '/api/sesion', { email, clave: CLAVE, recordar: true });
  comprobar('17. Entra con la clave correcta', bien.status === 200 && !!bien.datos.token);
  comprobar('18. Y dice a dónde ir', bien.datos.destino === '/portal.html');

  const sinSesion = await pedir('GET', '/api/cuenta');
  comprobar('19. Sin sesión no se ven los datos', sinSesion.status === 401);
  const inventado = await pedir('GET', '/api/cuenta', undefined, 'f'.repeat(43));
  comprobar('20. Un token inventado no sirve', inventado.status === 401);

  titulo('Límite de intentos');

  const victima = `bloqueo${Date.now()}@e.com`;
  await pedir('POST', '/api/registro', { organizacion: 'X', email: victima, clave: CLAVE });
  let bloqueo = null;
  for (let i = 0; i < 6; i++) {
    bloqueo = await pedir('POST', '/api/sesion', { email: victima, clave: 'incorrecta' });
  }
  comprobar('21. Después de varios intentos bloquea un rato', bloqueo.status === 429,
    `status ${bloqueo.status}`);
  const conClaveBuena = await pedir('POST', '/api/sesion', { email: victima, clave: CLAVE });
  comprobar('22. Y el bloqueo aplica aunque la clave sea la correcta',
    conClaveBuena.status === 429);

  // ── Segundo factor ────────────────────────────────────────────────────────
  titulo('Verificación en dos pasos');

  const iniciar = await pedir('POST', '/api/cuenta/mfa/iniciar', {}, token);
  comprobar('23. Entrega un secreto y su enlace para la app',
    iniciar.status === 200 && iniciar.datos.secreto.length >= 16 &&
    /^otpauth:\/\/totp\//.test(iniciar.datos.url));

  const secreto = iniciar.datos.secreto;

  const codigoMal = await pedir('POST', '/api/cuenta/mfa/confirmar', { codigo: '000000' }, token);
  comprobar('24. No activa con un código inventado', codigoMal.status === 400);

  const yaLogueado = await pedir('POST', '/api/sesion', { email, clave: CLAVE });
  comprobar('25. Mientras no se confirme, se entra sin segundo factor',
    !yaLogueado.datos.necesitaSegundoFactor);

  const codigoBien = codigoTotp(secreto, Math.floor(Date.now() / 30000));
  const confirmar = await pedir('POST', '/api/cuenta/mfa/confirmar', { codigo: codigoBien }, token);
  comprobar('26. Se activa con el código real de la app', confirmar.status === 200);

  const conMfa = await pedir('POST', '/api/sesion', { email, clave: CLAVE });
  comprobar('27. Ahora el ingreso pide el segundo factor',
    conMfa.datos.necesitaSegundoFactor === true && !!conMfa.datos.token);

  const pendiente = conMfa.datos.token;
  const conPendiente = await pedir('GET', '/api/cuenta', undefined, pendiente);
  comprobar('28. Con la sesión a medias no se ve nada', conPendiente.status === 401);

  const mfaMal = await pedir('POST', '/api/sesion/mfa', { codigo: '123456' }, pendiente);
  comprobar('29. Un código equivocado no completa el ingreso', mfaMal.status === 401);

  const mfaBien = await pedir('POST', '/api/sesion/mfa',
    { codigo: codigoTotp(secreto, Math.floor(Date.now() / 30000)) }, pendiente);
  comprobar('30. Con el código correcto sí', mfaBien.status === 200);
  const ahoraSi = await pedir('GET', '/api/cuenta', undefined, pendiente);
  comprobar('31. Y esa sesión ya sirve', ahoraSi.status === 200);

  const bajarSinClave = await pedir('POST', '/api/cuenta/mfa/desactivar', { clave: 'x' }, token);
  comprobar('32. Desactivarlo exige la contraseña', bajarSinClave.status === 401);
  const bajar = await pedir('POST', '/api/cuenta/mfa/desactivar', { clave: CLAVE }, token);
  comprobar('33. Con la contraseña se puede desactivar', bajar.status === 200);

  // ── Sesiones ──────────────────────────────────────────────────────────────
  titulo('Sesiones abiertas');

  const sesiones = await pedir('GET', '/api/cuenta/sesiones', undefined, token);
  comprobar('34. Lista las sesiones abiertas', sesiones.status === 200 && sesiones.datos.sesiones.length >= 2);
  comprobar('35. No devuelve los tokens completos',
    sesiones.datos.sesiones.every((s) => s.id.length <= 8));

  await pedir('POST', '/api/cuenta/sesiones/cerrar', {}, token);
  const otraCerrada = await pedir('GET', '/api/cuenta', undefined, bien.datos.token);
  comprobar('36. Cerrar las otras deja afuera a las demás', otraCerrada.status === 401);
  const laMia = await pedir('GET', '/api/cuenta', undefined, token);
  comprobar('37. Pero no a la propia', laMia.status === 200);

  // ── Recuperar contraseña ──────────────────────────────────────────────────
  titulo('Recuperar la contraseña');

  const olvideExiste = await pedir('POST', '/api/clave/olvide', { email });
  const olvideNo = await pedir('POST', '/api/clave/olvide', { email: 'nadie@ninguna.com' });
  comprobar('38. Contesta igual exista o no la cuenta',
    olvideExiste.status === olvideNo.status &&
    JSON.stringify(olvideExiste.datos) === JSON.stringify(olvideNo.datos));

  const enlaceInvalido = await pedir('POST', '/api/clave/restablecer',
    { token: 'inventado', clave: 'otra frase larga mia' });
  comprobar('39. Un enlace inventado no cambia nada', enlaceInvalido.status === 400);

  // ── Plan y pago ───────────────────────────────────────────────────────────
  titulo('Plan y pago');

  const cambio = await pedir('POST', '/api/suscripciones/plan', { planId: 'empresa' }, token);
  comprobar('40. Cambia de plan', cambio.status === 200 && cambio.datos.espacioGB === 3000);
  const inexistentePlan = await pedir('POST', '/api/suscripciones/plan', { planId: 'gratis' }, token);
  comprobar('41. No acepta un plan que no existe', inexistentePlan.status === 400);
  await pedir('POST', '/api/suscripciones/plan', { planId: 'estudio' }, token);

  const checkout = await pedir('POST', '/api/suscripciones/checkout', { planId: 'estudio' }, token);
  comprobar('42. Devuelve link de pago, referencia y monto',
    checkout.status === 200 && !!checkout.datos.checkoutUrl &&
    !!checkout.datos.referencia && checkout.datos.montoMensual === 34900);

  const referencia = checkout.datos.referencia;

  const avisar = (cuerpo, firmaMala) => {
    const crudo = JSON.stringify(cuerpo);
    const firma = firmaMala ? 'a'.repeat(64)
      : crypto.createHmac('sha256', SECRETO_WEBHOOK).update(crudo).digest('hex');
    return fetch(BASE + '/api/webhooks/mercadopago', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-signature': firma },
      body: crudo,
    }).then(async (r) => ({ status: r.status, datos: await r.json() }));
  };

  titulo('Acreditación del pago');

  const sinFirma = await avisar({ id: 'e1', referencia, estado: 'approved' }, true);
  comprobar('43. Sin firma válida no acredita', sinFirma.status === 401);
  const sigueEnPrueba = await pedir('GET', '/api/cuenta', undefined, token);
  comprobar('44. Y la cuenta sigue en prueba', sigueEnPrueba.datos.estado === 'prueba');

  const pago = await avisar({ id: 'e1', referencia, estado: 'approved' });
  comprobar('45. Con firma válida acredita', pago.status === 200);
  const activa = await pedir('GET', '/api/cuenta', undefined, token);
  comprobar('46. La cuenta queda activa', activa.datos.estado === 'activa');
  comprobar('47. Se emitió la factura',
    activa.datos.facturas.length === 1 && activa.datos.facturas[0].monto === 34900,
    JSON.stringify(activa.datos.facturas));

  const otraVez = await avisar({ id: 'e1', referencia, estado: 'approved' });
  const trasRepetir = await pedir('GET', '/api/cuenta', undefined, token);
  comprobar('48. El mismo aviso repetido no factura dos veces',
    otraVez.datos.repetido === true && trasRepetir.datos.facturas.length === 1);

  const ajena = await avisar({ id: 'e2', referencia: 'sub_inventada', estado: 'approved' });
  comprobar('49. Un aviso de una suscripción que no existe no rompe nada', ajena.status === 404);

  const rechazo = await avisar({ id: 'e3', referencia, estado: 'rejected' });
  const morosa = await pedir('GET', '/api/cuenta', undefined, token);
  comprobar('50. Un cobro rechazado marca la mora',
    rechazo.status === 200 && morosa.datos.moroso === true);
  comprobar('51. Pero no le saca el espacio', morosa.datos.espacioGB === 1000);

  await avisar({ id: 'e4', referencia, estado: 'approved' });
  const alDia = await pedir('GET', '/api/cuenta', undefined, token);
  comprobar('52. Al pagar vuelve a estar al día', alDia.datos.moroso === false);

  // ── Administración ────────────────────────────────────────────────────────
  titulo('Panel de administración');

  const adminMal = await pedir('POST', '/api/sesion', { modo: 'admin', email: 'admin', clave: 'otra' });
  comprobar('53. No entra con la contraseña equivocada', adminMal.status === 401);

  const admin = await pedir('POST', '/api/sesion', { modo: 'admin', email: 'admin', clave: 'admin' });
  comprobar('54. Entra con la contraseña inicial', admin.status === 200 && !!admin.datos.token);
  comprobar('55. Avisa que la contraseña es la inicial', admin.datos.claveInicial === true);

  const tAdmin = admin.datos.token;

  const cliente = await pedir('GET', '/api/cuenta', undefined, tAdmin);
  comprobar('56. La sesión de administración no sirve como cliente', cliente.status === 401);

  const resumen = await pedir('GET', '/api/admin/resumen', undefined, tAdmin);
  comprobar('57. Da el resumen del negocio',
    resumen.status === 200 && resumen.datos.cuentas.total >= 1 &&
    resumen.datos.facturadoUltimos30 >= 34900,
    JSON.stringify(resumen.datos));

  const clientes = await pedir('GET', '/api/admin/clientes', undefined, tAdmin);
  comprobar('58. Lista los clientes', clientes.status === 200 && clientes.datos.clientes.length >= 1);
  comprobar('59. Sin exponer las contraseñas',
    !/scrypt/.test(JSON.stringify(clientes.datos)));

  const sinAdmin = await pedir('GET', '/api/admin/clientes', undefined, token);
  comprobar('60. Un cliente no puede entrar al panel', sinAdmin.status === 401);

  titulo('Configuración desde el panel');

  const catalogo = await pedir('GET', '/api/admin/almacenamiento/catalogo', undefined, tAdmin);
  comprobar('61. Ofrece los proveedores de almacenamiento',
    catalogo.status === 200 && catalogo.datos.catalogo.length >= 5);

  const probarMal = await pedir('POST', '/api/admin/almacenamiento/probar',
    { proveedor: 'idrive-e2', endpoint: 'http://127.0.0.1:1', region: 'x',
      bucket: 'b', accessKey: 'a', secretKey: 's' }, tAdmin);
  comprobar('62. Probar un proveedor caído avisa sin romper',
    probarMal.status === 200 && probarMal.datos.ok === false);

  const guardarMal = await pedir('PUT', '/api/admin/almacenamiento',
    { proveedor: 'idrive-e2', endpoint: 'http://127.0.0.1:1', region: 'x',
      bucket: 'b', accessKey: 'a', secretKey: 's' }, tAdmin);
  comprobar('63. No guarda una configuración que no funciona', guardarMal.status === 400);

  const nuevosPlanes = catalogo.datos.actual ? null : null;
  const planesAdmin = await pedir('GET', '/api/admin/planes', undefined, tAdmin);
  const modificados = planesAdmin.datos.planes.map((p) =>
    p.id === 'personal' ? { ...p, precioMensual: 17500 } : p);
  const guardarPlanes = await pedir('PUT', '/api/admin/planes', { planes: modificados }, tAdmin);
  comprobar('64. Se pueden cambiar los precios', guardarPlanes.status === 200);
  const publicos = await pedir('GET', '/api/planes');
  comprobar('65. El precio nuevo se ve en el sitio al instante',
    publicos.datos.planes[0].precioMensual === 17500);

  const mora = await pedir('PUT', '/api/admin/mora',
    { mora: { aviso: 1, cortarSubidas: 7, borrar: 120 } }, tAdmin);
  comprobar('66. Se puede cambiar la escalera de mora', mora.status === 200);

  titulo('Contraseña del administrador');

  const cambioMal = await pedir('POST', '/api/admin/clave',
    { actual: 'no es', nueva: 'una frase larga y propia' }, tAdmin);
  comprobar('67. Pide la contraseña actual de verdad', cambioMal.status === 401);

  const cortaAdmin = await pedir('POST', '/api/admin/clave',
    { actual: 'admin', nueva: 'corta' }, tAdmin);
  comprobar('68. Exige una contraseña larga para el panel', cortaAdmin.status === 400);

  const cambioOk = await pedir('POST', '/api/admin/clave',
    { actual: 'admin', nueva: 'una frase larga y propia' }, tAdmin);
  comprobar('69. Cambia la contraseña', cambioOk.status === 200);

  const viejaClave = await pedir('POST', '/api/sesion', { modo: 'admin', email: 'admin', clave: 'admin' });
  comprobar('70. La contraseña vieja deja de servir', viejaClave.status === 401);

  const nuevaClave = await pedir('POST', '/api/sesion',
    { modo: 'admin', email: 'admin', clave: 'una frase larga y propia' });
  comprobar('71. La nueva funciona', nuevaClave.status === 200);
  comprobar('72. Y ya no avisa de la contraseña inicial', !nuevaClave.datos.claveInicial);

  titulo('Registro de lo que pasó');

  const auditoria = await pedir('GET', '/api/admin/auditoria', undefined, nuevaClave.datos.token);
  comprobar('73. Quedó registrado el alta, el ingreso y los cambios',
    auditoria.datos.eventos.some((e) => e.que === 'alta de cuenta') &&
    auditoria.datos.eventos.some((e) => e.que === 'ingreso de administración') &&
    auditoria.datos.eventos.some((e) => e.que === 'cambió los planes'));

  const avisos = await pedir('GET', '/api/admin/avisos', undefined, nuevaClave.datos.token);
  comprobar('74. Los mails quedaron encolados, no perdidos',
    avisos.datos.avisos.some((a) => /lista/i.test(a.asunto)) &&
    avisos.datos.avisos.some((a) => /acreditado/i.test(a.asunto)));

  titulo('Higiene de las respuestas');

  comprobar('75. La API no se cachea',
    (laMia.cabeceras.get('cache-control') || '').includes('no-store'));
  comprobar('76. Manda X-Content-Type-Options',
    laMia.cabeceras.get('x-content-type-options') === 'nosniff');
  comprobar('77. Y no se puede meter en un marco ajeno',
    laMia.cabeceras.get('x-frame-options') === 'DENY');

  const inexistenteRuta = await pedir('GET', '/api/nada');
  comprobar('78. Una ruta que no existe contesta 404 en JSON', inexistenteRuta.status === 404);

  titulo('Descargas y lista de espera');

  const descarga = await pedir('GET', '/api/descargas/windows');
  // Esta prueba antes exigía que SIEMPRE hubiera una versión, y pasaba gracias
  // al 0.7.1 escrito a mano: informaba una versión inventada, con el archivo
  // sin subir. El contrato real tiene dos ramas, y las dos son honestas.
  comprobar('85. O publica una versión de verdad, o dice que no hay ninguna',
    descarga.status === 200 && (
      (descarga.datos.disponible === true && /^\d+\.\d+\.\d+$/.test(descarga.datos.version)) ||
      (descarga.datos.disponible === false && descarga.datos.version === null &&
       !descarga.datos.url)),
    JSON.stringify(descarga.datos).slice(0, 160));
  comprobar('86. La huella se calcula del archivo, no se escribe a mano',
    descarga.datos.sha256 === null || /^[a-f0-9]{64}$/.test(descarga.datos.sha256),
    String(descarga.datos.sha256).slice(0, 20));

  const anotar = await pedir('POST', '/api/avisarme', { email: 'quiero@celular.com', sobre: 'celular' });
  comprobar('87. Se puede anotar en la lista de espera del celular', anotar.status === 200);
  const mailMal = await pedir('POST', '/api/avisarme', { email: 'no-es-mail' });
  comprobar('88. Con un email inválido no anota', mailMal.status === 400);

  titulo('La sesión viaja en cookie');

  const conCookie = await fetch(BASE + '/api/sesion', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, clave: CLAVE }),
  });
  const galleta = conCookie.headers.get('set-cookie') || '';
  comprobar('79. Al entrar deja la cookie de sesión', /bp_sesion=/.test(galleta), galleta.slice(0, 60));
  comprobar('80. La cookie es HttpOnly, para que el JavaScript no la pueda leer',
    /HttpOnly/i.test(galleta));
  comprobar('81. Y no se manda a sitios de terceros', /SameSite=Lax/i.test(galleta));

  const soloCookie = galleta.split(';')[0];
  const conSoloCookie = await fetch(BASE + '/api/cuenta', { headers: { Cookie: soloCookie } });
  comprobar('82. Con la cookie sola ya se puede usar la API', conSoloCookie.status === 200);

  const salir = await fetch(BASE + '/api/sesion/salir', {
    method: 'POST', headers: { Cookie: soloCookie },
  });
  comprobar('83. Salir borra la cookie',
    /bp_sesion=;/.test(salir.headers.get('set-cookie') || ''));
  const despues = await fetch(BASE + '/api/cuenta', { headers: { Cookie: soloCookie } });
  comprobar('84. Y esa sesión ya no sirve', despues.status === 401);

  console.log('\n──────────────────────────────────────────────────────');
  console.log(`  ${pasadas} de ${pasadas + falladas} pruebas pasadas`);
  if (falladas) { console.log('\n  Fallaron:'); for (const f of fallos) console.log(`    · ${f}`); }
  console.log('──────────────────────────────────────────────────────\n');

  app.servidor.close();
  process.exit(falladas ? 1 : 0);
})();
