'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Correo, probado contra un servidor SMTP de mentira.
 
   Igual que con el almacenamiento: si el sistema tiene que poder cambiar de
   proveedor sin romperse, hay que probar el contrato, no un proveedor.
 
     node pruebas/correo.cjs
   ═══════════════════════════════════════════════════════════════════════════ */

const net = require('node:net');
const { crear, despacharCola, CATALOGO } = require('../correo/index.cjs');
const { abrir, encolarAviso } = require('../servidor/base.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

/**
 * Servidor SMTP de mentira. `modo` permite hacerlo fallar a propósito:
 * rechazar-auth | rechazar-destinatario | cortar | sin-starttls
 */
function servidorFalso(modo = 'normal') {
  const recibidos = [];
  const comandos = [];
  const abiertos = new Set();

  const servidor = net.createServer((sock) => {
    abiertos.add(sock);
    sock.on('close', () => abiertos.delete(sock));
    sock.on('error', () => {});

    let enDatos = false;
    let respuestasAuth = 0;
    let mensaje = '';
    let sobre = {};

    sock.write('220 servidor-de-mentira\r\n');

    sock.on('data', (d) => {
      const texto = d.toString('utf8');

      if (enDatos) {
        mensaje += texto;
        if (mensaje.includes('\r\n.\r\n')) {
          enDatos = false;
          recibidos.push({ ...sobre, crudo: mensaje });
          mensaje = '';
          sock.write('250 Aceptado\r\n');
        }
        return;
      }

      for (const linea of texto.split('\r\n').filter(Boolean)) {
        comandos.push(linea);
        const cmd = linea.split(' ')[0].toUpperCase();

        if (modo === 'cortar' && cmd === 'MAIL') return sock.destroy();

        if (cmd === 'EHLO' || cmd === 'HELO') {
          sock.write('250-servidor-de-mentira\r\n');
          if (modo !== 'sin-starttls') sock.write('250-STARTTLS\r\n');
          sock.write('250-AUTH LOGIN PLAIN\r\n250 OK\r\n');
        } else if (cmd === 'STARTTLS') {
          // No se hace el cifrado de verdad: alcanza con comprobar que el
          // cliente lo exige y lo pide antes de mandar credenciales.
          sock.write('454 En esta prueba no hay TLS\r\n');
        } else if (cmd === 'AUTH') {
          if (modo === 'rechazar-auth') sock.write('535 Credenciales inválidas\r\n');
          else if (/PLAIN\s+\S/.test(linea)) sock.write('235 Adelante\r\n');
          else sock.write('334 VXNlcm5hbWU6\r\n');
        } else if (cmd === 'MAIL') {
          sobre.de = (linea.match(/<(.*)>/) || [])[1];
          sock.write('250 OK\r\n');
        } else if (cmd === 'RCPT') {
          if (modo === 'rechazar-destinatario') sock.write('550 No existe esa casilla\r\n');
          else { sobre.para = (linea.match(/<(.*)>/) || [])[1]; sock.write('250 OK\r\n'); }
        } else if (cmd === 'DATA') {
          enDatos = true;
          sock.write('354 Mandá el mensaje\r\n');
        } else if (cmd === 'QUIT') {
          sock.write('221 Chau\r\n'); sock.end();
        } else if (/^[A-Za-z0-9+/=]+$/.test(linea) && linea.length > 8) {
          // Línea de credenciales del método LOGIN. Va al final a propósito:
          // "DATA" y "QUIT" también son letras, y si esta rama se evalúa antes
          // se las come y las respuestas quedan corridas.
          respuestasAuth++;
          sock.write(respuestasAuth >= 2 ? '235 Adelante\r\n' : '334 UGFzc3dvcmQ6\r\n');
        } else {
          sock.write('250 OK\r\n');
        }
      }
    });
  });

  return {
    recibidos, comandos,
    escuchar: () => new Promise((r) => servidor.listen(0, '127.0.0.1', () => r(servidor.address().port))),
    cerrar: () => new Promise((r) => {
      for (const s of abiertos) { try { s.destroy(); } catch {} }
      servidor.close(r);
    }),
  };
}

const decodificar = (crudo) => {
  // El cuerpo va en base64; se junta para poder leerlo.
  const partes = crudo.split('\r\n\r\n').slice(1).join('\r\n\r\n');
  return partes.split(/\r\n/).map((l) => {
    try { return /^[A-Za-z0-9+/=]+$/.test(l) ? Buffer.from(l, 'base64').toString('utf8') : ''; }
    catch { return ''; }
  }).join('');
};

console.log('BackupPrime — correo saliente\n');

(async () => {
  titulo('Catálogo');
  comprobar('1. Hay varios proveedores', CATALOGO.length >= 5);
  comprobar('2. Cada uno trae servidor y puerto ya cargados',
    CATALOGO.filter((p) => p.id !== 'personalizado').every((p) => p.host && p.puerto));
  comprobar('3. Está DonWeb entre las opciones', CATALOGO.some((p) => p.id === 'donweb'));
  let aviso = null;
  try { crear({ proveedor: 'inventado' }); } catch (e) { aviso = e.message; }
  comprobar('4. Un proveedor desconocido avisa con claridad',
    !!aviso && /disponibles/.test(aviso));
  let falta = null;
  try { crear({ proveedor: 'brevo', usuario: 'u', clave: 'c' }); } catch (e) { falta = e.message; }
  comprobar('5. Avisa si falta la dirección del remitente', !!falta && /desde la que se env/.test(falta));

  titulo('Envío');
  const srv = servidorFalso();
  const puerto = await srv.escuchar();
  const correo = crear({
    proveedor: 'personalizado', host: '127.0.0.1', puerto, seguro: 'ninguno',
    usuario: 'ariel', clave: 'secreta',
    de: 'avisos@backupprime.com', deNombre: 'BackupPrime',
  });

  await correo.enviar({
    para: 'ana@estudio.com.ar',
    asunto: 'Tu cuenta está lista',
    texto: 'Bajá el programa e ingresá con este mismo email.',
  });

  comprobar('6. El mensaje llega al servidor', srv.recibidos.length === 1);
  comprobar('7. Con el remitente y el destinatario correctos',
    srv.recibidos[0].de === 'avisos@backupprime.com' &&
    srv.recibidos[0].para === 'ana@estudio.com.ar');
  const asuntoDe = (crudo) => {
    const l = crudo.split('\r\n').find((x) => x.startsWith('Subject:')) || '';
    const m = l.match(/=\?UTF-8\?B\?(.*)\?=/);
    return m ? Buffer.from(m[1], 'base64').toString('utf8') : l.replace('Subject: ', '');
  };
  comprobar('8. El asunto viaja entero, con acentos y todo',
    asuntoDe(srv.recibidos[0].crudo) === 'Tu cuenta está lista',
    asuntoDe(srv.recibidos[0].crudo));
  comprobar('9. Y el cuerpo también',
    decodificar(srv.recibidos[0].crudo).includes('Bajá el programa'));
  comprobar('10. Se autenticó antes de mandar',
    srv.comandos.some((c) => /^AUTH/i.test(c)));
  comprobar('11. La contraseña no viaja en claro',
    !srv.comandos.some((c) => c.includes('secreta')));

  titulo('Acentos y formato');
  await correo.enviar({
    para: 'ana@estudio.com.ar',
    asunto: 'Respaldo de la Ferretería Ruiz — atención',
    texto: 'Se copiaron 47 archivos.',
    html: '<p>Se copiaron <b>47</b> archivos.</p>',
  });
  const conAcentos = srv.recibidos[1];
  comprobar('12. Un asunto con acentos no se rompe',
    /Subject: =\?UTF-8\?B\?/.test(conAcentos.crudo),
    conAcentos.crudo.split('\r\n').find((l) => l.startsWith('Subject')));
  comprobar('13. Manda versión con formato y versión de texto plano',
    /multipart\/alternative/.test(conAcentos.crudo) &&
    /text\/plain/.test(conAcentos.crudo) && /text\/html/.test(conAcentos.crudo));

  titulo('Cuando el servidor dice que no');
  const probado = await correo.probar('ana@estudio.com.ar');
  comprobar('14. El botón de probar informa que salió bien', probado.ok === true);
  await srv.cerrar();

  const malAuth = servidorFalso('rechazar-auth');
  const p2 = await malAuth.escuchar();
  const c2 = crear({ proveedor: 'personalizado', host: '127.0.0.1', puerto: p2,
    seguro: 'ninguno', usuario: 'u', clave: 'mala', de: 'avisos@backupprime.com' });
  const r2 = await c2.probar('ana@estudio.com.ar');
  comprobar('15. Con credenciales mal, avisa sin romperse', r2.ok === false, r2.detalle);
  comprobar('16. Y no filtra la contraseña en el mensaje de error',
    !String(r2.detalle).includes('mala'), r2.detalle);
  await malAuth.cerrar();

  const malDest = servidorFalso('rechazar-destinatario');
  const p3 = await malDest.escuchar();
  const c3 = crear({ proveedor: 'personalizado', host: '127.0.0.1', puerto: p3,
    seguro: 'ninguno', usuario: 'u', clave: 'c', de: 'avisos@backupprime.com' });
  const r3 = await c3.probar('no-existe@ninguna.com');
  comprobar('17. Si la casilla no existe, lo dice', r3.ok === false && /RCPT|casilla/i.test(r3.detalle));
  await malDest.cerrar();

  const corta = servidorFalso('cortar');
  const p4 = await corta.escuchar();
  const c4 = crear({ proveedor: 'personalizado', host: '127.0.0.1', puerto: p4,
    seguro: 'ninguno', usuario: 'u', clave: 'c', de: 'avisos@backupprime.com' });
  const r4 = await c4.probar('ana@estudio.com.ar');
  comprobar('18. Si corta la conexión, avisa y el proceso sigue vivo', r4.ok === false);
  await corta.cerrar();

  titulo('No se manda nada sin cifrar');
  const sinTls = servidorFalso('sin-starttls');
  const p5 = await sinTls.escuchar();
  const c5 = crear({ proveedor: 'personalizado', host: '127.0.0.1', puerto: p5,
    seguro: 'starttls', usuario: 'u', clave: 'c', de: 'avisos@backupprime.com' });
  const r5 = await c5.probar('ana@estudio.com.ar');
  comprobar('19. Si el servidor no ofrece cifrado, no se manda', r5.ok === false && /cifrado/i.test(r5.detalle));
  comprobar('20. Y las credenciales nunca se enviaron',
    !sinTls.comandos.some((c) => /^AUTH/i.test(c)));
  await sinTls.cerrar();

  titulo('La cola de avisos');
  const db = abrir(':memory:');
  encolarAviso(db, { para: 'uno@estudio.com', asunto: 'Bienvenida', cuerpo: 'Hola' });
  encolarAviso(db, { para: 'dos@estudio.com', asunto: 'Factura', cuerpo: 'Adjunta' });

  const srv2 = servidorFalso();
  const p6 = await srv2.escuchar();
  const c6 = crear({ proveedor: 'personalizado', host: '127.0.0.1', puerto: p6,
    seguro: 'ninguno', usuario: 'u', clave: 'c', de: 'avisos@backupprime.com' });

  const r6 = await despacharCola(db, c6);
  comprobar('21. Manda todo lo que estaba encolado', r6.enviados === 2 && r6.fallados === 0);
  comprobar('22. Y queda registrado que salieron',
    db.prepare("SELECT COUNT(*) c FROM avisos WHERE estado = 'enviado'").get().c === 2);

  const r7 = await despacharCola(db, c6);
  comprobar('23. No los vuelve a mandar en la corrida siguiente', r7.enviados === 0);
  await srv2.cerrar();

  encolarAviso(db, { para: 'tres@estudio.com', asunto: 'Aviso', cuerpo: 'Algo' });
  const caido = crear({ proveedor: 'personalizado', host: '127.0.0.1', puerto: 1,
    seguro: 'ninguno', usuario: 'u', clave: 'c', de: 'avisos@backupprime.com' });
  const r8 = await despacharCola(db, caido);
  comprobar('24. Si el servidor está caído, el aviso no se pierde',
    r8.fallados === 1 &&
    db.prepare("SELECT estado FROM avisos WHERE para = 'tres@estudio.com'").get().estado
      .startsWith('reintentar'));

  for (let i = 0; i < 6; i++) await despacharCola(db, caido);
  const final = db.prepare("SELECT estado FROM avisos WHERE para = 'tres@estudio.com'").get().estado;
  comprobar('25. Después de varios intentos se marca como fallado, con el motivo',
    final.startsWith('fallado:'), final.slice(0, 50));

  console.log('\n──────────────────────────────────────────────────────');
  console.log(`  ${pasadas} de ${pasadas + falladas} pruebas pasadas`);
  if (falladas) { console.log('\n  Fallaron:'); for (const f of fallos) console.log(`    · ${f}`); }
  console.log('──────────────────────────────────────────────────────\n');
  process.exit(falladas ? 1 : 0);
})();
