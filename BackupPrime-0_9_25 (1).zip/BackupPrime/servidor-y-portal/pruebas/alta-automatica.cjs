'use strict';
/* El alta deja de ser manual: un cliente se registra y el servidor le crea su
   bucket, lo verifica, y le dice al agente dónde respaldar. Sin que nadie toque
   la consola de e2 ni cargue claves en la máquina del cliente.

   Se prueba contra un e2 simulado, incluido uno que MIENTE sobre el versionado:
   contra ese, el alta tiene que fallar y la cuenta NO puede quedar marcada como
   aprovisionada. */
const { crearServidor } = require('./s3-simulado.cjs');
const { crearAplicacion } = require('../servidor/servidor.cjs');

let ok = 0, mal = 0; const fallos = [];
function comprobar(q, cond, extra) {
  if (cond) { ok++; console.log('  ok   ' + q); }
  else { mal++; fallos.push(q); console.log('  MAL  ' + q + (extra ? ' — ' + extra : '')); }
}
const titulo = (t) => console.log(`\n${t}`);

async function montar(personalidad) {
  const e2 = crearServidor(personalidad);
  await new Promise((r) => e2.listen(0, '127.0.0.1', r));
  const app = crearAplicacion({ archivoBase: ':memory:' });
  await new Promise((r) => app.servidor.listen(0, '127.0.0.1', r));

  const BASE = `http://127.0.0.1:${app.servidor.address().port}`;
  const galletas = {};
  async function pedir(metodo, ruta, cuerpo, quien, bearer) {
    const r = await fetch(BASE + ruta, {
      method: metodo,
      headers: Object.assign(
        cuerpo ? { 'Content-Type': 'application/json' } : {},
        galletas[quien] ? { Cookie: galletas[quien] } : {},
        bearer ? { Authorization: 'Bearer ' + bearer } : {}),
      body: cuerpo ? JSON.stringify(cuerpo) : undefined,
    });
    const sc = r.headers.getSetCookie ? r.headers.getSetCookie() : [];
    if (sc.length && quien) galletas[quien] = sc[0].split(';')[0];
    let j = {}; try { j = await r.json(); } catch (e) {}
    return { codigo: r.status, cuerpo: j };
  }

  // El bucket común tiene que existir: el panel no guarda una configuración de
  // almacenamiento que no funciona, y hace bien.
  await fetch(`http://127.0.0.1:${e2.address().port}/comun`, {
    method: 'PUT', headers: { Authorization: 'AWS4-HMAC-SHA256 prueba' },
  });

  await pedir('POST', '/api/sesion', { email: 'admin', clave: 'admin', modo: 'admin' }, 'admin');
  await pedir('PUT', '/api/admin/almacenamiento', {
    proveedor: 'idrive-e2', endpoint: `http://127.0.0.1:${e2.address().port}`,
    region: 'us-southeast-1', accessKey: 'AK', secretKey: 'SK', bucket: 'comun',
  }, 'admin');
  return { pedir, cerrar: () => { app.servidor.close(); e2.close(); } };
}

(async () => {
  titulo('Por defecto sigue siendo por carpeta, no se cambia solo');
  {
    const { pedir, cerrar } = await montar('completo');
    const e = await pedir('GET', '/api/admin/e2', null, 'admin');
    comprobar('Arranca en modo carpeta', e.cuerpo.modo === 'prefijo', e.cuerpo.modo);
    comprobar('Y avisa que la separación es lógica', e.cuerpo.tieneApiKey === false);
    cerrar();
  }

  titulo('Con bucket propio: el alta es automática');
  {
    const { pedir, cerrar } = await montar('completo');
    let r = await pedir('PUT', '/api/admin/e2',
      { modo: 'bucket', region: '', prefijoBucket: 'bp' }, 'admin');
    comprobar('Sin región no deja activarlo', r.codigo === 400, `dio ${r.codigo}`);

    r = await pedir('PUT', '/api/admin/e2', {
      modo: 'bucket', region: 'us-southeast-1', prefijoBucket: 'bp',
      retencionDias: 20, modoRetencion: 'GOVERNANCE', apiKey: 'CLAVE-DE-PRUEBA',
    }, 'admin');
    comprobar('Se activa con región', r.codigo === 200, JSON.stringify(r.cuerpo));

    r = await pedir('GET', '/api/admin/e2', null, 'admin');
    comprobar('La clave API NO vuelve al navegador', r.cuerpo.apiKey === undefined,
      JSON.stringify(r.cuerpo));
    comprobar('Pero informa que está cargada', r.cuerpo.tieneApiKey === true);

    // Un cliente se registra. Nadie toca la consola de e2.
    const EMAIL = 'nuevo@estudio.com.ar', CLAVE = 'UnaClaveLarga2026!';
    r = await pedir('POST', '/api/registro', {
      email: EMAIL, organizacion: 'Estudio Pérez & Asociados', clave: CLAVE,
      nombre: 'Ariel', planId: 'estudio' }, 'c');
    comprobar('El registro funciona', r.codigo === 201 || r.codigo === 200, `dio ${r.codigo}`);

    // El prefijo NO se expone en la cuenta pública del cliente: no es asunto
    // suyo dónde guardamos. Se comprueba por donde importa, que es lo que
    // recibe el agente.
    const ag = await pedir('POST', '/api/agent-auth/login', {
      email: EMAIL, password: CLAVE, deviceName: 'PC-NUEVA', agentVersion: '0.9.22' });
    comprobar('El agente entra', ag.codigo === 200, JSON.stringify(ag.cuerpo).slice(0, 120));
    const alm = ag.cuerpo.almacenamiento || {};
    comprobar('Y recibe DÓNDE respaldar', !!alm.prefijo, JSON.stringify(alm));
    comprobar('Con su bucket propio', /^bp-estudio-perez/.test(alm.bucket || ''), alm.bucket);
    comprobar('Y la región', alm.region === 'us-southeast-1', alm.region);
    comprobar('NUNCA recibe las claves del almacenamiento',
      !/secretKey|secret_key|accessKey|"SK"/.test(JSON.stringify(ag.cuerpo)),
      JSON.stringify(ag.cuerpo).slice(0, 200));

    // Dos clientes que se llaman IGUAL: el segundo Pérez no puede caer en el
    // bucket del primero.
    await pedir('POST', '/api/registro', {
      email: 'otro@estudio.com.ar', organizacion: 'Estudio Pérez & Asociados',
      clave: CLAVE, nombre: 'B', planId: 'estudio' }, 'd');
    const ag2 = await pedir('POST', '/api/agent-auth/login', {
      email: 'otro@estudio.com.ar', password: CLAVE, deviceName: 'PC-B', agentVersion: '0.9.22' });
    const b2 = (ag2.cuerpo.almacenamiento || {}).bucket;
    comprobar('El segundo también recibe bucket propio', /^bp-estudio-perez/.test(b2 || ''), b2);
    comprobar('Dos clientes con el MISMO nombre reciben buckets DISTINTOS',
      b2 && b2 !== alm.bucket, `${alm.bucket} vs ${b2}`);

    titulo('El botón de probar del panel');
    r = await pedir('POST', '/api/admin/e2/probar', {}, 'admin');
    comprobar('Prueba el alta completa y da verde', r.cuerpo.ok === true, JSON.stringify(r.cuerpo.pasos));
    comprobar('Usa un bucket descartable, no el de un cliente',
      /prueba/.test(r.cuerpo.bucket || ''), r.cuerpo.bucket);
    cerrar();
  }

  titulo('Proveedor que MIENTE sobre el versionado');
  {
    const { pedir, cerrar } = await montar('mentiroso');
    await pedir('PUT', '/api/admin/e2', {
      modo: 'bucket', region: 'us-southeast-1', prefijoBucket: 'bp', retencionDias: 0,
    }, 'admin');

    const EMAIL = 'roto@estudio.com.ar', CLAVE = 'UnaClaveLarga2026!';
    await pedir('POST', '/api/registro', {
      email: EMAIL, organizacion: 'Sin Versionado SA', clave: CLAVE,
      nombre: 'C', planId: 'estudio' }, 'e');
    await pedir('POST', '/api/sesion', { email: EMAIL, clave: CLAVE }, 'e');

    const cuenta = await pedir('GET', '/api/cuenta', null, 'e');
    comprobar('La cuenta NO queda marcada como aprovisionada',
      !cuenta.cuerpo.prefijo, String(cuenta.cuerpo.prefijo));

    const ag = await pedir('POST', '/api/agent-auth/login', {
      email: EMAIL, password: CLAVE, deviceName: 'PC-X', agentVersion: '0.9.22' });
    comprobar('El agente NO puede respaldar contra un espacio sin historial',
      ag.codigo === 503, `dio ${ag.codigo}`);
    comprobar('Y el mensaje no culpa al cliente',
      /preparar tu espacio/i.test(ag.cuerpo.error || ''), ag.cuerpo.error);

    const r = await pedir('POST', '/api/admin/e2/probar', {}, 'admin');
    comprobar('El botón de probar lo detecta antes de tener clientes adentro',
      r.cuerpo.ok === false, JSON.stringify(r.cuerpo.pasos));

    const aud = await pedir('GET', '/api/admin/auditoria', null, 'admin');
    comprobar('Y queda registrado el alta fallida',
      /FALLÓ el alta de espacio/.test(JSON.stringify(aud.cuerpo)),
      JSON.stringify(aud.cuerpo).slice(0, 200));
    cerrar();
  }

  console.log('\n──────────────────────────────');
  console.log(`  ${ok} de ${ok + mal} pasadas`);
  if (mal) { console.log('  Fallaron:'); fallos.forEach((f) => console.log('    · ' + f)); }
  process.exit(mal ? 1 : 0);
})().catch((e) => { console.error('error inesperado:', e); process.exit(1); });
