'use strict';
/* Verifica que cada elemento que el JavaScript busca por id exista realmente en
   el HTML, y que los archivos que las páginas incluyen estén en su lugar.
   Es el mismo tipo de error que en el programa de escritorio dejó la
   restauración por FTP sin funcionar: cada lado bien, el nombre distinto.

     node pruebas/interfaz.cjs                                             */

const fs = require('node:fs');
const path = require('node:path');

const RAIZ = path.join(__dirname, '..');
let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};

const paginas = ['index.html', 'registro.html', 'ingreso.html', 'descargas.html',
                 'pago-simulado.html', 'terminos.html', 'privacidad.html',
                 'admin.html', 'portal.html'];
const guiones = {
  'index.html': ['js/planes.js', 'js/landing.js', 'js/puertas.js', 'js/tiempo.js'],
  'registro.html': ['js/planes.js', 'js/registro.js'],
  'admin.html': ['js/admin.js'],
  'portal.html': ['js/portal.js'],
  'ingreso.html': ['js/ingreso.js'],
  'descargas.html': ['js/descargas.js'],
  'pago-simulado.html': ['js/pago-simulado.js'],
  // Páginas legales: solo texto, sin comportamiento.
  'terminos.html': [],
  'privacidad.html': [],
};

console.log('BackupPrime — coherencia entre las páginas y su código\n');

for (const pagina of paginas) {
  const html = fs.readFileSync(path.join(RAIZ, pagina), 'utf8');
  const ids = new Set([...html.matchAll(/\bid="([^"]+)"/g)].map((m) => m[1]));

  // Los archivos que la página incluye tienen que existir
  for (const src of [...html.matchAll(/<script src="([^"]+)"/g)].map((m) => m[1])) {
    comprobar(`${pagina}: incluye ${src} y el archivo existe`, fs.existsSync(path.join(RAIZ, src)));
  }
  for (const href of [...html.matchAll(/<link[^>]+href="([^"]+\.css)"/g)].map((m) => m[1])) {
    comprobar(`${pagina}: la hoja de estilo ${href} existe`, fs.existsSync(path.join(RAIZ, href)));
  }

  // Cada getElementById del código de esa página tiene que encontrar algo
  const buscados = new Set();
  // Algunos elementos los dibuja el propio código: sus ids no están en el HTML
  // pero existen igual cuando corre. Se recogen de las plantillas del JS.
  const creados = new Set();
  for (const archivo of guiones[pagina]) {
    const js = fs.readFileSync(path.join(RAIZ, archivo), 'utf8');
    for (const m of js.matchAll(/getElementById\(\s*['"]([^'"]+)['"]\s*\)/g)) buscados.add(m[1]);
    for (const m of js.matchAll(/\$\(\s*['"]([^'"]+)['"]\s*\)/g)) buscados.add(m[1]);
    for (const m of js.matchAll(/\bid="([^"'`$]+)"/g)) creados.add(m[1]);
  }
  const faltantes = [...buscados].filter((id) => !ids.has(id) && !creados.has(id));
  comprobar(`${pagina}: todos los elementos que busca el código existen`,
    faltantes.length === 0, faltantes.join(', '));

  // Ids repetidos: el navegador se queda con el primero y el resto queda muerto
  const todos = [...html.matchAll(/\bid="([^"]+)"/g)].map((m) => m[1]);
  const repetidos = todos.filter((v, i) => todos.indexOf(v) !== i);
  comprobar(`${pagina}: no hay ids repetidos`, repetidos.length === 0, repetidos.join(', '));

  // Cada campo de formulario con label tiene que estar asociado
  const labels = [...html.matchAll(/<label[^>]*for="([^"]+)"/g)].map((m) => m[1]);
  const sinCampo = labels.filter((f) => !ids.has(f));
  comprobar(`${pagina}: cada etiqueta apunta a un campo real`, sinCampo.length === 0, sinCampo.join(', '));


  comprobar(`${pagina}: tiene favicon`, /rel="icon"/.test(html));
  comprobar(`${pagina}: y el archivo existe`,
    fs.existsSync(path.join(RAIZ, 'favicon', 'favicon.ico')));
  comprobar(`${pagina}: declara el idioma`, /<html lang="es/.test(html));
  comprobar(`${pagina}: es usable en el celular`, /viewport/.test(html));
}


// ── Coherencia de la marca ────────────────────────────────────────────────
// El logo tiene que ser el mismo en todas las páginas. Antes había un cuadrado
// con una "B" inventada en unas y el logo de verdad en otras.
const marcas = new Map();
for (const pagina of paginas) {
  const html = fs.readFileSync(path.join(RAIZ, pagina), 'utf8');
  const svgs = [...html.matchAll(/<svg[^>]*viewBox="0 0 256 256"[\s\S]*?<\/svg>/g)].map((m) => m[0]);
  if (!svgs.length) continue;

  comprobar(`${pagina}: usa el logo de las tres barras`,
    svgs.every((v) => (v.match(/<rect/g) || []).length >= 3));
  comprobar(`${pagina}: con las tres opacidades del original`,
    svgs.every((v) => v.includes('opacity=".43"') && v.includes('opacity=".71"')));
  comprobar(`${pagina}: sin la "B" inventada`, !/logo-marca|>B</.test(html));

  // El texto de la marca va en un solo elemento: si no, el gap del flex le abre
  // un hueco entre "Backup" y "Prime".
  if (/class="logo/.test(html)) {
    comprobar(`${pagina}: el nombre va en un solo elemento`,
      /<span class="logo-texto">Backup<em>Prime<\/em>/.test(html));
  }

  for (const v of svgs) {
    const clave = v.replace(/width="\d+" height="\d+"/, '').replace(/\s+/g, ' ');
    marcas.set(clave, (marcas.get(clave) || []).concat(pagina));
  }
}
comprobar('El logo es idéntico en todas las páginas (salvo la variante para fondo oscuro)',
  marcas.size <= 2, [...marcas.keys()].length + ' variantes: ' +
  [...marcas.values()].map((v) => v.join('+')).join(' | '));


// ── Enlaces que no van a ningún lado ──────────────────────────────────────
// Un enlace roto en la portada es lo primero que ve alguien evaluando el
// servicio, y ya nos pasó tener varios apuntando a páginas inexistentes.
for (const pagina of paginas) {
  const html = fs.readFileSync(path.join(RAIZ, pagina), 'utf8');
  const roto = [];
  for (const m of html.matchAll(/href="([^"]+)"/g)) {
    const destino = m[1];
    if (/^(#|mailto:|tel:|https?:)/.test(destino)) continue;
    const limpio = destino.split('#')[0].split('?')[0].replace(/^\//, '');
    if (!limpio) continue;
    if (!fs.existsSync(path.join(RAIZ, limpio))) roto.push(destino);
  }
  comprobar(`${pagina}: no tiene enlaces a páginas que no existen`,
    roto.length === 0, roto.join(', '));
}

// ── Afirmaciones que no podemos sostener ──────────────────────────────────
// No es una prueba de estilo: son cosas que si un cliente las pone a prueba
// nos dejan mal parados.
const FRASES_PROHIBIDAS = [
  ['100% seguro', 'no existe nada 100% seguro'],
  ['garantizamos que nunca', 'no se puede garantizar'],
  ['imposible de hackear', 'nada es imposible de hackear'],
  ['un cliente no puede ver el de otro', 'es una obviedad que suena a amateur'],
  ['militar', 'el "cifrado de grado militar" es marketing vacío'],
  ['en una noche', 'el tiempo depende de la conexión de cada uno'],

  // Estas estuvieron publicadas y NO eran ciertas. Cada una prometía algo que
  // el producto no hacía, en un sitio que vende seguridad a estudios contables.
  ['bloqueo de objetos', 'NUNCA se probó contra iDrive e2: no se promete hasta correr el diagnóstico'],
  ['factura electrónica', 'no hay integración con AFIP: no se emiten comprobantes fiscales'],
  ['hasta 30 versiones', 'la retención pasó a ventanas de tiempo, y hoy nada poda'],
  ['aviso por mail si un equipo deja de respaldar', 'ese aviso no existe: se ve en pantalla'],
  ['microsoft 365', 'no se respalda Microsoft 365'],
  ['extremo a extremo', 'el modo gestionado no lo es, y decirlo sería mentir'],
];
// El panel de administración queda afuera: ahí "bloqueo de objetos" es el nombre
// de una opción de configuración, no una promesa al cliente. Lo que se controla
// son las páginas PÚBLICAS, que es donde una promesa se vuelve un compromiso.
const PUBLICAS = paginas.filter((p) => p !== 'admin.html');
for (const pagina of PUBLICAS) {
  const html = fs.readFileSync(path.join(RAIZ, pagina), 'utf8').toLowerCase();
  for (const [frase, motivo] of FRASES_PROHIBIDAS) {
    comprobar(`${pagina}: no dice "${frase}"`, !html.includes(frase), motivo);
  }
}

// El sitio no puede quedar sin precios si el backend no responde
const planesJs = fs.readFileSync(path.join(RAIZ, 'js/planes.js'), 'utf8');
comprobar('Hay planes de respaldo por si el backend no contesta', /RESPALDO\s*=/.test(planesJs));
comprobar('Los precios se piden al backend', /fetch\(API \+ '\/planes'/.test(planesJs));

// La contraseña no puede terminar en la URL ni en el almacenamiento del navegador
const registroJs = fs.readFileSync(path.join(RAIZ, 'js/registro.js'), 'utf8');
comprobar('La contraseña no se guarda en el navegador',
  !/localStorage|sessionStorage/.test(registroJs));
comprobar('El alta viaja por POST, no por la URL',
  !/registro\?.*clave=/.test(registroJs));

console.log('\n──────────────────────────────────────────────────────');
console.log(`  ${pasadas} de ${pasadas + falladas} pruebas pasadas`);
if (falladas) { console.log('\n  Fallaron:'); for (const f of fallos) console.log(`    · ${f}`); }
console.log('──────────────────────────────────────────────────────\n');
process.exit(falladas ? 1 : 0);
