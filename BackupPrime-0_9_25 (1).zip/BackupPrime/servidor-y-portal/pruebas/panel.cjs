'use strict';
/* Carga admin.html en un navegador simulado contra el servidor real y comprueba
   que el panel de clientes salga de la API y que las puertas de rescate
   funcionen desde la pantalla, no solo desde la API. */
const { JSDOM, VirtualConsole } = require('jsdom');
const { crearAplicacion } = require('../servidor/servidor.cjs');

let ok = 0, mal = 0; const fallos = [];
function comprobar(q, cond, extra) {
  if (cond) { ok++; console.log('  ok   ' + q); }
  else { mal++; fallos.push(q); console.log('  MAL  ' + q + (extra ? ' — ' + extra : '')); }
}
const esperar = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const app = crearAplicacion({ archivoBase: ':memory:' });
  await new Promise((r) => app.servidor.listen(0, '127.0.0.1', r));
  const BASE = `http://127.0.0.1:${app.servidor.address().port}`;

  const galletas = {};
  async function pedir(metodo, ruta, cuerpo, quien = 'x') {
    const r = await fetch(BASE + ruta, {
      method: metodo,
      headers: Object.assign(cuerpo ? { 'Content-Type': 'application/json' } : {},
        galletas[quien] ? { Cookie: galletas[quien] } : {}),
      body: cuerpo ? JSON.stringify(cuerpo) : undefined,
    });
    const sc = r.headers.getSetCookie ? r.headers.getSetCookie() : [];
    if (sc.length) galletas[quien] = sc[0].split(';')[0];
    let j = {}; try { j = await r.json(); } catch (e) {}
    return { codigo: r.status, cuerpo: j };
  }

  // Un cliente real, con un equipo real.
  const EMAIL = 'ficha@ejemplo.com', CLAVE = 'UnaClaveLarga2026!';
  await pedir('POST', '/api/registro', { email: EMAIL, organizacion: 'Estudio De La Ficha',
    clave: CLAVE, nombre: 'A', planId: 'estudio' }, 'c');
  const ag = await pedir('POST', '/api/agent-auth/login',
    { email: EMAIL, password: CLAVE, deviceName: 'PC-FICHA', agentVersion: '0.9.21' });
  await fetch(BASE + '/api/agent/uso', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + ag.cuerpo.agentToken },
    body: JSON.stringify({ deviceName: 'PC-FICHA', bytes: 300 * 1024 ** 3, archivos: 9000 }),
  });
  await pedir('POST', '/api/sesion', { email: 'admin', clave: 'admin', modo: 'admin' }, 'admin');
  const cookie = galletas.admin;

  const vc = new VirtualConsole();
  const errores = [];
  vc.on('jsdomError', (e) => errores.push(e.message));

  const dom = await JSDOM.fromURL(BASE + '/admin.html', {
    runScripts: 'dangerously', resources: 'usable', virtualConsole: vc,
    beforeParse(w) {
      w.fetch = (u, o) => {
        o = Object.assign({}, o);
        o.headers = Object.assign({}, o.headers, { Cookie: cookie });
        return globalThis.fetch(new URL(String(u), BASE).href, o);
      };
      w.confirm = () => true;   // el panel pregunta antes de rescatar
    },
  });
  await esperar(1200);
  const doc = dom.window.document;
  const $ = (id) => doc.getElementById(id);

  console.log('\n── El panel arranca ──');
  const deJs = errores.filter((e) => !/fonts\.googleapis|Could not load link|stylesheet/.test(e));
  comprobar('Sin errores de JavaScript', deJs.length === 0, deJs.join(' | '));

  console.log('\n── Clientes: de la API, no de la maqueta ──');
  comprobar('Lista al cliente real', /Estudio De La Ficha/.test($('tablaClientes').textContent),
    $('tablaClientes').textContent.slice(0, 120));
  const enClientes = $('panel-clientes').textContent;
  for (const fantasma of ['Estudio Molina', 'Contadores Ruiz', 'Textil Norte', 'Estudio Paz']) {
    comprobar('Ya no aparece "' + fantasma + '" en Clientes', !enClientes.includes(fantasma));
  }

  console.log('\n── Buscador ──');
  $('buscarCliente').value = 'nadie-asi';
  $('buscarCliente').dispatchEvent(new dom.window.Event('input', { bubbles: true }));
  await esperar(80);
  comprobar('Filtra y avisa cuando no hay coincidencias',
    /Ningún cliente coincide/.test($('tablaClientes').textContent),
    $('tablaClientes').textContent.slice(0, 100));
  $('buscarCliente').value = '';
  $('buscarCliente').dispatchEvent(new dom.window.Event('input', { bubbles: true }));
  await esperar(80);

  console.log('\n── Ficha del cliente ──');
  doc.querySelector('[data-ficha]').click();
  await esperar(600);
  comprobar('Se abre la ficha', !$('fichaCliente').classList.contains('oculto'));
  comprobar('Muestra su email', /ficha@ejemplo.com/.test($('fichaDatos').textContent));
  comprobar('Muestra su equipo real', /PC-FICHA/.test($('fichaEquipos').textContent),
    $('fichaEquipos').textContent.slice(0, 120));
  comprobar('Muestra el consumo informado', /300 GB/.test($('fichaDatos').textContent),
    $('fichaDatos').textContent.slice(0, 160));

  console.log('\n── Puerta 1: restablecer la contraseña ──');
  $('claveAdminRescate').value = 'equivocada';
  $('rescateClave').click();
  await esperar(500);
  comprobar('Con la clave de admin mal, no rescata y lo dice',
    /no coincide/i.test($('rescateMensaje').textContent), $('rescateMensaje').textContent);

  $('claveAdminRescate').value = 'admin';
  $('rescateClave').click();
  await esperar(600);
  const m = $('rescateMensaje').textContent.match(/provisoria:\s*(\S+)/i);
  comprobar('Muestra la contraseña provisoria', !!m, $('rescateMensaje').textContent.slice(0, 140));

  if (m) {
    const r = await pedir('POST', '/api/sesion', { email: EMAIL, clave: m[1] }, 'nuevo');
    comprobar('Y el cliente entra de verdad con esa contraseña', r.codigo === 200, `dio ${r.codigo}`);
  }

  console.log('\n── Puerta 3: destrabar ──');
  $('rescateDestrabar').click();
  await esperar(500);
  comprobar('Destraba y avisa', /volver a intentar|Listo/i.test($('rescateMensaje').textContent),
    $('rescateMensaje').textContent.slice(0, 120));

  console.log('\n── Cobros ──');
  comprobar('Avisa que falta el secreto del webhook',
    /Falta el secreto/.test($('mpEstado').textContent), $('mpEstado').textContent.slice(0, 120));
  $('mpWebhook').value = 'secreto-desde-el-panel';
  $('guardarMp').click();
  await esperar(700);
  comprobar('Después de cargarlo, deja de avisar',
    /está cargado/.test($('mpEstado').textContent), $('mpEstado').textContent.slice(0, 120));

  const pago = await pedir('GET', '/api/admin/mercadopago', null, 'admin');
  comprobar('Y el secreto quedó guardado en el servidor', pago.cuerpo.tieneWebhookSecret === true,
    JSON.stringify(pago.cuerpo));

  console.log('\n── Alta automática: la pantalla existe y está enchufada ──');
  // El JS de este panel ya existía, pero el HTML no: los campos no estaban en
  // ninguna parte, así que la configuración no se podía cargar y el alta seguía
  // siendo a mano aunque el motor estuviera hecho.
  for (const id of ['e2Modo', 'e2Region', 'e2Prefijo', 'e2Dias', 'e2ModoRet', 'e2ApiKey']) {
    comprobar('Está el campo ' + id, !!$(id));
  }
  comprobar('Están los botones de guardar y probar', !!$('guardarE2') && !!$('probarE2'));
  comprobar('Avisa que el bloqueo de objetos no se puede agregar después',
    /solo se puede pedir al crear el bucket/.test($('panel-integraciones').textContent));
  const e2Texto = $('panel-integraciones').textContent;
  comprobar('Distingue las DOS retenciones: la de objetos y la de versiones',
    /DOS retenciones distintas/.test(e2Texto) && /versiones/.test(e2Texto));
  comprobar('Avisa que la retención cuesta plata en espacio',
    /se le sigue pagando/.test(e2Texto));
  // Que nadie pode las versiones es hoy el riesgo más grande de espacio, y no
  // se puede tapar mientras no exista la poda con recolección de bloques.
  comprobar('Avisa que todavía nadie poda las versiones viejas',
    /NADIE poda/.test(e2Texto));
  comprobar('Aclara que la clave API no hace falta con bucket propio',
    /no hace falta con bucket propio/.test(e2Texto));
  comprobar('Aclara que cambiar el prefijo no renombra los buckets ya creados',
    /no renombra los ya creados/.test(e2Texto));

  $('e2Region').value = 'us-southeast-1';
  $('e2Prefijo').value = 'bp';
  $('e2Dias').value = '30';
  $('e2Modo').value = 'bucket';
  $('e2ApiKey').value = 'clave-de-prueba';
  $('guardarE2').click();
  await esperar(700);
  const guardado = await pedir('GET', '/api/admin/e2', null, 'admin');
  comprobar('Guardar desde la pantalla llega al servidor',
    guardado.cuerpo.modo === 'bucket' && guardado.cuerpo.region === 'us-southeast-1',
    JSON.stringify(guardado.cuerpo));
  comprobar('Y la clave API queda cargada', guardado.cuerpo.tieneApiKey === true,
    JSON.stringify(guardado.cuerpo));
  comprobar('Pero el campo se vacía en pantalla: no queda a la vista',
    $('e2ApiKey').value === '', $('e2ApiKey').value);

  console.log('\n── Integraciones: sin estados inventados ──');
  const tablaInteg = $('panel-integraciones').querySelector('table').textContent;
  comprobar('Ninguna fila dice "Responde" inventado', !/Responde/.test(tablaInteg), tablaInteg.slice(0, 140));
  comprobar('Dice que la facturación electrónica no está implementada',
    /No implementada/.test(tablaInteg), tablaInteg.slice(0, 140));

  console.log('\n──────────────────────────────');
  console.log(`  ${ok} de ${ok + mal} pasadas`);
  if (mal) { console.log('  Fallaron:'); fallos.forEach((f) => console.log('    · ' + f)); }
  app.servidor.close();
  process.exit(mal ? 1 : 0);
})().catch((e) => { console.error('error inesperado:', e); process.exit(1); });
