'use strict';
/* La versión publicada sale de la carpeta `descargas`, no de una constante.

   Antes había un 0.7.1 escrito a mano en el servidor y otro en descargas.html.
   Se desincronizaron: el sitio anunciaba una versión de hace catorce versiones,
   con el archivo ni siquiera subido, y el botón llevaba a un 404. */
const fs = require('node:fs');
const path = require('node:path');
const { crearAplicacion } = require('../servidor/servidor.cjs');

let ok = 0, mal = 0; const fallos = [];
function comprobar(q, cond, extra) {
  if (cond) { ok++; console.log('  ok   ' + q); }
  else { mal++; fallos.push(q); console.log('  MAL  ' + q + (extra ? ' — ' + extra : '')); }
}
const titulo = (t) => console.log(`\n${t}`);

const CARPETA = path.join(__dirname, '..', 'descargas');
const creados = [];
function publicar(nombre, contenido) {
  const ruta = path.join(CARPETA, nombre);
  fs.writeFileSync(ruta, contenido);
  creados.push(ruta);
  return ruta;
}
function limpiar() {
  for (const r of creados) { try { fs.unlinkSync(r); } catch (e) {} }
  creados.length = 0;
}

(async () => {
  const app = crearAplicacion({ archivoBase: ':memory:' });
  await new Promise((r) => app.servidor.listen(0, '127.0.0.1', r));
  const BASE = `http://127.0.0.1:${app.servidor.address().port}`;
  const pedir = async () => (await fetch(BASE + '/api/descargas/windows')).json();

  try {
    titulo('Sin instalador publicado');
    limpiar();
    let d = await pedir();
    comprobar('Dice que no está disponible', d.disponible === false, JSON.stringify(d));
    comprobar('NO inventa un número de versión', d.version === null, String(d.version));
    comprobar('NO entrega una url que lleva a un 404', !d.url, String(d.url));
    comprobar('Explica qué hacer', /carpeta/.test(d.mensaje || ''), d.mensaje);

    titulo('Con un instalador');
    publicar('BackupPrime-Setup-0.9.22.exe', Buffer.alloc(2 * 1024 * 1024, 7));
    d = await pedir();
    comprobar('Publica la versión del archivo', d.version === '0.9.22', d.version);
    comprobar('La url apunta al archivo real',
      d.url === '/descargas/BackupPrime-Setup-0.9.22.exe', d.url);
    comprobar('Calcula la huella del archivo', /^[0-9a-f]{64}$/.test(d.sha256 || ''), d.sha256);
    comprobar('Informa el peso', d.megas === 2, String(d.megas));

    titulo('El archivo se puede bajar de verdad');
    const r = await fetch(BASE + d.url);
    comprobar('La descarga responde 200', r.status === 200, `dio ${r.status}`);
    const bytes = Buffer.from(await r.arrayBuffer());
    comprobar('Y el tamaño coincide con lo anunciado', bytes.length === d.bytes,
      `${bytes.length} vs ${d.bytes}`);
    const huella = require('node:crypto').createHash('sha256').update(bytes).digest('hex');
    comprobar('Y la huella anunciada es la del archivo que llega', huella === d.sha256);

    titulo('Con varias versiones: publica la más nueva');
    publicar('BackupPrime-Setup-0.9.9.exe', Buffer.alloc(1024, 1));
    d = await pedir();
    // Ordenadas como texto, "0.9.9" sale después de "0.9.22" y publicaría la
    // vieja. Por eso se comparan por número.
    comprobar('0.9.22 gana sobre 0.9.9, aunque como texto sea al revés',
      d.version === '0.9.22', d.version);
    comprobar('Y avisa que hay otras en la carpeta',
      (d.otras || []).indexOf('0.9.9') >= 0, JSON.stringify(d.otras));

    publicar('BackupPrime-Setup-0.10.0.exe', Buffer.alloc(1024, 2));
    d = await pedir();
    comprobar('0.10.0 gana sobre 0.9.22', d.version === '0.10.0', d.version);

    titulo('Archivos que no corresponden');
    publicar('notas.txt', 'nada');
    publicar('BackupPrime-Setup-vieja.exe', 'nada');
    d = await pedir();
    comprobar('Ignora lo que no sea un instalador con versión',
      d.version === '0.10.0', d.version);

    titulo('Al reemplazar el archivo, la huella se recalcula');
    const ruta = path.join(CARPETA, 'BackupPrime-Setup-0.10.0.exe');
    const antes = (await pedir()).sha256;
    fs.writeFileSync(ruta, Buffer.alloc(4096, 9));
    fs.utimesSync(ruta, new Date(), new Date(Date.now() + 1000));
    const despues = (await pedir()).sha256;
    comprobar('Una huella vieja en caché sería peor que ninguna', antes !== despues,
      `${antes} vs ${despues}`);

    titulo('Ya no queda el 0.7.1 escrito a mano');
    const servidor = fs.readFileSync(path.join(__dirname, '..', 'servidor', 'servidor.cjs'), 'utf8');
    const pagina = fs.readFileSync(path.join(__dirname, '..', 'descargas.html'), 'utf8');
    // Se miran las líneas de CÓDIGO: el comentario que explica el bug sí menciona
  // el 0.7.1, y prohibirlo obligaría a borrar la explicación de por qué existe
  // esta prueba.
  const codigo = servidor.split('\n')
    .filter((l) => !/^\s*(\*|\/\/|\/\*)/.test(l)).join('\n');
  comprobar('Ni en el servidor (fuera de los comentarios)', !/0\.7\.1/.test(codigo),
    (codigo.split('\n').find((l) => /0\.7\.1/.test(l)) || '').trim());
    comprobar('Ni en la página de descargas', !/0\.7\.1/.test(pagina));
  } finally {
    limpiar();
    app.servidor.close();
  }

  console.log('\n──────────────────────────────');
  console.log(`  ${ok} de ${ok + mal} pasadas`);
  if (mal) { console.log('  Fallaron:'); fallos.forEach((f) => console.log('    · ' + f)); }
  process.exit(mal ? 1 : 0);
})().catch((e) => { limpiar(); console.error('error inesperado:', e); process.exit(1); });
