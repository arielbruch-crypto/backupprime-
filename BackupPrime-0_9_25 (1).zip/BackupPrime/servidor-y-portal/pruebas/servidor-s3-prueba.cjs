'use strict';
// Servidor compatible con S3, mínimo, para probar el cliente de BackupPrime:
// PUT de objeto, GET de objeto y ListObjectsV2 con paginación.
// No valida la firma (eso lo prueba el servidor real); valida que la petición
// esté bien armada y que los datos vayan y vuelvan enteros.

const http = require('node:http');

function crearServidorS3({ host = '127.0.0.1' } = {}) {
  const objetos = new Map();   // "bucket/clave" -> Buffer
  const stats = { puts: 0, gets: 0, lists: 0, firmados: 0 };

  const xmlEscape = (t) => String(t)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');

  const servidor = http.createServer((req, res) => {
    const url = new URL(req.url, `http://${req.headers.host}`);
    const partes = url.pathname.replace(/^\//, '').split('/');
    const bucket = partes.shift();
    const clave = decodeURIComponent(partes.join('/'));

    if (req.headers.authorization && req.headers.authorization.startsWith('AWS4-HMAC-SHA256')) {
      stats.firmados++;
    }

    // ── ListObjectsV2 ──
    if (req.method === 'GET' && !clave && url.searchParams.get('list-type') === '2') {
      stats.lists++;
      const prefijo = url.searchParams.get('prefix') || '';
      const maxKeys = Number(url.searchParams.get('max-keys')) || 1000;
      const desde = url.searchParams.get('continuation-token') || '';

      const todas = [...objetos.keys()]
        .filter((k) => k.startsWith(bucket + '/'))
        .map((k) => k.slice(bucket.length + 1))
        .filter((k) => k.startsWith(prefijo))
        .sort();
      const arranque = desde ? todas.findIndex((k) => k > desde) : 0;
      const pagina = arranque < 0 ? [] : todas.slice(arranque, arranque + maxKeys);
      const truncado = arranque >= 0 && arranque + maxKeys < todas.length;

      const cuerpo =
        `<?xml version="1.0" encoding="UTF-8"?>` +
        `<ListBucketResult><Name>${bucket}</Name>` +
        `<IsTruncated>${truncado}</IsTruncated>` +
        (truncado ? `<NextContinuationToken>${xmlEscape(pagina[pagina.length - 1])}</NextContinuationToken>` : '') +
        pagina.map((k) =>
          `<Contents><Key>${xmlEscape(k)}</Key>` +
          `<Size>${objetos.get(bucket + '/' + k).length}</Size></Contents>`).join('') +
        `</ListBucketResult>`;
      res.writeHead(200, { 'Content-Type': 'application/xml' });
      return res.end(cuerpo);
    }

    // ── PUT de objeto ──
    if (req.method === 'PUT' && clave) {
      stats.puts++;
      const trozos = [];
      req.on('data', (c) => trozos.push(c));
      req.on('end', () => {
        objetos.set(`${bucket}/${clave}`, Buffer.concat(trozos));
        res.writeHead(200); res.end();
      });
      return;
    }

    // ── HEAD de objeto ──
    if (req.method === 'HEAD' && clave) {
      const dato = objetos.get(`${bucket}/${clave}`);
      if (!dato) { res.writeHead(404); return res.end(); }
      res.writeHead(200, { 'Content-Length': dato.length });
      return res.end();
    }

    // ── GET de objeto ──
    if (req.method === 'GET' && clave) {
      stats.gets++;
      const dato = objetos.get(`${bucket}/${clave}`);
      if (!dato) { res.writeHead(404); return res.end('<Error><Code>NoSuchKey</Code></Error>'); }
      res.writeHead(200, { 'Content-Length': dato.length });
      return res.end(dato);
    }

    if (req.method === 'DELETE' && clave) {
      objetos.delete(`${bucket}/${clave}`);
      res.writeHead(204); return res.end();
    }

    res.writeHead(400); res.end('<Error><Code>BadRequest</Code></Error>');
  });

  return {
    objetos, stats,
    escuchar: () => new Promise((r) => servidor.listen(0, host, () => r(servidor.address().port))),
    cerrar: () => new Promise((r) => servidor.close(r)),
  };
}

module.exports = { crearServidorS3 };
