'use strict';
/* Recolector de bloques.

   Lo que se prueba no es que borre: es que NO borre cuando no corresponde.
   `bloques-referenciados.cjs` ya demostró el daño; acá se comprueba que las
   barandas lo evitan. */
const crypto = require('node:crypto');
const fsp = require('node:fs/promises');
const path = require('node:path');

const { inventariar, recolectar } = require('../servidor/recolector.cjs');

let ok = 0, mal = 0; const fallos = [];
function comprobar(q, cond, extra) {
  if (cond) { ok++; console.log('  ok   ' + q); }
  else { mal++; fallos.push(q); console.log('  MAL  ' + q + (extra ? ' — ' + extra : '')); }
}
const titulo = (t) => console.log(`\n${t}`);

const AHORA = new Date('2026-08-22T12:00:00Z').getTime();
const HORA = 3600000;
const hace = (h) => new Date(AHORA - h * HORA).toISOString();

function almacenFalso(objetos, { fallaLeer = [], fallaBorrar = [] } = {}) {
  return {
    borrados: [],
    async leer(clave, destino) {
      if (fallaLeer.includes(clave)) throw new Error('ilegible a propósito');
      if (!objetos.has(clave)) { const e = new Error('NoSuchKey'); e.status = 404; throw e; }
      await fsp.mkdir(path.dirname(destino), { recursive: true });
      await fsp.writeFile(destino, objetos.get(clave).datos);
      return { bytes: objetos.get(clave).datos.length };
    },
    async listar(prefijo) {
      return { archivos: [...objetos.entries()]
        .filter(([k]) => k.startsWith(prefijo || ''))
        .map(([k, v]) => ({ clave: k, size: v.datos.length, modificado: v.modificado })) };
    },
    async borrar(clave) {
      if (fallaBorrar.includes(clave)) throw new Error('no se pudo borrar');
      objetos.delete(clave);
      this.borrados.push(clave);
    },
  };
}

/* Escenario: dos archivos que comparten un bloque, más bloques que sobran. */
function escenario({ sobrantes = 2, edadSobrantesH = 72 } = {}) {
  const objetos = new Map();
  const poner = (clave, datos, horas = 500) =>
    objetos.set(clave, { datos: Buffer.from(datos), modificado: hace(horas) });

  const compartido = 'a'.repeat(64);
  const propioUno = 'b'.repeat(64);
  const propioDos = 'c'.repeat(64);

  for (const h of [compartido, propioUno, propioDos]) {
    poner(`bloques/${h.slice(0, 2)}/${h}`, 'contenido-' + h.slice(0, 4), 500);
  }
  const indice = (archivo, hs) => Buffer.from(JSON.stringify({
    formato: 1, archivo, bytes: 100, huella: 'x',
    bloques: hs.map((h) => ({ h, n: 50 })),
  }));
  poner('indices/C/uno.txt.bpi', indice('C/uno.txt', [compartido, propioUno]));
  poner('indices-copia/C/uno.txt.bpi', indice('C/uno.txt', [compartido, propioUno]));
  poner('indices/C/dos.txt.bpi', indice('C/dos.txt', [compartido, propioDos]));
  poner('indices-copia/C/dos.txt.bpi', indice('C/dos.txt', [compartido, propioDos]));

  const huellasSobrantes = [];
  for (let i = 0; i < sobrantes; i++) {
    const h = crypto.createHash('sha256').update('sobra' + i).digest('hex');
    poner(`bloques/${h.slice(0, 2)}/${h}`, 'basura-' + i, edadSobrantesH);
    huellasSobrantes.push(h);
  }
  return { objetos, compartido, propioUno, huellasSobrantes };
}

(async () => {
  titulo('Inventario: dice qué sobra sin tocar nada');
  let { objetos, huellasSobrantes } = escenario();
  let alm = almacenFalso(objetos);
  let inv = await inventariar({ almacen: alm, opciones: { ahora: AHORA } });
  comprobar('Cuenta los índices vivos', inv.indices === 2, String(inv.indices));
  comprobar('Y los bloques realmente en uso', inv.bloquesEnUso === 3, String(inv.bloquesEnUso));
  comprobar('Detecta los que sobran', inv.bloquesSobrantes === 2, String(inv.bloquesSobrantes));
  comprobar('No borró nada', alm.borrados.length === 0);
  comprobar('El inventario es confiable', inv.confiable === true);

  titulo('El bloque COMPARTIDO nunca aparece como sobrante');
  // Es el que rompe todo: parece huérfano de un archivo y lo usa otro.
  comprobar('No está en la lista de sobrantes',
    !inv.sobrantes.some((s) => s.huella === 'a'.repeat(64)),
    JSON.stringify(inv.sobrantes.map((s) => s.huella.slice(0, 6))));

  titulo('Dos tiempos: la primera pasada NO borra');
  ({ objetos, huellasSobrantes } = escenario());
  alm = almacenFalso(objetos);
  // El escenario es chico: dos bloques sobrantes son el 27% del almacén y la
  // baranda del 5% se dispara. Esa baranda tiene su propia prueba más abajo;
  // acá se está probando otra cosa, así que se afloja a propósito.
  let r = await recolectar({ almacen: alm, candidatos: {},
    opciones: { ahora: AHORA, borrar: true, topeProporcion: 1 } });
  comprobar('No borra nada en la primera vuelta', r.borrados.length === 0,
    JSON.stringify(r.borrados));
  comprobar('Pero los anota como candidatos',
    Object.keys(r.nuevosCandidatos).length === 2, JSON.stringify(r.nuevosCandidatos));

  titulo('Segunda pasada, pasada la gracia: ahí sí');
  r = await recolectar({ almacen: alm, candidatos: r.nuevosCandidatos,
    opciones: { ahora: AHORA + 72 * HORA, borrar: true, topeProporcion: 1 } });
  comprobar('Ahora borra los dos', r.borrados.length === 2, JSON.stringify(r.borrados));
  comprobar('Y los bloques en uso siguen intactos',
    objetos.has(`bloques/aa/${'a'.repeat(64)}`) &&
    objetos.has(`bloques/bb/${'b'.repeat(64)}`));

  titulo('Un bloque que VOLVIÓ a usarse no se borra');
  // La carrera real: el cliente respaldó y reutilizó el bloque por dedup.
  ({ objetos, huellasSobrantes } = escenario());
  alm = almacenFalso(objetos);
  r = await recolectar({ almacen: alm, candidatos: {},
    opciones: { ahora: AHORA, borrar: true, topeProporcion: 1 } });
  const revivido = huellasSobrantes[0];
  objetos.set('indices/C/tres.txt.bpi', {
    datos: Buffer.from(JSON.stringify({ formato: 1, archivo: 'C/tres.txt', bytes: 1,
      bloques: [{ h: revivido, n: 1 }] })),
    modificado: hace(1),
  });
  r = await recolectar({ almacen: alm, candidatos: r.nuevosCandidatos,
    opciones: { ahora: AHORA + 72 * HORA, borrar: true, topeProporcion: 1 } });
  comprobar('El bloque reutilizado sobrevive',
    objetos.has(`bloques/${revivido.slice(0, 2)}/${revivido}`),
    JSON.stringify(r.borrados));

  titulo('Baranda: un índice ilegible aborta TODO');
  ({ objetos } = escenario());
  alm = almacenFalso(objetos, { fallaLeer: ['indices/C/uno.txt.bpi', 'indices-copia/C/uno.txt.bpi'] });
  r = await recolectar({ almacen: alm, candidatos: {},
    opciones: { ahora: AHORA, borrar: true, topeProporcion: 1 } });
  comprobar('No borra nada', r.borrados.length === 0);
  comprobar('Y dice por qué', /No se pudieron leer/.test(r.motivoCorte || ''), r.motivoCorte);
  comprobar('El inventario se marca como NO confiable', r.confiable === false);

  titulo('Baranda: bloques recién subidos no se tocan');
  ({ objetos } = escenario({ sobrantes: 2, edadSobrantesH: 2 }));
  alm = almacenFalso(objetos);
  inv = await inventariar({ almacen: alm, opciones: { ahora: AHORA } });
  comprobar('Un bloque de hace 2 horas no cuenta como sobrante',
    inv.bloquesSobrantes === 0 && inv.bloquesRecientes === 2,
    `sobrantes ${inv.bloquesSobrantes}, recientes ${inv.bloquesRecientes}`);

  titulo('Baranda: si quiere borrar demasiado, se planta');
  ({ objetos } = escenario({ sobrantes: 40 }));
  alm = almacenFalso(objetos);
  r = await recolectar({ almacen: alm, candidatos: {},
    opciones: { ahora: AHORA, borrar: true, topeProporcion: 0.05 } });
  comprobar('No borra nada', r.borrados.length === 0);
  comprobar('Y avisa cuánto habría borrado', /% del almacén/.test(r.motivoCorte || ''),
    r.motivoCorte);

  titulo('Simulación: por defecto NO borra');
  ({ objetos } = escenario());
  alm = almacenFalso(objetos);
  r = await recolectar({ almacen: alm, candidatos: {}, opciones: { ahora: AHORA, topeProporcion: 1 } });
  const candidatos = r.nuevosCandidatos;
  r = await recolectar({ almacen: alm, candidatos,
    opciones: { ahora: AHORA + 72 * HORA, topeProporcion: 1 } });
  comprobar('Sin pedirlo explícitamente, no borra', r.borrados.length === 0 && r.simulado === true);
  comprobar('Pero informa qué borraría', r.borrariaAhora === 2, String(r.borrariaAhora));
  comprobar('Y cuánto espacio liberaría', r.bytesQueLiberaria > 0, String(r.bytesQueLiberaria));

  titulo('Un borrado que falla no se da por hecho');
  ({ objetos, huellasSobrantes } = escenario());
  const primero = huellasSobrantes[0];
  const claveFalla = `bloques/${primero.slice(0, 2)}/${primero}`;
  alm = almacenFalso(objetos, { fallaBorrar: [claveFalla] });
  r = await recolectar({ almacen: alm, candidatos: {},
    opciones: { ahora: AHORA, borrar: true, topeProporcion: 1 } });
  r = await recolectar({ almacen: alm, candidatos: r.nuevosCandidatos,
    opciones: { ahora: AHORA + 72 * HORA, borrar: true, topeProporcion: 1 } });
  comprobar('El bloque que no se pudo borrar sigue anotado',
    !!r.nuevosCandidatos[primero], JSON.stringify(Object.keys(r.nuevosCandidatos)));
  comprobar('Y no figura entre los borrados', !r.borrados.includes(claveFalla));

  console.log('\n──────────────────────────────');
  console.log(`  ${ok} de ${ok + mal} pasadas`);
  if (mal) { console.log('  Fallaron:'); fallos.forEach((f) => console.log('    · ' + f)); }
  process.exit(mal ? 1 : 0);
})().catch((e) => { console.error('error inesperado:', e); process.exit(1); });
