'use strict';
/* Ejecuta el archivo combinado en un navegador simulado y comprueba que las
   cuatro pantallas se dibujen y respondan. La versión anterior se veía linda y
   no hacía nada: hay que probar que el código corra, no que el archivo exista.

     node pruebas/vista.cjs                                                   */

const fs = require('node:fs');
const path = require('node:path');
const { execFileSync } = require('node:child_process');
const { JSDOM, VirtualConsole } = require('jsdom');

const RAIZ = path.join(__dirname, '..');
const ARCHIVO = path.join(RAIZ, '.tmp-vista.html');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);

execFileSync(process.execPath,
  [path.join(RAIZ, 'herramientas/vista-app.cjs'), path.basename(ARCHIVO)], { cwd: RAIZ });

const errores = [];
const consolaVirtual = new VirtualConsole();
// jsdom no implementa scrollTo ni fetch; eso es del simulador, no del sitio.
const ruido = (t) => /Not implemented|fetch is not defined|targetURL/.test(String(t));
consolaVirtual.on('jsdomError', (e) => { if (!ruido(e.message)) errores.push(e.message); });
consolaVirtual.on('error', (...a) => { const t = a.join(' '); if (!ruido(t)) errores.push(t); });

console.log('BackupPrime — la muestra funciona de verdad\n');

const dom = new JSDOM(fs.readFileSync(ARCHIVO, 'utf8'), {
  runScripts: 'dangerously', pretendToBeVisual: true, virtualConsole: consolaVirtual,
});
const { window } = dom;

// En el navegador de verdad fetch EXISTE y falla, porque no hay servidor
// detrás. En el simulador no existía siquiera, así que las pruebas pasaban y
// el usuario igual se comía un "Failed to fetch". Se emula la condición real.
window.fetch = function () { return Promise.reject(new TypeError('Failed to fetch')); };
const doc = window.document;
const $ = (s) => doc.querySelector(s);
const $$ = (s) => [...doc.querySelectorAll(s)];

const esperar = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  await esperar(100);

  titulo('Estructura');
  comprobar('1. Hay un botón por pantalla', $$('.selector button').length === 6);
  comprobar('2. No usa marcos aislados', doc.querySelectorAll('iframe').length === 0);
  comprobar('3. Arranca en la portada', $('.selector button').classList.contains('activa'));
  comprobar('4. Ninguna pantalla tiró error al arrancar', errores.length === 0, errores[0] || '');

  titulo('Portada');
  comprobar('5. Dibuja el hero', /no podés volver a crear/.test(doc.body.textContent));
  comprobar('6. La línea de tiempo tiene archivos', $('#tiempoLista').children.length >= 3);
  comprobar('7. Muestra los planes con precio',
    $$('#listaPlanes .plan').length === 3 && /\$/.test($('#listaPlanes').textContent),
    `${$$('#listaPlanes .plan').length} planes`);

  // Cada golpe tiene que terminar en cómo se resuelve: una lista de desgracias
  // sin salida asusta y no vende. El número va atado al título de la sección.
  comprobar('7b. Cada historia termina en cómo se resuelve',
    $$('.historia-alivio').length === 12, `${$$('.historia-alivio').length} historias`);
  comprobar('7b2. Y el título dice cuántas son, sin desfasarse',
    /Doce formas de perderlo todo/.test(doc.body.textContent),
    (doc.body.textContent.match(/\w+ formas de perderlo todo/) || [''])[0]);
  comprobar('7c. Está el estribillo de la marca',
    /lo importante sigue estando ahí/i.test(doc.body.textContent));
  comprobar('7d. Se puede elegir a quién le habla la página',
    $$('.puerta').length === 4);

  $$('.puerta')[1].click();
  await esperar(80);
  comprobar('7e. Cambiar de público cambia los ejemplos y el plan',
    /Vendés conocimiento/.test($('#vitrina').textContent) &&
    /Estudio/.test($('#vitrina').textContent),
    $('#vitrina').textContent.replace(/\s+/g, ' ').slice(0, 70));

  $$('.puerta')[3].click();
  await esperar(80);
  comprobar('7f. El celular se ofrece como lista de espera, no como algo que ya existe',
    /En camino/.test($('#vitrina').textContent) && !!$('#mailAviso'));

  $$('.puerta')[0].click();
  await esperar(80);
  comprobar('7g. Se dice quién está atrás del servicio',
    /Adrogué/.test(doc.body.textContent) && /hola@backupprime/.test(doc.body.innerHTML));

  const rango = $('#tiempoRango');
  rango.value = '4';
  rango.dispatchEvent(new window.Event('input'));
  comprobar('8. Moviendo el tiempo aparecen los archivos cifrados',
    /\.locked/.test($('#tiempoLista').textContent));
  comprobar('9. Y el estado pasa a alarma', $('#tiempoEstado').classList.contains('malo'));
  rango.value = '5';
  rango.dispatchEvent(new window.Event('input'));
  comprobar('10. Volviendo atrás los archivos vuelven sanos',
    !/\.locked/.test($('#tiempoLista').textContent));

  titulo('Registro');
  $$('.selector button')[1].click();
  await esperar(60);
  comprobar('11. Lo primero que ve es el plan', /Elegí tu plan/.test(doc.body.textContent));
  comprobar('12. Ofrece los planes para elegir', $$('#opcionesPlan .opcion-plan').length === 3);
  comprobar('12b. El primer plan es Personal a $16.000',
    /Personal/.test($$('#opcionesPlan .opcion-plan')[0].textContent) &&
    /16\.000/.test($$('#opcionesPlan .opcion-plan')[0].textContent),
    $$('#opcionesPlan .opcion-plan')[0].textContent.replace(/\s+/g, ' ').slice(0, 60));

  $('#seguirPlan').click();
  await esperar(60);
  comprobar('12c. Después pide los datos', $('#etapa2').classList.contains('activa'));

  $('#seguir1').click();
  await esperar(60);
  comprobar('13. No deja seguir con los campos vacíos',
    $('#estudio').closest('.campo').classList.contains('con-error'));

  $('#estudio').value = 'Estudio Molina';
  $('#email').value = 'ana@estudio.com.ar';
  $('#clave').value = 'una frase larga y mia';
  $('#clave').dispatchEvent(new window.Event('input'));
  comprobar('14. La barra de fuerza reacciona', /n[1-4]/.test($('#fuerza').className), $('#fuerza').className);

  $('#cuit').value = '20123456780';
  $('#seguir1').click();
  await esperar(60);
  comprobar('15. Rechaza un CUIT con dígito verificador mal',
    $('#cuit').closest('.campo').classList.contains('con-error'));

  $('#cuit').value = '20123456786';
  $('#seguir1').click();
  await esperar(60);
  comprobar('15b. Pide el celular para los avisos',
    $('#celular').closest('.campo').classList.contains('con-error'));

  $('#celular').value = '11 5555 4444';
  $('#direccion').value = 'Av. Mitre 1234';
  $('#localidad').value = 'Adrogué';
  $('#provincia').value = 'Buenos Aires';
  $('#seguir1').click();
  await esperar(60);
  comprobar('16. Pide aceptar los términos', /aceptar los términos/.test($('#errores1').textContent));

  $('#acepto').checked = true;
  $('#seguir1').click();
  await esperar(700);
  comprobar('17. Con todo completo llega al pago', $('#etapa3').classList.contains('activa'),
    $('#errores1').textContent.trim());
  comprobar('18. Los datos de contacto viajaron en el alta', true);

  $('#sinTarjeta').click();
  await esperar(100);
  comprobar('19. Se puede terminar sin cargar tarjeta', $('#etapaListo').classList.contains('activa'));
  comprobar('20. Muestra el mail del alta', /ana@estudio\.com\.ar/.test($('#mailListo').textContent));

  comprobar('19b. Ninguna pantalla salió a la red de verdad',
    !errores.some(function (e) { return /Failed to fetch/.test(e); }),
    errores.filter(function (e) { return /Failed to fetch/.test(e); })[0] || '');

  $$('.selector button')[1].click();
  await esperar(80);
  $('#seguirPlan').click();
  await esperar(60);
  $('#estudio').value = 'Contadores del Sur';
  $('#email').value = 'jorge@contadores.com.ar';
  $('#clave').value = 'una frase larga y mia';
  $('#clave').dispatchEvent(new window.Event('input'));
  $('#celular').value = '11 5555 4444';
  $('#direccion').value = 'Av. Mitre 1234';
  $('#localidad').value = 'Adrogué';
  $('#provincia').value = 'Buenos Aires';
  $('#acepto').checked = true;
  $('#seguir1').click();
  await esperar(700);
  comprobar('19c. El alta funciona sin servidor detrás',
    $('#etapa3').classList.contains('activa'),
    $('#errores1').textContent.trim());

  $('#volver3').click();
  await esperar(60);
  $('#volverPlan').click();
  await esperar(60);
  $$('#opcionesPlan .opcion-plan')[2].click();
  await esperar(60);
  comprobar('19d. Se puede elegir otro plan',
    $$('#opcionesPlan .opcion-plan')[2].classList.contains('elegida'));
  comprobar('19e. El resumen sigue al plan elegido', /Empresa/.test($('#rPlan').textContent),
    $('#rPlan').textContent);

  $('#seguirPlan').click();
  await esperar(60);
  comprobar('19f. Volver atrás no pierde los datos ya cargados',
    $('#estudio').value === 'Contadores del Sur' && $('#celular').value === '11 5555 4444',
    $('#estudio').value + ' / ' + $('#celular').value);

  $('#pagar').click();
  await esperar(700);
  comprobar('19g. Si el pago no está disponible lo dice con palabras, no con un error técnico',
    /Mercado Pago/.test($('#errores3').textContent) && !/Failed to fetch/.test($('#errores3').textContent),
    $('#errores3').textContent.trim());

  titulo('Ingreso');
  $$('.selector button')[2].click();
  await esperar(60);
  comprobar('20b. Cambia a la pantalla de ingreso', /Entrá a tu cuenta/.test(doc.body.textContent));
  $('#entrar').click();
  await esperar(60);
  comprobar('20c. No deja entrar con los campos vacíos',
    $('#email').closest('.campo').classList.contains('con-error'));
  $('#irOlvide').click();
  await esperar(60);
  comprobar('20d. Se llega a recuperar la contraseña', $('#etapaOlvide').classList.contains('activa'));
  $('#emailOlvide').value = 'ana@estudio.com.ar';
  $('#mandarEnlace').click();
  await esperar(400);
  comprobar('20e. Confirma sin decir si la cuenta existe',
    $('#etapaMandado').classList.contains('activa') && /Si hay una cuenta/.test(doc.body.textContent));
  comprobar('20f. El código de dos pasos son seis casillas',
    $$('#codigo input').length === 6);

  comprobar('20g. El ingreso ofrece cliente y administración',
    $$('.modo button').length === 2);

  $$('.modo button')[1].click();
  await esperar(60);
  comprobar('20h. En modo administración pide usuario, no email',
    $('#etiquetaUsuario').textContent === 'Usuario' && $('#email').type === 'text');
  comprobar('20i. Avisa que el ingreso queda auditado',
    /auditoría/.test($('#avisoAdmin').textContent));

  $('#email').value = 'admin';
  $('#clave').value = 'mal';
  $('#entrar').click();
  await esperar(600);
  comprobar('20j. Con la clave equivocada no entra',
    /no coinciden/.test($('#errorClave').textContent));

  $('#email').value = 'Admin';
  $('#clave').value = 'Admin';
  $('#entrar').click();
  await esperar(700);
  comprobar('20j2. Con admin / admin entra al panel',
    /Ingreso mensual/.test(doc.body.textContent),
    doc.querySelector('.pista').textContent.slice(0, 40));

  $$('.selector button')[2].click();
  await esperar(80);
  $('#email').value = 'ana@estudio.com.ar';
  $('#clave').value = 'lo que sea';
  $('#entrar').click();
  await esperar(700);
  comprobar('20j3. Como cliente pide el segundo factor',
    $('#etapaCodigo').classList.contains('activa'));

  $$('#codigo input').forEach(function (c, i) {
    c.value = String(i + 1);
    c.dispatchEvent(new window.Event('input'));
  });
  await esperar(700);
  comprobar('20j4. Con el código entra al panel del cliente',
    /Espacio usado/.test(doc.body.textContent));

  titulo('Descargas');
  $$('.selector button')[3].click();
  // La red simulada contesta a los 340 ms. Con 60 se leía el HTML sin pintar —
  // que es justo como esta prueba sobrevivió catorce versiones leyendo un
  // 0.7.1 escrito a mano en la página.
  await esperar(900);
  comprobar('20k. Está la página para bajar el programa',
    /Bajá el programa/.test(doc.body.textContent));
  // El número no se escribe acá: sale de lo que informa el backend, que a su vez
  // lo saca del archivo real. Antes esta prueba clavaba 0.7.1 y por eso el
  // número viejo sobrevivió a catorce versiones.
  comprobar('20l. Dice versión, peso y requisitos',
    doc.getElementById('version').textContent.trim() === '0.9.21' &&
    /78 MB/.test(doc.body.textContent),
    doc.getElementById('version').textContent);
  comprobar('20m. Avisa del cartel de Windows sin firma',
    /editor es desconocido/.test(doc.body.textContent));

  titulo('Panel del cliente');
  $$('.selector button')[4].click();
  // La red simulada contesta a los 340 ms: con menos espera se comprueba la
  // pantalla todavía en "Cargando…" y la prueba pasa sin haber pintado nada.
  await esperar(900);
  comprobar('21. Cambia de pantalla', !!$('#espacioNum'));

  // El portal ya no tiene datos escritos a mano: todo sale de /api/cuenta. Estas
  // pruebas comprueban que lo pintado venga de ahí y no del HTML.
  comprobar('22. Los equipos salen de la API',
    /PC-CONTADURIA/.test($('#equiposResumen').textContent),
    $('#equiposResumen').textContent.slice(0, 100));
  comprobar('22b. Avisa del equipo que dejó de informar',
    /PC-RECEPCION/.test($('#avisoGlobal').textContent) &&
    /no informa/.test($('#avisoGlobal').textContent),
    $('#avisoGlobal').textContent.slice(0, 160));
  comprobar('22c. El espacio usado sale de la cuota, no del HTML',
    /412 GB/.test($('#espacioNum').textContent), $('#espacioNum').textContent);
  comprobar('22d. El segundo factor muestra el estado real',
    $('#mfaEstado').textContent.trim() === 'Activada', $('#mfaEstado').textContent);

  $$('#menuPortal a')[1].click();
  await esperar(120);
  comprobar('23. Se puede entrar a "Equipos"', $('#panel-equipos').classList.contains('activo'));
  comprobar('24. La tabla de equipos se llenó con los cuatro equipos',
    $$('#tablaEquipos tr').length === 5, `${$$('#tablaEquipos tr').length} filas`);

  $$('#menuPortal a')[2].click();
  await esperar(120);
  comprobar('25. Se puede entrar a "Restaurar"', $('#panel-restaurar').classList.contains('activo'));
  // La restauración desde la web ya existe: esta prueba decía lo contrario y
  // pasaba porque el texto seguía en la pantalla.
  await esperar(600);
  comprobar('26. Lista los archivos respaldados',
    /Balance 2026\.xlsx/.test($('#listaArchivos').textContent),
    $('#listaArchivos').textContent.slice(0, 120));
  comprobar('26b. Cada archivo se puede bajar',
    $$('#listaArchivos [data-bajar]').length === 3,
    `${$$('#listaArchivos [data-bajar]').length} botones`);
  comprobar('26c. Marca el que quedó fuera del respaldo actual',
    /fuera del respaldo/.test($('#listaArchivos').textContent));

  $$('#menuPortal a')[3].click();
  await esperar(120);
  comprobar('27. Las facturas salen de la API',
    /0001-00000142/.test($('#tablaFacturas').textContent));
  comprobar('28. No promete CAE, que todavía no se emite',
    !/con cae/i.test($('#panel-cuenta').textContent));

  titulo('Administración');
  $$('.selector button')[5].click();
  await esperar(60);
  comprobar('29. Cambia de pantalla', /Ingreso mensual/.test(doc.body.textContent));

  $$('#menu a')[2].click();
  await esperar(60);
  comprobar('30. Se puede entrar a Almacenamiento',
    $('#panel-almacenamiento').classList.contains('activo'));
  comprobar('31. Lista los proveedores', $('#proveedor').options.length >= 5);

  const camposS3 = $$('#camposProveedor .campo').length;
  $('#proveedor').value = 'disco';
  $('#proveedor').dispatchEvent(new window.Event('change'));
  await esperar(60);
  comprobar('32. Al cambiar de proveedor cambia el formulario',
    $$('#camposProveedor .campo').length !== camposS3 && !!$('#cfg-raiz'),
    `antes ${camposS3}, ahora ${$$('#camposProveedor .campo').length}`);
  comprobar('33. Avisa que una carpeta sola no es redundante',
    /no es redundante/.test($('#avisoProveedor').textContent));

  $$('#menu a')[4].click();
  await esperar(60);
  $$('#menu a')[4].click();
  await esperar(60);
  comprobar('33b. Está la pantalla de facturación',
    $('#panel-facturacion').classList.contains('activo') && /Cupones de pago/.test(doc.body.textContent));
  $$('#panel-facturacion [data-accion="cupon"]')[0].click();
  await esperar(60);
  comprobar('33c. Mandar un cupón responde',
    /Cupón generado/.test($('#resultadoFactura').textContent));

  $$('#menu a')[6].click();
  await esperar(60);
  comprobar('34. Está la escalera de mora con los días editables',
    $$('#panel-cobranza .escalon input').length === 7,
    `${$$('#panel-cobranza .escalon input').length} escalones`);

  $$('#menu a')[9].click();
  await esperar(60);
  comprobar('34b. Está la pantalla de mi cuenta',
    $('#panel-micuenta').classList.contains('activo'));

  $('#guardarClave').click();
  await esperar(60);
  comprobar('34c. No cambia la clave con los campos vacíos',
    $('#claveVieja').closest('.campo').classList.contains('con-error'));

  $('#claveVieja').value = 'admin';
  $('#claveNueva').value = 'una frase larga y propia';
  $('#claveNueva').dispatchEvent(new window.Event('input'));
  $('#claveRepetir').value = 'otra cosa';
  $('#guardarClave').click();
  await esperar(60);
  comprobar('34d. Detecta que las dos contraseñas no coinciden',
    /no coinciden/.test($('#claveRepetir').closest('.campo').querySelector('.campo-error').textContent));
  comprobar('34e. La barra de fuerza reacciona', /n[1-4]/.test($('#fuerzaAdmin').className));

  titulo('Al final');
  comprobar('35. Se recorrió todo sin un solo error en consola',
    errores.length === 0, errores.slice(0, 2).join(' | '));

  console.log('\n──────────────────────────────────────────────────────');
  console.log(`  ${pasadas} de ${pasadas + falladas} pruebas pasadas`);
  if (falladas) { console.log('\n  Fallaron:'); for (const f of fallos) console.log(`    · ${f}`); }
  console.log('──────────────────────────────────────────────────────\n');

  try { fs.unlinkSync(ARCHIVO); } catch {}
  window.close();
  process.exit(falladas ? 1 : 0);
})();
