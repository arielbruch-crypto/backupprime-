'use strict';
/* S3 simulado para comprobar que `probar-e2-versionado.cjs` dice la verdad.

   Tres personalidades, porque lo que importa no es que la herramienta ande
   contra un proveedor bueno: es que se ponga en ROJO contra uno que miente.

     completo   — crea buckets, versiona y frena el borrado
     sin-lock   — versiona pero no soporta Object Lock
     mentiroso  — no soporta Object Lock y, además, contesta 200 al activar el
                  versionado sin aplicarlo. Es el caso peligroso: todo parece
                  andar y el historial de versiones no existe.
*/
const http = require('node:http');
const crypto = require('node:crypto');

function crearServidor(personalidad) {
  const buckets = new Map();   // nombre -> { versionado, lock }
  const objetos = new Map();   // `${bucket}|${clave}` -> [{ id, datos, hasta }]

  return http.createServer((req, res) => {
    const url = new URL(req.url, 'http://x');
    const partes = url.pathname.replace(/^\//, '').split('/');
    const bucket = partes[0] || null;
    const clave = partes.slice(1).join('/');
    const q = url.searchParams;
    const trozos = [];
    req.on('data', (c) => trozos.push(c));
    req.on('end', () => {
      // Los objetos se guardan como Buffer, NO como texto. Convertirlos a UTF-8
      // corrompe todo lo binario —un bloque cifrado deja de descifrar— y las
      // pruebas fallaban culpando a la clave cuando el problema era el simulado.
      const crudo = Buffer.concat(trozos);
      const cuerpo = crudo.toString('utf8');
      const responder = (codigo, texto = '') => {
        res.writeHead(codigo, { 'Content-Type': 'application/xml' });
        res.end(texto);
      };

      // Toda petición tiene que venir firmada.
      if (!req.headers.authorization || !/AWS4-HMAC-SHA256/.test(req.headers.authorization)) {
        return responder(403, '<Error><Code>AccessDenied</Code></Error>');
      }

      // Listar buckets
      if (!bucket && req.method === 'GET') {
        return responder(200, '<ListAllMyBucketsResult><Buckets>' +
          [...buckets.keys()].map((b) => `<Bucket><Name>${b}</Name></Bucket>`).join('') +
          '</Buckets></ListAllMyBucketsResult>');
      }

      // Crear bucket. Hay que excluir TODAS las subrecursos: sin esto, un
      // PUT /bucket?object-lock caía acá y volvía a crear el bucket, apagando
      // el versionado que se acababa de prender.
      const subrecurso = ['versioning', 'object-lock', 'lifecycle', 'cors', 'policy']
        .some((k) => q.has(k));
      if (bucket && !clave && req.method === 'PUT' && !subrecurso) {
        const pideLock = req.headers['x-amz-bucket-object-lock-enabled'] === 'true';
        if (pideLock && (personalidad === 'sin-lock' || personalidad === 'mentiroso')) {
          return responder(501, '<Error><Code>NotImplemented</Code></Error>');
        }
        buckets.set(bucket, { versionado: pideLock, lock: pideLock });
        return responder(200);
      }

      const b = buckets.get(bucket);
      if (bucket && !b) return responder(404, '<Error><Code>NoSuchBucket</Code></Error>');

      // Configuración de Object Lock: se acepta y se recuerda.
      if (req.method === 'PUT' && q.has('object-lock')) {
        if (!b.lock) return responder(409, '<Error><Code>InvalidBucketState</Code></Error>');
        b.retencion = /GOVERNANCE|COMPLIANCE/.test(cuerpo) ? cuerpo.match(/GOVERNANCE|COMPLIANCE/)[0] : null;
        return responder(200);
      }

      // Activar versionado
      if (req.method === 'PUT' && q.has('versioning')) {
        if (personalidad === 'mentiroso') return responder(200); // dice que sí y no hace nada
        b.versionado = /Enabled/.test(cuerpo);
        return responder(200);
      }
      // Consultar versionado
      if (req.method === 'GET' && q.has('versioning')) {
        return responder(200, '<VersioningConfiguration>' +
          (b.versionado ? '<Status>Enabled</Status>' : '') + '</VersioningConfiguration>');
      }

      // Listar versiones
      if (req.method === 'GET' && q.has('versions')) {
        const prefijo = q.get('prefix') || '';
        let xml = '<ListVersionsResult>';
        for (const [k, versiones] of objetos) {
          const [bk, ck] = k.split('|');
          if (bk !== bucket || !ck.startsWith(prefijo)) continue;
          for (const v of [...versiones].reverse()) {
            xml += `<Version><Key>${ck}</Key><VersionId>${v.id}</VersionId></Version>`;
          }
        }
        return responder(200, xml + '</ListVersionsResult>');
      }

      // Subir objeto
      if (clave && req.method === 'PUT') {
        const k = `${bucket}|${clave}`;
        const lista = objetos.get(k) || [];
        const modo = req.headers['x-amz-object-lock-mode'];
        if (modo && !b.lock) return responder(400, '<Error><Code>InvalidRequest</Code></Error>');
        const version = {
          id: b.versionado ? crypto.randomBytes(8).toString('hex') : 'null',
          datos: crudo,
          hasta: modo ? req.headers['x-amz-object-lock-retain-until-date'] : null,
        };
        // Sin versionado, se pisa: se pierde lo anterior.
        objetos.set(k, b.versionado ? [...lista, version] : [version]);
        return responder(200);
      }

      // Bajar objeto
      if (clave && req.method === 'GET') {
        const lista = objetos.get(`${bucket}|${clave}`) || [];
        const id = q.get('versionId');
        const v = id ? lista.find((x) => x.id === id) : lista[lista.length - 1];
        if (!v) return responder(404, '<Error><Code>NoSuchKey</Code></Error>');
        res.writeHead(200, { 'Content-Length': v.datos.length });
        return res.end(v.datos);
      }

      // Borrar objeto
      if (clave && req.method === 'DELETE') {
        const k = `${bucket}|${clave}`;
        const lista = objetos.get(k) || [];
        const id = q.get('versionId');
        const v = lista.find((x) => x.id === id);
        const bypass = req.headers['x-amz-bypass-governance-retention'] === 'true';
        if (v && v.hasta && new Date(v.hasta) > new Date() && !bypass) {
          return responder(403, '<Error><Code>AccessDenied</Code></Error>');
        }
        objetos.set(k, lista.filter((x) => x !== v));
        return responder(204);
      }

      // Borrar bucket
      if (bucket && !clave && req.method === 'DELETE') {
        buckets.delete(bucket);
        return responder(204);
      }

      responder(200, '<Result/>');
    });
  });
}

module.exports = { crearServidor };
