'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Restauración desde la web.

   El sitio la promete desde el día uno y no existía. Este es el rearmado del
   lado del servidor: leer el índice, juntar los bloques, descifrar y devolver
   el archivo.

   Lo importante de esta prueba: **cifra con el módulo del AGENTE y descifra con
   el del SERVIDOR**. Si los dos formatos se separan, se cae acá y no el día que
   un cliente necesita su balance. Escribir dos veces el mismo descifrado es
   cómo se llega a archivos que solo se pueden abrir de un lado.
   ═══════════════════════════════════════════════════════════════════════════ */
const crypto = require('node:crypto');
const fs = require('node:fs');
const fsp = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');

const { armarArchivo, descifrarBloque, estaCifrado, puedeDescargarDesdeLaWeb } =
  require('../servidor/restaurar-web.cjs');
// El agente, tal cual lo usa el programa instalado.
const agente = require('../../cliente-windows/electron/cifrado.cjs');

let ok = 0, mal = 0; const fallos = [];
function comprobar(q, cond, extra) {
  if (cond) { ok++; console.log('  ok   ' + q); }
  else { mal++; fallos.push(q); console.log('  MAL  ' + q + (extra ? ' — ' + extra : '')); }
}
const titulo = (t) => console.log(`\n${t}`);

/* Un almacén de mentira, con la misma forma que el de verdad: `leer(clave, destino)`. */
function almacenFalso(objetos) {
  return {
    async leer(clave, destinoLocal) {
      if (!objetos.has(clave)) {
        const e = new Error('NoSuchKey: ' + clave);
        e.status = 404;
        throw e;
      }
      await fsp.mkdir(path.dirname(destinoLocal), { recursive: true });
      await fsp.writeFile(destinoLocal, objetos.get(clave));
      return { bytes: objetos.get(clave).length };
    },
  };
}

/* Arma un archivo respaldado como lo dejaría el agente: bloques cifrados con la
   misma función que usa el programa, más su índice. */
function respaldar(contenido, clave, { prefijo = '', ruta = 'C/Datos/balance.xlsx', cortes = 3 } = {}) {
  const objetos = new Map();
  const pedazo = Math.ceil(contenido.length / cortes);
  const bloques = [];
  for (let i = 0; i < contenido.length; i += pedazo) {
    const trozo = contenido.subarray(i, i + pedazo);
    const huella = crypto.createHash('sha256').update(trozo).digest('hex');
    const guardado = clave ? agente.cifrar(trozo, clave) : trozo;
    objetos.set(`${prefijo}bloques/${huella.slice(0, 2)}/${huella}`, guardado);
    bloques.push({ h: huella, n: trozo.length });
  }
  const indice = {
    formato: 1, archivo: ruta, bytes: contenido.length,
    huella: crypto.createHash('sha256').update(contenido).digest('hex'),
    creado: new Date().toISOString(), bloques,
  };
  const texto = Buffer.from(JSON.stringify(indice));
  objetos.set(`${prefijo}indices/${ruta}.bpi`, texto);
  objetos.set(`${prefijo}indices-copia/${ruta}.bpi`, texto);
  return { objetos, indice };
}

(async () => {
  const CLAVE = agente.claveNueva();
  const CONTENIDO = crypto.randomBytes(300000);

  titulo('El servidor abre lo que cifró el agente');
  let { objetos } = respaldar(CONTENIDO, CLAVE);
  let r = await armarArchivo({
    almacen: almacenFalso(objetos), prefijo: '', rutaRelativa: 'C/Datos/balance.xlsx', clave: CLAVE,
  });
  comprobar('El archivo se arma completo', r.bytes === CONTENIDO.length, `${r.bytes} vs ${CONTENIDO.length}`);
  comprobar('Y es EXACTAMENTE el original', r.archivo.equals(CONTENIDO));
  comprobar('Devuelve el nombre para la descarga', r.nombre === 'balance.xlsx', r.nombre);

  titulo('Un archivo viejo sin cifrar también se restaura');
  // Hasta la 0.9.10 los archivos de menos de 25 MB iban sin cifrar. Un cliente
  // viejo tiene las dos cosas en el mismo bucket.
  ({ objetos } = respaldar(CONTENIDO, null));
  r = await armarArchivo({
    almacen: almacenFalso(objetos), prefijo: '', rutaRelativa: 'C/Datos/balance.xlsx', clave: CLAVE,
  });
  comprobar('Se devuelve tal cual, sin intentar descifrarlo', r.archivo.equals(CONTENIDO));

  titulo('Cuando falta un pedazo, se FALLA. No se entrega cortado');
  ({ objetos } = respaldar(CONTENIDO, CLAVE));
  const unBloque = [...objetos.keys()].find((k) => k.includes('bloques/'));
  objetos.delete(unBloque);
  let error = null;
  try {
    await armarArchivo({ almacen: almacenFalso(objetos), prefijo: '',
      rutaRelativa: 'C/Datos/balance.xlsx', clave: CLAVE });
  } catch (e) { error = e; }
  comprobar('Un bloque faltante corta la descarga', error && error.codigo === 'bloque_faltante',
    error && error.message);
  comprobar('Y el mensaje dice qué pasó sin tecnicismos',
    error && /Falta un pedazo/.test(error.message), error && error.message);

  titulo('Si el archivo armado no coincide con su huella, tampoco se entrega');
  const roto = respaldar(CONTENIDO, CLAVE);
  const indiceRoto = JSON.parse(roto.objetos.get('indices/C/Datos/balance.xlsx.bpi').toString());
  indiceRoto.huella = 'f'.repeat(64);
  const textoRoto = Buffer.from(JSON.stringify(indiceRoto));
  roto.objetos.set('indices/C/Datos/balance.xlsx.bpi', textoRoto);
  roto.objetos.set('indices-copia/C/Datos/balance.xlsx.bpi', textoRoto);
  error = null;
  try {
    await armarArchivo({ almacen: almacenFalso(roto.objetos), prefijo: '',
      rutaRelativa: 'C/Datos/balance.xlsx', clave: CLAVE });
  } catch (e) { error = e; }
  comprobar('Un archivo que no verifica NO se entrega',
    error && error.codigo === 'huella_no_coincide', error && error.message);

  titulo('La copia del índice salva la restauración');
  ({ objetos } = respaldar(CONTENIDO, CLAVE));
  objetos.delete('indices/C/Datos/balance.xlsx.bpi');   // se pierde la principal
  r = await armarArchivo({ almacen: almacenFalso(objetos), prefijo: '',
    rutaRelativa: 'C/Datos/balance.xlsx', clave: CLAVE });
  comprobar('Con el índice principal perdido, se usa la copia', r.archivo.equals(CONTENIDO));

  ({ objetos } = respaldar(CONTENIDO, CLAVE));
  objetos.delete('indices/C/Datos/balance.xlsx.bpi');
  objetos.delete('indices-copia/C/Datos/balance.xlsx.bpi');
  error = null;
  try {
    await armarArchivo({ almacen: almacenFalso(objetos), prefijo: '',
      rutaRelativa: 'C/Datos/balance.xlsx', clave: CLAVE });
  } catch (e) { error = e; }
  comprobar('Sin ninguna de las dos, se dice claro', error && error.codigo === 'indice_ilegible',
    error && error.message);

  titulo('La clave equivocada no devuelve basura');
  ({ objetos } = respaldar(CONTENIDO, CLAVE));
  error = null;
  try {
    await armarArchivo({ almacen: almacenFalso(objetos), prefijo: '',
      rutaRelativa: 'C/Datos/balance.xlsx', clave: agente.claveNueva() });
  } catch (e) { error = e; }
  comprobar('Con otra clave, falla en vez de entregar un archivo ilegible', !!error,
    'no falló');

  titulo('Archivos grandes: se manda al programa, no se cae el servidor');
  ({ objetos } = respaldar(CONTENIDO, CLAVE));
  error = null;
  try {
    await armarArchivo({ almacen: almacenFalso(objetos), prefijo: '',
      rutaRelativa: 'C/Datos/balance.xlsx', clave: CLAVE, topeBytes: 1000 });
  } catch (e) { error = e; }
  comprobar('Por encima del tope se rechaza', error && error.codigo === 'demasiado_grande',
    error && error.message);

  titulo('Frase privada: el servidor NO puede, y lo dice');
  let p = puedeDescargarDesdeLaWeb({ cifrado_modo: 'privada' });
  comprobar('Se rechaza la descarga web', p.puede === false, JSON.stringify(p));
  comprobar('Y se explica que es por diseño, no por una falla',
    /solo vos/.test(p.mensaje), p.mensaje);
  comprobar('Con la salida: restaurar desde el programa',
    /desde el programa/.test(p.mensaje));

  p = puedeDescargarDesdeLaWeb({ cifrado_modo: 'gestionada' });
  comprobar('En modo gestionado sí se puede', p.puede === true);

  titulo('El prefijo del cliente se respeta');
  ({ objetos } = respaldar(CONTENIDO, CLAVE, { prefijo: 'clientes/abc/' }));
  r = await armarArchivo({ almacen: almacenFalso(objetos), prefijo: 'clientes/abc/',
    rutaRelativa: 'C/Datos/balance.xlsx', clave: CLAVE });
  comprobar('Se lee del espacio del cliente', r.archivo.equals(CONTENIDO));

  // ── De punta a punta, contra el servidor real ────────────────────────────
  titulo('El circuito completo: el portal lista y baja');
  const { crearAplicacion } = require('../servidor/servidor.cjs');
  const { crearServidor } = require('./s3-simulado.cjs');

  const s3 = crearServidor('completo');
  await new Promise((res) => s3.listen(0, '127.0.0.1', res));
  const app = crearAplicacion({ archivoBase: ':memory:' });
  await new Promise((res) => app.servidor.listen(0, '127.0.0.1', res));
  const BASE = `http://127.0.0.1:${app.servidor.address().port}`;
  const galletas = {};

  async function pedirApi(metodo, ruta, cuerpo, quien) {
    const rr = await fetch(BASE + ruta, {
      method: metodo,
      headers: Object.assign(cuerpo ? { 'Content-Type': 'application/json' } : {},
        galletas[quien] ? { Cookie: galletas[quien] } : {}),
      body: cuerpo ? JSON.stringify(cuerpo) : undefined,
    });
    const sc = rr.headers.getSetCookie ? rr.headers.getSetCookie() : [];
    if (sc.length && quien) galletas[quien] = sc[0].split(';')[0];
    return rr;
  }

  try {
    const almacenReal = require('../almacenamiento/s3.cjs').crear({
      endpoint: `http://127.0.0.1:${s3.address().port}`, region: 'us-east-1',
      accessKey: 'AK', secretKey: 'SK', bucket: 'maestro',
    });
    // El bucket va PRIMERO: guardar el almacenamiento lo prueba antes de
    // aceptarlo, y contra un bucket inexistente devuelve 404 y no guarda nada.
    // Sin esto el servidor seguía escribiendo en disco y la prueba parecía decir
    // que el portal no encuentra archivos, cuando el problema era el arnés.
    await almacenReal.peticion('PUT', '/maestro', '', { largo: 0 });

    await pedirApi('POST', '/api/sesion', { email: 'admin', clave: 'admin', modo: 'admin' }, 'admin');
    const guardado = await pedirApi('PUT', '/api/admin/almacenamiento', {
      proveedor: 'idrive-e2', endpoint: `http://127.0.0.1:${s3.address().port}`,
      region: 'us-east-1', accessKey: 'AK', secretKey: 'SK', bucket: 'maestro',
    }, 'admin');
    comprobar('El almacenamiento de prueba quedó configurado', guardado.status === 200,
      JSON.stringify(await guardado.json()).slice(0, 160));

    const EMAIL = 'web@ejemplo.com', PASS = 'UnaClaveLarga2026!';
    await pedirApi('POST', '/api/registro', { email: EMAIL, organizacion: 'Estudio Web',
      clave: PASS, nombre: 'W', planId: 'estudio' }, 'c');

    // Se le arma un respaldo como lo dejaría el agente, con su clave gestionada.
    const claveCuenta = agente.claveNueva();
    app.db.prepare("UPDATE cuentas SET prefijo = ?, cifrado_modo = 'gestionada', cifrado_clave = ? WHERE email = ?")
      .run('clientes/web/', claveCuenta.toString('base64'), EMAIL);

    const armado = respaldar(CONTENIDO, claveCuenta, { prefijo: 'clientes/web/' });
    const catalogo = { 'C/Datos/balance.xlsx': { bytes: CONTENIDO.length, mtimeMs: Date.now(), cubierto: true },
                       'D/Viejo/2024.pst': { bytes: 5000, mtimeMs: Date.now() - 9e8, cubierto: false } };
    armado.objetos.set('clientes/web/indices/_catalogo.json', Buffer.from(JSON.stringify(catalogo)));
    for (const [clave, datos] of armado.objetos) {
      await almacenReal.peticion('PUT', `/maestro/${clave}`, '', {
        cuerpo: datos, hashCuerpo: crypto.createHash('sha256').update(datos).digest('hex'),
        largo: datos.length });
    }

    await pedirApi('POST', '/api/sesion', { email: EMAIL, clave: PASS }, 'c');

    let rr = await pedirApi('GET', '/api/portal/archivos', null, 'c');
    let d = await rr.json();
    comprobar('El portal lista los archivos respaldados', (d.archivos || []).length === 2,
      JSON.stringify(d).slice(0, 200));
    comprobar('Marca el que quedó fuera del respaldo',
      d.archivos.some((a) => a.fueraDelRespaldo && a.nombre === '2024.pst'),
      JSON.stringify(d.archivos));
    comprobar('Y dice que se puede descargar', d.puedeDescargar === true);

    rr = await pedirApi('GET', '/api/portal/archivos?buscar=balance', null, 'c');
    d = await rr.json();
    comprobar('El buscador filtra', d.archivos.length === 1 && d.archivos[0].nombre === 'balance.xlsx',
      JSON.stringify(d.archivos));

    rr = await pedirApi('POST', '/api/portal/descargar', { ruta: 'C/Datos/balance.xlsx' }, 'c');
    comprobar('La descarga responde 200', rr.status === 200, `dio ${rr.status}`);
    const bajado = Buffer.from(await rr.arrayBuffer());
    comprobar('Y el archivo que llega es EXACTAMENTE el original',
      bajado.equals(CONTENIDO), `${bajado.length} vs ${CONTENIDO.length}`);

    rr = await pedirApi('POST', '/api/portal/descargar', { ruta: '../otro-cliente/secreto.xlsx' }, 'c');
    comprobar('Una ruta con .. se rechaza: no se sale del espacio del cliente',
      rr.status === 400, `dio ${rr.status}`);

    rr = await pedirApi('POST', '/api/portal/descargar', { ruta: 'C/Datos/no-existe.xlsx' }, 'c');
    comprobar('Un archivo inexistente da 404 con mensaje claro', rr.status === 404, `dio ${rr.status}`);

    rr = await fetch(BASE + '/api/portal/archivos');
    comprobar('Sin sesión no se lista nada', rr.status === 401, `dio ${rr.status}`);

    // Frase privada: el servidor NO puede, y no lo intenta.
    app.db.prepare("UPDATE cuentas SET cifrado_modo = 'privada' WHERE email = ?").run(EMAIL);
    rr = await pedirApi('GET', '/api/portal/archivos', null, 'c');
    d = await rr.json();
    comprobar('Con frase privada, la lista se ve pero sin descarga', d.puedeDescargar === false,
      JSON.stringify(d).slice(0, 160));
    rr = await pedirApi('POST', '/api/portal/descargar', { ruta: 'C/Datos/balance.xlsx' }, 'c');
    comprobar('Y la descarga se rechaza explicando', rr.status === 409, `dio ${rr.status}`);

    const aud = await pedirApi('GET', '/api/admin/auditoria', null, 'admin');
    comprobar('Cada descarga queda auditada',
      /descargó un archivo desde la web/.test(JSON.stringify(await aud.json())));
  } finally {
    s3.close(); app.servidor.close();
  }

  console.log('\n──────────────────────────────');
  console.log(`  ${ok} de ${ok + mal} pasadas`);
  if (mal) { console.log('  Fallaron:'); fallos.forEach((f) => console.log('    · ' + f)); }
  process.exit(mal ? 1 : 0);
})().catch((e) => { console.error('error inesperado:', e); process.exit(1); });
