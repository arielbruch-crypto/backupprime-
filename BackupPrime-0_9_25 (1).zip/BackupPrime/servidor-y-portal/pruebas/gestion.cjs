'use strict';
/* Comprueba las rutas nuevas de autogestión y de rescate contra un servidor
   real. No lee el código: hace los pedidos y mira lo que vuelve. */
const { crearAplicacion } = require('../servidor/servidor.cjs');

let ok = 0, mal = 0; const fallos = [];
function comprobar(q, cond, extra) {
  if (cond) { ok++; console.log('  ok   ' + q); }
  else { mal++; fallos.push(q); console.log('  MAL  ' + q + (extra ? ' — ' + extra : '')); }
}
const titulo = (t) => console.log(`\n${t}`);

(async () => {
  const app = crearAplicacion({ archivoBase: ':memory:' });
  await new Promise((r) => app.servidor.listen(0, '127.0.0.1', r));
  const BASE = `http://127.0.0.1:${app.servidor.address().port}`;

  const galletas = {};
  async function pedir(metodo, ruta, cuerpo, quien = 'cliente') {
    const r = await fetch(BASE + ruta, {
      method: metodo,
      headers: Object.assign(
        cuerpo ? { 'Content-Type': 'application/json' } : {},
        galletas[quien] ? { Cookie: galletas[quien] } : {}),
      body: cuerpo ? JSON.stringify(cuerpo) : undefined,
    });
    const sc = r.headers.getSetCookie ? r.headers.getSetCookie() : [];
    if (sc.length) galletas[quien] = sc[0].split(';')[0];
    let j = {}; try { j = await r.json(); } catch (e) {}
    return { codigo: r.status, cuerpo: j };
  }

  const EMAIL = 'gestion@ejemplo.com', CLAVE = 'UnaClaveLarga2026!';
  await pedir('POST', '/api/registro', {
    email: EMAIL, organizacion: 'Estudio Gestión', clave: CLAVE,
    nombre: 'Ariel', planId: 'estudio' });
  await pedir('POST', '/api/sesion', { email: EMAIL, clave: CLAVE });
  let idCliente = null;

  // ── Cambiar la propia contraseña ─────────────────────────────────────────
  titulo('Cambiar la contraseña estando adentro');
  let r = await pedir('POST', '/api/cuenta/clave', { actual: 'equivocada', nueva: 'OtraClaveLarga2026!' });
  comprobar('Con la contraseña actual mal, no cambia', r.codigo === 401, `dio ${r.codigo}`);

  r = await pedir('POST', '/api/cuenta/clave', { actual: CLAVE, nueva: '123' });
  comprobar('Rechaza una contraseña débil', r.codigo === 400, `dio ${r.codigo}`);

  const CLAVE2 = 'LaNuevaClaveLarga2026!';
  r = await pedir('POST', '/api/cuenta/clave', { actual: CLAVE, nueva: CLAVE2 });
  comprobar('Cambia la contraseña', r.codigo === 200, JSON.stringify(r.cuerpo));

  r = await pedir('POST', '/api/sesion', { email: EMAIL, clave: CLAVE });
  comprobar('La contraseña vieja ya no sirve', r.codigo === 401, `dio ${r.codigo}`);
  r = await pedir('POST', '/api/sesion', { email: EMAIL, clave: CLAVE2 });
  comprobar('La nueva sí', r.codigo === 200, `dio ${r.codigo}`);

  // ── Editar datos ─────────────────────────────────────────────────────────
  titulo('Corregir los datos de facturación');
  r = await pedir('PUT', '/api/cuenta/datos', { organizacion: 'Estudio Gestión SRL', cuit: '30-71234567-2' });  // dígito verificador cambiado a propósito
  comprobar('Rechaza un CUIT inválido', r.codigo === 400, `dio ${r.codigo}`);

  r = await pedir('PUT', '/api/cuenta/datos', { organizacion: '' });
  comprobar('Rechaza la razón social vacía', r.codigo === 400, `dio ${r.codigo}`);

  r = await pedir('PUT', '/api/cuenta/datos', {
    organizacion: 'Estudio Gestión SRL', cuit: '30-71234567-1',
    direccion: 'Mitre 500', localidad: 'Adrogué', provincia: 'Buenos Aires' });
  comprobar('Guarda los datos corregidos', r.codigo === 200, JSON.stringify(r.cuerpo).slice(0, 120));

  r = await pedir('GET', '/api/cuenta');
  comprobar('Y quedan guardados', r.cuerpo.organizacion === 'Estudio Gestión SRL',
    r.cuerpo.organizacion);
  comprobar('El email NO se puede cambiar desde acá', r.cuerpo.email === EMAIL, r.cuerpo.email);

  // ── Desvincular un equipo ────────────────────────────────────────────────
  titulo('Desvincular un equipo');
  const ag = await pedir('POST', '/api/agent-auth/login',
    { email: EMAIL, password: CLAVE2, deviceName: 'PC-VIEJA', agentVersion: '0.9.21' }, 'agente');
  comprobar('El agente dio de alta el equipo', ag.codigo === 200, JSON.stringify(ag.cuerpo).slice(0, 100));

  r = await pedir('POST', '/api/cuenta/equipos/desvincular', { nombre: 'NO-EXISTE' });
  comprobar('No desvincula un equipo que no existe', r.codigo === 404, `dio ${r.codigo}`);

  r = await pedir('POST', '/api/cuenta/equipos/desvincular', { nombre: 'PC-VIEJA' });
  comprobar('Desvincula el equipo', r.codigo === 200, JSON.stringify(r.cuerpo));
  comprobar('Y aclara que los archivos siguen guardados',
    /siguen guardados/.test(r.cuerpo.mensaje || ''), r.cuerpo.mensaje);

  r = await pedir('GET', '/api/cuenta');
  comprobar('El equipo salió de la lista', (r.cuerpo.equipos || []).length === 0,
    JSON.stringify(r.cuerpo.equipos));

  // ── Baja ─────────────────────────────────────────────────────────────────
  titulo('Dar de baja la suscripción');
  r = await pedir('POST', '/api/suscripciones/cancelar', { clave: 'mala' });
  comprobar('Sin la contraseña, no da de baja', r.codigo === 401, `dio ${r.codigo}`);

  r = await pedir('POST', '/api/suscripciones/cancelar', { clave: CLAVE2, motivo: 'prueba' });
  comprobar('Da de baja', r.codigo === 200, JSON.stringify(r.cuerpo));

  r = await pedir('GET', '/api/cuenta');
  comprobar('La cuenta queda cancelada', r.cuerpo.estado === 'cancelada', r.cuerpo.estado);
  comprobar('Y RESTAURAR sigue permitido aunque esté de baja',
    r.cuerpo.cuota && r.cuerpo.cuota.puedeRestaurar === true,
    JSON.stringify(r.cuerpo.cuota));

  // Dar de baja NO puede destruir nada. Con la cuenta anterior ya se había
  // desvinculado el equipo, así que hace falta una cuenta aparte: si no, la
  // lista ya está vacía y la comprobación pasa sin comprobar nada.
  const EMAIL3 = 'baja@ejemplo.com';
  await pedir('POST', '/api/registro', { email: EMAIL3, organizacion: 'Baja SA',
    clave: CLAVE, nombre: 'C', planId: 'estudio' }, 'baja');
  await pedir('POST', '/api/agent-auth/login',
    { email: EMAIL3, password: CLAVE, deviceName: 'PC-QUE-SIGUE', agentVersion: '0.9.21' }, 'ag3');
  await pedir('POST', '/api/sesion', { email: EMAIL3, clave: CLAVE }, 'baja');
  await pedir('POST', '/api/suscripciones/cancelar', { clave: CLAVE }, 'baja');
  r = await pedir('GET', '/api/cuenta', null, 'baja');
  comprobar('Dar de baja NO borra los equipos ni los datos',
    (r.cuerpo.equipos || []).some((e) => e.nombre === 'PC-QUE-SIGUE'),
    JSON.stringify(r.cuerpo.equipos));

  // ── Puertas de rescate ───────────────────────────────────────────────────
  titulo('Las puertas de rescate del panel');
  r = await pedir('POST', '/api/admin/clientes/clave', { id: idCliente, claveAdmin: 'admin' }, 'admin');
  comprobar('Sin sesión de admin, no se puede rescatar', r.codigo === 401, `dio ${r.codigo}`);

  // El panel entra por el mismo endpoint, con modo admin y el usuario en `email`.
  await pedir('POST', '/api/sesion', { email: 'admin', clave: 'admin', modo: 'admin' }, 'admin');
  const lista = await pedir('GET', '/api/admin/clientes', null, 'admin');
  idCliente = (lista.cuerpo.clientes.find((c) => c.email === EMAIL) || {}).id;
  comprobar('El panel lista al cliente', !!idCliente, JSON.stringify(lista.cuerpo).slice(0, 140));

  r = await pedir('POST', '/api/admin/clientes/ficha', { id: idCliente }, 'admin');
  comprobar('El admin ve la ficha del cliente', r.codigo === 200 && r.cuerpo.cliente,
    `dio ${r.codigo} ${JSON.stringify(r.cuerpo).slice(0, 120)}`);

  r = await pedir('POST', '/api/admin/clientes/clave',
    { id: idCliente, claveAdmin: 'equivocada' }, 'admin');
  comprobar('Sin la contraseña del admin, no restablece', r.codigo === 401, `dio ${r.codigo}`);

  r = await pedir('POST', '/api/admin/clientes/clave',
    { id: idCliente, claveAdmin: 'admin' }, 'admin');
  comprobar('Restablece la contraseña del cliente', r.codigo === 200 && !!r.cuerpo.provisoria,
    JSON.stringify(r.cuerpo).slice(0, 140));
  const provisoria = r.cuerpo.provisoria;

  r = await pedir('POST', '/api/sesion', { email: EMAIL, clave: provisoria });
  comprobar('El cliente entra con la provisoria', r.codigo === 200, `dio ${r.codigo}`);

  r = await pedir('POST', '/api/admin/clientes/mfa',
    { id: idCliente, claveAdmin: 'admin' }, 'admin');
  comprobar('Desactivar el 2FA de quien no lo tenía avisa y no rompe', r.codigo === 200,
    JSON.stringify(r.cuerpo));

  r = await pedir('POST', '/api/admin/clientes/destrabar', { id: idCliente }, 'admin');
  comprobar('Destraba los intentos', r.codigo === 200, JSON.stringify(r.cuerpo));

  r = await pedir('POST', '/api/admin/clientes/ficha', { id: 'no-existe' }, 'admin');
  comprobar('Un cliente inexistente da 404, no 500', r.codigo === 404, `dio ${r.codigo}`);

  // ── Cobros ───────────────────────────────────────────────────────────────
  titulo('Configuración de cobros');
  r = await pedir('GET', '/api/admin/mercadopago', null, 'admin');
  comprobar('Arranca sin secreto de webhook', r.cuerpo.tieneWebhookSecret === false,
    JSON.stringify(r.cuerpo));

  r = await pedir('PUT', '/api/admin/mercadopago', { webhookSecret: 'secreto-de-prueba' }, 'admin');
  comprobar('Se puede cargar el secreto desde el panel', r.codigo === 200 && r.cuerpo.tieneWebhookSecret,
    JSON.stringify(r.cuerpo));

  r = await pedir('GET', '/api/admin/mercadopago', null, 'admin');
  comprobar('El secreto NO vuelve al navegador', r.cuerpo.webhookSecret === undefined,
    JSON.stringify(r.cuerpo));

  // Y lo que motivó todo esto: que el pago simulado deje de dar 503.
  const EMAIL2 = 'pago@ejemplo.com';
  await pedir('POST', '/api/registro', { email: EMAIL2, organizacion: 'Pago SA',
    clave: CLAVE, nombre: 'B', planId: 'estudio' }, 'pagador');
  r = await pedir('POST', '/api/pago-simulado', { planId: 'estudio' }, 'pagador');
  comprobar('Sin referencia da 400 con explicación, no 500', r.codigo === 400,
    `dio ${r.codigo} ${JSON.stringify(r.cuerpo).slice(0, 120)}`);

  const ck = await pedir('POST', '/api/suscripciones/checkout', { planId: 'estudio' }, 'pagador');
  const referencia = ck.cuerpo.referencia ||
    (ck.cuerpo.checkoutUrl || '').split('referencia=')[1];
  comprobar('El checkout entrega una referencia', !!referencia,
    JSON.stringify(ck.cuerpo).slice(0, 140));

  r = await pedir('POST', '/api/pago-simulado',
    { referencia, estado: 'approved' }, 'pagador');
  comprobar('El pago simulado YA NO da 503', r.codigo === 200,
    `dio ${r.codigo} ${JSON.stringify(r.cuerpo).slice(0, 120)}`);

  r = await pedir('GET', '/api/cuenta', null, 'pagador');
  comprobar('Y la cuenta queda ACTIVA después de pagar', r.cuerpo.estado === 'activa',
    r.cuerpo.estado);
  comprobar('Y se emitió la factura', (r.cuerpo.facturas || []).length === 1,
    JSON.stringify(r.cuerpo.facturas));

  // ── Alerta de ransomware ─────────────────────────────────────────────────
  titulo('El agente avisa que frenó por cifrado masivo');
  const EMAIL_R = 'ransom@ejemplo.com';
  await pedir('POST', '/api/registro', { email: EMAIL_R, organizacion: 'Estudio Atacado',
    clave: CLAVE, nombre: 'R', planId: 'estudio' }, 'r');
  const agR = await pedir('POST', '/api/agent-auth/login',
    { email: EMAIL_R, password: CLAVE, deviceName: 'PC-INFECTADA', agentVersion: '0.9.22' }, 'r-ag');

  r = await fetch(BASE + '/api/agent/alerta', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ deviceName: 'PC-INFECTADA', tipo: 'ransomware', motivos: ['x'] }),
  });
  comprobar('Sin sesión de agente, la alerta se rechaza', r.status === 401, `dio ${r.status}`);

  r = await fetch(BASE + '/api/agent/alerta', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json',
               Authorization: 'Bearer ' + agR.cuerpo.agentToken },
    body: JSON.stringify({
      deviceName: 'PC-INFECTADA', tipo: 'ransomware',
      motivos: ['820 archivos modificados en 3 minutos', '31 de 40 medidos con entropía de cifrado'],
    }),
  });
  const cuerpoR = await r.json();
  comprobar('Con sesión de agente, se registra', r.status === 200, `dio ${r.status}`);
  comprobar('Y le confirma que sus copias anteriores están a salvo',
    /a salvo/.test(cuerpoR.mensaje || ''), cuerpoR.mensaje);

  const audR = await pedir('GET', '/api/admin/auditoria', null, 'admin');
  const textoR = JSON.stringify(audR.cuerpo);
  comprobar('Queda en la auditoría con el equipo y el motivo',
    /ALERTA de cifrado masivo/.test(textoR) && /PC-INFECTADA/.test(textoR),
    textoR.slice(0, 200));

  // No hay endpoint para ver la cola de correo, así que se mira la base. El
  // aviso por mail importa: la notificación vive en la máquina que puede estar
  // justamente comprometida.
  const encolados = app.db.prepare(
    "SELECT para, asunto FROM avisos WHERE asunto LIKE '%ransomware%' OR asunto LIKE '%ALERTA%'").all();
  comprobar('Se le encola el aviso por mail al cliente',
    encolados.some((a) => a.para === EMAIL_R), JSON.stringify(encolados));

  // ── Auditoría ────────────────────────────────────────────────────────────
  titulo('Todo rescate queda registrado');
  r = await pedir('GET', '/api/admin/auditoria', null, 'admin');
  const texto = JSON.stringify(r.cuerpo);
  comprobar('Quedó registrado el restablecimiento de contraseña',
    /restableció la contraseña/.test(texto), texto.slice(0, 160));
  comprobar('Quedó registrada la baja', /dio de baja/.test(texto));

  console.log('\n──────────────────────────────');
  console.log(`  ${ok} de ${ok + mal} pasadas`);
  if (mal) { console.log('  Fallaron:'); fallos.forEach((f) => console.log('    · ' + f)); }
  app.servidor.close();
  process.exit(mal ? 1 : 0);
})().catch((e) => { console.error('error inesperado:', e); process.exit(1); });
