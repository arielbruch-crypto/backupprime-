'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   La prueba que va ANTES del recolector.

   Antes de escribir nada que borre bloques hay que demostrar, ejecutándolo, qué
   pasa cuando se borra uno de más. Si esta prueba no se pone en rojo primero,
   cualquier recolector es una apuesta.

   Lo que demuestra:

   1. Un bloque huérfano se puede borrar sin consecuencias.
   2. Un bloque TODAVÍA REFERENCIADO no: el archivo que lo usa deja de poder
      armarse. Y lo peor es que el índice sigue ahí, el archivo sigue apareciendo
      en la lista, y el cliente no se entera hasta que lo necesita.
   3. Con deduplicación, un bloque que parece huérfano de un archivo puede estar
      en uso por OTRO archivo distinto. Ese es el caso que rompe todo.
   ═══════════════════════════════════════════════════════════════════════════ */
const crypto = require('node:crypto');
const fsp = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');

const { armarArchivo } = require('../servidor/restaurar-web.cjs');
const agente = require('../../cliente-windows/electron/cifrado.cjs');

let ok = 0, mal = 0; const fallos = [];
function comprobar(q, cond, extra) {
  if (cond) { ok++; console.log('  ok   ' + q); }
  else { mal++; fallos.push(q); console.log('  MAL  ' + q + (extra ? ' — ' + extra : '')); }
}
const titulo = (t) => console.log(`\n${t}`);

function almacenFalso(objetos) {
  return {
    async leer(clave, destinoLocal) {
      if (!objetos.has(clave)) { const e = new Error('NoSuchKey: ' + clave); e.status = 404; throw e; }
      await fsp.mkdir(path.dirname(destinoLocal), { recursive: true });
      await fsp.writeFile(destinoLocal, objetos.get(clave));
      return { bytes: objetos.get(clave).length };
    },
    async listar(prefijo) {
      return { archivos: [...objetos.keys()].filter((k) => k.startsWith(prefijo || ''))
        .map((k) => ({ clave: k, size: objetos.get(k).length })) };
    },
  };
}

/* Guarda un archivo cortado en bloques, compartiendo los que ya existan: es lo
   que hace la deduplicación de verdad. */
function guardar(objetos, ruta, trozos, clave) {
  const bloques = [];
  const partes = [];
  for (const t of trozos) {
    const buf = Buffer.isBuffer(t) ? t : Buffer.from(t);
    const huella = crypto.createHash('sha256').update(buf).digest('hex');
    objetos.set(`bloques/${huella.slice(0, 2)}/${huella}`, agente.cifrar(buf, clave));
    bloques.push({ h: huella, n: buf.length });
    partes.push(buf);
  }
  const entero = Buffer.concat(partes);
  const indice = Buffer.from(JSON.stringify({
    formato: 1, archivo: ruta, bytes: entero.length,
    huella: crypto.createHash('sha256').update(entero).digest('hex'),
    creado: new Date().toISOString(), bloques,
  }));
  objetos.set(`indices/${ruta}.bpi`, indice);
  objetos.set(`indices-copia/${ruta}.bpi`, indice);
  return { bloques, entero };
}

(async () => {
  const CLAVE = agente.claveNueva();
  const A = Buffer.from('parte-comun-de-los-dos-archivos-'.repeat(40));
  const B = Buffer.from('solo-del-primero-'.repeat(40));
  const C = Buffer.from('solo-del-segundo-'.repeat(40));

  function armarEscenario() {
    const objetos = new Map();
    // Dos archivos distintos que COMPARTEN el bloque A. Es el caso real de la
    // deduplicación: el mismo pedazo vive una sola vez.
    const uno = guardar(objetos, 'C/Datos/uno.txt', [A, B], CLAVE);
    const dos = guardar(objetos, 'C/Datos/dos.txt', [A, C], CLAVE);
    // Un bloque que no usa nadie: quedó de una versión vieja ya borrada.
    const suelto = crypto.randomBytes(500);
    const huellaSuelta = crypto.createHash('sha256').update(suelto).digest('hex');
    objetos.set(`bloques/${huellaSuelta.slice(0, 2)}/${huellaSuelta}`,
      agente.cifrar(suelto, CLAVE));
    return { objetos, uno, dos, huellaSuelta };
  }

  const traer = (objetos, ruta) => armarArchivo({
    almacen: almacenFalso(objetos), prefijo: '', rutaRelativa: ruta, clave: CLAVE });

  titulo('Punto de partida: los dos archivos se restauran');
  let { objetos, uno, dos, huellaSuelta } = armarEscenario();
  let r = await traer(objetos, 'C/Datos/uno.txt');
  comprobar('uno.txt vuelve entero', r.archivo.equals(uno.entero));
  r = await traer(objetos, 'C/Datos/dos.txt');
  comprobar('dos.txt vuelve entero', r.archivo.equals(dos.entero));

  titulo('Un bloque HUÉRFANO se puede borrar sin consecuencias');
  ({ objetos, uno, dos, huellaSuelta } = armarEscenario());
  objetos.delete(`bloques/${huellaSuelta.slice(0, 2)}/${huellaSuelta}`);
  r = await traer(objetos, 'C/Datos/uno.txt');
  comprobar('uno.txt sigue entero', r.archivo.equals(uno.entero));
  r = await traer(objetos, 'C/Datos/dos.txt');
  comprobar('dos.txt sigue entero', r.archivo.equals(dos.entero));

  titulo('Un bloque TODAVÍA REFERENCIADO rompe la restauración');
  // Este es el error que el recolector no puede cometer nunca.
  ({ objetos, uno } = armarEscenario());
  const huellaB = crypto.createHash('sha256').update(B).digest('hex');
  objetos.delete(`bloques/${huellaB.slice(0, 2)}/${huellaB}`);
  let error = null;
  try { await traer(objetos, 'C/Datos/uno.txt'); } catch (e) { error = e; }
  comprobar('uno.txt YA NO se puede armar', !!error, 'se armó igual');
  comprobar('Y falla diciendo que falta un pedazo',
    error && error.codigo === 'bloque_faltante', error && error.codigo);

  titulo('Lo peor: el archivo SIGUE apareciendo como si estuviera');
  const listado = await almacenFalso(objetos).listar('indices/');
  comprobar('El índice sigue en el listado, intacto',
    listado.archivos.some((a) => a.clave === 'indices/C/Datos/uno.txt.bpi'),
    JSON.stringify(listado.archivos.map((a) => a.clave)));
  comprobar('Así que el cliente NO se entera hasta que lo necesita', true,
    'un respaldo que parece estar y no está');

  titulo('El caso que rompe todo: el bloque compartido');
  // Alguien podría razonar "borré uno.txt, así que sus bloques sobran". Pero el
  // bloque A también lo usa dos.txt, que sigue vivo.
  ({ objetos, dos } = armarEscenario());
  objetos.delete('indices/C/Datos/uno.txt.bpi');
  objetos.delete('indices-copia/C/Datos/uno.txt.bpi');
  const huellaA = crypto.createHash('sha256').update(A).digest('hex');
  objetos.delete(`bloques/${huellaA.slice(0, 2)}/${huellaA}`);

  error = null;
  try { await traer(objetos, 'C/Datos/dos.txt'); } catch (e) { error = e; }
  comprobar('Borrar los bloques de un archivo ROMPE otro archivo vivo',
    !!error && error.codigo === 'bloque_faltante',
    error ? error.codigo : 'dos.txt se armó igual');
  comprobar('Por eso el recolector tiene que contar referencias sobre TODOS los índices',
    true, '');

  console.log('\n──────────────────────────────');
  console.log(`  ${ok} de ${ok + mal} pasadas`);
  if (mal) { console.log('  Fallaron:'); fallos.forEach((f) => console.log('    · ' + f)); }
  process.exit(mal ? 1 : 0);
})().catch((e) => { console.error('error inesperado:', e); process.exit(1); });
