'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   La misma batería de pruebas contra todos los proveedores.

   Esto es lo que garantiza que puedas cambiar de proveedor sin que se rompa
   nada: si los dos almacenes pasan exactamente las mismas pruebas, son
   intercambiables. El día que agregues uno nuevo, lo sumás acá y sabés en un
   minuto si sirve.

     node pruebas/almacenamiento.cjs
   ═══════════════════════════════════════════════════════════════════════════ */

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { crear, migrar, CATALOGO } = require('../almacenamiento/index.cjs');
const { crearServidorS3 } = require('./servidor-s3-prueba.cjs');

const TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'bp-alm-'));

let pasadas = 0, falladas = 0;
const fallos = [];
function comprobar(nombre, condicion, detalle = '') {
  if (condicion) { pasadas++; console.log(`  ok   ${nombre}`); }
  else { falladas++; fallos.push(nombre); console.log(`  FALLA ${nombre}${detalle ? ' — ' + detalle : ''}`); }
}
const titulo = (t) => console.log(`\n${t}`);

// Archivos de origen para las pruebas
const fuente = path.join(TEMP, 'fuente');
fs.mkdirSync(fuente, { recursive: true });
const archivo = path.join(fuente, 'balance.xlsx');
fs.writeFileSync(archivo, 'planilla contable');
const grande = path.join(fuente, 'grande.bin');
fs.writeFileSync(grande, Buffer.alloc(300 * 1024, 7));
const raro = path.join(fuente, 'raro.txt');
fs.writeFileSync(raro, 'nombre con espacios y acentos');

/** Corre el contrato completo contra un almacén cualquiera. */
async function contrato(etiqueta, almacen, n) {
  titulo(`${etiqueta}`);

  const p = await almacen.probar();
  comprobar(`${n}.1 Responde al botón "Probar conexión"`, p.ok === true, p.detalle);

  const espacio = await almacen.espacioDeCliente('cli-777');
  comprobar(`${n}.2 Da un espacio propio para el cliente`, /cli-777/.test(espacio.prefijo));

  const otro = await almacen.espacioDeCliente('cli-777');
  comprobar(`${n}.3 Pedirlo dos veces no rompe nada`, otro.prefijo === espacio.prefijo);

  const k1 = `${espacio.prefijo}C/Users/ana/balance.xlsx`;
  const g1 = await almacen.guardar(k1, archivo);
  comprobar(`${n}.4 Guarda un archivo`, g1.bytes === 17, `bytes ${g1.bytes}`);

  comprobar(`${n}.5 Sabe que el archivo está`, await almacen.existe(k1));
  comprobar(`${n}.6 Sabe que otro no está`, !(await almacen.existe(`${espacio.prefijo}no-existe.txt`)));

  const vuelta = path.join(TEMP, `vuelta-${n}.xlsx`);
  const l1 = await almacen.leer(k1, vuelta);
  comprobar(`${n}.7 Lo devuelve entero`,
    fs.readFileSync(vuelta, 'utf8') === 'planilla contable' && l1.bytes === 17);

  const k2 = `${espacio.prefijo}C/Users/ana/nombre con espacios.txt`;
  await almacen.guardar(k2, raro);
  const vuelta2 = path.join(TEMP, `vuelta-${n}.txt`);
  await almacen.leer(k2, vuelta2);
  comprobar(`${n}.8 Soporta nombres con espacios`,
    fs.readFileSync(vuelta2, 'utf8') === 'nombre con espacios y acentos');

  const k3 = `${espacio.prefijo}C/grande.bin`;
  const g3 = await almacen.guardar(k3, grande);
  comprobar(`${n}.9 Soporta archivos grandes`, g3.bytes === 300 * 1024);

  const lista = await almacen.listar(espacio.prefijo);
  comprobar(`${n}.10 Lista lo que hay en el espacio del cliente`, lista.archivos.length === 3,
    `encontrados ${lista.archivos.length}`);
  comprobar(`${n}.11 Informa el tamaño de cada uno`, lista.archivos.every((a) => a.bytes > 0));

  const uso = await almacen.usoDe(espacio.prefijo);
  comprobar(`${n}.12 Calcula el espacio usado`, uso.bytes === 17 + 29 + 300 * 1024 && uso.archivos === 3,
    `${uso.bytes} bytes en ${uso.archivos}`);

  const otroCliente = await almacen.espacioDeCliente('cli-888');
  await almacen.guardar(`${otroCliente.prefijo}suyo.txt`, archivo);
  const listaAjena = await almacen.listar(espacio.prefijo);
  comprobar(`${n}.13 Un cliente no ve los archivos de otro`, listaAjena.archivos.length === 3);

  const enlace = almacen.enlaceDescarga(k1, 600);
  comprobar(`${n}.14 Genera un enlace temporal de descarga`, typeof enlace === 'string' && enlace.length > 20);
  comprobar(`${n}.15 El enlace lleva vencimiento`, /Expires|vence/.test(enlace));
  comprobar(`${n}.16 El enlace va firmado`, /Signature|firma/.test(enlace));

  await almacen.borrar(k3);
  comprobar(`${n}.17 Borra un archivo`, !(await almacen.existe(k3)));
  let rompio = false;
  try { await almacen.borrar(`${espacio.prefijo}nunca-existio.txt`); } catch { rompio = true; }
  comprobar(`${n}.18 Borrar algo que no está no revienta`, !rompio);

  let fugado = false;
  try {
    await almacen.guardar('../../fuera-del-corral.txt', archivo);
    fugado = await almacen.existe('../../fuera-del-corral.txt');
  } catch { fugado = false; }
  comprobar(`${n}.19 No se puede escribir fuera del corral`, !fugado);

  return espacio.prefijo;
}

(async () => {
  console.log('BackupPrime — el mismo contrato para todos los proveedores');

  // ── Catálogo ──────────────────────────────────────────────────────────────
  titulo('Catálogo de proveedores');
  comprobar('0.1 Hay más de un proveedor disponible', CATALOGO.length >= 2);
  comprobar('0.2 Cada uno declara qué datos pide',
    CATALOGO.every((p) => Array.isArray(p.campos) && p.campos.length));
  let aviso = null;
  try { crear({ proveedor: 'inventado' }); } catch (e) { aviso = e.message; }
  comprobar('0.3 Un proveedor desconocido avisa con claridad',
    !!aviso && /inventado/.test(aviso) && /disponibles/.test(aviso));
  let faltante = null;
  try { crear({ proveedor: 'idrive-e2', bucket: 'x' }); } catch (e) { faltante = e.message; }
  comprobar('0.4 Avisa qué campo falta completar', !!faltante && /accessKey/.test(faltante));

  // ── Disco ─────────────────────────────────────────────────────────────────
  const almacenDisco = crear({
    proveedor: 'disco',
    raiz: path.join(TEMP, 'disco'),
    urlPublica: 'https://backupprime.com/descargas',
    secretoEnlaces: 'secreto-de-prueba',
  });
  const prefijo = await contrato('Carpeta del servidor', almacenDisco, 1);

  titulo('Enlaces temporales del disco');
  const clave = `${prefijo}C/Users/ana/balance.xlsx`;
  const url = new URL(almacenDisco.enlaceDescarga(clave, 600));
  comprobar('1.20 Un enlace válido se acepta',
    almacenDisco.validarEnlace(clave, url.searchParams.get('vence'), url.searchParams.get('firma')));
  comprobar('1.21 Una firma cambiada se rechaza',
    !almacenDisco.validarEnlace(clave, url.searchParams.get('vence'), 'a'.repeat(64)));
  comprobar('1.22 Un enlace vencido se rechaza',
    !almacenDisco.validarEnlace(clave, '1000000000', almacenDisco
      .enlaceDescarga(clave, -10).match(/firma=([a-f0-9]+)/)[1]));
  comprobar('1.23 La firma de un archivo no sirve para otro',
    !almacenDisco.validarEnlace(`${prefijo}otro.txt`,
      url.searchParams.get('vence'), url.searchParams.get('firma')));

  // ── S3 ────────────────────────────────────────────────────────────────────
  const s3 = crearServidorS3();
  const puerto = await s3.escuchar();
  const almacenS3 = crear({
    proveedor: 'idrive-e2',
    endpoint: `http://127.0.0.1:${puerto}`,
    region: 'us-east-1', bucket: 'backupprime',
    accessKey: 'AKIA', secretKey: 'secreta',
  });
  await contrato('Compatible con S3 (iDrive e2, B2, Wasabi, MinIO)', almacenS3, 2);

  // ── Migración entre proveedores ───────────────────────────────────────────
  titulo('Cambiar de proveedor');

  const destino = crear({
    proveedor: 'disco',
    raiz: path.join(TEMP, 'disco-nuevo'),
    urlPublica: '/descargas', secretoEnlaces: 'otro',
  });
  await destino.espacioDeCliente('cli-777');

  const r = await migrar(almacenS3, destino, 'clientes/cli-777/');
  comprobar('3.1 Copia todo lo del cliente al proveedor nuevo', r.copiados === 2 && r.fallados === 0,
    `copiados ${r.copiados}, fallados ${r.fallados}`);

  const enOrigen = await almacenS3.listar('clientes/cli-777/');
  const enDestino = await destino.listar('clientes/cli-777/');
  comprobar('3.2 Queda la misma cantidad de archivos', enOrigen.archivos.length === enDestino.archivos.length);

  const control = path.join(TEMP, 'control.xlsx');
  await destino.leer('clientes/cli-777/C/Users/ana/balance.xlsx', control);
  comprobar('3.3 El contenido llega intacto al proveedor nuevo',
    fs.readFileSync(control, 'utf8') === 'planilla contable');

  const otraVez = await migrar(almacenS3, destino, 'clientes/cli-777/');
  comprobar('3.4 Volver a lanzarla no copia de nuevo lo que ya está',
    otraVez.copiados === 0 && otraVez.salteados === 2,
    `copiados ${otraVez.copiados}, salteados ${otraVez.salteados}`);

  comprobar('3.5 No toca los datos de otros clientes',
    (await almacenS3.listar('clientes/cli-888/')).archivos.length === 1);

  await s3.cerrar();

  console.log('\n──────────────────────────────────────────────────────');
  console.log(`  ${pasadas} de ${pasadas + falladas} pruebas pasadas`);
  if (falladas) { console.log('\n  Fallaron:'); for (const f of fallos) console.log(`    · ${f}`); }
  console.log('──────────────────────────────────────────────────────\n');

  try { fs.rmSync(TEMP, { recursive: true, force: true }); } catch {}
  process.exit(falladas ? 1 : 0);
})();
