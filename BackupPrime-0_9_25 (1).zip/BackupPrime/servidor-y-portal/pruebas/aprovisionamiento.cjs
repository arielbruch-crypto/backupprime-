'use strict';
/* Aprovisionamiento: se prueba contra una e2 simulada, incluyendo proveedores
   que MIENTEN. Lo que importa no es que ande contra uno bueno: es que se ponga
   en rojo contra uno que dice que sí y no hace nada. */
const { crearServidor } = require('./s3-simulado.cjs');
const { crear } = require('../almacenamiento/s3.cjs');
const { crearReseller, prepararBucket, nombreDeBucket } = require('../servidor/e2.cjs');

let ok = 0, mal = 0; const fallos = [];
function comprobar(q, cond, extra) {
  if (cond) { ok++; console.log('  ok   ' + q); }
  else { mal++; fallos.push(q); console.log('  MAL  ' + q + (extra ? ' — ' + extra : '')); }
}
const titulo = (t) => console.log(`\n${t}`);

/* ── API de reseller simulada ── */
function resellerSimulado(guion = {}) {
  const llamadas = [];
  return {
    llamadas,
    async pedirHttp(metodo, url, cuerpo, cabeceras) {
      llamadas.push({ metodo, url, cuerpo, token: cabeceras && cabeceras.token });
      const ruta = url.split('/v1')[1];
      if (guion[ruta]) return guion[ruta](cuerpo);
      if (ruta === '/create_user') return { status: 200, datos: { user_created: true } };
      if (ruta === '/enable_user_region') {
        return { status: 200, datos: { storage_added: true, storage_dn: 'abc1.mi.idrivee2-9.com' } };
      }
      if (ruta === '/create_access_key') {
        return { status: 200, datos: { created: true, data: { access_key: 'AK123', secret_key: 'SK456' } } };
      }
      return { status: 200, datos: {} };
    },
  };
}

(async () => {
  titulo('Nombre del bucket');
  const n1 = nombreDeBucket('Estudio Contable Pérez & Asociados S.R.L.', 'cuenta-1');
  const n2 = nombreDeBucket('Estudio Contable Pérez & Asociados S.R.L.', 'cuenta-2');
  comprobar('Es válido para S3 (minúsculas, sin acentos ni símbolos)',
    /^[a-z0-9][a-z0-9-]{1,61}[a-z0-9]$/.test(n1) && !/[áéíóúñ@&.]/.test(n1), n1);
  comprobar('Entra en 63 caracteres', n1.length <= 63, `${n1.length}: ${n1}`);
  comprobar('Es legible: se reconoce al cliente en el panel de e2', /perez/.test(n1), n1);
  comprobar('Dos clientes con el MISMO nombre no colisionan', n1 !== n2, `${n1} vs ${n2}`);
  comprobar('Es determinístico: el reintento cae en el mismo bucket',
    n1 === nombreDeBucket('Estudio Contable Pérez & Asociados S.R.L.', 'cuenta-1'));
  comprobar('Una organización vacía no rompe el nombre',
    /^[a-z0-9][a-z0-9-]{1,61}[a-z0-9]$/.test(nombreDeBucket('', 'x')), nombreDeBucket('', 'x'));
  comprobar('Un nombre en chino tampoco',
    /^[a-z0-9][a-z0-9-]{1,61}[a-z0-9]$/.test(nombreDeBucket('会計事務所', 'y')), nombreDeBucket('会計事務所', 'y'));

  titulo('La API de reseller');
  const sim = resellerSimulado();
  const rs = crearReseller({ apiKey: 'CLAVE-DE-PRUEBA', pedirHttp: sim.pedirHttp });
  await rs.crearUsuario({ email: 'respaldos+c1@backupprime.com', clave: 'secreta', nombre: 'Estudio', cuotaGB: 1000 });
  const alta = sim.llamadas[0];
  comprobar('Manda la clave API en la cabecera token', alta.token === 'CLAVE-DE-PRUEBA');
  comprobar('La contraseña va en base64, como pide e2',
    Buffer.from(alta.cuerpo.password, 'base64').toString('utf8') === 'secreta', alta.cuerpo.password);
  comprobar('Pide NO notificar por mail al cliente', alta.cuerpo.email_notification === false);
  comprobar('Manda la cuota del plan', alta.cuerpo.quota === 1000);

  const reg = await rs.habilitarRegion({ email: 'x@y.com', region: 'us-southeast-1' });
  comprobar('Habilitar región devuelve el storage_dn del cliente',
    reg.storage_dn === 'abc1.mi.idrivee2-9.com', JSON.stringify(reg));

  const cl = await rs.crearClave({ email: 'x@y.com', storageDn: 'abc1', nombre: 'k', buckets: ['bp-uno'] });
  comprobar('La clave se pide acotada a UN bucket',
    JSON.stringify(sim.llamadas[2].cuerpo.buckets) === '["bp-uno"]', JSON.stringify(sim.llamadas[2].cuerpo));
  comprobar('Devuelve access_key y secret_key', cl.data.access_key === 'AK123' && cl.data.secret_key === 'SK456');

  titulo('Errores de e2: cada uno se distingue del otro');
  for (const [codigo, que] of [
    ['email_already_in_use', 'el email ya tiene cuenta de iDrive'],
    ['payment_failed', 'la cuenta de reseller tiene un problema de pago'],
    ['user_disabled', 'el usuario está deshabilitado'],
  ]) {
    const s = resellerSimulado({
      '/create_user': () => ({ status: 403, datos: { error: { type: 'invalid_request_error', code: codigo, message: que } } }),
    });
    const r = crearReseller({ apiKey: 'k', pedirHttp: s.pedirHttp });
    let capturado = null;
    try { await r.crearUsuario({ email: 'a@b.com', clave: 'x', nombre: 'y', cuotaGB: 1 }); }
    catch (e) { capturado = e; }
    comprobar(`"${codigo}" llega con su código para poder decidir`,
      capturado && capturado.codigo === codigo, capturado && capturado.message);
  }

  /* ── Preparar el bucket contra S3 simulado ── */
  async function conProveedor(personalidad, fn) {
    const srv = crearServidor(personalidad);
    await new Promise((r) => srv.listen(0, '127.0.0.1', r));
    const puerto = srv.address().port;
    const almacen = crear({
      endpoint: `http://127.0.0.1:${puerto}`, region: 'us-east-1',
      accessKey: 'AK', secretKey: 'SK', bucket: 'x',
    });
    try { return await fn(almacen.peticion); } finally { srv.close(); }
  }

  titulo('Proveedor completo');
  await conProveedor('completo', async (pedir) => {
    const r = await prepararBucket({ pedir, bucket: 'bp-completo', retencionDias: 30 });
    comprobar('El bucket queda utilizable', r.ok === true, JSON.stringify(r.pasos));
    comprobar('Con bloqueo de objetos', r.conLock === true);
    comprobar('Con versionado comprobado de verdad', r.versionado === true);
  });

  titulo('Proveedor sin bloqueo de objetos');
  await conProveedor('sin-lock', async (pedir) => {
    const r = await prepararBucket({ pedir, bucket: 'bp-sinlock' });
    comprobar('Igual queda utilizable: versionado alcanza para la máquina del tiempo', r.ok === true,
      JSON.stringify(r.pasos));
    comprobar('Pero avisa que NO tiene bloqueo de objetos', r.conLock === false);
    comprobar('Y lo deja escrito en los pasos',
      r.pasos.some((p) => /SIN bloqueo/.test(p.que)), JSON.stringify(r.pasos));
  });

  titulo('Proveedor que MIENTE sobre el versionado');
  await conProveedor('mentiroso', async (pedir) => {
    const r = await prepararBucket({ pedir, bucket: 'bp-mentiroso' });
    comprobar('El alta NO se da por buena', r.ok === false, JSON.stringify(r.pasos));
    comprobar('Y dice exactamente qué falló',
      r.pasos.some((p) => !p.ok && /versionado/.test(p.que)), JSON.stringify(r.pasos));
  });

  titulo('Reintento: el cliente entra antes de que termine el alta');
  await conProveedor('completo', async (pedir) => {
    await prepararBucket({ pedir, bucket: 'bp-reintento', retencionDias: 30 });
    const r = await prepararBucket({ pedir, bucket: 'bp-reintento', retencionDias: 30 });
    comprobar('Aprovisionar dos veces el mismo bucket no falla', r.ok === true, JSON.stringify(r.pasos));
  });

  console.log('\n──────────────────────────────');
  console.log(`  ${ok} de ${ok + mal} pasadas`);
  if (mal) { console.log('  Fallaron:'); fallos.forEach((f) => console.log('    · ' + f)); }
  process.exit(mal ? 1 : 0);
})().catch((e) => { console.error('error inesperado:', e); process.exit(1); });
