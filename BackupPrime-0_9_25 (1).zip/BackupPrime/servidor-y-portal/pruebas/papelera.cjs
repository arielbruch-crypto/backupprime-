'use strict';
/* Papelera: una sola por cliente, del lado del servidor.

   Lo que importa acá: que borrar NO destruya nada, que el cliente vea bajar su
   cuota en el momento —si no, aprieta borrar, el número no se mueve y llama— y
   que recuperar sea deshacer, no bajar archivos a ninguna máquina. */
const { crearAplicacion } = require('../servidor/servidor.cjs');

let ok = 0, mal = 0; const fallos = [];
function comprobar(q, cond, extra) {
  if (cond) { ok++; console.log('  ok   ' + q); }
  else { mal++; fallos.push(q); console.log('  MAL  ' + q + (extra ? ' — ' + extra : '')); }
}
const titulo = (t) => console.log(`\n${t}`);

(async () => {
  const app = crearAplicacion({ archivoBase: ':memory:' });
  await new Promise((r) => app.servidor.listen(0, '127.0.0.1', r));
  const BASE = `http://127.0.0.1:${app.servidor.address().port}`;
  const galletas = {};

  async function pedir(metodo, ruta, cuerpo, quien, bearer) {
    const r = await fetch(BASE + ruta, {
      method: metodo,
      headers: Object.assign(cuerpo ? { 'Content-Type': 'application/json' } : {},
        galletas[quien] ? { Cookie: galletas[quien] } : {},
        bearer ? { Authorization: 'Bearer ' + bearer } : {}),
      body: cuerpo ? JSON.stringify(cuerpo) : undefined,
    });
    const sc = r.headers.getSetCookie ? r.headers.getSetCookie() : [];
    if (sc.length && quien) galletas[quien] = sc[0].split(';')[0];
    let j = {}; try { j = await r.json(); } catch (e) {}
    return { codigo: r.status, cuerpo: j };
  }

  const GB = 1024 ** 3;
  const EMAIL = 'papelera@ejemplo.com', CLAVE = 'UnaClaveLarga2026!';
  await pedir('POST', '/api/registro', { email: EMAIL, organizacion: 'Estudio Papelera',
    clave: CLAVE, nombre: 'P', planId: 'estudio' }, 'c');
  const ag = await pedir('POST', '/api/agent-auth/login',
    { email: EMAIL, password: CLAVE, deviceName: 'PC-01', agentVersion: '0.9.22' });
  await pedir('POST', '/api/agent/uso',
    { deviceName: 'PC-01', bytes: 100 * GB, archivos: 5000 }, null, ag.cuerpo.agentToken);
  await pedir('POST', '/api/sesion', { email: EMAIL, clave: CLAVE }, 'c');

  titulo('Arranca vacía');
  let r = await pedir('GET', '/api/portal/papelera', null, 'c');
  comprobar('Sin nada adentro', r.cuerpo.total === 0, JSON.stringify(r.cuerpo));
  comprobar('Y dice cuántos días se guardan', r.cuerpo.diasRetencion === 30);

  titulo('Mandar a la papelera');
  r = await pedir('POST', '/api/portal/papelera/mandar',
    { ruta: 'D/Viejo/2024.pst', bytes: 10 * GB, equipo: 'PC-01' }, 'c');
  comprobar('Se manda un archivo', r.codigo === 200 && r.cuerpo.movidos === 1,
    JSON.stringify(r.cuerpo));
  comprobar('Y avisa por cuántos días se puede recuperar',
    /30 días/.test(r.cuerpo.mensaje || ''), r.cuerpo.mensaje);

  r = await pedir('GET', '/api/portal/papelera', null, 'c');
  comprobar('Aparece en la lista', r.cuerpo.total === 1, JSON.stringify(r.cuerpo.archivos));
  comprobar('Con los días que le quedan', r.cuerpo.archivos[0].diasRestantes === 30,
    String(r.cuerpo.archivos[0].diasRestantes));
  comprobar('Y de qué equipo salió', r.cuerpo.archivos[0].equipo === 'PC-01');

  titulo('La cuota baja EN EL MOMENTO');
  // Si no bajara, el cliente aprieta borrar, el número no se mueve, y llama.
  r = await pedir('GET', '/api/cuenta', null, 'c');
  comprobar('Se descuenta lo que está en la papelera',
    r.cuerpo.cuota.usadoBytes === 90 * GB,
    `${r.cuerpo.cuota.usadoBytes} vs ${90 * GB}`);

  titulo('Recuperar es deshacer, no bajar nada');
  const id = (await pedir('GET', '/api/portal/papelera', null, 'c')).cuerpo.archivos[0].id;
  r = await pedir('POST', '/api/portal/papelera/recuperar', { id }, 'c');
  comprobar('Se recupera', r.codigo === 200 && r.cuerpo.recuperados === 1, JSON.stringify(r.cuerpo));
  comprobar('Y se aclara que nunca se movieron',
    /nunca se movieron/.test(r.cuerpo.mensaje || ''), r.cuerpo.mensaje);

  r = await pedir('GET', '/api/cuenta', null, 'c');
  comprobar('La cuota vuelve a contarlo', r.cuerpo.cuota.usadoBytes === 100 * GB,
    String(r.cuerpo.cuota.usadoBytes));

  titulo('Una carpeta entera, con su espacio real');
  // Antes solo se podían borrar archivos sueltos, y el tamaño era uno solo para
  // todo el pedido: mandar una carpeta mostraba la cantidad y cero espacio.
  r = await pedir('POST', '/api/portal/papelera/mandar', {
    carpeta: 'C/Datos/Viejos',
    archivos: [
      { ruta: 'C/Datos/Viejos/a.pst', bytes: 3 * GB },
      { ruta: 'C/Datos/Viejos/b.xlsx', bytes: 2 * GB },
      { ruta: 'C/Datos/Viejos/sub/c.pdf', bytes: 1 * GB },
    ],
  }, 'c');
  comprobar('Se mandan los tres archivos de la carpeta', r.cuerpo.movidos === 3,
    JSON.stringify(r.cuerpo));
  comprobar('Y se informa el espacio REAL, sumando cada uno',
    r.cuerpo.bytes === 6 * GB, `${r.cuerpo.bytes} vs ${6 * GB}`);

  r = await pedir('GET', '/api/portal/papelera', null, 'c');
  comprobar('Cada archivo conserva SU tamaño, no un promedio',
    r.cuerpo.archivos.some((a) => a.bytes === 3 * GB) &&
    r.cuerpo.archivos.some((a) => a.bytes === 1 * GB),
    JSON.stringify(r.cuerpo.archivos.map((a) => a.bytes)));
  comprobar('El total de la papelera es la suma', r.cuerpo.bytes === 6 * GB,
    String(r.cuerpo.bytes));

  r = await pedir('GET', '/api/cuenta', null, 'c');
  comprobar('Y la cuota baja los 6 GB completos',
    r.cuerpo.cuota.usadoBytes === 94 * GB, String(r.cuerpo.cuota.usadoBytes));

  // Se deja limpio para lo que sigue.
  const enPapelera = (await pedir('GET', '/api/portal/papelera', null, 'c')).cuerpo.archivos;
  await pedir('POST', '/api/portal/papelera/recuperar',
    { ids: enPapelera.map((a) => a.id) }, 'c');

  titulo('Es UNA papelera por cliente, no una por PC');
  await pedir('POST', '/api/portal/papelera/mandar',
    { ruta: 'C/Datos/a.txt', bytes: 1024, equipo: 'PC-01' }, 'c');
  await pedir('POST', '/api/portal/papelera/mandar',
    { ruta: 'C/Datos/b.txt', bytes: 2048, equipo: 'PC-JORGE' }, 'c');
  r = await pedir('GET', '/api/portal/papelera', null, 'c');
  comprobar('Se ven los archivos de las dos máquinas juntos', r.cuerpo.total === 2,
    JSON.stringify(r.cuerpo.archivos.map((a) => a.equipo)));

  titulo('Nadie ve la papelera de otro');
  const OTRO = 'otro@ejemplo.com';
  await pedir('POST', '/api/registro', { email: OTRO, organizacion: 'Otro Estudio',
    clave: CLAVE, nombre: 'O', planId: 'estudio' }, 'o');
  await pedir('POST', '/api/sesion', { email: OTRO, clave: CLAVE }, 'o');
  r = await pedir('GET', '/api/portal/papelera', null, 'o');
  comprobar('La papelera del otro está vacía', r.cuerpo.total === 0, JSON.stringify(r.cuerpo));

  const ajeno = (await pedir('GET', '/api/portal/papelera', null, 'c')).cuerpo.archivos[0].id;
  r = await pedir('POST', '/api/portal/papelera/recuperar', { id: ajeno }, 'o');
  comprobar('Y no puede recuperar lo ajeno', r.cuerpo.recuperados === 0, JSON.stringify(r.cuerpo));

  titulo('Sin sesión, nada');
  r = await pedir('GET', '/api/portal/papelera', null, 'nadie');
  comprobar('La papelera pide sesión', r.codigo === 401, `dio ${r.codigo}`);

  titulo('Una ruta que se sale del espacio del cliente se ignora');
  r = await pedir('POST', '/api/portal/papelera/mandar', { ruta: '../otro/secreto.xlsx' }, 'c');
  comprobar('No se acepta', r.cuerpo.movidos === 0, JSON.stringify(r.cuerpo));

  titulo('Lo vencido se saca solo');
  app.db.prepare("UPDATE papelera SET vence_el = '2020-01-01T00:00:00.000Z' WHERE cuenta_id = " +
    "(SELECT id FROM cuentas WHERE email = ?)").run(EMAIL);
  const sacados = app.vaciarPapeleraVencida();
  comprobar('Se vacía lo que pasó los 30 días', sacados === 2, String(sacados));
  r = await pedir('GET', '/api/portal/papelera', null, 'c');
  comprobar('Y la papelera queda vacía', r.cuerpo.total === 0, JSON.stringify(r.cuerpo));

  const aud = await pedir('GET', '/api/admin/auditoria', null, 'admin');
  titulo('Todo queda registrado');
  await pedir('POST', '/api/sesion', { email: 'admin', clave: 'admin', modo: 'admin' }, 'admin');
  const aud2 = await pedir('GET', '/api/admin/auditoria', null, 'admin');
  const texto = JSON.stringify(aud2.cuerpo);
  comprobar('Queda el envío a la papelera', /mandó archivos a la papelera/.test(texto));
  comprobar('Y el vencimiento, con lo que falta borrar de verdad',
    /pendiente de borrado real/.test(texto), texto.slice(0, 160));

  console.log('\n──────────────────────────────');
  console.log(`  ${ok} de ${ok + mal} pasadas`);
  if (mal) { console.log('  Fallaron:'); fallos.forEach((f) => console.log('    · ' + f)); }
  app.servidor.close();
  process.exit(mal ? 1 : 0);
})().catch((e) => { console.error('error inesperado:', e); process.exit(1); });
