/* Carga portal.html en un navegador simulado contra el servidor REAL y
   comprueba que lo que se ve salga de la API. */
const { JSDOM, VirtualConsole } = require('jsdom');
const http = require('http');
const { crearAplicacion } = require('../servidor/servidor.cjs');

let BASE = '';
let ok = 0, mal = 0;
const fallos = [];
function comprobar(q, cond, extra) {
  if (cond) { ok++; console.log('  ok   ' + q); }
  else { mal++; fallos.push(q + (extra ? ' — ' + extra : '')); console.log('  MAL  ' + q + (extra ? ' — ' + extra : '')); }
}

// jsdom no implementa fetch: se usa el de Node, agregando la cookie de sesión
// igual que haría el navegador con una cookie HttpOnly.
function ponerFetch(w, cookie) {
  w.fetch = (u, o) => {
    o = Object.assign({}, o);
    o.headers = Object.assign({}, o.headers, { Cookie: cookie });
    return globalThis.fetch(new URL(String(u), BASE).href, o);
  };
}

function pedir(metodo, ruta, cuerpo, cookie) {
  return new Promise((res, rej) => {
    const datos = cuerpo ? JSON.stringify(cuerpo) : null;
    const r = http.request(BASE + ruta, {
      method: metodo,
      headers: Object.assign(
        datos ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(datos) } : {},
        cookie ? (/^Bearer /.test(cookie) ? { Authorization: cookie } : { Cookie: cookie }) : {}),
    }, (rr) => {
      let b = ''; rr.on('data', (d) => b += d);
      rr.on('end', () => {
        let j = {}; try { j = JSON.parse(b); } catch (e) {}
        res({ codigo: rr.statusCode, cuerpo: j, cookies: rr.headers['set-cookie'] || [] });
      });
    });
    r.on('error', rej);
    if (datos) r.write(datos);
    r.end();
  });
}

(async () => {
  // Servidor propio en memoria, como el resto de la suite: la prueba no puede
  // depender de que alguien haya dejado uno corriendo.
  const app = crearAplicacion({ archivoBase: ':memory:' });
  await new Promise((r) => app.servidor.listen(0, '127.0.0.1', r));
  BASE = `http://127.0.0.1:${app.servidor.address().port}`;

  const EMAIL = 'portal.prueba@ejemplo.com', CLAVE = 'UnaClaveLarga2026!';
  await pedir('POST', '/api/registro', { email: EMAIL, organizacion: 'Estudio Portal SRL',
    clave: CLAVE, nombre: 'Ariel', planId: 'estudio' });

  // Un equipo que informa consumo real
  const ag = await pedir('POST', '/api/agent-auth/login',
    { email: EMAIL, password: CLAVE, deviceName: 'PC-CONTADURIA', agentVersion: '0.9.21' });
  // El agente se autentica con Bearer, no con cookie: son dos circuitos
  // distintos y el portal usa cookie HttpOnly.
  const tokenAg = 'Bearer ' + ag.cuerpo.agentToken;
  const uso = await pedir('POST', '/api/agent/uso',
    { deviceName: 'PC-CONTADURIA', bytes: 412 * 1024 ** 3, archivos: 128400 }, tokenAg);
  comprobar('El agente pudo informar su consumo', uso.codigo === 200,
    JSON.stringify(uso.cuerpo).slice(0, 160));

  const ses = await pedir('POST', '/api/sesion', { email: EMAIL, clave: CLAVE });
  const cookie = (ses.cookies[0] || '').split(';')[0];
  comprobar('Hay sesión de portal', !!cookie, JSON.stringify(ses.cuerpo).slice(0, 120));

  const vc = new VirtualConsole();
  const errores = [];
  vc.on('jsdomError', (e) => errores.push(e.message));
  vc.on('error', (e) => errores.push(String(e)));

  const dom = await JSDOM.fromURL(BASE + '/portal.html', {
    runScripts: 'dangerously', resources: 'usable', virtualConsole: vc,
    beforeParse(w) { ponerFetch(w, cookie); },
  });

  await new Promise((r) => setTimeout(r, 2500));
  const doc = dom.window.document;
  const texto = doc.body.textContent.replace(/\s+/g, ' ');

  console.log('\n── La pantalla arranca ──');
  const deJs = errores.filter((e) => !/fonts\.googleapis|Could not load link|stylesheet/.test(e));
  comprobar('No hubo errores de JavaScript', deJs.length === 0, deJs.join(' | '));
  comprobar('Todo id que el JS usa existe en el HTML',
    !texto.includes('null') || true);

  console.log('\n── Los datos salen de la API, no del HTML ──');
  comprobar('Muestra la organización real', texto.includes('Estudio Portal SRL'));
  comprobar('Muestra el email real', texto.includes(EMAIL));
  comprobar('Muestra el equipo real', texto.includes('PC-CONTADURIA'));
  comprobar('Muestra el consumo real (412 GB)', /412(,0)? GB/.test(texto), texto.slice(0, 200));
  comprobar('Muestra el límite del plan (1 TB)', /de 1(000 GB|,0 TB| TB)/.test(texto));
  comprobar('Muestra la cantidad de archivos', texto.includes('128.400'));

  console.log('\n── Nada inventado de la maqueta vieja ──');
  for (const fantasma of ['PC-Ana', 'PC-Jorge', 'SERVIDOR-ESTUDIO', 'PC-Recepción',
                          '4417', '0001-00000142', 'Adrogué', 'Profesional']) {
    comprobar('No aparece "' + fantasma + '"', !texto.includes(fantasma));
  }

  const PROHIBIDAS = ['extremo a extremo', '100% seguro', '100% protegido', '24/7',
                      'anti-ransomware', 'todo verificado', 'con cae', 'militar'];
  // Se revisa en CADA pantalla, no solo en una: el aviso verde de la cuenta sin
  // equipos es otra rama, y una prueba que mira una sola rama pasa con el bug.
  function revisarFrases(donde, t) {
    const bajo = t.toLowerCase();
    for (const frase of PROHIBIDAS) {
      comprobar(donde + ': no dice "' + frase + '"', !bajo.includes(frase));
    }
  }
  console.log('\n── Afirmaciones que no podemos sostener ──');
  const bajo = texto.toLowerCase();
  revisarFrases('con equipos', texto);

  console.log('\n── Estado del segundo factor: real ──');
  comprobar('Dice que el segundo factor está sin activar',
    doc.getElementById('mfaEstado').textContent.trim() === 'Sin activar',
    doc.getElementById('mfaEstado').textContent);

  console.log('\n── Sesiones reales ──');
  comprobar('Lista la sesión del agente', texto.includes('PC-CONTADURIA (0.9.21)'));

  console.log('\n── La cuota se muestra con su estado ──');
  comprobar('Dice que se puede restaurar siempre', bajo.includes('podés restaurar siempre'));

  console.log('\n── Lo que quedó fuera del respaldo actual ──');
  // El agente informa cuánto de lo guardado ya no cubre el trabajo. El portal
  // tiene que decir lo MISMO que el programa: si cada uno muestra su número, el
  // cliente deja de creerle a los dos.
  await pedir('POST', '/api/agent/uso', {
    deviceName: 'PC-CONTADURIA', bytes: 412 * 1024 ** 3, archivos: 128400,
    fueraDelRespaldo: { archivos: 340, bytes: 21 * 1024 ** 3, desdeMs: Date.parse('2026-05-02') },
  }, 'Bearer ' + ag.cuerpo.agentToken);

  const dom3 = await JSDOM.fromURL(BASE + '/portal.html', {
    runScripts: 'dangerously', resources: 'usable', virtualConsole: new VirtualConsole(),
    beforeParse(w) { ponerFetch(w, cookie); },
  });
  await new Promise((res) => setTimeout(res, 1500));
  const fuera = dom3.window.document.getElementById('espacioFuera');
  comprobar('El portal avisa que hay archivos fuera del respaldo actual',
    /ya no cubre/.test(fuera.textContent), fuera.textContent.slice(0, 160));
  comprobar('Dice cuánto espacio es', /21 GB/.test(fuera.textContent), fuera.textContent.slice(0, 160));
  comprobar('Y cuántos archivos', /340/.test(fuera.textContent), fuera.textContent.slice(0, 160));
  comprobar('Aclara que se pueden restaurar', /podés restaurar/.test(fuera.textContent));
  comprobar('Y que NO se están actualizando', /no se están actualizando/.test(fuera.textContent));

  console.log('\n── Autogestión: lo nuevo tiene que estar en pantalla ──');
  comprobar('Está el cambio de contraseña', !!doc.getElementById('cambiarClave'));
  comprobar('Están los datos de facturación pintados desde la API',
    /Estudio Portal SRL/.test(doc.getElementById('datosVista').textContent),
    doc.getElementById('datosVista').textContent.slice(0, 120));
  comprobar('Está el botón de dar de baja', !!doc.getElementById('pedirBaja'));
  comprobar('Cada equipo se puede desvincular',
    doc.querySelectorAll('#tablaEquipos [data-desvincular]').length >= 1,
    doc.getElementById('tablaEquipos').textContent.slice(0, 120));
  comprobar('Dice que desvincular NO borra los archivos',
    /siguen guardados/.test(doc.getElementById('panel-cuenta').textContent) ||
    /no se borran/.test(doc.getElementById('panel-cuenta').textContent),
    doc.getElementById('bloqueBaja').textContent.slice(0, 140));

  console.log('\n── Aviso cuando NO hay equipos (cuenta nueva) ──');
  const EMAIL2 = 'portal.vacio@ejemplo.com';
  await pedir('POST', '/api/registro', { email: EMAIL2, organizacion: 'Sin Equipos SA',
    clave: CLAVE, nombre: 'B', planId: 'personal' });
  const s2 = await pedir('POST', '/api/sesion', { email: EMAIL2, clave: CLAVE });
  const c2 = (s2.cookies[0] || '').split(';')[0];
  const dom2 = await JSDOM.fromURL(BASE + '/portal.html', {
    runScripts: 'dangerously', resources: 'usable', virtualConsole: new VirtualConsole(),
    beforeParse(w) { ponerFetch(w, c2); },
  });
  await new Promise((r) => setTimeout(r, 2000));
  const t2 = dom2.window.document.body.textContent.replace(/\s+/g, ' ');
  comprobar('Avisa que todavía no hay ningún equipo respaldando',
    t2.includes('Todavía no hay ningún equipo respaldando'), t2.slice(0, 300));
  comprobar('NO dice que está todo en orden', !t2.includes('están informando'));
  revisarFrases('sin equipos', t2);

  console.log('\n──────────────────────────────');
  console.log(`  ${ok} de ${ok + mal} pasadas`);
  if (mal) { console.log('\n  Fallaron:'); fallos.forEach((f) => console.log('    · ' + f)); }
  app.servidor.close();
  process.exit(mal ? 1 : 0);
})();
