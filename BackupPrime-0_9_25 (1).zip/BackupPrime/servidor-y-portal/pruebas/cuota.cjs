'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Cuota de espacio: que el número sea uno solo y que los límites se apliquen
   como corresponde.

   Dos cosas se prueban acá, y las dos vienen de decisiones de producto:

   1) El MISMO número en el programa de escritorio y en el portal. Si difieren,
      el cliente deja de creerle a los dos. Por eso hay una sola función que
      calcula el consumo y la usan las tres pantallas.

   2) Qué pasa al llegar al tope. Tres estados, no dos: hasta el 100% todo bien,
      entre el 100% y el 110% se avisa pero SE SIGUE RESPALDANDO, y recién
      pasada la gracia se frenan las subidas.

      Y una regla que no se negocia: **las restauraciones nunca se frenan.** Un
      cliente que se pasó de cupo y necesita recuperar sus archivos tiene que
      poder. Discutir plata en ese momento va contra la razón de ser del producto.

     node pruebas/cuota.cjs
   ═══════════════════════════════════════════════════════════════════════════ */

const { crearAplicacion } = require('../servidor/servidor.cjs');

let pasadas = 0, falladas = 0;
const fallos = [];
const comprobar = (n, c, d = '') => {
  if (c) { pasadas++; console.log(`  ok   ${n}`); }
  else { falladas++; fallos.push(n); console.log(`  FALLA ${n}${d ? ' — ' + d : ''}`); }
};
const titulo = (t) => console.log(`\n${t}`);
const GB = 1024 * 1024 * 1024;

console.log('BackupPrime — cuota de espacio\n');

(async () => {
  const app = crearAplicacion({ archivoBase: ':memory:' });
  await new Promise((r) => app.servidor.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${app.servidor.address().port}`;
  const db = app.db;

  const pedir = async (metodo, ruta, cuerpo, token) => {
    const cab = { 'Content-Type': 'application/json' };
    if (token) cab.Authorization = 'Bearer ' + token;
    const r = await fetch(base + ruta, {
      method: metodo, headers: cab,
      body: cuerpo === undefined ? undefined : JSON.stringify(cuerpo),
    });
    let datos = {};
    try { datos = await r.json(); } catch {}
    return { status: r.status, datos };
  };

  const EMAIL = 'contador@estudio.com.ar';
  const CLAVE = 'clave-larga-de-prueba';
  await pedir('POST', '/api/registro', {
    email: EMAIL, clave: CLAVE, organizacion: 'Estudio',
    cuit: '20123456786', planId: 'estudio',      // 1000 GB
  });

  // Sesión del portal y sesión del agente, sobre la misma cuenta.
  const web = await pedir('POST', '/api/sesion', { email: EMAIL, clave: CLAVE });
  const tokenWeb = web.datos.token;
  const login = await pedir('POST', '/api/agent-auth/login', {
    email: EMAIL, password: CLAVE, deviceName: 'PC-CONTADOR', agentVersion: '0.8.5',
  });
  const tokenAgente = login.datos.agentToken;

  titulo('El programa recibe la cuota ya al ingresar');
  {
    comprobar('el ingreso trae el estado de la cuota', !!login.datos.cuota,
      JSON.stringify(login.datos).slice(0, 140));
    comprobar('con el plan recién creado está en cero',
      login.datos.cuota.usadoBytes === 0 && login.datos.cuota.estado === 'ok',
      JSON.stringify(login.datos.cuota));
    comprobar('el límite es el del plan',
      login.datos.cuota.limiteBytes === 1000 * GB,
      String(login.datos.cuota.limiteBytes));
  }

  titulo('El equipo informa su consumo');
  {
    const r = await pedir('POST', '/api/agent/uso',
      { deviceName: 'PC-CONTADOR', bytes: 300 * GB, archivos: 120000 }, tokenAgente);
    comprobar('el servidor lo acepta', r.status === 200, JSON.stringify(r.datos).slice(0, 120));
    comprobar('devuelve el consumo actualizado', r.datos.cuota.usadoBytes === 300 * GB,
      String(r.datos.cuota.usadoBytes));
    comprobar('el porcentaje es correcto', r.datos.cuota.porcentaje === 30,
      String(r.datos.cuota.porcentaje));
    comprobar('a 30% no hay ningún aviso', r.datos.cuota.estado === 'ok' && !r.datos.mensaje);
  }

  titulo('El portal muestra EXACTAMENTE el mismo número');
  {
    const r = await pedir('GET', '/api/cuenta', undefined, tokenWeb);
    comprobar('el portal informa la cuota', !!r.datos.cuota);
    comprobar('coincide con lo que ve el programa',
      r.datos.cuota.usadoBytes === 300 * GB && r.datos.cuota.porcentaje === 30,
      JSON.stringify(r.datos.cuota));
  }

  titulo('Varios equipos suman al mismo plan');
  {
    // Es la razón por la que la cuenta la lleva el servidor: un cliente con tres
    // equipos no puede tener tres cuentas distintas del mismo cupo.
    await pedir('POST', '/api/agent-auth/login', {
      email: EMAIL, password: CLAVE, deviceName: 'PC-RECEPCION', agentVersion: '0.8.5',
    }).then((r) => pedir('POST', '/api/agent/uso',
      { deviceName: 'PC-RECEPCION', bytes: 100 * GB, archivos: 40000 }, r.datos.agentToken));

    const r = await pedir('GET', '/api/agent/cuota', undefined, tokenAgente);
    comprobar('el total suma los dos equipos', r.datos.cuota.usadoBytes === 400 * GB,
      String(r.datos.cuota.usadoBytes));
    comprobar('se puede ver el detalle por equipo',
      Array.isArray(r.datos.equipos) && r.datos.equipos.length === 2,
      JSON.stringify(r.datos.equipos));
  }

  titulo('Se informa el total absoluto, no la diferencia');
  {
    // Con diferencias, un aviso perdido o repetido desajusta la cuenta para
    // siempre y nadie se entera hasta que no cierra con la factura.
    await pedir('POST', '/api/agent/uso',
      { deviceName: 'PC-CONTADOR', bytes: 310 * GB, archivos: 121000 }, tokenAgente);
    await pedir('POST', '/api/agent/uso',
      { deviceName: 'PC-CONTADOR', bytes: 310 * GB, archivos: 121000 }, tokenAgente);
    const r = await pedir('GET', '/api/agent/cuota', undefined, tokenAgente);
    comprobar('informar dos veces lo mismo no duplica el consumo',
      r.datos.cuota.usadoBytes === 410 * GB, String(r.datos.cuota.usadoBytes));
  }

  titulo('Aviso al 80%, no al llegar al tope');
  {
    await pedir('POST', '/api/agent/uso',
      { deviceName: 'PC-CONTADOR', bytes: 750 * GB, archivos: 200000 }, tokenAgente);
    const r = await pedir('GET', '/api/agent/cuota', undefined, tokenAgente);
    // 750 + 100 = 850 GB de 1000 → 85%
    comprobar('a 85% el estado es de aviso', r.datos.cuota.estado === 'aviso',
      `${r.datos.cuota.porcentaje}% → ${r.datos.cuota.estado}`);
    comprobar('hay un mensaje para mostrar', !!r.datos.mensaje, String(r.datos.mensaje));
    comprobar('todavía se puede subir', r.datos.cuota.puedeSubir === true,
      'avisar al 100% es tarde para que el cliente decida');
  }

  titulo('Pasado el 100%: se avisa pero SE SIGUE RESPALDANDO');
  {
    await pedir('POST', '/api/agent/uso',
      { deviceName: 'PC-CONTADOR', bytes: 950 * GB, archivos: 250000 }, tokenAgente);
    const r = await pedir('GET', '/api/agent/cuota', undefined, tokenAgente);
    // 950 + 100 = 1050 GB de 1000 → 105%, dentro de la gracia del 10%
    comprobar('el estado es "excedido"', r.datos.cuota.estado === 'excedido',
      `${r.datos.cuota.porcentaje}% → ${r.datos.cuota.estado}`);
    comprobar('el respaldo NO se frena todavía', r.datos.cuota.puedeSubir === true,
      'la gracia existe para que el cliente tenga tiempo de decidir');
    comprobar('el mensaje avisa que conviene ampliar',
      /ampliar/i.test(r.datos.mensaje || ''), String(r.datos.mensaje));
  }

  titulo('Pasada la gracia: se frenan las subidas');
  {
    await pedir('POST', '/api/agent/uso',
      { deviceName: 'PC-CONTADOR', bytes: 1200 * GB, archivos: 300000 }, tokenAgente);
    const r = await pedir('GET', '/api/agent/cuota', undefined, tokenAgente);
    comprobar('el estado es "frenado"', r.datos.cuota.estado === 'frenado',
      `${r.datos.cuota.porcentaje}% → ${r.datos.cuota.estado}`);
    comprobar('no se puede subir', r.datos.cuota.puedeSubir === false);

    // Lo más importante de todo el archivo.
    comprobar('LAS RESTAURACIONES SIGUEN PERMITIDAS', r.datos.cuota.puedeRestaurar === true,
      'frenar una restauración por una cuestión de facturación es el peor ' +
      'momento posible: es justo cuando el cliente necesita el producto');

    comprobar('el mensaje aclara que los archivos siguen a salvo',
      /a salvo|restaurar/i.test(r.datos.mensaje || ''), String(r.datos.mensaje));
  }

  titulo('El portal sigue coincidiendo con el programa en el caso feo');
  {
    const web2 = await pedir('GET', '/api/cuenta', undefined, tokenWeb);
    const ag2 = await pedir('GET', '/api/agent/cuota', undefined, tokenAgente);
    comprobar('mismo consumo', web2.datos.cuota.usadoBytes === ag2.datos.cuota.usadoBytes,
      `web: ${web2.datos.cuota.usadoBytes} · agente: ${ag2.datos.cuota.usadoBytes}`);
    comprobar('mismo estado', web2.datos.cuota.estado === ag2.datos.cuota.estado,
      `web: ${web2.datos.cuota.estado} · agente: ${ag2.datos.cuota.estado}`);
    comprobar('mismo mensaje', web2.datos.mensajeCuota === ag2.datos.mensaje);
  }

  titulo('Cambiar de plan actualiza la cuota sin tocar nada más');
  {
    await pedir('POST', '/api/suscripciones/plan', { planId: 'empresa' }, tokenWeb);  // 3000 GB
    const r = await pedir('GET', '/api/agent/cuota', undefined, tokenAgente);
    comprobar('el límite nuevo se aplica', r.datos.cuota.limiteBytes === 3000 * GB,
      String(r.datos.cuota.limiteBytes));
    comprobar('vuelve a poder subir', r.datos.cuota.puedeSubir === true);
    comprobar('el estado vuelve a normal', r.datos.cuota.estado === 'ok',
      `${r.datos.cuota.porcentaje}% → ${r.datos.cuota.estado}`);
  }

  titulo('Un equipo ajeno no puede informar consumo');
  {
    const r = await pedir('POST', '/api/agent/uso',
      { deviceName: 'PC-QUE-NO-EXISTE', bytes: 999 * GB }, tokenAgente);
    comprobar('rechaza un equipo no registrado', r.status === 404, String(r.status));

    const sinToken = await pedir('POST', '/api/agent/uso',
      { deviceName: 'PC-CONTADOR', bytes: 1 }, null);
    comprobar('sin sesión no se acepta', sinToken.status === 401);

    // Una sesión del portal no sirve para informar consumo: son tipos distintos.
    const conWeb = await pedir('POST', '/api/agent/uso',
      { deviceName: 'PC-CONTADOR', bytes: 1 }, tokenWeb);
    comprobar('una sesión del portal no puede informar consumo de un equipo',
      conWeb.status === 401, String(conWeb.status));
  }

  titulo('Valores raros no rompen la cuenta');
  {
    for (const malo of [-5, 'muchos', null, 1.7e30]) {
      await pedir('POST', '/api/agent/uso',
        { deviceName: 'PC-CONTADOR', bytes: malo }, tokenAgente);
    }
    const r = await pedir('GET', '/api/agent/cuota', undefined, tokenAgente);
    comprobar('el consumo nunca queda negativo ni NaN',
      Number.isFinite(r.datos.cuota.usadoBytes) && r.datos.cuota.usadoBytes >= 0,
      String(r.datos.cuota.usadoBytes));
  }

  app.servidor.close();

  console.log(`\n${pasadas} pasadas, ${falladas} falladas`);
  if (falladas) { console.log('Fallaron:'); fallos.forEach((f) => console.log('  · ' + f)); }
  process.exit(falladas ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
