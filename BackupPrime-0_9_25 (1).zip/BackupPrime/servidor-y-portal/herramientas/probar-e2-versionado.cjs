'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   ¿Se puede aprovisionar un bucket automáticamente, con versionado y
   protección anti-ransomware?

   Esta herramienta NO forma parte del producto. Existe para contestar con
   datos, contra tu cuenta real, tres preguntas que definen el diseño del
   aprovisionamiento automático y que no se pueden contestar leyendo código:

     1. ¿Se puede CREAR un bucket por API?
     2. ¿Se puede activar el VERSIONADO por API, y queda activo de verdad?
     3. ¿Se puede activar OBJECT LOCK, y frena de verdad un borrado?

   La tercera es la que importa el día del ransomware. Y la segunda es la que
   falla en silencio: un bucket sin versionado guarda bien, restaura el archivo
   actual, y todo PARECE andar. Lo único que no funciona es "volvé la carpeta al
   lunes", y eso se descubre el peor día.

   No se comprueba leyendo la respuesta del proveedor: se comprueba pisando un
   objeto y exigiendo que la versión vieja siga bajándose con su contenido
   original, y pidiendo un borrado que TIENE que ser rechazado. Un proveedor que
   contesta "listo" y no lo hizo queda en rojo igual.

   ── Uso ────────────────────────────────────────────────────────────────────

     node herramientas/probar-e2-versionado.cjs \
       --endpoint=https://TU-REGION.idrivee2.com \
       --region=TU-REGION \
       --accessKey=... --secretKey=...

   Los valores son los mismos que cargás en el panel, en Almacenamiento.
   También se pueden pasar por variables de entorno: BP_ENDPOINT, BP_REGION,
   BP_ACCESS_KEY, BP_SECRET_KEY.

   Opciones:
     --conservar   no borra el bucket de prueba al terminar (para mirarlo)
     --bucket=X    usa ese nombre en vez de uno al azar

   ── Seguridad ──────────────────────────────────────────────────────────────

   Crea un bucket NUEVO, con nombre al azar, y trabaja solo adentro de ese.
   Nunca toca un bucket existente ni escribe en el de ningún cliente. Al
   terminar lo borra; si no puede, te dice el nombre para que lo borres a mano.
   ═══════════════════════════════════════════════════════════════════════════ */

const crypto = require('node:crypto');
const { crear } = require('../almacenamiento/s3.cjs');

// ── Argumentos ─────────────────────────────────────────────────────────────

const args = {};
for (const a of process.argv.slice(2)) {
  const m = a.match(/^--([^=]+)(?:=(.*))?$/);
  if (m) args[m[1]] = m[2] === undefined ? true : m[2];
}

const cfg = {
  endpoint: args.endpoint || process.env.BP_ENDPOINT,
  region: args.region || process.env.BP_REGION || 'us-east-1',
  accessKey: args.accessKey || process.env.BP_ACCESS_KEY,
  secretKey: args.secretKey || process.env.BP_SECRET_KEY,
};

if (!cfg.endpoint || !cfg.accessKey || !cfg.secretKey) {
  console.error(`
  Faltan datos de conexión.

    node herramientas/probar-e2-versionado.cjs \\
      --endpoint=https://TU-REGION.idrivee2.com \\
      --region=TU-REGION \\
      --accessKey=... --secretKey=...

  Son los mismos valores del panel, en Almacenamiento.
`);
  process.exit(2);
}

const BUCKET = args.bucket ||
  `bp-diagnostico-${crypto.randomBytes(5).toString('hex')}`;
const CLAVE = 'prueba/documento.txt';
const V1 = 'CONTENIDO-ORIGINAL-' + crypto.randomBytes(6).toString('hex');
const V2 = 'CONTENIDO-PISADO-' + crypto.randomBytes(6).toString('hex');

const sha256 = (d) => crypto.createHash('sha256').update(d).digest('hex');

// El almacén se crea apuntando al bucket de prueba. Se usa solo su petición
// firmada: las operaciones de bucket no están en el contrato del módulo.
const almacen = crear({ ...cfg, bucket: BUCKET });
const pedir = almacen.peticion;

// ── Salida ─────────────────────────────────────────────────────────────────

// El veredicto se arma con banderas explícitas, NO buscando texto en las
// preguntas: buscar por texto agarraba "crear un bucket CON Object Lock" y
// concluía que no se podían crear buckets cuando sí se habían creado sin lock.
const ESTADO = {
  creaBucket: null, conLock: null, versionado: null, recupera: null, protege: null,
};

const RESULTADOS = [];
function anotar(pregunta, veredicto, detalle) {
  RESULTADOS.push({ pregunta, veredicto, detalle });
  const marca = veredicto === 'sí' ? '  SÍ  ' : veredicto === 'no' ? '  NO  ' : '  ??  ';
  console.log(`${marca} ${pregunta}`);
  if (detalle) console.log(`       ${detalle}`);
}
const titulo = (t) => console.log(`\n${t}\n${'─'.repeat(t.length)}`);

const etiqueta = (xml, nombre) => {
  const m = String(xml).match(new RegExp(`<${nombre}[^>]*>([^<]*)</${nombre}>`));
  return m ? m[1] : null;
};
const cortar = (t, n = 180) => String(t || '').replace(/\s+/g, ' ').trim().slice(0, n);

// ═══ Recorrido ═════════════════════════════════════════════════════════════

(async () => {
  console.log(`
╔══════════════════════════════════════════════════════════════════════╗
║  BackupPrime — ¿se puede aprovisionar solo?                          ║
╚══════════════════════════════════════════════════════════════════════╝

  Proveedor : ${cfg.endpoint}
  Región    : ${cfg.region}
  Bucket    : ${BUCKET}  (nuevo, se borra al terminar)
`);

  let bucketCreado = false;
  let conObjectLock = false;

  // ── 1. Conexión ──────────────────────────────────────────────────────────
  titulo('1. Conexión');
  try {
    const r = await pedir('GET', '/', '');
    if (r.status === 200) {
      const cuantos = (r.cuerpo.match(/<Bucket>/g) || []).length;
      anotar('Las credenciales sirven', 'sí', `El proveedor contestó 200. Buckets a la vista: ${cuantos}.`);
    } else if (r.status === 403) {
      anotar('Las credenciales sirven', 'no',
        'Respondió 403. La clave no tiene permiso para listar buckets, o la firma no coincide. ' +
        'Ojo con el endpoint: el host entra en la firma.');
      return terminar(1);
    } else {
      anotar('Las credenciales sirven', '??', `Respondió ${r.status}. ${cortar(r.cuerpo)}`);
    }
  } catch (e) {
    anotar('Las credenciales sirven', 'no', `No se pudo conectar: ${e.message}`);
    return terminar(1);
  }

  // ── 2. Crear el bucket, pidiendo Object Lock ─────────────────────────────
  titulo('2. Crear el bucket por API');
  // En S3 el Object Lock SOLO se puede pedir al crear el bucket. Si acá no se
  // puede, ese bucket no va a poder tener protección anti-ransomware nunca.
  try {
    const r = await pedir('PUT', `/${BUCKET}`, '', {
      extra: { 'x-amz-bucket-object-lock-enabled': 'true' }, largo: 0,
    });
    if (r.status >= 200 && r.status < 300) {
      bucketCreado = true; conObjectLock = true;
      ESTADO.creaBucket = 'sí'; ESTADO.conLock = 'sí';
      anotar('Se puede crear un bucket CON Object Lock', 'sí',
        'El aprovisionamiento automático completo es posible.');
    } else {
      ESTADO.conLock = 'no';
      anotar('Se puede crear un bucket CON Object Lock', 'no',
        `Respondió ${r.status}. ${cortar(r.cuerpo)}`);
      // Segundo intento sin Object Lock: distingue "no soporta Object Lock" de
      // "no deja crear buckets".
      const r2 = await pedir('PUT', `/${BUCKET}`, '', { largo: 0 });
      if (r2.status >= 200 && r2.status < 300) {
        bucketCreado = true; ESTADO.creaBucket = 'sí';
        anotar('Se puede crear un bucket SIN Object Lock', 'sí',
          'Los buckets se crean solos, pero sin protección contra borrado.');
      } else {
        ESTADO.creaBucket = 'no';
        anotar('Se puede crear un bucket SIN Object Lock', 'no',
          `Respondió ${r2.status}. ${cortar(r2.cuerpo)} — los buckets habría que crearlos a mano.`);
        return terminar(1);
      }
    }
  } catch (e) {
    ESTADO.creaBucket = 'no';
    anotar('Se puede crear un bucket por API', 'no', e.message);
    return terminar(1);
  }

  // ── 3. Versionado ────────────────────────────────────────────────────────
  titulo('3. Versionado');
  const cuerpoVersionado =
    '<VersioningConfiguration xmlns="http://s3.amazonaws.com/doc/2006-03-01/">' +
    '<Status>Enabled</Status></VersioningConfiguration>';
  try {
    const r = await pedir('PUT', `/${BUCKET}`, 'versioning', {
      cuerpo: cuerpoVersionado, hashCuerpo: sha256(cuerpoVersionado),
      largo: Buffer.byteLength(cuerpoVersionado),
      extra: { 'content-type': 'application/xml' },
    });
    anotar('El proveedor ACEPTA activar el versionado', r.status < 300 ? 'sí' : 'no',
      `Respondió ${r.status}. ${r.status >= 300 ? cortar(r.cuerpo) : ''}`);
  } catch (e) {
    anotar('El proveedor ACEPTA activar el versionado', 'no', e.message);
  }

  // Que lo acepte no quiere decir que lo haya hecho. Se vuelve a preguntar.
  let versionadoActivo = false;
  try {
    const r = await pedir('GET', `/${BUCKET}`, 'versioning');
    const estado = etiqueta(r.cuerpo, 'Status');
    versionadoActivo = estado === 'Enabled';
    ESTADO.versionado = versionadoActivo ? 'sí' : 'no';
    anotar('Y al volver a preguntar, quedó activo', versionadoActivo ? 'sí' : 'no',
      `El proveedor informa: ${estado || '(sin estado)'}.`);
  } catch (e) {
    anotar('Y al volver a preguntar, quedó activo', '??', e.message);
  }

  // ── 4. La prueba de verdad: pisar un archivo y recuperar el anterior ──────
  titulo('4. La máquina del tiempo, comprobada de verdad');
  let idV1 = null;
  try {
    const p1 = await pedir('PUT', `/${BUCKET}/${CLAVE}`, '', {
      cuerpo: V1, hashCuerpo: sha256(V1), largo: Buffer.byteLength(V1),
    });
    if (p1.status >= 300) throw new Error(`no se pudo subir la primera versión (${p1.status})`);

    const p2 = await pedir('PUT', `/${BUCKET}/${CLAVE}`, '', {
      cuerpo: V2, hashCuerpo: sha256(V2), largo: Buffer.byteLength(V2),
    });
    if (p2.status >= 300) throw new Error(`no se pudo pisar el archivo (${p2.status})`);

    const lista = await pedir('GET', `/${BUCKET}`, 'versions');
    const ids = [...String(lista.cuerpo).matchAll(/<VersionId>([^<]*)<\/VersionId>/g)]
      .map((m) => m[1]).filter((v) => v && v !== 'null');
    anotar('Quedaron guardadas las dos versiones', ids.length >= 2 ? 'sí' : 'no',
      `El proveedor lista ${ids.length} versión(es) del archivo.`);

    // La última de la lista suele ser la más vieja, pero no se confía: se prueba
    // cada una hasta encontrar la que devuelve el contenido original.
    for (const id of ids) {
      const g = await pedir('GET', `/${BUCKET}/${CLAVE}`, `versionId=${encodeURIComponent(id)}`);
      if (g.status === 200 && g.cuerpo === V1) { idV1 = id; break; }
    }
    ESTADO.recupera = idV1 ? 'sí' : 'no';
    anotar('Y la versión ANTERIOR se baja con su contenido original',
      idV1 ? 'sí' : 'no',
      idV1 ? 'Volver una carpeta a una fecha va a funcionar en este bucket.'
           : 'El contenido viejo NO se pudo recuperar. Sin esto no hay máquina del tiempo.');
  } catch (e) {
    ESTADO.recupera = 'no';
    anotar('La máquina del tiempo funciona', 'no', e.message);
  }

  // ── 5. Object Lock: que el borrado sea RECHAZADO ─────────────────────────
  titulo('5. Protección contra borrado (anti-ransomware)');
  if (!conObjectLock) {
    ESTADO.protege = 'no';
    anotar('El bucket tiene Object Lock', 'no',
      'No se pudo pedir al crearlo, y en S3 no se puede agregar después.');
  } else {
    const hasta = new Date(Date.now() + 24 * 3600 * 1000).toISOString().replace(/\.\d{3}Z$/, 'Z');
    const CLAVE_L = 'prueba/protegido.txt';
    const DATO = 'NO-SE-PUEDE-BORRAR';
    let idProtegido = null;
    try {
      const p = await pedir('PUT', `/${BUCKET}/${CLAVE_L}`, '', {
        cuerpo: DATO, hashCuerpo: sha256(DATO), largo: Buffer.byteLength(DATO),
        extra: {
          'x-amz-object-lock-mode': 'GOVERNANCE',
          'x-amz-object-lock-retain-until-date': hasta,
        },
      });
      anotar('Se puede subir un objeto con retención', p.status < 300 ? 'sí' : 'no',
        p.status >= 300 ? `Respondió ${p.status}. ${cortar(p.cuerpo)}` : `Retenido hasta ${hasta}.`);

      if (p.status < 300) {
        const lista = await pedir('GET', `/${BUCKET}`, 'versions&prefix=prueba/protegido.txt');
        const m = String(lista.cuerpo).match(/<VersionId>([^<]*)<\/VersionId>/);
        idProtegido = m ? m[1] : null;

        if (idProtegido) {
          const d = await pedir('DELETE', `/${BUCKET}/${CLAVE_L}`,
            `versionId=${encodeURIComponent(idProtegido)}`);
          // Lo que queremos es que FALLE. Un 204 acá significa que la retención
          // no protege nada.
          ESTADO.protege = d.status === 403 ? 'sí' : 'no';
          anotar('Y el proveedor RECHAZA borrarlo', d.status === 403 ? 'sí' : 'no',
            d.status === 403
              ? 'Una clave robada por un ransomware no podría destruir el respaldo.'
              : `Respondió ${d.status}: el borrado NO fue rechazado. La retención no protege.`);
        } else {
          anotar('Y el proveedor RECHAZA borrarlo', '??',
            'No se pudo obtener el versionId del objeto protegido.');
        }
      }
    } catch (e) {
      anotar('La retención frena el borrado', '??', e.message);
    }
  }

  // ── 6. Limpieza ──────────────────────────────────────────────────────────
  titulo('6. Limpieza');
  if (args.conservar) {
    console.log(`       Se conserva el bucket ${BUCKET} porque pediste --conservar.`);
  } else {
    await limpiar(bucketCreado);
  }

  terminar(0);
})().catch((e) => {
  console.error('\n  Se cortó por un error inesperado:', e.message);
  process.exit(1);
});

// ═══ Limpieza y cierre ═════════════════════════════════════════════════════

async function limpiar(bucketCreado) {
  if (!bucketCreado) return;
  try {
    const lista = await pedir('GET', `/${BUCKET}`, 'versions');
    const entradas = [...String(lista.cuerpo).matchAll(
      /<(?:Version|DeleteMarker)>[\s\S]*?<Key>([^<]*)<\/Key>[\s\S]*?<VersionId>([^<]*)<\/VersionId>/g)];
    for (const [, clave, id] of entradas) {
      // El bypass hace falta para borrar lo que quedó bajo retención GOVERNANCE.
      await pedir('DELETE', `/${BUCKET}/${clave}`, `versionId=${encodeURIComponent(id)}`,
        { extra: { 'x-amz-bypass-governance-retention': 'true' } });
    }
    const r = await pedir('DELETE', `/${BUCKET}`, '');
    if (r.status >= 200 && r.status < 300) {
      console.log(`       Bucket ${BUCKET} borrado.`);
    } else {
      console.log(`       NO se pudo borrar el bucket (${r.status}).`);
      console.log(`       Borralo a mano desde la consola de tu proveedor: ${BUCKET}`);
    }
  } catch (e) {
    console.log(`       NO se pudo limpiar: ${e.message}`);
    console.log(`       Borralo a mano desde la consola de tu proveedor: ${BUCKET}`);
  }
}

function terminar(codigo) {
  const sinDato = '(no se llegó a probar)';
  const crea = ESTADO.creaBucket, versiona = ESTADO.versionado;
  const recupera = ESTADO.recupera, protege = ESTADO.protege;

  console.log(`
╔══════════════════════════════════════════════════════════════════════╗
║  VEREDICTO                                                           ║
╚══════════════════════════════════════════════════════════════════════╝

  Crear buckets por API .................... ${crea || sinDato}${crea === 'sí' && ESTADO.conLock === 'no' ? '  (pero sin Object Lock)' : ''}
  Versionado activo y comprobado ........... ${versiona || sinDato}
  Se recupera la versión anterior .......... ${recupera || sinDato}
  El borrado se rechaza (anti-ransomware) .. ${protege || sinDato}
`);

  if (crea === 'sí' && recupera === 'sí' && protege === 'sí') {
    console.log('  → Se puede aprovisionar TODO automático, con protección real.\n');
  } else if (crea === 'sí' && recupera === 'sí') {
    console.log('  → Se puede aprovisionar automático CON versionado.');
    console.log('    Sin Object Lock: un ransomware con la clave del cliente todavía');
    console.log('    podría borrar versiones. Conviene que la clave del agente NO');
    console.log('    tenga permiso de borrado.\n');
  } else if (crea === 'sí') {
    console.log('  → Los buckets se crean solos, pero NO se comprobó el historial de');
    console.log('    versiones. Sin eso no hay máquina del tiempo: no habilites el');
    console.log('    aprovisionamiento automático hasta resolverlo.\n');
  } else {
    console.log('  → Los buckets habría que crearlos a mano por ahora.\n');
  }

  process.exit(codigo);
}
