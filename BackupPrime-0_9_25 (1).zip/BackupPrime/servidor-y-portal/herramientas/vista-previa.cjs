'use strict';
/* Arma una copia de una página con el CSS y el JS metidos adentro, para poder
   verla sin levantar el servidor. Solo sirve para mirar: en producción van los
   archivos separados, que se cachean por separado.

     node herramientas/vista-previa.cjs index.html salida.html                */

const fs = require('node:fs');
const path = require('node:path');

const RAIZ = path.join(__dirname, '..');
const entrada = process.argv[2] || 'index.html';
const salida = process.argv[3] || 'vista-previa.html';
const demo = process.argv.includes('--demo');

let html = fs.readFileSync(path.join(RAIZ, entrada), 'utf8');

// CSS adentro
html = html.replace(/<link rel="stylesheet" href="([^"]+)" \/>/g, (m, href) => {
  const css = fs.readFileSync(path.join(RAIZ, href), 'utf8');
  return `<style>\n${css}\n</style>`;
});

// JS adentro
html = html.replace(/<script src="([^"]+)"><\/script>/g, (m, src) => {
  let js = fs.readFileSync(path.join(RAIZ, src), 'utf8');

  if (demo) {
    // Sin backend detrás, el alta se simula para poder recorrer los tres pasos.
    js = js.replace(
      /  function pedir\(ruta, cuerpo, token\) \{[\s\S]*?\n  \}\n/,
      `  function pedir(ruta, cuerpo) {
    // VISTA PREVIA: responde como respondería el backend, sin red.
    return new Promise(function (resolver, rechazar) {
      setTimeout(function () {
        if (ruta === '/registro') {
          if (cuerpo.email === 'ocupado@estudio.com.ar') {
            var e = new Error('Ya hay una cuenta con ese email.');
            e.status = 409;
            return rechazar(e);
          }
          return resolver({
            id: 'demo', email: cuerpo.email, token: 'demo',
            estado: 'prueba', descargaUrl: '#'
          });
        }
        if (ruta === '/suscripciones/checkout') {
          return rechazar(new Error('En la vista previa no se abre Mercado Pago.'));
        }
        resolver({ ok: true });
      }, 420);
    });
  }\n`);
  }
  return `<script>\n${js}\n</script>`;
});

// Enlaces entre páginas dentro de la vista previa
if (demo) {
  html = html.replace(/href="registro\.html([^"]*)"/g, 'href="#registro-en-el-zip"');
  html = html.replace(/href="index\.html"/g, 'href="#"');
  html = html.replace(/href="\/portal\/"/g, 'href="#portal-en-el-zip"');
}

fs.writeFileSync(path.join(RAIZ, salida), html);
console.log(`${salida} — ${(Buffer.byteLength(html) / 1024).toFixed(0)} KB`);
