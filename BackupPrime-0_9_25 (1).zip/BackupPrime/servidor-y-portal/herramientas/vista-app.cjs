'use strict';
/* Junta todas las pantallas en un solo archivo navegable y funcionando.

   El intento anterior las metía en marcos aislados y ahí adentro el código no
   corre, así que quedaba una foto. Acá se guarda cada pantalla como texto y al
   cambiar de una a otra se reemplaza el contenido y se vuelve a ejecutar su
   código. Como solo hay una pantalla en el documento por vez, no se pisan ni
   los estilos ni los nombres de los elementos.

     node herramientas/vista-app.cjs [salida.html]                            */

const fs = require('node:fs');
const path = require('node:path');

const RAIZ = path.join(__dirname, '..');
const SALIDA = process.argv[2] || 'vista-app.html';

const PANTALLAS = [
  { archivo: 'index.html',    nombre: 'Portada',
    nota: 'Arrastrá la línea de tiempo del hero, o esperá: salta sola al día del virus.' },
  { archivo: 'registro.html', nombre: 'Registro',
    nota: 'Los tres pasos funcionan. Probá un CUIT cualquiera, una clave corta, o ocupado@estudio.com.ar.' },
  { archivo: 'ingreso.html',  nombre: 'Ingreso',
    nota: 'Como cliente entrá con cualquier email y clave. Para el panel, tocá "Administración" y usá admin / admin.' },
  { archivo: 'descargas.html', nombre: 'Descargas',
    nota: 'A donde llega el cliente después de suscribirse.' },
  { archivo: 'portal.html',   nombre: 'Panel del cliente',
    nota: 'Andá a "Mis archivos": abrí carpetas, tildá una entera, hacé clic en un archivo para ver sus versiones.' },
  { archivo: 'admin.html',    nombre: 'Administración',
    nota: 'En "Almacenamiento" cambiá el proveedor y mirá cómo cambia el formulario. En "Cobranza" están tus 4 meses.' },
];

// La muestra no tiene servidor detrás. En vez de parchear función por función
// —que fue lo que dejó pasar un "Failed to fetch" a la cara del usuario— se
// reemplaza fetch entero por una red simulada. Así ninguna pantalla puede
// intentar salir a internet, pase lo que pase.
const RED_SIMULADA = `var fetch = function (url, opciones) {
  var ruta = String(url).replace(/^[^]*\\/api/, '');
  var cuerpo = {};
  try { cuerpo = JSON.parse((opciones && opciones.body) || '{}'); } catch (e) {}

  function r(estado, datos) {
    return {
      ok: estado < 400, status: estado,
      headers: { get: function () { return null; } },
      json: function () { return Promise.resolve(datos); },
      text: function () { return Promise.resolve(JSON.stringify(datos)); }
    };
  }

  return new Promise(function (resolver) {
    setTimeout(function () {
      switch (ruta) {
        case '/registro':
          if (cuerpo.email === 'ocupado@estudio.com.ar') {
            return resolver(r(409, { mensaje: 'Ya hay una cuenta con ese email.' }));
          }
          return resolver(r(201, { id: 'muestra', email: cuerpo.email, token: 'muestra',
                                   estado: 'prueba', descargaUrl: 'descargas.html' }));

        case '/suscripciones/plan':
          return resolver(r(200, { planId: cuerpo.planId, ok: true }));

        case '/suscripciones/checkout':
          return resolver(r(503, { mensaje: 'En esta muestra no se abre Mercado Pago.' }));

        case '/sesion':
          if (cuerpo.modo === 'admin') {
            var u = String(cuerpo.email || '').trim().toLowerCase();
            var c = String(cuerpo.clave || '').trim().toLowerCase();
            return u === 'admin' && c === 'admin'
              ? resolver(r(200, { destino: 'admin.html' }))
              : resolver(r(401, { mensaje: 'no coincide' }));
          }
          return resolver(r(200, { necesitaSegundoFactor: true }));

        case '/sesion/mfa':
          return resolver(r(200, { destino: cuerpo.modo === 'admin' ? 'admin.html' : 'portal.html' }));

        case '/clave/olvide':
          return resolver(r(200, { ok: true }));

        case '/admin/clave':
          return cuerpo.actual === 'admin'
            ? resolver(r(200, { ok: true }))
            : resolver(r(401, { mensaje: 'La contraseña actual no coincide.' }));

        case '/admin/almacenamiento/probar':
          return resolver(r(200, { ok: true,
            detalle: 'Conectado. En la muestra no se prueba contra el proveedor de verdad.' }));

        case '/portal/archivos':
          return resolver(r(200, {
            puedeDescargar: true, total: 3, topeMB: 512,
            archivos: [
              { ruta: 'C/Datos/Balances/Balance 2026.xlsx', nombre: 'Balance 2026.xlsx',
                carpeta: 'C/Datos/Balances', bytes: 2411724, modificado: Date.now() - 3600e3,
                fueraDelRespaldo: false },
              { ruta: 'C/Datos/Outlook/archivo.pst', nombre: 'archivo.pst',
                carpeta: 'C/Datos/Outlook', bytes: 682991616, modificado: Date.now() - 8 * 3600e3,
                fueraDelRespaldo: false },
              { ruta: 'D/Viejo/IVA 2024.pdf', nombre: 'IVA 2024.pdf',
                carpeta: 'D/Viejo', bytes: 184320, modificado: Date.now() - 240 * 86400e3,
                fueraDelRespaldo: true },
            ],
          }));

        case '/descargas/windows':
          return resolver(r(200, {
            disponible: true, url: '#', version: '0.9.21',
            megas: 78, bytes: 78 * 1048576,
            sha256: 'a'.repeat(64),
          }));

        case '/planes':
          return resolver(r(200, { planes: [
            { id: 'personal', nombre: 'Personal', espacioGB: 200, precioMensual: 16000 },
            { id: 'estudio', nombre: 'Estudio', espacioGB: 1000, precioMensual: 34900 },
            { id: 'empresa', nombre: 'Empresa', espacioGB: 3000, precioMensual: 74900 },
          ] }));

        // Datos de muestra con la MISMA forma que devuelve el backend. Van acá,
        // en la herramienta de vista, y no en el portal: la pantalla de verdad
        // no puede tener un solo número escrito a mano.
        case '/cuenta':
          return resolver(r(200, {
            id: 'muestra', email: 'vos@estudio.com.ar', organizacion: 'Estudio Contable Muestra',
            planId: 'estudio', estado: 'activa', moroso: false, espacioGB: 1000, mfa: true,
            facturas: [
              { fecha: '2026-08-01', numero: 'FC-B 0001-00000142', concepto: 'Plan Estudio · agosto',
                importe: 34900, estado: 'pagada' },
              { fecha: '2026-07-01', numero: 'FC-B 0001-00000121', concepto: 'Plan Estudio · julio',
                importe: 34900, estado: 'pagada' },
            ],
            cuota: { usadoBytes: 442381045862, limiteBytes: 1073741824000, espacioGB: 1000,
                     porcentaje: 41.2, estado: 'ok', puedeSubir: true, puedeRestaurar: true,
                     medidoEn: new Date(Date.now() - 26 * 60000).toISOString() },
            mensajeCuota: null,
            equipos: [
              { nombre: 'PC-CONTADURIA', bytes: 214748364800, archivos: 128400,
                ultimo_aviso: new Date(Date.now() - 42 * 60000).toISOString() },
              { nombre: 'PC-JORGE', bytes: 96636764160, archivos: 41200,
                ultimo_aviso: new Date(Date.now() - 5 * 3600000).toISOString() },
              { nombre: 'SERVIDOR-ESTUDIO', bytes: 128849018880, archivos: 96300,
                ultimo_aviso: new Date(Date.now() - 11 * 3600000).toISOString() },
              { nombre: 'PC-RECEPCION', bytes: 2147483648, archivos: 1800,
                ultimo_aviso: new Date(Date.now() - 12 * 86400000).toISOString() },
            ],
          }));

        case '/cuenta/sesiones':
          return resolver(r(200, { sesiones: [
            { id: 'aaaa1111', ip: '190.55.12.4', agente: 'Chrome en Windows',
              creada: new Date(Date.now() - 3 * 60000).toISOString() },
            { id: 'bbbb2222', ip: '190.55.12.4', agente: 'PC-CONTADURIA (0.9.21)',
              creada: new Date(Date.now() - 42 * 60000).toISOString() },
          ] }));

        default:
          return resolver(r(200, { ok: true }));
      }
    }, 340);
  });
};
`;

const paginas = PANTALLAS.map((p) => {
  const html = fs.readFileSync(path.join(RAIZ, p.archivo), 'utf8');

  const estilos = [...html.matchAll(/<style>([\s\S]*?)<\/style>/g)].map((m) => m[1]).join('\n');
  const cuerpo = (html.match(/<body>([\s\S]*?)<\/body>/) || [, ''])[1]
    .replace(/<script src="[^"]+"><\/script>/g, '');

  // Cada archivo va en su propio try/catch. En el sitio real son etiquetas
  // <script> separadas: si una falla, las otras siguen. Al juntarlas todas en
  // una sola función perdíamos esa propiedad y un error tumbaba la pantalla
  // entera.
  let codigo = [...html.matchAll(/<script src="([^"]+)"><\/script>/g)]
    .map((m) => {
      const fuente = fs.readFileSync(path.join(RAIZ, m[1]), 'utf8');
      return `try {\n${fuente}\n} catch (e) { console.error('${m[1]}:', e); }`;
    })
    .join('\n');

  codigo = RED_SIMULADA + '\n' + codigo;

  // Al entrar, el sitio real hace window.location.href = 'portal.html'. Acá no
  // hay páginas sueltas, así que eso se traduce a cambiar de pantalla. Sin
  // esto, entrar con usuario y contraseña no llevaba a ningún lado.
  codigo = codigo.replace(/window\.location\.href = ([^;]+);/g, 'window.__muestraIr($1);');


  // Sin backend, los planes salen de la copia local en lugar de pedirse.
  codigo = codigo.replace(
    /  function pedirPlanes\(\) \{[\s\S]*?\n  \}\n/,
    '  function pedirPlanes() { return Promise.resolve(RESPALDO); }\n');


  return { ...p, estilos, cuerpo, codigo, id: p.archivo.replace('.html', '') };
});

const base = fs.readFileSync(path.join(RAIZ, 'css/estilo.css'), 'utf8');

const documento = `<!DOCTYPE html>
<html lang="es-AR">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>BackupPrime — todas las pantallas</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet" />
<style>
${base}
</style>
<style id="estiloPantalla"></style>
<style>
  .selector { position: sticky; top: 0; z-index: 900; background: #0a0e1a; color: #fff;
              padding: 0 16px; display: flex; align-items: center; gap: 4px;
              flex-wrap: wrap; min-height: 52px; }
  .selector .marca { font-family: "Space Grotesk", sans-serif; font-weight: 700; font-size: .92rem;
                     margin-right: 12px; display: flex; align-items: center; gap: 8px; }
  .selector .marca svg { display: block; }
  .selector button { font: inherit; font-size: .86rem; font-weight: 500; padding: 6px 13px;
                     border-radius: 6px; border: 0; background: transparent;
                     color: rgba(255,255,255,.62); cursor: pointer; }
  .selector button:hover { color: #fff; background: rgba(255,255,255,.08); }
  .selector button.activa { background: #12969f; color: #fff; }
  .selector .paso { font-size: .7rem; opacity: .5; margin-right: 5px; font-variant-numeric: tabular-nums; }
  .pista { background: #fff; border-bottom: 1px solid #e3e8f5; padding: 10px 18px;
           font-size: .84rem; color: #6b7590; }
  .pista b { color: #0a0e1a; font-weight: 600; }
</style>
</head>
<body>

<div class="selector" id="selector">
  <span class="marca">
    <svg width="24" height="24" viewBox="0 0 256 256" aria-hidden="true">
      <rect x="73" y="66" width="110" height="34" rx="17" fill="#5cbcc3" opacity=".43"/>
      <rect x="60" y="121" width="135" height="34" rx="17" fill="#5cbcc3" opacity=".71"/>
      <rect x="49" y="176" width="155" height="34" rx="17" fill="#5cbcc3"/>
    </svg>
    <span>Backup<em style="font-style:normal;color:#5cbcc3;">Prime</em></span>
  </span>
</div>
<div class="pista" id="pista"></div>
<div id="pantalla"></div>

<script id="datos" type="application/json">${
  JSON.stringify(paginas.map((p) => ({
    id: p.id, nombre: p.nombre, nota: p.nota,
    estilos: p.estilos, cuerpo: p.cuerpo, codigo: p.codigo,
  }))).replace(/</g, '\\u003c')
}</script>

<script>
(function () {
  var PAGINAS = JSON.parse(document.getElementById('datos').textContent);
  var selector = document.getElementById('selector');
  var pista = document.getElementById('pista');
  var contenedor = document.getElementById('pantalla');
  var estilo = document.getElementById('estiloPantalla');
  var actual = -1;

  PAGINAS.forEach(function (p, i) {
    var b = document.createElement('button');
    b.innerHTML = '<span class="paso">' + (i + 1) + '</span>' + p.nombre;
    b.addEventListener('click', function () { mostrar(i); });
    selector.appendChild(b);
  });

  var botones = selector.querySelectorAll('button');

  function mostrar(i) {
    if (i === actual) return;
    actual = i;
    var p = PAGINAS[i];

    for (var j = 0; j < botones.length; j++) botones[j].classList.toggle('activa', j === i);
    pista.innerHTML = '<b>' + p.nombre + '.</b> ' + p.nota;

    estilo.textContent = p.estilos;
    contenedor.innerHTML = p.cuerpo;

    // El código de cada pantalla se vuelve a ejecutar sobre el contenido nuevo.
    try { new Function(p.codigo)(); }
    catch (e) { console.error('Error en ' + p.nombre + ':', e); }

    window.scrollTo({ top: 0 });
  }

  // Los enlaces entre páginas cambian de pantalla en lugar de navegar.
  var DESTINOS = { 'index.html': 0, 'registro.html': 1, 'ingreso.html': 2,
                   'descargas.html': 3, 'portal.html': 4, 'admin.html': 5 };
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('a[href]');
    if (!a) return;
    var href = (a.getAttribute('href') || '').split('/').pop();
    var ancla = href.split('#')[1] || '';
    var destino = DESTINOS[href.split('#')[0]];
    if (destino === undefined) return;
    e.preventDefault();
    mostrar(destino);
    // "Administración" en el pie abre el ingreso ya en ese modo.
    if (ancla === 'admin') {
      var b = document.querySelector('.modo button[data-modo="admin"]');
      if (b) b.click();
    }
  });

  // El código de las pantallas la usa en lugar de navegar de verdad.
  window.__muestraIr = function (destino) {
    var archivo = String(destino).split('/').pop().split('#')[0];
    var i = DESTINOS[archivo];
    if (i !== undefined) mostrar(i);
  };

  mostrar(0);
})();
</script>
</body>
</html>`;

fs.writeFileSync(path.join(RAIZ, SALIDA), documento);
console.log(`${SALIDA} — ${(Buffer.byteLength(documento) / 1024).toFixed(0)} KB, ${paginas.length} pantallas`);
