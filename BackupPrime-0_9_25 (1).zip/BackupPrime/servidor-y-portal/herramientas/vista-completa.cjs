'use strict';
/* Junta todas las pantallas en un solo archivo, cada una aislada en su propio
   marco para que los estilos y el código de una no pisen los de otra.
   Es solo para mirar: en producción cada página va por separado.

     node herramientas/vista-completa.cjs                                     */

const { execFileSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');

const RAIZ = path.join(__dirname, '..');
const SALIDA = process.argv[2] || 'vista-completa.html';

const PANTALLAS = [
  { archivo: 'index.html',    nombre: 'Portada',
    nota: 'Esperá un segundo con la línea de tiempo a la vista: salta sola al día del virus.' },
  { archivo: 'registro.html', nombre: 'Registro',
    nota: 'Los tres pasos funcionan. Probá un CUIT cualquiera, o ocupado@estudio.com.ar.' },
  { archivo: 'portal.html',   nombre: 'Panel del cliente',
    nota: 'Andá a "Mis archivos", abrí carpetas y hacé clic en un archivo para ver sus versiones.' },
  { archivo: 'admin.html',    nombre: 'Administración',
    nota: 'Mirá "Almacenamiento" y "Cobranza y mora": ahí se configura todo sin tocar código.' },
];

const escaparAtributo = (t) => t.replace(/&/g, '&amp;').replace(/"/g, '&quot;');

const paginas = PANTALLAS.map((p) => {
  const temporal = path.join(RAIZ, `.tmp-${p.archivo}`);
  execFileSync(process.execPath,
    [path.join(__dirname, 'vista-previa.cjs'), p.archivo, path.basename(temporal), '--demo'],
    { cwd: RAIZ });
  const html = fs.readFileSync(temporal, 'utf8');
  fs.unlinkSync(temporal);
  return { ...p, html };
});

const documento = `<!DOCTYPE html>
<html lang="es-AR">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>BackupPrime — todas las pantallas</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet" />
<style>
  :root { --marca:#0c08ff; --tinta:#0a0e1a; --linea:#e3e8f5; --bruma:#f4f6fb; --suave:#6b7590; }
  * { box-sizing: border-box; }
  body { margin:0; font-family:"Inter",system-ui,sans-serif; background:var(--bruma); color:var(--tinta); }

  .selector { position:sticky; top:0; z-index:100; background:var(--tinta); color:#fff;
              padding:0 18px; display:flex; align-items:center; gap:6px; flex-wrap:wrap; min-height:56px; }
  .selector .marca { font-family:"Space Grotesk",sans-serif; font-weight:700; font-size:.95rem;
                     margin-right:14px; display:flex; align-items:center; gap:8px; }
  .selector .cuadro { width:24px; height:24px; border-radius:6px; background:var(--marca);
                      display:grid; place-items:center; font-size:.8rem; }
  .selector button { font:inherit; font-size:.88rem; font-weight:500; padding:7px 14px; border-radius:6px;
                     border:0; background:transparent; color:rgba(255,255,255,.65); cursor:pointer; }
  .selector button:hover { color:#fff; background:rgba(255,255,255,.08); }
  .selector button[aria-selected="true"] { background:var(--marca); color:#fff; font-weight:600; }
  .selector .paso { font-size:.72rem; opacity:.45; margin-right:4px; font-variant-numeric:tabular-nums; }

  .nota { background:#fff; border-bottom:1px solid var(--linea); padding:11px 20px;
          font-size:.86rem; color:var(--suave); }
  .nota b { color:var(--tinta); font-weight:600; }

  .pantalla { display:block; }
  .pantalla > h2 { font-family:"Space Grotesk",sans-serif; font-size:1rem; margin:0;
                   padding:14px 20px 0; }
  .pantalla iframe { width:100%; height:min(1500px, 88vh); border:0; display:block; background:#fff; }
  /* Sin JavaScript se ven las cuatro, una abajo de la otra. Con JavaScript,
     una por vez. */
  .conJs .pantalla { display:none; }
  .conJs .pantalla.activa { display:block; }
  .conJs .pantalla > h2 { display:none; }
</style>
</head>
<body>

<div class="selector" role="tablist">
  <span class="marca"><span class="cuadro">B</span> BackupPrime</span>
  ${paginas.map((p, i) => `<button role="tab" data-i="${i}" aria-selected="${i === 0}">` +
      `<span class="paso">${i + 1}</span>${p.nombre}</button>`).join('\n  ')}
</div>

<div class="nota" id="nota"><b>Portada.</b> ${paginas[0].nota}</div>

${paginas.map((p, i) => `<section class="pantalla${i === 0 ? ' activa' : ''}" data-i="${i}">
  <h2>${i + 1}. ${p.nombre}</h2>
  <iframe title="${p.nombre}" srcdoc="${escaparAtributo(p.html)}"></iframe>
</section>`).join('\n')}

<script>
(function () {
  var notas = ${JSON.stringify(paginas.map((p) => ({ nombre: p.nombre, nota: p.nota })))};
  document.body.classList.add('conJs');
  var botones = document.querySelectorAll('.selector button');
  var pantallas = document.querySelectorAll('.pantalla');
  function mostrar(i) {
    for (var j = 0; j < botones.length; j++) botones[j].setAttribute('aria-selected', j === i);
    for (var k = 0; k < pantallas.length; k++) pantallas[k].classList.toggle('activa', k === i);
    document.getElementById('nota').innerHTML = '<b>' + notas[i].nombre + '.</b> ' + notas[i].nota;
    window.scrollTo({ top: 0 });
  }
  for (var b = 0; b < botones.length; b++) {
    botones[b].addEventListener('click', function () { mostrar(Number(this.dataset.i)); });
  }
})();
</script>
</body>
</html>`;

fs.writeFileSync(path.join(RAIZ, SALIDA), documento);
console.log(`${SALIDA} — ${(Buffer.byteLength(documento) / 1024).toFixed(0)} KB, ${paginas.length} pantallas`);
