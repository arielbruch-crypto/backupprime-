# Poner BackupPrime en producción

En orden. Cada paso se puede verificar antes de pasar al siguiente, y hasta el
paso 6 nadie de afuera ve nada.

---

## 1. El servidor

En DonWeb, un Cloud Server con Ubuntu 22.04 o 24.04. Con 2 núcleos, 4 GB de RAM
y 40 GB de disco alcanza para los primeros cientos de clientes: los archivos no
viven acá, viven en el storage.

```bash
# Node 22, que es el que trae SQLite adentro
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs

sudo adduser --system --group --home /opt/backupprime backupprime
sudo mkdir -p /opt/backupprime/datos
sudo chown -R backupprime:backupprime /opt/backupprime
```

Subí el proyecto a `/opt/backupprime` y probá que arranque:

```bash
sudo -u backupprime PORT=4000 BACKUPPRIME_HTTPS=0 node --no-warnings servidor/servidor.cjs
```

## 2. Que quede corriendo siempre

`/etc/systemd/system/backupprime.service`:

```ini
[Unit]
Description=BackupPrime
After=network.target

[Service]
User=backupprime
WorkingDirectory=/opt/backupprime
Environment=PORT=4000
Environment=BACKUPPRIME_BASE=/opt/backupprime/datos/backupprime.db
ExecStart=/usr/bin/node --no-warnings servidor/servidor.cjs
Restart=always
RestartSec=3

# Que el proceso no pueda tocar más de lo que necesita
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
PrivateTmp=true
ReadWritePaths=/opt/backupprime/datos

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable --now backupprime
sudo systemctl status backupprime
```

## 3. HTTPS

Sin esto no se sube nada: las contraseñas viajarían en claro. Caddy lo resuelve
con dos líneas y renueva el certificado solo.

```bash
sudo apt install -y caddy
```

`/etc/caddy/Caddyfile`:

```
backupprime.com, www.backupprime.com {
    reverse_proxy localhost:4000
    encode gzip

    header {
        Strict-Transport-Security "max-age=31536000; includeSubDomains"
        X-Content-Type-Options "nosniff"
        Referrer-Policy "strict-origin-when-cross-origin"
        -Server
    }
}
```

Antes apuntá el dominio: `A` de `backupprime.com` y de `www` a la IP del
servidor. Después `sudo systemctl reload caddy` y verificá que
`https://backupprime.com` responda.

## 4. Respaldo de la base

**Este paso no es opcional.** La base es un archivo y tiene la relación entre
cada cliente y sus datos. Si se pierde, los archivos siguen en el storage pero
no sabés de quién es cada uno.

`/opt/backupprime/respaldar.sh`:

```bash
#!/bin/bash
set -e
DESTINO=/opt/backupprime/respaldos
mkdir -p "$DESTINO"
FECHA=$(date +%Y%m%d-%H%M)
# .backup de sqlite3 copia en caliente, sin cortar el servicio
sqlite3 /opt/backupprime/datos/backupprime.db ".backup '$DESTINO/base-$FECHA.db'"
gzip -f "$DESTINO/base-$FECHA.db"
find "$DESTINO" -name 'base-*.db.gz' -mtime +30 -delete
```

Cada hora, con `crontab -e` del usuario `backupprime`:

```
0 * * * * /opt/backupprime/respaldar.sh
```

Y una copia **afuera del servidor**: el respaldo que vive en el mismo disco que
el original no es un respaldo. Mandalo al storage o a otro lado.

## 5. El almacenamiento

Entrá al panel con **admin / admin**, andá a Administración → Mi cuenta y
**cambiá la contraseña**. Después a Almacenamiento:

1. Elegí iDrive e2 (o el proveedor que hayas contratado).
2. Cargá endpoint, región, bucket y claves.
3. **Probar conexión.** El sistema no te deja guardar una configuración que no
   responda.

Antes de esto conviene tener las respuestas de iDrive sobre límite de buckets,
claves acotadas por prefijo y modo governance del Object Lock.

## 6. Mercado Pago

En el panel de desarrolladores de Mercado Pago:

1. Creá la aplicación y sacá el **access token**. Empezá con las credenciales de
   **prueba**.
2. Configurá la URL del webhook: `https://backupprime.com/api/webhooks/mercadopago`
3. Guardá el secreto de firma del webhook.

Los tres valores van en la tabla de ajustes, clave `mercadopago`. En cuanto haya
`accessToken` cargado, la pantalla de pago simulado se apaga sola y el checkout
lleva a Mercado Pago de verdad.

Probá el circuito completo con una tarjeta de prueba: alta, cobro, y que la
cuenta quede activa con su factura.

## 7. Facturación electrónica

Contratá un proveedor con API — TusFacturas, Facturante o similar — y cargá sus
credenciales. Antes de eso, hablá con tu contador sobre con qué condición fiscal
vas a facturar: si es monotributo, una suscripción que crece te hace saltar de
categoría y eso cambia el precio de los planes.

Hasta que esté, la factura se anota en la base sin CAE. Sirve para llevar la
cuenta, no para entregársela al cliente.

## 8. Correo

Los avisos se encolan en la tabla `avisos` y se ven desde el panel. Para que
salgan de verdad hace falta un servicio de envío. **No uses el servidor de correo
del hosting**: los mails van a caer en spam. Un servicio transaccional
(Postmark, Brevo, Amazon SES) con el dominio verificado por SPF, DKIM y DMARC.

## 9. El instalador

Subí `BackupPrime-Setup-0.5.7.exe` a `/opt/backupprime/descargas/` y verificá
que `https://backupprime.com/descargas.html` lo ofrezca. Actualizá el código
SHA-256 que muestra esa página.

Y tramitá la firma digital del ejecutable. Es el primer obstáculo de la venta: un
estudio contable que ve "editor desconocido" cierra la ventana.

---

## Antes de abrir la puerta

- [ ] Contraseña del panel cambiada
- [ ] Segundo factor activado en el panel
- [ ] HTTPS andando, HTTP redirige
- [ ] Respaldo de la base corriendo y **probado restaurándolo**
- [ ] Almacenamiento configurado y probado
- [ ] Mercado Pago en producción, circuito de cobro probado de punta a punta
- [ ] Facturación emitiendo con CAE
- [ ] Mails saliendo y llegando a Gmail sin caer en spam
- [ ] Un alta completa hecha por vos, con tu tarjeta, de principio a fin
- [ ] Una restauración completa hecha por vos desde el portal y desde el programa
- [ ] Términos y política de privacidad publicados
- [ ] Precios revisados con tu contador

## El primer mes

Poné en la agenda, una vez por semana:

1. Mirar el panel: equipos que dejaron de respaldar, cobros rechazados, cuentas
   cerca del límite de espacio.
2. Bajar un archivo al azar de un cliente real y abrirlo. Un respaldo que nunca
   se restauró es una carpeta con datos.
3. Revisar que los respaldos de la base estén saliendo.

## Cuánto sale por mes

| Qué | Aproximado |
|---|---|
| Cloud Server en DonWeb | según plan |
| Storage | por TB usado |
| Servicio de correo | gratis hasta cierto volumen |
| Facturación electrónica | por comprobante o abono |
| Certificado de firma de código | anual |

Con los primeros diez clientes en el plan Estudio, la infraestructura se paga
sola varias veces.
