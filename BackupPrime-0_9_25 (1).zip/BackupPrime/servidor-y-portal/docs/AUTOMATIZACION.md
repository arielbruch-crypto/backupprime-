# De la publicidad al primer respaldo, sin que nadie intervenga

El objetivo que planteaste: el cliente se suscribe, baja el programa y empieza a
trabajar. Traducido a pasos, y marcando cuál falta:

| # | Qué pasa | Dónde vive | Estado |
|---|---|---|---|
| 1 | Entra al sitio y elige plan | `index.html` | ✅ hecho |
| 2 | Crea cuenta con email y contraseña | `registro.html` → `POST /api/registro` | ✅ hecho |
| 3 | **Se crea su espacio en iDrive e2** | backend | ⚠️ definido, falta enchufar |
| 4 | Carga la tarjeta en Mercado Pago | `POST /api/suscripciones/checkout` | ✅ contrato listo |
| 5 | **Se acredita el pago solo** | webhook | ✅ contrato y pruebas listos |
| 6 | Baja el programa ya asociado a su cuenta | pantalla final del registro | ⚠️ ver abajo |
| 7 | Entra con el mismo email y respalda | cliente 0.5.7 | ✅ funciona |
| 8 | Restaura desde la web | portal | ❌ falta |

Los dos puntos flojos son el 3 y el 6, y el 6 es el que más fricción te genera
en la venta.

---

## El paso 3: crear el espacio del cliente

Que el cliente no sepa dónde están sus datos es una decisión de producto
correcta, pero implica que el programa **nunca** puede tener credenciales de
iDrive. Si las tuviera, alcanza con abrir el ejecutable con un editor para
sacarlas y llegar al bucket de todos los clientes.

Dos formas de resolverlo, en orden de preferencia:

**Que el backend sea el que escribe.** El programa sube a tu API y tu API
escribe en iDrive. Es lo que ya hace el cliente hoy. Ventaja: el secreto nunca
sale del servidor y podés medir cuota y cortar abusos en un solo lugar.
Desventaja: todo el tráfico de respaldo pasa por tu servidor de DonWeb, así que
el ancho de banda y la CPU de ese servidor son tu techo de crecimiento.

**Credenciales temporales acotadas.** El backend le da al programa credenciales
que vencen en una hora y solo pueden escribir bajo `clientes/<id>/`. El programa
sube directo a iDrive. Ventaja: tu servidor deja de ser el cuello de botella.
Desventaja: depende de que iDrive e2 soporte STS o políticas por prefijo — hay
que confirmarlo con ellos antes de diseñarlo así.

Arrancá con la primera, que ya la tenés, y medí. Cuando el tráfico moleste,
migrás.

**Creá el espacio en el alta, no en el pago.** Si esperás al pago, la prueba de
14 días no puede respaldar nada y perdés al cliente antes de cobrarle. La
provisión tiene que ser idempotente: si se llama dos veces, no rompe.

## El paso 6: que el programa sepa quién lo bajó

Hoy el cliente baja el instalador, lo instala y escribe su email y contraseña.
Es un paso donde la gente se traba y te llama.

**Instalador con el alta adentro.** Al terminar el registro le das un link con
un token de un solo uso y corto: `/descargas/cliente?t=…`. El backend genera el
instalador con ese token embebido; al abrirse por primera vez lo canjea, se
registra el equipo solo y arranca eligiendo carpetas. El cliente nunca escribe
la contraseña en el programa. Requiere firmar el ejecutable — que ya te falta
igual, así que conviene resolver las dos cosas juntas.

Mientras tanto, lo barato: mandale el mail con el link de descarga y su email ya
escrito en el mensaje, para que solo tenga que poner la contraseña.

---

## Seguridad: lo que hay que tener antes de vender

Estás guardando papeles de trabajo de terceros. Si te entran, el problema no es
tuyo solo, es de cada estudio que te confió sus clientes.

**Lo que ya está en el código que te entrego**

- Contraseñas con `scrypt` y sal por usuario, nunca en claro ni con MD5/SHA.
- Webhook con firma verificada en tiempo constante y descarte de repetidos.
- Validación duplicada: navegador y servidor.
- `Cache-Control: no-store` y `X-Content-Type-Options: nosniff` en la API.
- La contraseña no toca `localStorage` ni la URL.
- CUIT validado con dígito verificador: un CUIT mal tipeado hoy es una factura
  rechazada el mes que viene.

**Lo que falta y te recomiendo, en orden de importancia**

1. **HSTS y HTTPS obligatorio.** `Strict-Transport-Security: max-age=31536000; includeSubDomains`.
2. **Límite de intentos de ingreso.** Cinco por email y por IP cada quince
   minutos. Sin esto, un diccionario contra tu login es cuestión de horas.
3. **Content-Security-Policy.** El sitio no usa JavaScript embebido salvo la
   pantalla simulada de Mercado Pago, así que podés poner una política estricta
   casi sin trabajo.
4. **Cookies de sesión `HttpOnly`, `Secure` y `SameSite=Lax`,** en vez de token
   en memoria, para el portal. Un token en JavaScript es robable con cualquier XSS.
5. **Segundo factor obligatorio para el panel de administración.** Tu panel
   puede ver los datos de todos los clientes: es el objetivo más valioso.
   Ponelo además en un subdominio aparte y, si podés, detrás de lista blanca de IP.
6. **Registro de auditoría.** Quién entró, desde dónde, qué restauró y qué borró.
   El día que un cliente pregunte "¿alguien vio mis archivos?", necesitás poder
   responder con datos.
7. **Borrado diferido.** Que una cancelación no borre nada por 30 días. Protege
   contra el empleado enojado y contra tu propio error.
8. **Probá la restauración vos, todos los meses.** Un backup que nunca se
   restauró es una carpeta con datos, no un respaldo. Que sea una tarea agendada.
9. **Tipografías propias en vez del CDN de Google.** Un pedido menos a un
   tercero desde la computadora de tus clientes, y carga más rápido.
10. **Página de estado del servicio.** Cuando algo se caiga, que puedan mirar un
    lugar en vez de llamarte.

---

## Estética: dos cosas concretas

El sitio ya sigue tu marca. Dos observaciones para cuando lo pases a producción:

- **Poné capturas reales del programa** en la sección de cómo funciona. Nada
  convence más que ver la pantalla que van a usar. Hoy hay una lista de texto.
- **Mostrá quién sos.** Un estudio contable de Adrogué le confía los papeles de
  sus clientes a alguien: una foto, un nombre, un teléfono y una dirección valen
  más que cualquier sello de seguridad. Es tu ventaja sobre iDrive, no tu
  desventaja.

---

## Después del sitio: los celulares

Cuando encaremos Android e iOS, dos cosas que conviene dejar preparadas ahora
para no rehacerlas:

- **La API de respaldo tiene que ser la misma** para el programa de escritorio y
  para los teléfonos. Si el móvil termina con rutas propias, vas a mantener dos
  backends.
- **iOS no deja respaldar en segundo plano como Windows.** Lo que se puede hacer
  es fotos, videos, contactos y calendario, disparado cuando la app está abierta
  o con las ventanas que da el sistema. Conviene que la publicidad del móvil hable
  de "las fotos y los contactos" y no de "todo el teléfono", para no prometer lo
  que la plataforma no permite.
