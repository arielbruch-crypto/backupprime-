# Decisiones tomadas

Las que se pueden decidir sin esperar a nadie, con el motivo y con qué cambiaría
si el motivo deja de valer.

## Mora: 4 meses, con las bajadas siempre vivas

Día 1 aviso, día 5 se suspenden las subidas, avisos a los 15, 30, 90 y 110, y a
los 120 se borra. Treinta días más de recuperación solo desde tu panel.

La restauración funciona hasta el último día. Un cliente que no puede sacar sus
archivos porque debe dos meses siente que le secuestraste los datos, y se lo
cuenta al estudio de al lado.

Configurable desde **Administración → Cobranza y mora**, sin tocar código.

## Storage: cualquiera, y cambiarlo es una pantalla

El sistema no habla con iDrive: habla con `almacenamiento/`. Hoy sirven iDrive
e2, Backblaze B2, Wasabi, Amazon S3, MinIO y una carpeta del servidor.

Los dos motores pasan **las mismas 51 pruebas**. Eso es lo que garantiza que
sean intercambiables: si uno pasa y el otro no, no son equivalentes y el sistema
se rompería al cambiar. Cuando agregues un proveedor, lo sumás a la lista y en
un minuto sabés si sirve.

La migración es reanudable: copia lo que falta, saltea lo que ya está, y se
puede cortar y retomar. Mientras corre, los clientes siguen trabajando contra el
proveedor viejo.

## Subidas por tu API, bajadas directo del proveedor

Las subidas siguen pasando por el backend: ya funciona, no requiere tocar el
cliente y la llave del storage nunca sale del servidor. Las bajadas van con
enlace firmado directo al proveedor, que es el caso pesado y en ráfaga.

**Revisar cuando**: los respaldos concurrentes empiecen a poner lento el portal.
Ahí se cambia solo esa mitad.

## Región y qué decimos sobre los datos

No hay región de e2 en Sudamérica. Frankfurt o París pueden salir más simples
legalmente que Miami, porque la ley argentina de datos personales trata distinto
a los países con protección adecuada. Confirmalo con un abogado.

Del sitio saqué **"datos alojados en la Argentina"**, que era falso y lo había
escrito yo. Quedó *empresa argentina, facturación en pesos, soporte en
castellano*, que es cierto y vende igual o mejor.

## Facturación: con proveedor, no contra ARCA

Certificados, punto de venta y CAE por comprobante no es donde querés gastar tus
meses. Antes de eso, preguntale a tu contador con qué condición fiscal vas a
facturar: si es monotributo, una suscripción que crece te hace saltar de
categoría y eso cambia el precio de los planes.

---

# ¿Conviene comprar equipos propios?

Preguntaste si es mejor invertir en fierros. **Todavía no, y el número que lo
dispara es 200 TB.**

Con 8 TB en la nube pagás algo así como 40 dólares por mes. Para tener eso
propio y que sea un respaldo de verdad necesitás dos servidores en dos edificios
distintos —si están en el mismo lugar no es respaldo, es un disco más—, discos
en RAID, enlaces simétricos en las dos puntas, energía redundante, repuestos y
alguien que atienda a las tres de la mañana. Son varios miles de dólares de
entrada y un costo mensual que no baja, contra cuarenta dólares.

El punto donde se da vuelta está por encima de los 200 TB almacenados, que a tus
planes actuales son varios cientos de clientes. Cuando llegues ahí, ya vas a
tener con qué pagar a alguien que lo opere.

Hay un argumento más fuerte que el costo: **le estás vendiendo a estudios que
tienen los papeles de sus clientes**. Si el disco se rompe un sábado, el
problema no es tuyo, es de cada uno de ellos. Un proveedor grande replica solo y
te responde por eso. Vos, con dos servidores, no.

Y hay una tercera opción que no es ninguna de las dos: **el mismo archivo en dos
proveedores distintos**. Cuesta el doble de almacenamiento —que es la parte
barata— y te saca de encima el riesgo de que un proveedor te cierre la cuenta.
El código ya lo permite: son dos almacenes configurados. Ese sería mi próximo
paso antes que comprar equipos.

Si igual querés equipos propios, MinIO ya está en la lista de proveedores: el
mismo código, otra configuración. La decisión no te queda trabada.
