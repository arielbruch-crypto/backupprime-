# De tener solo el dominio a estar funcionando

Punto de partida: `backupprime.com` registrado en DonWeb, nada más.

El orden importa. Está pensado para que las esperas —propagación de DNS,
verificaciones, trámites— corran en paralelo mientras hacés otra cosa, y para
que **nadie de afuera vea nada hasta que vos quieras**.

---

## Día 1 — Comprar

### En DonWeb

**Cloud Server Linux.** No hosting compartido: BackupPrime es un proceso
corriendo todo el día con su propia base de datos.

| Recurso | Con qué arrancar |
|---|---|
| vCPU | 2 |
| RAM | 4 GB |
| Disco | 40 GB SSD |
| Transferencia | La más alta que ofrezcan (ver la cuenta más abajo) |
| Sistema | Ubuntu 24.04 LTS, instalación mínima |
| Backups del proveedor | Sí |

Sin licencias de cPanel, Ferozo ni Windows. Sin correo del hosting. Sin SSL
pago: el certificado lo saca Caddy solo.

Cuando termines vas a tener una **IP** y una **clave de root**. Con eso empieza
todo lo demás.

### Fuera de DonWeb

**Casillas de correo.** Google Workspace o Zoho Mail. Contratá **una sola
casilla** y creá `hola@` y `soporte@` como alias, que no se cobran.

**Servicio de envío automático.** Es por donde salen los avisos y las facturas
del sistema. **Podés usar el de DonWeb** y tener todo en una sola factura en
pesos: el sistema habla con cualquier proveedor por SMTP y se elige desde el
panel, así que empezar con ellos no te ata a nada.

Antes de contratarlo, preguntales tres cosas:

1. ¿Tienen SMTP autenticado o API para mandar de a un mail desde una aplicación,
   o solo campañas desde el panel? Una factura no puede esperar a un envío masivo.
2. ¿Puedo configurar DKIM propio para `avisos.backupprime.com`?
3. ¿Cuál es el límite de envíos por hora y qué pasa si lo paso?

Si las tres dan bien, arrancá con ellos. Si no, Brevo o Postmark, y el día que
quieras volver cambiás una pantalla.

**Registrá también `backupprime.com.ar`.** Sale poco y evita que alguien lo tome
cuando empieces a hacerte conocido acá.

---

## Día 1, mientras tanto — DNS y correo

El correo no depende del servidor, así que se puede dejar andando hoy mismo.

En el panel de DNS de DonWeb, para `backupprime.com`:

| Tipo | Nombre | Valor | Para qué |
|---|---|---|---|
| MX | `@` | Los que te dé Google o Zoho | Dónde se reciben tus mails |
| TXT | `@` | El SPF que te dé tu proveedor de casillas | Quién puede enviar en tu nombre |
| TXT | `selector._domainkey` | El DKIM de tu proveedor de casillas | Firma que verifica que el mail es tuyo |
| TXT | `_dmarc` | `v=DMARC1; p=none; rua=mailto:hola@backupprime.com` | Qué hacer con los que no verifican |
| TXT | `avisos` | El SPF del servicio de envío | Autoriza el subdominio de avisos |
| TXT | `sel._domainkey.avisos` | El DKIM del servicio de envío | Lo mismo, para los automáticos |

**Los envíos automáticos van por el subdominio `avisos.backupprime.com`, no por
el dominio principal.** La reputación de envío se construye por dominio: si
algún día un aviso automático cae mal, con la separación tu correo personal
sigue llegando. Sin ella se cae todo junto y te enterás cuando un cliente te
dice que no le contestás los mails.

**Un solo SPF por dominio.** Si ponés dos registros SPF en `@`, se rompen los
dos y tus mails empiezan a caer en spam sin ningún aviso. Es la razón práctica
más fuerte para usar el subdominio.

`p=none` en DMARC quiere decir "por ahora solo observá". Cuando lleves unas
semanas viendo que todo verifica bien, se pasa a `p=quarantine`.

**Todavía no toques el registro A.** Mientras no exista, nadie que escriba
`backupprime.com` en el navegador ve nada. Esa es tu red de seguridad.

Probá que el correo ande mandándote un mail a vos mismo y otro desde una casilla
de Gmail.

---

## Día 2 — El servidor

Con la IP y la clave de root, seguí `PRODUCCION.md` de la carpeta `docs`. En
resumen:

1. Instalar Node 22 y crear el usuario del servicio.
2. Subir el proyecto a `/opt/backupprime`.
3. Dejarlo corriendo como servicio con systemd.
4. Instalar Caddy para el HTTPS.
5. **Configurar el respaldo de la base y probar restaurarlo.**

Para probar antes de que exista el dominio, entrá por
`http://LA-IP-DEL-SERVIDOR:4000`. Funciona todo salvo el HTTPS.

---

## Día 3 — Conectar los servicios

Desde el panel de administración, con **admin / admin**, y lo primero es
cambiar esa contraseña.

**Almacenamiento.** Cargá las claves de iDrive e2 y tocá *Probar conexión*. El
sistema no te deja guardar una configuración que no responda.

**Mercado Pago.** Credenciales de **prueba** primero. La URL del webhook es
`https://backupprime.com/api/webhooks/mercadopago`.

**Correo.** Las credenciales del servicio de envío.

**Precios.** Revisalos antes de que los vea alguien.

---

## Día 4 — Abrir la puerta

Recién ahora, en el DNS:

| Tipo | Nombre | Valor |
|---|---|---|
| A | `@` | La IP del servidor |
| A | `www` | La IP del servidor |

En cuanto propaga —de minutos a un par de horas— Caddy saca el certificado solo
y el sitio queda en línea con HTTPS.

Antes de contarle a nadie, hacé **vos** el camino completo: entrá al sitio,
suscribite con tu tarjeta de prueba, bajá el programa, instalalo, respaldá una
carpeta, y **restaurá un archivo desde la web y desde el programa**. Si algo de
eso no funciona, mejor descubrirlo vos.

---

## La cuenta que conviene hacer antes: la transferencia

Las subidas de los clientes pasan por tu servidor antes de ir a iDrive, así que
**cada gigabyte cuenta dos veces**: entra desde la computadora del cliente y
sale hacia el storage.

Un estudio que respalda 200 GB la primera vez consume 400 GB de transferencia.
Diez clientes nuevos en un mes son 4 TB.

Tres formas de manejarlo:

1. Contratá transferencia de sobra y mirá el consumo las primeras semanas.
2. Escaloná las altas: el primer respaldo es el pesado, después solo sube lo que
   cambió.
3. Si el consumo se vuelve el costo principal, ahí conviene que el programa suba
   directo a iDrive con credenciales temporales. Esa mitad del sistema quedó
   preparada para cambiar, y este es el disparador concreto.

**Preguntale a soporte de DonWeb antes de pagar:** si la transferencia cuenta el
tráfico entrante, el saliente o los dos, y qué pasa si te pasás. La respuesta
cambia el plan que te conviene.

---

## Lo que puede correr en paralelo desde hoy

Estos dos son trámites con espera, así que arrancalos el día 1 aunque el resto
no esté:

**El certificado de firma del instalador.** Entre tres días y dos semanas. Sin
él, Windows le muestra "Editor desconocido" a cada cliente. Está todo en
`FIRMA.md`.

**La facturación electrónica.** Elegí proveedor y hablá con tu contador sobre
con qué condición fiscal vas a facturar. Si es monotributo, una suscripción que
crece te hace saltar de categoría, y eso cambia el precio de tus planes.

---

## Antes de vender

- [ ] Contraseña del panel cambiada y segundo factor activado
- [ ] HTTPS andando
- [ ] Respaldo de la base corriendo **y probado restaurándolo**
- [ ] Mercado Pago en producción, cobro probado de punta a punta
- [ ] Mails llegando a Gmail sin caer en spam
- [ ] Un alta completa hecha por vos
- [ ] Una restauración completa hecha por vos, desde la web y desde el programa
- [ ] Términos y política de privacidad publicados
- [ ] Precios revisados con tu contador
