# Contrato de la API del sitio

El sitio no sabe nada del backend salvo estas rutas. Mientras tu Fastify las
respete, el sitio funciona sin tocarle una línea.

Está escrito dos veces a propósito: acá en prosa y en `api-mock/servidor.cjs`
como código que corre. Y `pruebas/flujo.cjs` lo verifica. Para probar el
backend real:

```
BASE=https://backupprime.com node pruebas/flujo.cjs
```

Si las 42 pruebas pasan contra tu servidor, el sitio va a andar.

---

## `GET /api/planes`

Los precios viven en el backend, no en el sitio. Cambiás un precio en un lugar
y queda cambiado en la portada, en el formulario y en la factura.

```json
{ "planes": [
  { "id": "profesional", "nombre": "Profesional", "para": "Estudios de 4 a 15 personas",
    "precioMensual": 34900, "espacioGB": 1000, "destacado": true,
    "incluye": ["Equipos ilimitados", "1 TB de espacio"] }
]}
```

`precioMensual` en pesos enteros, IVA incluido. Exactamente un plan con
`destacado: true`.

## `POST /api/registro`

```json
{ "organizacion": "Estudio Molina", "email": "ana@estudio.com.ar",
  "clave": "una frase larga y mia", "cuit": "20123456786", "planId": "profesional" }
```

Responde `201`:

```json
{ "id": "a1b2", "email": "ana@estudio.com.ar", "token": "…",
  "estado": "prueba", "pruebaHasta": "2026-08-18T…", "descargaUrl": "/descargas/…exe" }
```

Errores: `409` si el email ya existe. `400` con `{ "campo": "clave", "mensaje": "…" }`
para que el sitio marque el campo exacto. El `mensaje` se muestra tal cual al
visitante, así que escribilo en castellano y sin jerga.

**El backend valida todo de nuevo.** Lo del navegador es para ayudar a
completar, no protege nada: cualquiera manda el POST a mano.

**Acá se crea el espacio del cliente**, antes de que pague. Si no, no puede
respaldar durante la prueba y los 14 días no sirven para nada.

## `POST /api/suscripciones/plan`

Con `Authorization: Bearer`. Cambia el plan y ajusta la cuota.

## `POST /api/suscripciones/checkout`

Crea la preapproval en Mercado Pago y devuelve:

```json
{ "checkoutUrl": "https://mercadopago.com…", "referencia": "sub_a1b2_123", "montoMensual": 34900 }
```

La `referencia` es cómo reconciliás el webhook con la cuenta. Guardala antes de
mandar al visitante a pagar.

## `POST /api/webhooks/mercadopago`

Tres cosas, en este orden, antes de tocar la base:

1. **Verificar la firma** contra el cuerpo crudo, con comparación de tiempo
   constante. Sin esto cualquiera activa cuentas gratis con un `curl`.
2. **Descartar repetidos** por id de evento. Mercado Pago reintenta; el mismo
   aviso no puede facturar dos veces.
3. **Buscar la cuenta por la referencia**, nunca por algo que venga del
   navegador.

Aprobado → cuenta activa, factura emitida, mail al cliente. Rechazado → cuenta
morosa y aviso, **sin borrar archivos ni cortar el acceso**.

## `GET /api/cuenta`

Estado, plan, cuota y facturas. Nunca el hash de la contraseña.

---

## Rutas que faltan definir con vos

El portal del cliente y el panel de administración necesitan estas, que dependen
de cómo tengas armado el backend hoy:

| Ruta | Para qué |
|---|---|
| `POST /api/sesion` | Entrar. Devuelve token o pide segundo factor |
| `POST /api/sesion/mfa` | Validar el código del segundo factor |
| `POST /api/clave/olvide` y `/api/clave/restablecer` | Recuperar contraseña |
| `GET /api/archivos` | Explorar el respaldo desde la web |
| `GET /api/archivos/:id/descargar` | Restaurar desde la web |
| `GET /api/equipos` | Equipos registrados y última vez que respaldaron |
| `GET /api/facturas` | Estado de cuenta |
| `GET /api/admin/*` | Panel interno, con permisos aparte |

El cliente de escritorio ya usa varias de estas contra tu backend. Pasame ese
código y las alineo en vez de inventar nombres nuevos.
