'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Base de datos.

   SQLite, que viene adentro de Node 22: no hay que instalar ni administrar un
   motor aparte. Para el tamaño de BackupPrime —miles de cuentas, no millones—
   sobra, y el día que quede chico se migra a PostgreSQL cambiando este archivo.

   La base es UN archivo. Respaldarla es copiarlo. Eso importa: si perdés esta
   base, sabés que los archivos de los clientes siguen en el storage pero no
   sabés de quién es cada uno.
   ═══════════════════════════════════════════════════════════════════════════ */

const { DatabaseSync } = require('node:sqlite');
const path = require('node:path');
const fs = require('node:fs');

const ESQUEMA = [
  `CREATE TABLE IF NOT EXISTS cuentas (
     id            TEXT PRIMARY KEY,
     email         TEXT NOT NULL UNIQUE,
     clave_hash    TEXT NOT NULL,
     organizacion  TEXT NOT NULL,
     cuit          TEXT,
     celular       TEXT,
     telefono      TEXT,
     direccion     TEXT,
     localidad     TEXT,
     provincia     TEXT,
     plan_id       TEXT NOT NULL,
     estado        TEXT NOT NULL DEFAULT 'prueba',
     moroso        INTEGER NOT NULL DEFAULT 0,
     mora_desde    TEXT,
     prueba_hasta  TEXT,
     prefijo       TEXT,
     mfa_secreto   TEXT,
     mfa_activo    INTEGER NOT NULL DEFAULT 0,
     referencia    TEXT,
     creada        TEXT NOT NULL
   )`,
  `CREATE TABLE IF NOT EXISTS sesiones (
     token      TEXT PRIMARY KEY,
     cuenta_id  TEXT NOT NULL,
     tipo       TEXT NOT NULL DEFAULT 'cliente',
     pendiente  INTEGER NOT NULL DEFAULT 0,
     ip         TEXT,
     agente     TEXT,
     creada     TEXT NOT NULL,
     vence      TEXT NOT NULL
   )`,
  /* Papelera de archivos.

     Una sola por cliente, del lado del servidor. Si viviera en cada equipo, un
     estudio con cuatro PCs vería cuatro papeleras distintas y lo borrado desde
     la web no aparecería en el programa.

     Y el vaciado lo hace el servidor, que corre siempre: si dependiera del
     agente, un cliente que apaga la máquina un mes nunca liberaría el espacio. */
  `CREATE TABLE IF NOT EXISTS papelera (
     id            TEXT PRIMARY KEY,
     cuenta_id     TEXT NOT NULL,
     ruta          TEXT NOT NULL,
     nombre        TEXT NOT NULL,
     bytes         INTEGER NOT NULL DEFAULT 0,
     equipo        TEXT,
     borrado_el    TEXT NOT NULL,
     vence_el      TEXT NOT NULL,
     quien         TEXT,
     UNIQUE (cuenta_id, ruta)
   )`,

  `CREATE TABLE IF NOT EXISTS equipos (
     id            TEXT PRIMARY KEY,
     cuenta_id     TEXT NOT NULL,
     nombre        TEXT NOT NULL,
     version       TEXT,
     ultimo_aviso  TEXT,
     bytes         INTEGER NOT NULL DEFAULT 0,
     archivos      INTEGER NOT NULL DEFAULT 0
   )`,
  `CREATE TABLE IF NOT EXISTS facturas (
     id         TEXT PRIMARY KEY,
     cuenta_id  TEXT NOT NULL,
     numero     TEXT NOT NULL,
     monto      INTEGER NOT NULL,
     estado     TEXT NOT NULL,
     concepto   TEXT,
     emitida    TEXT NOT NULL,
     pagada     TEXT
   )`,
  `CREATE TABLE IF NOT EXISTS eventos_pago (
     id       TEXT PRIMARY KEY,
     visto    TEXT NOT NULL
   )`,
  `CREATE TABLE IF NOT EXISTS avisos (
     id         INTEGER PRIMARY KEY AUTOINCREMENT,
     cuenta_id  TEXT,
     para       TEXT NOT NULL,
     asunto     TEXT NOT NULL,
     cuerpo     TEXT NOT NULL,
     estado     TEXT NOT NULL DEFAULT 'encolado',
     enviado    TEXT,
     creado     TEXT NOT NULL
   )`,
  `CREATE TABLE IF NOT EXISTS auditoria (
     id        INTEGER PRIMARY KEY AUTOINCREMENT,
     quien     TEXT NOT NULL,
     que       TEXT NOT NULL,
     detalle   TEXT,
     ip        TEXT,
     cuando    TEXT NOT NULL
   )`,
  `CREATE TABLE IF NOT EXISTS intentos (
     clave     TEXT PRIMARY KEY,
     cantidad  INTEGER NOT NULL DEFAULT 0,
     hasta     TEXT
   )`,
  `CREATE TABLE IF NOT EXISTS ajustes (
     clave  TEXT PRIMARY KEY,
     valor  TEXT NOT NULL
   )`,
  `CREATE INDEX IF NOT EXISTS idx_sesiones_cuenta ON sesiones(cuenta_id)`,
  `CREATE INDEX IF NOT EXISTS idx_equipos_cuenta ON equipos(cuenta_id)`,
  `CREATE INDEX IF NOT EXISTS idx_facturas_cuenta ON facturas(cuenta_id)`,
];

function abrir(rutaArchivo) {
  const destino = rutaArchivo || process.env.BACKUPPRIME_BASE ||
    path.join(__dirname, '..', 'datos', 'backupprime.db');

  if (destino !== ':memory:') fs.mkdirSync(path.dirname(destino), { recursive: true });

  const db = new DatabaseSync(destino);
  // WAL: lecturas mientras se escribe, y menos riesgo de corrupción si se corta
  // la luz en medio de una transacción.
  db.exec('PRAGMA journal_mode = WAL');
  db.exec('PRAGMA foreign_keys = ON');
  for (const sentencia of ESQUEMA) db.exec(sentencia);

  /* ── Columnas agregadas después ──────────────────────────────────────────
     `CREATE TABLE IF NOT EXISTS` no agrega columnas a una tabla que ya existe:
     una base creada con una versión anterior se queda sin ellas y las consultas
     fallan en producción, no acá. Se agregan una por una, ignorando el error de
     "ya existe", que es el caso normal. */
  const columnasNuevas = [
    ['equipos', 'fuera_archivos', 'INTEGER NOT NULL DEFAULT 0'],
    ['equipos', 'fuera_bytes', 'INTEGER NOT NULL DEFAULT 0'],
    ['equipos', 'fuera_desde', 'TEXT'],
    // Modo de cifrado de la cuenta. En 'gestionada' el servidor guarda la clave
    // y puede armar archivos para la descarga web. En 'privada' NO la tiene, y
    // esa es la promesa de ese modo: no se rompe ni para dar una función linda.
    ['cuentas', 'cifrado_modo', "TEXT NOT NULL DEFAULT 'gestionada'"],
    ['cuentas', 'cifrado_clave', 'TEXT'],
  ];
  for (const [tabla, columna, tipo] of columnasNuevas) {
    try { db.exec(`ALTER TABLE ${tabla} ADD COLUMN ${columna} ${tipo}`); }
    catch { /* ya existía */ }
  }
  return db;
}

/** Ajustes que se editan desde el panel, no desde un archivo de configuración. */
function ajuste(db, clave, porDefecto) {
  const fila = db.prepare('SELECT valor FROM ajustes WHERE clave = ?').get(clave);
  if (!fila) return porDefecto;
  try { return JSON.parse(fila.valor); } catch { return fila.valor; }
}

function guardarAjuste(db, clave, valor) {
  db.prepare(`INSERT INTO ajustes (clave, valor) VALUES (?, ?)
              ON CONFLICT(clave) DO UPDATE SET valor = excluded.valor`)
    .run(clave, JSON.stringify(valor));
  return valor;
}

function auditar(db, quien, que, detalle, ip) {
  db.prepare('INSERT INTO auditoria (quien, que, detalle, ip, cuando) VALUES (?, ?, ?, ?, ?)')
    .run(quien, que, detalle == null ? null : String(detalle), ip || null, new Date().toISOString());
}

/**
 * Encola un aviso en vez de mandarlo en el acto.
 *
 * Si el servidor de correo está caído, el alta del cliente no puede fallar por
 * eso. El envío lo hace un proceso aparte que reintenta; acá solo se anota.
 */
function encolarAviso(db, { cuentaId, para, asunto, cuerpo }) {
  db.prepare(`INSERT INTO avisos (cuenta_id, para, asunto, cuerpo, creado)
              VALUES (?, ?, ?, ?, ?)`)
    .run(cuentaId || null, para, asunto, cuerpo, new Date().toISOString());
}

module.exports = { abrir, ajuste, guardarAjuste, auditar, encolarAviso, ESQUEMA };
