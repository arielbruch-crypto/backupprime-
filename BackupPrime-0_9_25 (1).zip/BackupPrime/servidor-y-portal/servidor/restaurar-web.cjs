'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Restauración desde la web.

   El sitio la promete desde el día uno y no existía: la restauración solo se
   podía hacer desde el programa instalado. Este módulo es lo que falta del lado
   del servidor — leer el índice de un archivo, juntar sus bloques, descifrarlos
   y devolver el archivo armado.

   ── Lo que NO puede hacer, y es a propósito ─────────────────────────────────

   Con **frase privada** el servidor no tiene la clave y no puede descifrar
   nada. Esa es exactamente la promesa de ese modo, y no se rompe ni para dar
   una función linda: si el servidor pudiera leer esos archivos, la frase
   privada sería decoración.

   En modo privado, la respuesta es un rechazo explicado, no un archivo roto.

   ── Por qué se verifica la huella ───────────────────────────────────────────

   Al terminar de armar se compara con la huella guardada en el índice. Un
   archivo que se baja incompleto y **parece** correcto es la peor forma de
   fallar: el cliente lo abre meses después y ahí se entera. Si no coincide, se
   falla ruidosamente en vez de entregarlo.
   ═══════════════════════════════════════════════════════════════════════════ */

const crypto = require('node:crypto');

// El formato lo define el agente y NO se reimplementa acá: se lee de su propio
// módulo. Escribir una segunda versión del descifrado es cómo se llega a que un
// cambio de formato deje archivos que solo se pueden abrir de un lado.
//
//   marca 'BPE1' || IV (12) || etiqueta GCM (16) || cuerpo
const MARCA = Buffer.from('BPE1');
const ALGORITMO = 'aes-256-gcm';
const LARGO_IV = 12;
const LARGO_ETIQUETA = 16;
const LARGO_CABECERA = MARCA.length + LARGO_IV + LARGO_ETIQUETA;

/** ¿Estos datos los cifró BackupPrime? */
function estaCifrado(datos) {
  return Buffer.isBuffer(datos) && datos.length >= LARGO_CABECERA &&
         datos.subarray(0, MARCA.length).equals(MARCA);
}

/**
 * Descifra un bloque.
 *
 * Un bloque sin la marca se devuelve tal cual: hasta la 0.9.10 los archivos de
 * menos de 25 MB se subían sin cifrar, y un cliente viejo puede tener las dos
 * cosas mezcladas en el mismo bucket. Rechazarlos dejaría sin restaurar
 * archivos que están perfectos.
 */
function descifrarBloque(buffer, clave) {
  if (!estaCifrado(buffer)) return buffer;
  if (!clave) {
    const err = new Error('Ese archivo está cifrado y no tenemos la clave para abrirlo.');
    err.codigo = 'sin_clave';
    throw err;
  }
  const iv = buffer.subarray(MARCA.length, MARCA.length + LARGO_IV);
  const etiqueta = buffer.subarray(MARCA.length + LARGO_IV, LARGO_CABECERA);
  const cuerpo = buffer.subarray(LARGO_CABECERA);
  const d = crypto.createDecipheriv(ALGORITMO, clave, iv);
  d.setAuthTag(etiqueta);
  return Buffer.concat([d.update(cuerpo), d.final()]);
}

/* El contrato del almacén baja a un archivo del disco: no tiene lectura a
   memoria. Se envuelve acá, con temporal y limpieza garantizada, en vez de
   agregarle métodos nuevos al módulo que usa el resto del sistema. */
const fs = require('node:fs');
const fsp = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');

async function conTemporal(almacen, clave, fn) {
  const ruta = path.join(os.tmpdir(),
    `bp-web-${process.pid}-${crypto.randomBytes(6).toString('hex')}`);
  try {
    await almacen.leer(clave, ruta);
    return await fn(ruta);
  } finally {
    try { await fsp.unlink(ruta); } catch { /* ya no está */ }
  }
}
const leerComoTexto = (almacen, clave) =>
  conTemporal(almacen, clave, (r) => fsp.readFile(r, 'utf8'));
const leerComoBuffer = (almacen, clave) =>
  conTemporal(almacen, clave, (r) => fsp.readFile(r));

const claveBloque = (prefijo, huella) =>
  `${prefijo}bloques/${huella.slice(0, 2)}/${huella}`;
const claveIndice = (prefijo, rutaRelativa) => `${prefijo}indices/${rutaRelativa}.bpi`;
const claveIndiceCopia = (prefijo, rutaRelativa) => `${prefijo}indices-copia/${rutaRelativa}.bpi`;

/**
 * Lee el índice de un archivo. Si la copia principal no se puede leer, usa la
 * segunda: para eso existe la redundancia.
 */
async function leerIndice({ almacen, prefijo, rutaRelativa }) {
  const intentos = [
    claveIndice(prefijo, rutaRelativa),
    claveIndiceCopia(prefijo, rutaRelativa),
  ];
  let ultimo = null;
  for (const clave of intentos) {
    try {
      const texto = await leerComoTexto(almacen, clave);
      const indice = JSON.parse(texto);
      if (!indice || !Array.isArray(indice.bloques)) {
        throw new Error('El índice no tiene la lista de bloques.');
      }
      return indice;
    } catch (e) { ultimo = e; }
  }
  const err = new Error('No se pudo leer el índice de ese archivo, ni su copia. ' +
    (ultimo ? ultimo.message : ''));
  err.codigo = 'indice_ilegible';
  throw err;
}

/**
 * Arma el archivo completo en memoria.
 *
 * Se usa solo para descargas de un archivo desde la web, con un tope de tamaño:
 * armar tres gigas en RAM para un cliente tiraría abajo el servidor para todos
 * los demás. Por encima del tope, la pantalla manda a usar el programa, que
 * rearma en disco y sin límite.
 */
async function armarArchivo({ almacen, prefijo, rutaRelativa, clave, topeBytes = 512 * 1024 * 1024 }) {
  const indice = await leerIndice({ almacen, prefijo, rutaRelativa });

  const bytes = Number(indice.bytes) || 0;
  if (topeBytes && bytes > topeBytes) {
    const err = new Error('Ese archivo es demasiado grande para bajarlo desde la web.');
    err.codigo = 'demasiado_grande';
    err.bytes = bytes;
    throw err;
  }

  const partes = [];
  for (const b of indice.bloques) {
    let crudo;
    try {
      crudo = await leerComoBuffer(almacen, claveBloque(prefijo, b.h));
    } catch (e) {
      // Un bloque que falta significa que el archivo NO se puede armar. Se dice
      // así, en vez de devolver un archivo cortado que parece bueno.
      const err = new Error('Falta un pedazo de ese archivo en el almacenamiento.');
      err.codigo = 'bloque_faltante';
      err.huella = b.h;
      throw err;
    }
    partes.push(descifrarBloque(crudo, clave));
  }

  const archivo = Buffer.concat(partes);

  if (indice.huella) {
    const obtenida = crypto.createHash('sha256').update(archivo).digest('hex');
    if (obtenida !== indice.huella) {
      const err = new Error('El archivo armado no coincide con su huella guardada.');
      err.codigo = 'huella_no_coincide';
      throw err;
    }
  }

  return {
    archivo,
    nombre: String(indice.archivo || rutaRelativa).split('/').pop(),
    bytes: archivo.length,
    creado: indice.creado || null,
  };
}

/** ¿Se puede bajar desde la web esta cuenta? */
function puedeDescargarDesdeLaWeb(cuenta) {
  if (cuenta && cuenta.cifrado_modo === 'privada') {
    return {
      puede: false,
      motivo: 'frase_privada',
      mensaje: 'Tu cuenta usa frase privada: la clave la tenés solo vos, así que ' +
               'ni siquiera nosotros podemos abrir estos archivos desde la web. ' +
               'Restaurá desde el programa, que sí tiene tu frase.',
    };
  }
  return { puede: true };
}

module.exports = {
  armarArchivo, leerIndice, descifrarBloque, estaCifrado, puedeDescargarDesdeLaWeb,
  leerTextoDe: leerComoTexto,
  claveBloque, claveIndice, claveIndiceCopia,
};
