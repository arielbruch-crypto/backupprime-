'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Aprovisionamiento automático de espacio en iDrive e2.

   El objetivo: el cliente paga, baja el programa, pone su email y su
   contraseña, y respalda. No se entera de que existe iDrive, ni de buckets, ni
   de claves. Y Ariel no crea nada a mano.

   Dos APIs distintas, no confundirlas:

   - **API de reseller** (`api.idrivee2.com`, cabecera `token`): administra
     subcuentas, regiones y claves de acceso. NO crea buckets.
   - **S3** (el `storage_dn` de cada región): crea el bucket, prende el
     versionado y pone la retención.

   Reglas que no se negocian acá:

   1. **El versionado se COMPRUEBA, no se cree.** Se sube un objeto, se pisa, y
      se exige que la versión anterior vuelva con su contenido original. Un
      bucket sin versionado guarda bien y restaura el archivo actual: todo
      parece andar y "volvé la carpeta al lunes" no encuentra nada. Eso se
      descubre el día del ransomware.
   2. **El alta falla ruidosamente.** Mejor un alta que se cae y avisa que un
      espacio a medias que nadie sabe que está roto.
   3. **Nada de borrar.** Este módulo no llama a `remove_user` ni a
      `remove_user_region`: las dos destruyen datos del cliente.
   ═══════════════════════════════════════════════════════════════════════════ */

const https = require('node:https');
const crypto = require('node:crypto');

const BASE_RESELLER = 'https://api.idrivee2.com/api/reseller/v1';

/* ── Nombre del bucket ──────────────────────────────────────────────────────
   S3 exige 3 a 63 caracteres, minúsculas, sin arroba ni puntos consecutivos, y
   único a nivel global del proveedor. El email del cliente no sirve como
   nombre, y "estudio-perez" solo tampoco: el segundo Pérez choca. Va legible
   más un sufijo corto del id, que lo hace único y reconocible de un vistazo en
   el panel de e2. */
function nombreDeBucket(organizacion, idCuenta, prefijo = 'bp') {
  const base = String(organizacion || '')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')  // saca acentos
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 30)
    .replace(/-+$/g, '');
  const sufijo = crypto.createHash('sha256').update(String(idCuenta))
    .digest('hex').slice(0, 8);
  const nombre = `${prefijo}-${base || 'cliente'}-${sufijo}`;
  return nombre.slice(0, 63).replace(/-+$/g, '');
}

/* ── Cliente de la API de reseller ───────────────────────────────────────── */

function crearReseller({ apiKey, base = BASE_RESELLER, pedirHttp = pedirHttps }) {
  if (!apiKey) throw new Error('Falta la clave API de reseller.');

  async function llamar(metodo, ruta, cuerpo) {
    const r = await pedirHttp(metodo, base + ruta, cuerpo, { token: apiKey });
    if (r.datos && r.datos.error) {
      const e = new Error(r.datos.error.message || 'Error de la API de e2');
      e.codigo = r.datos.error.code;
      e.http = r.status;
      throw e;
    }
    if (r.status >= 300) {
      const e = new Error(`La API de e2 respondió ${r.status}`);
      e.http = r.status;
      throw e;
    }
    return r.datos || {};
  }

  return {
    regiones: () => llamar('GET', '/regions'),
    usuarios: () => llamar('GET', '/users'),

    /** Crea la subcuenta. `clave` va en base64, como pide e2. */
    crearUsuario: ({ email, clave, nombre, cuotaGB }) =>
      llamar('PUT', '/create_user', {
        email,
        password: Buffer.from(String(clave), 'utf8').toString('base64'),
        first_name: String(nombre || 'Cliente').slice(0, 64),
        quota: Number(cuotaGB) || 0,
        // Sin esto el cliente recibe un mail de iDrive y se entera de todo.
        email_notification: false,
      }),

    habilitarRegion: ({ email, region }) =>
      llamar('POST', '/enable_user_region', { email, region }),

    regionesDe: ({ email }) => llamar('POST', '/list_user_regions', { email }),

    /**
     * Crea una clave acotada. `permisos`: 0 lectura, 1 escritura, 2 ambas.
     * `buckets` la limita a esos buckets. La consola de e2 además ofrece
     * permisos finos de borrado que la API documentada no expone: si algún día
     * los acepta, van acá.
     */
    crearClave: ({ email, storageDn, nombre, permisos = 2, buckets }) =>
      llamar('POST', '/create_access_key', Object.assign(
        { email, storage_dn: storageDn, name: String(nombre).slice(0, 64), permissions: permisos },
        buckets && buckets.length ? { buckets } : {})),

    uso: ({ email, desde, hasta }) =>
      llamar('POST', '/usage_stats', { email, date_from: desde, date_to: hasta }),
  };
}

function pedirHttps(metodo, url, cuerpo, cabeceras) {
  return new Promise((resolver, rechazar) => {
    const datos = cuerpo ? JSON.stringify(cuerpo) : null;
    const u = new URL(url);
    const peticion = https.request({
      method: metodo, hostname: u.hostname, path: u.pathname + u.search,
      headers: Object.assign(
        datos ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(datos) } : {},
        cabeceras || {}),
      timeout: 30000,
    }, (res) => {
      let texto = '';
      res.on('data', (c) => texto += c);
      res.on('end', () => {
        let parseado = null;
        try { parseado = JSON.parse(texto); } catch (e) { /* puede no ser JSON */ }
        resolver({ status: res.statusCode, datos: parseado, texto });
      });
    });
    peticion.on('timeout', () => { peticion.destroy(new Error('La API de e2 no respondió a tiempo.')); });
    peticion.on('error', rechazar);
    if (datos) peticion.write(datos);
    peticion.end();
  });
}

/* ── Preparar el bucket por S3 ───────────────────────────────────────────── */

const sha256 = (d) => crypto.createHash('sha256').update(d).digest('hex');
const etiqueta = (xml, n) => {
  const m = String(xml).match(new RegExp(`<${n}[^>]*>([^<]*)</${n}>`));
  return m ? m[1] : null;
};

/**
 * Crea el bucket y lo deja utilizable. Recibe `pedir`, la petición firmada del
 * módulo S3, para no escribir un segundo SigV4: si lo escribiera, un error de
 * firma en los dos se cancelaría y esto diría que todo anda.
 *
 * Es idempotente: un bucket que ya existe no es un error. El cliente puede
 * entrar a los 40 segundos de pagar, antes de que termine el alta, y el
 * reintento tiene que llegar al mismo lugar.
 */
async function prepararBucket({ pedir, bucket, retencionDias = 20, modoRetencion = 'GOVERNANCE' }) {
  const pasos = [];
  const anotar = (que, ok, detalle) => pasos.push({ que, ok, detalle });

  // 1. Crear, pidiendo Object Lock. En S3 solo se puede pedir acá: si este
  //    bucket nace sin lock, no se le puede agregar nunca más.
  let conLock = false;
  let r = await pedir('PUT', `/${bucket}`, '', {
    extra: { 'x-amz-bucket-object-lock-enabled': 'true' }, largo: 0,
  });
  if (r.status >= 200 && r.status < 300) {
    conLock = true;
    anotar('crear el bucket con bloqueo de objetos', true);
  } else if (/BucketAlreadyOwnedByYou|BucketAlreadyExists/.test(r.cuerpo || '')) {
    conLock = true;   // ya existía: se sigue, es un reintento
    anotar('el bucket ya existía', true);
  } else {
    const r2 = await pedir('PUT', `/${bucket}`, '', { largo: 0 });
    if (!(r2.status >= 200 && r2.status < 300) &&
        !/BucketAlreadyOwnedByYou|BucketAlreadyExists/.test(r2.cuerpo || '')) {
      anotar('crear el bucket', false, `HTTP ${r.status} ${String(r.cuerpo).slice(0, 200)}`);
      return { ok: false, pasos, conLock: false };
    }
    anotar('crear el bucket SIN bloqueo de objetos', true,
      'El proveedor rechazó el bloqueo. Este bucket no va a poder tenerlo nunca.');
  }

  // 2. Versionado.
  const xmlV = '<VersioningConfiguration xmlns="http://s3.amazonaws.com/doc/2006-03-01/">' +
    '<Status>Enabled</Status></VersioningConfiguration>';
  await pedir('PUT', `/${bucket}`, 'versioning', {
    cuerpo: xmlV, hashCuerpo: sha256(xmlV), largo: Buffer.byteLength(xmlV),
    extra: { 'content-type': 'application/xml' },
  });
  const vr = await pedir('GET', `/${bucket}`, 'versioning');
  const versionado = etiqueta(vr.cuerpo, 'Status') === 'Enabled';
  anotar('versionado activo', versionado, versionado ? '' : 'El proveedor no lo informa como activo.');
  if (!versionado) return { ok: false, pasos, conLock };

  // 3. Retención por defecto. Gobernanza y no cumplimiento: cumplimiento ata
  //    también a nosotros —no se podría borrar ni por pedido del cliente ni
  //    para dejar de pagar espacio— y choca con el derecho de supresión.
  if (conLock && retencionDias > 0) {
    const xmlL = '<ObjectLockConfiguration xmlns="http://s3.amazonaws.com/doc/2006-03-01/">' +
      '<ObjectLockEnabled>Enabled</ObjectLockEnabled><Rule><DefaultRetention>' +
      `<Mode>${modoRetencion}</Mode><Days>${Number(retencionDias)}</Days>` +
      '</DefaultRetention></Rule></ObjectLockConfiguration>';
    const lr = await pedir('PUT', `/${bucket}`, 'object-lock', {
      cuerpo: xmlL, hashCuerpo: sha256(xmlL), largo: Buffer.byteLength(xmlL),
      extra: { 'content-type': 'application/xml' },
    });
    anotar('retención por defecto', lr.status < 300,
      lr.status < 300 ? `${modoRetencion}, ${retencionDias} días`
                      : `HTTP ${lr.status} ${String(lr.cuerpo).slice(0, 160)}`);
  }

  // 4. La comprobación que importa: pisar un archivo y recuperar el anterior.
  //    Sin esto solo sabemos lo que el proveedor dice de sí mismo.
  const clave = '.backupprime/comprobacion.txt';
  const v1 = 'ORIGINAL-' + crypto.randomBytes(6).toString('hex');
  const v2 = 'PISADO-' + crypto.randomBytes(6).toString('hex');
  await pedir('PUT', `/${bucket}/${clave}`, '',
    { cuerpo: v1, hashCuerpo: sha256(v1), largo: Buffer.byteLength(v1) });
  await pedir('PUT', `/${bucket}/${clave}`, '',
    { cuerpo: v2, hashCuerpo: sha256(v2), largo: Buffer.byteLength(v2) });

  const lista = await pedir('GET', `/${bucket}`, 'versions&prefix=.backupprime/');
  const ids = [...String(lista.cuerpo).matchAll(/<VersionId>([^<]*)<\/VersionId>/g)]
    .map((m) => m[1]).filter((v) => v && v !== 'null');

  let recupera = false;
  for (const id of ids) {
    const g = await pedir('GET', `/${bucket}/${clave}`, `versionId=${encodeURIComponent(id)}`);
    if (g.status === 200 && g.cuerpo === v1) { recupera = true; break; }
  }
  anotar('se recupera una versión anterior', recupera,
    recupera ? '' : 'El contenido viejo no volvió: en este bucket no hay máquina del tiempo.');

  return { ok: recupera, pasos, conLock, versionado };
}

module.exports = { crearReseller, prepararBucket, nombreDeBucket, pedirHttps };
