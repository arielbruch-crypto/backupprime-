'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Seguridad: contraseñas, sesiones, segundo factor y límite de intentos.

   Todo con lo que trae Node, sin bibliotecas de terceros. No es por purismo:
   cada dependencia en el camino de la autenticación es alguien más que puede
   equivocarse por vos, y estas piezas son chicas y estables.
   ═══════════════════════════════════════════════════════════════════════════ */

const crypto = require('node:crypto');

// ─── Contraseñas ─────────────────────────────────────────────────────────────

const SCRYPT = { N: 16384, r: 8, p: 1, largo: 64 };

function hashClave(clave) {
  const sal = crypto.randomBytes(16);
  const derivada = crypto.scryptSync(String(clave), sal, SCRYPT.largo, SCRYPT);
  return `scrypt$${SCRYPT.N}$${sal.toString('hex')}$${derivada.toString('hex')}`;
}

/** Comparación en tiempo constante: si tardara distinto según dónde falla,
 *  se podría adivinar la contraseña midiendo el tiempo de respuesta. */
function verificarClave(clave, guardado) {
  try {
    const [algo, n, salHex, esperadoHex] = String(guardado).split('$');
    if (algo !== 'scrypt') return false;
    const sal = Buffer.from(salHex, 'hex');
    const esperado = Buffer.from(esperadoHex, 'hex');
    const derivada = crypto.scryptSync(String(clave), sal, esperado.length,
      { N: Number(n) || SCRYPT.N, r: SCRYPT.r, p: SCRYPT.p });
    return crypto.timingSafeEqual(derivada, esperado);
  } catch {
    return false;
  }
}

/**
 * Fuerza mínima. Se mide por largo antes que por "una mayúscula y un símbolo":
 * una frase de cuatro palabras es más segura y más fácil de recordar que
 * "P@ssw0rd", que además es lo primero que prueba cualquier diccionario.
 */
function claveAceptable(clave, minimo = 10) {
  const c = String(clave || '');
  if (c.length < minimo) return `La contraseña necesita al menos ${minimo} caracteres.`;
  if (/^(.)\1+$/.test(c)) return 'Esa contraseña es un solo carácter repetido.';
  const comunes = ['contraseña', 'password', '1234567890', 'qwertyuiop', 'backupprime'];
  if (comunes.some((x) => c.toLowerCase().includes(x))) {
    return 'Esa contraseña es demasiado común. Probá con una frase que se te ocurra a vos.';
  }
  return null;
}

// ─── Sesiones ────────────────────────────────────────────────────────────────

const token = () => crypto.randomBytes(32).toString('base64url');

function crearSesion(db, cuentaId, { tipo = 'cliente', pendiente = false, ip, agente, dias = 30 } = {}) {
  const t = token();
  const ahora = new Date();
  const vence = new Date(ahora.getTime() + dias * 864e5);
  db.prepare(`INSERT INTO sesiones (token, cuenta_id, tipo, pendiente, ip, agente, creada, vence)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(t, cuentaId, tipo, pendiente ? 1 : 0, ip || null, agente || null,
         ahora.toISOString(), vence.toISOString());
  return t;
}

function leerSesion(db, t) {
  if (!t) return null;
  const s = db.prepare('SELECT * FROM sesiones WHERE token = ?').get(t);
  if (!s) return null;
  if (new Date(s.vence) < new Date()) {
    db.prepare('DELETE FROM sesiones WHERE token = ?').run(t);
    return null;
  }
  return s;
}

const cerrarSesion = (db, t) => db.prepare('DELETE FROM sesiones WHERE token = ?').run(t);
const cerrarTodas = (db, cuentaId, salvo) =>
  db.prepare('DELETE FROM sesiones WHERE cuenta_id = ? AND token IS NOT ?').run(cuentaId, salvo || null);

// ─── Segundo factor (TOTP, compatible con Google Authenticator) ─────────────

const BASE32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

function secretoTotp(bytes = 20) {
  const crudo = crypto.randomBytes(bytes);
  let bits = '';
  for (const b of crudo) bits += b.toString(2).padStart(8, '0');
  let salida = '';
  for (let i = 0; i + 5 <= bits.length; i += 5) salida += BASE32[parseInt(bits.slice(i, i + 5), 2)];
  return salida;
}

function base32ABuffer(texto) {
  let bits = '';
  for (const c of String(texto).toUpperCase().replace(/=+$/, '')) {
    const i = BASE32.indexOf(c);
    if (i < 0) continue;
    bits += i.toString(2).padStart(5, '0');
  }
  const bytes = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) bytes.push(parseInt(bits.slice(i, i + 8), 2));
  return Buffer.from(bytes);
}

function codigoTotp(secreto, contador) {
  const buf = Buffer.alloc(8);
  buf.writeBigUInt64BE(BigInt(contador));
  const mac = crypto.createHmac('sha1', base32ABuffer(secreto)).update(buf).digest();
  const desfase = mac[mac.length - 1] & 0x0f;
  const numero = ((mac[desfase] & 0x7f) << 24) | (mac[desfase + 1] << 16) |
                 (mac[desfase + 2] << 8) | mac[desfase + 3];
  return String(numero % 1000000).padStart(6, '0');
}

/** Acepta el código de la ventana actual y una para cada lado: los relojes de
 *  los teléfonos no siempre están en hora. */
function verificarTotp(secreto, codigo, margen = 1) {
  const limpio = String(codigo || '').replace(/\D/g, '');
  if (limpio.length !== 6) return false;
  const ventana = Math.floor(Date.now() / 30000);
  for (let i = -margen; i <= margen; i++) {
    const esperado = codigoTotp(secreto, ventana + i);
    if (crypto.timingSafeEqual(Buffer.from(esperado), Buffer.from(limpio))) return true;
  }
  return false;
}

const urlTotp = (secreto, email, emisor = 'BackupPrime') =>
  `otpauth://totp/${encodeURIComponent(emisor)}:${encodeURIComponent(email)}` +
  `?secret=${secreto}&issuer=${encodeURIComponent(emisor)}&digits=6&period=30`;

// ─── Límite de intentos ──────────────────────────────────────────────────────
//
// Sin esto, probar contraseñas contra el login es cuestión de horas. Se cuenta
// por clave (email + IP) y se bloquea un rato, no para siempre: bloquear para
// siempre convierte el ataque en una forma de dejar afuera a un cliente.

function registrarIntento(db, clave, { tope = 5, minutos = 15 } = {}) {
  const ahora = new Date();
  const fila = db.prepare('SELECT * FROM intentos WHERE clave = ?').get(clave);

  if (fila && fila.hasta && new Date(fila.hasta) > ahora) {
    return { bloqueado: true, hasta: fila.hasta };
  }

  const cantidad = (fila && new Date(fila.hasta || 0) > ahora ? fila.cantidad : (fila ? fila.cantidad : 0)) + 1;
  const hasta = cantidad >= tope
    ? new Date(ahora.getTime() + minutos * 60000).toISOString()
    : (fila ? fila.hasta : null);

  db.prepare(`INSERT INTO intentos (clave, cantidad, hasta) VALUES (?, ?, ?)
              ON CONFLICT(clave) DO UPDATE SET cantidad = excluded.cantidad, hasta = excluded.hasta`)
    .run(clave, cantidad, hasta);

  return { bloqueado: cantidad >= tope, hasta, cantidad };
}

const limpiarIntentos = (db, clave) => db.prepare('DELETE FROM intentos WHERE clave = ?').run(clave);

function estaBloqueado(db, clave) {
  const fila = db.prepare('SELECT * FROM intentos WHERE clave = ?').get(clave);
  return !!(fila && fila.hasta && new Date(fila.hasta) > new Date());
}

// ─── Varios ──────────────────────────────────────────────────────────────────

const idCorto = () => crypto.randomBytes(8).toString('hex');

function cuitValido(v) {
  const d = String(v || '').replace(/\D/g, '');
  if (d.length !== 11) return false;
  const pesos = [5, 4, 3, 2, 7, 6, 5, 4, 3, 2];
  let suma = 0;
  for (let i = 0; i < 10; i++) suma += Number(d[i]) * pesos[i];
  const resto = suma % 11;
  const verificador = resto === 0 ? 0 : (resto === 1 ? 9 : 11 - resto);
  return verificador === Number(d[10]);
}

const emailValido = (v) => /^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(String(v || '').trim());

module.exports = {
  hashClave, verificarClave, claveAceptable,
  token, crearSesion, leerSesion, cerrarSesion, cerrarTodas,
  secretoTotp, codigoTotp, verificarTotp, urlTotp,
  registrarIntento, limpiarIntentos, estaBloqueado,
  idCorto, cuitValido, emailValido,
};
