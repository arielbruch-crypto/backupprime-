'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   BackupPrime — servidor.

   Node solo, sin dependencias. Sirve el sitio y la API.

     node servidor/servidor.cjs
     PORT=8080 BACKUPPRIME_BASE=/var/backupprime/datos.db node servidor/servidor.cjs

   Lo que hace hoy: planes, alta de cuentas, aprovisionamiento del espacio,
   sesiones, segundo factor, recuperación de contraseña, cambio de plan,
   checkout, webhook de pagos con firma e idempotencia, mora, facturas,
   panel de administración y configuración del almacenamiento.

   Lo que falta y está marcado en el código: hablar de verdad con Mercado Pago
   y con el servicio de facturación electrónica. Hasta que estén las
   credenciales, esas dos partes corren en modo simulado.
   ═══════════════════════════════════════════════════════════════════════════ */

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { createHash } = require('node:crypto');
const crypto = require('node:crypto');

const { abrir, ajuste, guardarAjuste, auditar, encolarAviso } = require('./base.cjs');
const S = require('./seguridad.cjs');
const almacenamiento = require('../almacenamiento/index.cjs');
const RW = require('./restaurar-web.cjs');
const e2 = require('./e2.cjs');
const correo = require('../correo/index.cjs');

const RAIZ_SITIO = path.join(__dirname, '..');

/* Compara 0.9.21 contra 0.9.9 por número, no por texto: ordenadas como cadenas,
   "0.9.9" sale después de "0.9.21" y el sitio publicaría la vieja. */
function comparaVersiones(a, b) {
  const pa = String(a).split('.').map(Number);
  const pb = String(b).split('.').map(Number);
  for (let i = 0; i < 3; i++) {
    if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) - (pb[i] || 0);
  }
  return 0;
}

// ─── Planes ──────────────────────────────────────────────────────────────────
// Viven en la base para poder cambiarlos desde el panel sin tocar código.

const PLANES_INICIALES = [
  { id: 'personal', nombre: 'Personal', para: 'Para vos y tu familia',
    precioMensual: 16000, espacioGB: 200, destacado: false, visible: true,
    incluye: ['Todas las computadoras de tu casa', '200 GB de espacio',
              'Fotos, documentos y lo que elijas', 'Versiones anteriores de cada archivo',
              'Restauración desde la web'] },
  { id: 'estudio', nombre: 'Estudio', para: 'Estudios y comercios de hasta 15 personas',
    precioMensual: 34900, espacioGB: 1000, destacado: true, visible: true,
    incluye: ['Equipos ilimitados', '1 TB de espacio', 'Hasta 30 versiones por archivo',
              'Respaldo de carpetas de red', 'Verificación en dos pasos', 'Soporte por WhatsApp'] },
  { id: 'empresa', nombre: 'Empresa', para: 'Más de 15 personas o servidores',
    precioMensual: 74900, espacioGB: 3000, destacado: false, visible: true,
    incluye: ['Todo lo del plan Estudio', '3 TB de espacio', 'Respaldo de servidores',
              'Usuarios con permisos separados', 'Informe mensual por mail',
              'Soporte telefónico prioritario'] },
];

const MORA_INICIAL = { aviso: 1, cortarSubidas: 5, recordatorio2: 15, recordatorio3: 30,
                       avisoBorrado: 90, ultimoAviso: 110, borrar: 120 };

const ALMACEN_INICIAL = {
  proveedor: 'disco',
  raiz: path.join(RAIZ_SITIO, 'datos', 'almacen'),
  urlPublica: '/descargas-privadas',
  secretoEnlaces: crypto.randomBytes(32).toString('hex'),
};

function crearAplicacion({ archivoBase, claveAdmin } = {}) {
  const db = abrir(archivoBase);
  let huellaCache = null;

  if (!ajuste(db, 'planes')) guardarAjuste(db, 'planes', PLANES_INICIALES);
  if (!ajuste(db, 'mora')) guardarAjuste(db, 'mora', MORA_INICIAL);
  if (!ajuste(db, 'almacenamiento')) guardarAjuste(db, 'almacenamiento', ALMACEN_INICIAL);
  if (!ajuste(db, 'admin')) {
    // Primera vez: usuario admin con la contraseña que se pase por entorno, o
    // "admin" para poder entrar. El panel avisa hasta que se cambie.
    guardarAjuste(db, 'admin', {
      usuario: 'admin',
      claveHash: S.hashClave(claveAdmin || process.env.ADMIN_CLAVE || 'admin'),
      claveInicial: !claveAdmin && !process.env.ADMIN_CLAVE,
    });
  }

  const planes = () => ajuste(db, 'planes', PLANES_INICIALES);

  /**
   * Vacía la cola de avisos. Los mails se encolan al crearse y salen desde
   * acá, aparte: si el servidor de correo está caído, el alta de un cliente no
   * puede fallar por eso.
   */
  async function despachar() {
    const config = ajuste(db, 'correo', null);
    if (!config || !config.proveedor || !config.de) {
      return { enviados: 0, fallados: 0, motivo: 'Falta configurar el correo saliente.' };
    }
    try {
      return await correo.despacharCola(db, correo.crear(config));
    } catch (e) {
      auditar(db, 'sistema', 'falló el despacho de correo', e.message);
      return { enviados: 0, fallados: 0, motivo: e.message };
    }
  }
  const plan = (id) => planes().find((p) => p.id === id);
  const almacen = () => almacenamiento.crear(ajuste(db, 'almacenamiento', ALMACEN_INICIAL));

  /* El almacén de UN cliente. Con bucket propio apunta a su bucket; con carpeta
     compartida, al bucket común y el prefijo separa. La descarga web nunca
     recibe el bucket desde el navegador: sale de la cuenta. */
  function almacenDeCuenta(cuenta) {
    const base = ajuste(db, 'almacenamiento', ALMACEN_INICIAL);
    const cfg = ajuste(db, 'e2', {});
    // Con bucket propio el prefijo guardado es "<bucket>/": el bucket es lo que
    // va antes de la primera barra, y adentro las claves cuelgan de la raíz.
    // Misma regla que usa el login del agente; si las dos se separan, el portal
    // buscaría los archivos en un lugar y el programa los habría dejado en otro.
    if (cfg.modo === 'bucket' && cuenta.prefijo) {
      return {
        almacen: almacenamiento.crear({ ...base, bucket: String(cuenta.prefijo).split('/')[0] }),
        prefijo: String(cuenta.prefijo).split('/').slice(1).join('/'),
      };
    }
    return { almacen: almacenamiento.crear(base), prefijo: cuenta.prefijo || '' };
  }

  // Armar un archivo grande en memoria dejaría al servidor sin RAM para todos
  // los demás clientes. Por encima de esto, la pantalla manda al programa.
  const TOPE_DESCARGA_WEB = 512 * 1024 * 1024;

  // Días que un archivo queda recuperable en la papelera.
  const DIAS_PAPELERA = 30;

  // ── Aprovisionamiento ────────────────────────────────────────────────────
  //
  // Se hace en el alta, no en el pago: si esperara al pago, la prueba de 14
  // días no podría respaldar nada. Es idempotente a propósito, porque lo puede
  // llamar tanto el alta como el webhook.
  /**
   * Le da al cliente un espacio propio y utilizable.
   *
   * Dos modos, según lo que haya configurado Ariel en el panel:
   *
   * - **prefijo** (por defecto): una carpeta dentro del bucket común. Es lo que
   *   había siempre. No llama a e2. Separación LÓGICA: lo único que separa a dos
   *   estudios es que el código concatene bien la ruta.
   * - **bucket**: un bucket propio por cliente, creado por API, con versionado
   *   comprobado y bloqueo de objetos si el proveedor lo permite. La separación
   *   la garantiza el proveedor, no nuestro cuidado al escribir una línea.
   *
   * Se hace en el alta, no en el pago: si esperara al pago, la prueba de 14 días
   * no podría respaldar nada. Es idempotente a propósito, porque lo pueden
   * llamar el alta, el webhook y el ingreso del agente — el cliente entra a los
   * 40 segundos de pagar, antes de que termine esto.
   */
  async function provisionar(cuenta) {
    if (cuenta.prefijo) return cuenta.prefijo;

    const cfg = ajuste(db, 'e2', {});
    if (cfg.modo !== 'bucket') {
      const { prefijo } = await almacen().espacioDeCliente(cuenta.id);
      db.prepare('UPDATE cuentas SET prefijo = ? WHERE id = ?').run(prefijo, cuenta.id);
      auditar(db, 'sistema', 'espacio creado', `${cuenta.email} → ${prefijo}`);
      return prefijo;
    }

    const bucket = e2.nombreDeBucket(cuenta.organizacion, cuenta.id, cfg.prefijoBucket || 'bp');
    const almacenCliente = almacenamiento.crear({
      ...ajuste(db, 'almacenamiento', ALMACEN_INICIAL), bucket,
    });
    if (typeof almacenCliente.peticion !== 'function') {
      throw new Error('El proveedor de almacenamiento configurado no permite crear ' +
        'buckets. El alta por bucket propio necesita uno compatible con S3.');
    }

    const r = await e2.prepararBucket({
      pedir: almacenCliente.peticion,
      bucket,
      retencionDias: Number(cfg.retencionDias) || 0,
      modoRetencion: cfg.modoRetencion === 'COMPLIANCE' ? 'COMPLIANCE' : 'GOVERNANCE',
    });

    if (!r.ok) {
      // NO se marca la cuenta como aprovisionada. Un espacio a medias es peor
      // que ninguno: el cliente respaldaría creyendo que tiene historial de
      // versiones y se enteraría el día que necesita volver a una fecha.
      const porque = (r.pasos.find((p) => !p.ok) || {}).detalle || 'sin detalle';
      auditar(db, 'sistema', 'FALLÓ el alta de espacio', `${cuenta.email} → ${bucket}: ${porque}`);
      const e = new Error('No se pudo preparar el espacio del cliente: ' + porque);
      e.pasos = r.pasos;
      throw e;
    }

    db.prepare('UPDATE cuentas SET prefijo = ? WHERE id = ?').run(bucket + '/', cuenta.id);
    auditar(db, 'sistema', 'espacio creado',
      `${cuenta.email} → ${bucket}` + (r.conLock ? ' (con bloqueo de objetos)' : ' (SIN bloqueo)'));
    return bucket + '/';
  }

  // ── Cuota de espacio ───────────────────────────────────────────────────────
  //
  // UNA sola función calcula el consumo, y la usan el agente, el portal y el
  // panel. Si cada uno hiciera su cuenta, los números iban a diferir —el cliente
  // tiene varios equipos que suman al mismo plan— y un cliente que ve 340 GB en
  // el programa y 355 GB en la web deja de creerle a los dos.
  //
  // Qué se mide: el tamaño LÓGICO. Lo que suman los archivos del cliente más sus
  // versiones, como si no existiera la deduplicación.
  //
  // Por qué así y no lo que ocupa de verdad en el almacenamiento: porque el
  // ahorro por deduplicación depende de cuánto se repitan los datos, y cambia
  // solo, sin que el cliente haga nada. Un cupo que se mueve sin explicación no
  // se puede defender por teléfono ni poner en una factura. Midiendo lo lógico,
  // el cliente entiende el número y lo puede verificar mirando sus carpetas.
  //
  // La diferencia entre lo lógico y lo real queda como margen del negocio: en un
  // PST de 651 MB con 30 versiones fue del 97%. Eso permite ofrecer más espacio
  // nominal que la competencia por el mismo costo real. La deduplicación se le
  // devuelve al cliente en precio y en velocidad, no en un cupo confuso.
  const GRACIA = 0.10;   // 10% por encima del plan antes de frenar subidas
  const AVISO  = 0.80;   // se avisa desde el 80%, no al llegar al tope

  function estadoDeCuota(cuenta) {
    const elegido = plan(cuenta.plan_id) || planes()[0];
    const limite = elegido.espacioGB ? elegido.espacioGB * 1024 * 1024 * 1024 : 0;

    const fila = db.prepare(`SELECT COALESCE(SUM(bytes), 0) b, COALESCE(SUM(archivos), 0) a
                             FROM equipos WHERE cuenta_id = ?`).get(cuenta.id);

    // Lo que está en la papelera NO cuenta en la cuota, aunque los bloques
    // sigan ocupando lugar hasta que se vacíe. Si contara, el cliente aprieta
    // borrar, no ve bajar el número y llama. Ese espacio lo paga BackupPrime
    // durante los días de retención: es el precio de que la papelera exista.
    const enPapelera = Number(db.prepare(
      'SELECT COALESCE(SUM(bytes), 0) b FROM papelera WHERE cuenta_id = ?')
      .get(cuenta.id).b) || 0;

    const usado = Math.max(0, (Number(fila.b) || 0) - enPapelera);
    const proporcion = limite > 0 ? usado / limite : 0;
    const tope = limite > 0 ? Math.floor(limite * (1 + GRACIA)) : 0;

    return {
      usadoBytes: usado,
      archivos: Number(fila.a) || 0,
      limiteBytes: limite,
      espacioGB: elegido.espacioGB || null,
      porcentaje: limite > 0 ? Math.round(proporcion * 1000) / 10 : 0,
      // Tres estados, no dos. "Excedido" no es lo mismo que "frenado": entre el
      // 100% y el 110% el respaldo sigue andando y el cliente tiene tiempo de
      // decidir en lugar de encontrarse de un día para el otro sin respaldos.
      estado: limite === 0 ? 'sin-limite'
            : usado >= tope ? 'frenado'
            : usado >= limite ? 'excedido'
            : proporcion >= AVISO ? 'aviso'
            : 'ok',
      // Las subidas se frenan pasada la gracia. LAS RESTAURACIONES NUNCA: un
      // cliente que se pasó de cupo y necesita recuperar sus datos tiene que
      // poder hacerlo. Discutir plata en ese momento es el peor momento posible
      // y va contra la razón de ser del producto.
      puedeSubir: limite === 0 || usado < tope,
      puedeRestaurar: true,
      graciaBytes: tope,
      medidoEn: new Date().toISOString(),
    };
  }

  /** El texto que ve el cliente, igual en el programa y en la web. */
  function mensajeDeCuota(c) {
    const gb = (n) => (n / (1024 * 1024 * 1024)).toFixed(1).replace('.', ',') + ' GB';
    if (c.estado === 'sin-limite') return null;
    if (c.estado === 'frenado') {
      return `Se llenó tu espacio: usaste ${gb(c.usadoBytes)} de ${gb(c.limiteBytes)}. ` +
             `Los respaldos nuevos están en pausa hasta que amplíes el plan o liberes ` +
             `espacio. Tus archivos guardados siguen a salvo y los podés restaurar cuando quieras.`;
    }
    if (c.estado === 'excedido') {
      return `Te pasaste del espacio de tu plan: ${gb(c.usadoBytes)} de ${gb(c.limiteBytes)}. ` +
             `Seguimos respaldando por ahora, pero conviene ampliar el plan.`;
    }
    if (c.estado === 'aviso') {
      return `Usaste ${gb(c.usadoBytes)} de ${gb(c.limiteBytes)} (${c.porcentaje}%).`;
    }
    return null;
  }

  // ── Utilidades HTTP ──────────────────────────────────────────────────────

  const json = (res, codigo, cuerpo) => {
    const texto = JSON.stringify(cuerpo);
    res.writeHead(codigo, {
      'Content-Type': 'application/json; charset=utf-8',
      'Content-Length': Buffer.byteLength(texto),
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'strict-origin-when-cross-origin',
      'X-Frame-Options': 'DENY',
    });
    res.end(texto);
  };

  /**
   * La sesión viaja en una cookie HttpOnly: el JavaScript de la página no la
   * puede leer, así que un agujero de tipo XSS no alcanza para robarse la
   * sesión. Se acepta también el encabezado Authorization, que es lo que usa el
   * programa de escritorio.
   */
  function ponerCookie(res, token, dias) {
    const partes = [
      `bp_sesion=${token}`,
      'Path=/',
      'HttpOnly',
      'SameSite=Lax',
      `Max-Age=${Math.round(dias * 86400)}`,
    ];
    if (process.env.BACKUPPRIME_HTTPS !== '0') partes.push('Secure');
    const previas = res.getHeader('Set-Cookie');
    res.setHeader('Set-Cookie', (previas ? [].concat(previas) : []).concat(partes.join('; ')));
  }

  function borrarCookie(res) {
    res.setHeader('Set-Cookie', 'bp_sesion=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0');
  }

  function cookieDe(req) {
    const crudo = req.headers.cookie || '';
    for (const parte of crudo.split(';')) {
      const [k, ...v] = parte.trim().split('=');
      if (k === 'bp_sesion') return v.join('=');
    }
    return null;
  }

  const ipDe = (req) =>
    (req.headers['x-forwarded-for'] || '').split(',')[0].trim() ||
    req.socket.remoteAddress || '';

  function tokenDe(req) {
    const cab = req.headers.authorization || '';
    if (cab.startsWith('Bearer ')) return cab.slice(7);
    return cookieDe(req);
  }

  function sesionDe(req) {
    const s = S.leerSesion(db, tokenDe(req));
    if (!s || s.pendiente) return null;
    return s;
  }

  function cuentaDe(req) {
    const s = sesionDe(req);
    if (!s || s.tipo !== 'cliente') return null;
    return db.prepare('SELECT * FROM cuentas WHERE id = ?').get(s.cuenta_id);
  }

  const esAdmin = (req) => {
    const s = sesionDe(req);
    return s && s.tipo === 'admin' ? s : null;
  };

  const publica = (c) => ({
    id: c.id, email: c.email, organizacion: c.organizacion,
    planId: c.plan_id, estado: c.estado, moroso: !!c.moroso,
    pruebaHasta: c.prueba_hasta,
    espacioGB: (plan(c.plan_id) || {}).espacioGB || 0,
    // Sin este campo la pantalla de Seguridad no puede saber si el segundo
    // factor está activo, y tenía que inventarlo.
    mfa: !!c.mfa_activo,
    celular: c.celular, telefono: c.telefono,
    direccion: c.direccion, localidad: c.localidad, provincia: c.provincia,
  });

  // ── Rutas ────────────────────────────────────────────────────────────────

  const rutas = {

    'GET /api/planes': (req, res) =>
      json(res, 200, { planes: planes().filter((p) => p.visible !== false) }),

    'POST /api/registro': async (req, res, cuerpo) => {
      const email = String(cuerpo.email || '').trim().toLowerCase();
      const organizacion = String(cuerpo.organizacion || '').trim();

      if (!S.emailValido(email)) {
        return json(res, 400, { campo: 'email', mensaje: 'Revisá el email, parece incompleto.' });
      }
      // El "ya tenés cuenta" va antes que el resto: es la respuesta útil. Decirle
      // a alguien que su nombre es muy corto cuando el problema real es que ya
      // está registrado lo manda a corregir el campo equivocado.
      if (db.prepare('SELECT 1 FROM cuentas WHERE email = ?').get(email)) {
        return json(res, 409, { mensaje: 'Ya hay una cuenta con ese email.' });
      }
      const problema = S.claveAceptable(cuerpo.clave, 10);
      if (problema) return json(res, 400, { campo: 'clave', mensaje: problema });
      if (organizacion.length < 2) {
        return json(res, 400, { campo: 'estudio', mensaje: 'Poné tu nombre o el de tu empresa.' });
      }
      if (cuerpo.cuit && !S.cuitValido(cuerpo.cuit)) {
        return json(res, 400, { campo: 'cuit', mensaje: 'Ese número no es válido. Revisá los dígitos.' });
      }

      const elegido = plan(cuerpo.planId) || planes()[0];
      const id = S.idCorto();
      const ahora = new Date();

      db.prepare(`INSERT INTO cuentas
        (id, email, clave_hash, organizacion, cuit, celular, telefono, direccion,
         localidad, provincia, plan_id, estado, prueba_hasta, creada)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'prueba', ?, ?)`)
        .run(id, email, S.hashClave(cuerpo.clave), organizacion,
             cuerpo.cuit ? String(cuerpo.cuit).replace(/\D/g, '') : null,
             cuerpo.celular || null, cuerpo.telefono || null, cuerpo.direccion || null,
             cuerpo.localidad || null, cuerpo.provincia || null,
             elegido.id, new Date(ahora.getTime() + 14 * 864e5).toISOString(),
             ahora.toISOString());

      const cuenta = db.prepare('SELECT * FROM cuentas WHERE id = ?').get(id);

      try {
        await provisionar(cuenta);
      } catch (e) {
        // La cuenta queda creada igual: el espacio se reintenta. Perder el alta
        // porque el storage tuvo un hipo sería perder al cliente.
        auditar(db, 'sistema', 'falló el aprovisionamiento', `${email}: ${e.message}`);
      }

      encolarAviso(db, { cuentaId: id, para: email,
        asunto: 'Tu cuenta de BackupPrime está lista',
        cuerpo: 'Bajá el programa e ingresá con este mismo email.' });
      auditar(db, email, 'alta de cuenta', elegido.id, ipDe(req));

      const t = S.crearSesion(db, id, { ip: ipDe(req), agente: req.headers['user-agent'] });
      ponerCookie(res, t, 30);
      json(res, 201, {
        id, email, token: t, estado: 'prueba',
        pruebaHasta: cuenta.prueba_hasta, descargaUrl: '/descargas.html',
      });
    },

    'POST /api/sesion': (req, res, cuerpo) => {
      const modo = cuerpo.modo === 'admin' ? 'admin' : 'cliente';
      const usuario = String(cuerpo.email || '').trim().toLowerCase();
      const claveIntento = String(cuerpo.clave || '');
      const clave = `${modo}:${usuario}:${ipDe(req)}`;

      if (S.estaBloqueado(db, clave)) {
        return json(res, 429, { mensaje: 'Demasiados intentos. Esperá unos minutos.' });
      }

      if (modo === 'admin') {
        const admin = ajuste(db, 'admin');
        if (usuario !== admin.usuario || !S.verificarClave(claveIntento, admin.claveHash)) {
          S.registrarIntento(db, clave);
          auditar(db, usuario, 'ingreso de administración fallido', null, ipDe(req));
          return json(res, 401, { mensaje: 'El usuario o la contraseña no coinciden.' });
        }
        S.limpiarIntentos(db, clave);
        const t = S.crearSesion(db, 'admin', { tipo: 'admin', ip: ipDe(req), dias: 1 });
        ponerCookie(res, t, 1);
        auditar(db, usuario, 'ingreso de administración', null, ipDe(req));
        return json(res, 200, { token: t, destino: '/admin.html', claveInicial: !!admin.claveInicial });
      }

      const cuenta = db.prepare('SELECT * FROM cuentas WHERE email = ?').get(usuario);
      if (!cuenta || !S.verificarClave(claveIntento, cuenta.clave_hash)) {
        S.registrarIntento(db, clave);
        // Nunca decir cuál de los dos está mal: con eso se averigua quiénes son
        // los clientes probando direcciones.
        return json(res, 401, { mensaje: 'El email o la contraseña no coinciden.' });
      }
      S.limpiarIntentos(db, clave);

      if (cuenta.mfa_activo) {
        const t = S.crearSesion(db, cuenta.id, { pendiente: true, ip: ipDe(req), dias: 1 });
        ponerCookie(res, t, 1);
        return json(res, 200, { necesitaSegundoFactor: true, token: t });
      }

      const dias = cuerpo.recordar ? 30 : 1;
      const t = S.crearSesion(db, cuenta.id, {
        ip: ipDe(req), agente: req.headers['user-agent'], dias,
      });
      ponerCookie(res, t, dias);
      auditar(db, cuenta.email, 'ingreso', null, ipDe(req));
      json(res, 200, { token: t, destino: '/portal.html' });
    },

    'POST /api/sesion/mfa': (req, res, cuerpo) => {
      const t = tokenDe(req);
      const s = S.leerSesion(db, t);
      if (!s || !s.pendiente) return json(res, 401, { mensaje: 'La sesión venció. Entrá de nuevo.' });

      const cuenta = db.prepare('SELECT * FROM cuentas WHERE id = ?').get(s.cuenta_id);
      const clave = `mfa:${s.cuenta_id}:${ipDe(req)}`;
      if (S.estaBloqueado(db, clave)) {
        return json(res, 429, { mensaje: 'Demasiados intentos. Esperá unos minutos.' });
      }
      if (!cuenta || !S.verificarTotp(cuenta.mfa_secreto, cuerpo.codigo)) {
        S.registrarIntento(db, clave);
        return json(res, 401, { mensaje: 'Ese código no es válido o ya venció.' });
      }
      S.limpiarIntentos(db, clave);
      db.prepare('UPDATE sesiones SET pendiente = 0 WHERE token = ?').run(t);
      ponerCookie(res, t, 30);
      auditar(db, cuenta.email, 'ingreso con segundo factor', null, ipDe(req));
      json(res, 200, { token: t, destino: '/portal.html' });
    },

    'POST /api/clave/olvide': (req, res, cuerpo) => {
      const email = String(cuerpo.email || '').trim().toLowerCase();
      const cuenta = db.prepare('SELECT * FROM cuentas WHERE email = ?').get(email);
      if (cuenta) {
        const t = S.token();
        guardarAjuste(db, `recuperar:${t}`, { cuentaId: cuenta.id, vence: Date.now() + 3600e3 });
        encolarAviso(db, { cuentaId: cuenta.id, para: email,
          asunto: 'Recuperar tu contraseña',
          cuerpo: `Entrá acá para elegir una nueva: /clave-nueva.html?t=${t}\nEl enlace vence en una hora.` });
      }
      // La respuesta es idéntica exista o no la cuenta.
      json(res, 200, { ok: true });
    },

    'POST /api/clave/restablecer': (req, res, cuerpo) => {
      const dato = ajuste(db, `recuperar:${cuerpo.token}`);
      if (!dato || dato.vence < Date.now()) {
        return json(res, 400, { mensaje: 'Ese enlace ya venció. Pedí uno nuevo.' });
      }
      const problema = S.claveAceptable(cuerpo.clave, 10);
      if (problema) return json(res, 400, { campo: 'clave', mensaje: problema });

      db.prepare('UPDATE cuentas SET clave_hash = ? WHERE id = ?')
        .run(S.hashClave(cuerpo.clave), dato.cuentaId);
      db.prepare('DELETE FROM ajustes WHERE clave = ?').run(`recuperar:${cuerpo.token}`);
      S.cerrarTodas(db, dato.cuentaId);
      auditar(db, dato.cuentaId, 'contraseña restablecida', null, ipDe(req));
      json(res, 200, { ok: true });
    },

    'POST /api/sesion/salir': (req, res) => {
      const t = tokenDe(req);
      if (t) S.cerrarSesion(db, t);
      borrarCookie(res);
      json(res, 200, { ok: true });
    },

    /* ── Restaurar desde la web ──────────────────────────────────────────
       Lo que el sitio promete desde el día uno. El caso real: se rompió la
       computadora, el contador está en la casa de un cliente y necesita UN
       archivo. No puede instalar nada. */

    'GET /api/portal/archivos': async (req, res, cuerpo, url) => {
      const cuenta = cuentaDe(req);
      if (!cuenta) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });

      const permiso = RW.puedeDescargarDesdeLaWeb(cuenta);
      if (!cuenta.prefijo) {
        return json(res, 200, { archivos: [], total: 0, puedeDescargar: permiso.puede,
          mensaje: 'Todavía no hay nada respaldado.' });
      }

      let sitio;
      try { sitio = almacenDeCuenta(cuenta); }
      catch (e) { return json(res, 503, { mensaje: 'El almacenamiento no está configurado.' }); }

      let catalogo = {};
      try {
        catalogo = JSON.parse(await RW.leerTextoDe(
          sitio.almacen, `${sitio.prefijo}indices/_catalogo.json`));
      } catch (e) {
        // Sin catálogo no se inventa una lista vacía que parezca "no tenés
        // nada": se dice que no se pudo leer, que es distinto.
        return json(res, 200, {
          archivos: [], total: 0, puedeDescargar: permiso.puede,
          mensaje: 'No pudimos leer el listado de tus archivos. Probá de nuevo en unos minutos.',
        });
      }

      const buscar = String((url && url.searchParams.get('buscar')) || '').toLowerCase().trim();
      const todos = Object.entries(catalogo)
        .filter(([rel]) => !buscar || rel.toLowerCase().includes(buscar))
        .map(([rel, d]) => ({
          ruta: rel,
          nombre: rel.split('/').pop(),
          carpeta: rel.split('/').slice(0, -1).join('/'),
          bytes: Number(d.bytes) || 0,
          modificado: d.mtimeMs || null,
          // Se sigue respaldando, o quedó congelado. El cliente tiene que poder
          // distinguirlo: creer que una carpeta está protegida cuando hace meses
          // que no se toca es la peor confusión posible.
          fueraDelRespaldo: d.cubierto === false,
          fueraDesde: d.fueraDesde || null,
        }))
        .sort((a, b) => (b.modificado || 0) - (a.modificado || 0));

      json(res, 200, {
        archivos: todos.slice(0, 500),
        total: todos.length,
        recortado: todos.length > 500,
        puedeDescargar: permiso.puede,
        motivo: permiso.motivo || null,
        mensaje: permiso.mensaje || null,
        topeMB: Math.round(TOPE_DESCARGA_WEB / 1048576),
      });
    },

    'POST /api/portal/descargar': async (req, res, cuerpo) => {
      const cuenta = cuentaDe(req);
      if (!cuenta) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });

      const permiso = RW.puedeDescargarDesdeLaWeb(cuenta);
      if (!permiso.puede) return json(res, 409, { motivo: permiso.motivo, mensaje: permiso.mensaje });

      const ruta = String(cuerpo.ruta || '');
      // La ruta viene del navegador: se valida que no se salga del espacio del
      // cliente. Sin esto, un `../` alcanzaría para leer el bucket de otro.
      if (!ruta || ruta.includes('..') || ruta.startsWith('/')) {
        return json(res, 400, { mensaje: 'Esa ruta no es válida.' });
      }

      try {
        const clave = cuenta.cifrado_clave
          ? Buffer.from(cuenta.cifrado_clave, 'base64') : null;
        const sitio = almacenDeCuenta(cuenta);
        const r = await RW.armarArchivo({
          almacen: sitio.almacen, prefijo: sitio.prefijo,
          rutaRelativa: ruta, clave, topeBytes: TOPE_DESCARGA_WEB,
        });
        auditar(db, cuenta.email, 'descargó un archivo desde la web', ruta, ipDe(req));
        res.writeHead(200, {
          'Content-Type': 'application/octet-stream',
          'Content-Disposition': `attachment; filename="${encodeURIComponent(r.nombre)}"`,
          'Content-Length': r.bytes,
        });
        return res.end(r.archivo);
      } catch (e) {
        const codigos = {
          demasiado_grande: [413, `Ese archivo pesa más de ${Math.round(TOPE_DESCARGA_WEB / 1048576)} MB. ` +
            'Bajalo desde el programa, que no tiene ese límite.'],
          bloque_faltante: [500, 'Falta un pedazo de ese archivo en el almacenamiento. Escribinos.'],
          huella_no_coincide: [500, 'El archivo no pasó la verificación y preferimos no entregártelo roto. Escribinos.'],
          indice_ilegible: [404, 'No encontramos ese archivo en tu respaldo.'],
          sin_clave: [409, 'Ese archivo está cifrado con una clave que no tenemos.'],
        };
        const [codigo, mensaje] = codigos[e.codigo] || [500, 'No se pudo armar el archivo.'];
        auditar(db, cuenta.email, 'falló una descarga desde la web', `${ruta}: ${e.codigo || e.message}`, ipDe(req));
        return json(res, codigo, { mensaje });
      }
    },

    /* ── Papelera ────────────────────────────────────────────────────────
       Los archivos son del cliente y tiene derecho a borrarlos. Pero no se
       borran de una: van a la papelera, dejan de contar en su cuota, y siguen
       recuperables 30 días. El arrepentimiento llega a los dos días, no a los
       dos minutos, y tres carteles de confirmación los clickea cualquiera. */

    'GET /api/portal/papelera': (req, res) => {
      const cuenta = cuentaDe(req);
      if (!cuenta) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });

      const filas = db.prepare(
        'SELECT id, ruta, nombre, bytes, equipo, borrado_el, vence_el FROM papelera ' +
        'WHERE cuenta_id = ? ORDER BY borrado_el DESC').all(cuenta.id);
      const ahora = Date.now();

      json(res, 200, {
        archivos: filas.map((f) => ({
          ...f,
          diasRestantes: Math.max(0, Math.ceil((new Date(f.vence_el).getTime() - ahora) / 86400000)),
        })),
        total: filas.length,
        bytes: filas.reduce((n, f) => n + (Number(f.bytes) || 0), 0),
        diasRetencion: DIAS_PAPELERA,
      });
    },

    'POST /api/portal/papelera/mandar': (req, res, cuerpo) => {
      const cuenta = cuentaDe(req);
      if (!cuenta) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });

      /* Se acepta una lista con el tamaño de CADA archivo.
         Antes solo llegaba un `bytes` suelto para todo el pedido: al mandar una
         carpeta entera, la papelera mostraba la cantidad de archivos y cero
         espacio, y la cuota no bajaba lo que correspondía. */
      const items = Array.isArray(cuerpo.archivos) && cuerpo.archivos.length
        ? cuerpo.archivos.map((a) => ({ ruta: String(a.ruta || ''), bytes: Number(a.bytes) || 0 }))
        : (Array.isArray(cuerpo.rutas) ? cuerpo.rutas : [cuerpo.ruta].filter(Boolean))
            .map((r) => ({ ruta: String(r || ''), bytes: Number(cuerpo.bytes) || 0 }));

      if (!items.length) return json(res, 400, { mensaje: 'No elegiste ningún archivo.' });

      const ahora = new Date();
      const vence = new Date(ahora.getTime() + DIAS_PAPELERA * 86400000);
      const meter = db.prepare(
        'INSERT OR REPLACE INTO papelera ' +
        '(id, cuenta_id, ruta, nombre, bytes, equipo, borrado_el, vence_el, quien) ' +
        'VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');

      let n = 0, bytes = 0;
      for (const it of items) {
        // Misma validación que la descarga: la ruta viene del navegador y no
        // puede salirse del espacio del cliente.
        if (!it.ruta || it.ruta.includes('..') || it.ruta.startsWith('/')) continue;
        meter.run(S.idCorto(), cuenta.id, it.ruta, it.ruta.split('/').pop(),
          it.bytes, cuerpo.equipo || null,
          ahora.toISOString(), vence.toISOString(), cuenta.email);
        n++; bytes += it.bytes;
      }

      auditar(db, cuenta.email, 'mandó archivos a la papelera',
        `${n} archivo(s), ${bytes} bytes` + (cuerpo.carpeta ? ` — carpeta ${cuerpo.carpeta}` : ''),
        ipDe(req));
      json(res, 200, {
        ok: true, movidos: n, bytes, diasRetencion: DIAS_PAPELERA,
        mensaje: n === 1
          ? `Listo. Lo podés recuperar durante ${DIAS_PAPELERA} días.`
          : `Listo, ${n} archivos. Los podés recuperar durante ${DIAS_PAPELERA} días.`,
      });
    },

    'POST /api/portal/papelera/recuperar': (req, res, cuerpo) => {
      const cuenta = cuentaDe(req);
      if (!cuenta) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });

      const ids = Array.isArray(cuerpo.ids) ? cuerpo.ids : [cuerpo.id].filter(Boolean);
      if (!ids.length) return json(res, 400, { mensaje: 'No elegiste nada para recuperar.' });

      // Se borra la marca, nada más. El archivo nunca se movió del
      // almacenamiento: recuperar es dejar de estar en la lista para borrar.
      const sacar = db.prepare('DELETE FROM papelera WHERE id = ? AND cuenta_id = ?');
      let n = 0;
      for (const id of ids) n += sacar.run(String(id), cuenta.id).changes;

      auditar(db, cuenta.email, 'recuperó archivos de la papelera', `${n} archivo(s)`, ipDe(req));
      json(res, 200, {
        ok: true, recuperados: n,
        mensaje: 'Volvieron a estar disponibles. No hacía falta bajarlos: nunca se movieron.',
      });
    },

    'GET /api/cuenta': (req, res) => {
      const cuenta = cuentaDe(req);
      if (!cuenta) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      const facturas = db.prepare('SELECT numero, monto, estado, emitida FROM facturas WHERE cuenta_id = ? ORDER BY emitida DESC')
        .all(cuenta.id);
      // El mismo cálculo que ve el programa de escritorio. Si el portal hiciera
      // su propia cuenta, los dos números iban a diferir y el cliente dejaría de
      // creerle a ninguno.
      const cuota = estadoDeCuota(cuenta);
      json(res, 200, {
        ...publica(cuenta), facturas, cuota, mensajeCuota: mensajeDeCuota(cuota),
        equipos: db.prepare(`SELECT nombre, bytes, archivos, ultimo_aviso,
                             fuera_archivos, fuera_bytes, fuera_desde
                             FROM equipos WHERE cuenta_id = ?`).all(cuenta.id),
      });
    },

    'POST /api/suscripciones/plan': (req, res, cuerpo) => {
      const cuenta = cuentaDe(req);
      if (!cuenta) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      const elegido = plan(cuerpo.planId);
      if (!elegido) return json(res, 400, { mensaje: 'Ese plan no existe.' });
      db.prepare('UPDATE cuentas SET plan_id = ? WHERE id = ?').run(elegido.id, cuenta.id);
      auditar(db, cuenta.email, 'cambio de plan', elegido.id, ipDe(req));
      json(res, 200, { planId: elegido.id, espacioGB: elegido.espacioGB });
    },

    'POST /api/suscripciones/checkout': (req, res, cuerpo) => {
      const cuenta = cuentaDe(req);
      if (!cuenta) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      const elegido = plan(cuerpo.planId || cuenta.plan_id);
      const referencia = `sub_${cuenta.id}_${Date.now()}`;
      db.prepare('UPDATE cuentas SET referencia = ? WHERE id = ?').run(referencia, cuenta.id);

      // PENDIENTE: con las credenciales de Mercado Pago, acá va la creación de
      // la preapproval y se devuelve su init_point. Hasta entonces se devuelve
      // una pantalla propia para poder probar el circuito entero.
      const mp = ajuste(db, 'mercadopago', null);
      const url = mp && mp.accessToken
        ? `https://www.mercadopago.com.ar/subscriptions/checkout?preapproval_plan_id=${encodeURIComponent(mp.planId || '')}&external_reference=${encodeURIComponent(referencia)}`
        : `/pago-simulado.html?ref=${encodeURIComponent(referencia)}`;

      json(res, 200, { checkoutUrl: url, referencia, montoMensual: elegido.precioMensual });
    },

    'POST /api/webhooks/mercadopago': (req, res, cuerpo, url, crudo) => {
      const secreto = ajuste(db, 'mercadopago', {}).webhookSecret || process.env.MP_WEBHOOK_SECRET;
      if (!secreto) return json(res, 503, { mensaje: 'Falta configurar el secreto del webhook.' });

      const firma = String(req.headers['x-signature'] || '');
      const esperada = crypto.createHmac('sha256', secreto).update(crudo).digest('hex');
      const iguales = firma.length === esperada.length &&
        crypto.timingSafeEqual(Buffer.from(firma), Buffer.from(esperada));
      if (!iguales) return json(res, 401, { mensaje: 'Firma inválida.' });

      const idEvento = String(cuerpo.id || '');
      if (db.prepare('SELECT 1 FROM eventos_pago WHERE id = ?').get(idEvento)) {
        return json(res, 200, { repetido: true });
      }
      db.prepare('INSERT INTO eventos_pago (id, visto) VALUES (?, ?)')
        .run(idEvento, new Date().toISOString());

      // Se fuerza a texto: un aviso sin referencia hacía reventar a SQLite y
      // el webhook devolvía 500. Un aviso mal formado tiene que dar 404 y
      // quedar registrado, no tirar abajo el manejador.
      const referencia = cuerpo.referencia == null ? '' : String(cuerpo.referencia);
      const cuenta = referencia
        ? db.prepare('SELECT * FROM cuentas WHERE referencia = ?').get(referencia)
        : null;
      if (!cuenta) {
        auditar(db, 'mercadopago', 'aviso sin suscripción conocida', referencia || '(sin referencia)');
        return json(res, 404, { mensaje: 'No se encontró la suscripción.' });
      }

      // PENDIENTE: con credenciales, antes de acreditar hay que volver a
      // consultarle el estado a la API de Mercado Pago. El aviso solo trae un
      // identificador y no hay que confiar en lo que venga en el cuerpo.

      if (cuerpo.estado === 'approved') {
        const elegido = plan(cuenta.plan_id) || planes()[0];
        const n = db.prepare('SELECT COUNT(*) c FROM facturas').get().c + 1;
        db.prepare(`INSERT INTO facturas (id, cuenta_id, numero, monto, estado, concepto, emitida, pagada)
                    VALUES (?, ?, ?, ?, 'pagada', ?, ?, ?)`)
          .run(S.idCorto(), cuenta.id, `FC-B 0001-${String(n).padStart(8, '0')}`,
               elegido.precioMensual, `Plan ${elegido.nombre}`,
               new Date().toISOString(), new Date().toISOString());
        db.prepare("UPDATE cuentas SET estado = 'activa', moroso = 0, mora_desde = NULL WHERE id = ?")
          .run(cuenta.id);
        provisionar(cuenta).catch(() => {});
        encolarAviso(db, { cuentaId: cuenta.id, para: cuenta.email,
          asunto: 'Pago acreditado', cuerpo: 'Ya está activa tu suscripción.' });
        auditar(db, 'mercadopago', 'pago acreditado', cuenta.email);
      } else if (cuerpo.estado === 'rejected') {
        db.prepare('UPDATE cuentas SET moroso = 1, mora_desde = COALESCE(mora_desde, ?) WHERE id = ?')
          .run(new Date().toISOString(), cuenta.id);
        encolarAviso(db, { cuentaId: cuenta.id, para: cuenta.email,
          asunto: 'No pudimos cobrar tu suscripción',
          cuerpo: 'Revisá los datos de tu tarjeta. Tus archivos siguen guardados.' });
        auditar(db, 'mercadopago', 'cobro rechazado', cuenta.email);
      }

      const actualizada = db.prepare('SELECT estado FROM cuentas WHERE id = ?').get(cuenta.id);
      json(res, 200, { ok: true, estado: actualizada.estado });
    },

    // ── Segundo factor del cliente ──────────────────────────────────────────

    // ── Ingreso del programa de escritorio ──────────────────────────────────
    //
    // Es la ruta que hace realidad "bajás el agente, ponés tu email y tu
    // contraseña, y listo". El programa ya la llamaba desde hace tiempo; lo que
    // faltaba era esto del lado del servidor.
    //
    // Devuelve tres cosas: un token propio del equipo, los datos de la cuenta
    // para mostrar en pantalla, y la configuración del destino ya armada. El
    // cliente no tiene que saber qué es un bucket, un endpoint ni un prefijo.
    //
    // El equipo NO recibe las claves del almacenamiento. Recibe su prefijo y
    // pide URLs firmadas cuando necesita subir o bajar. Así una notebook robada
    // no da acceso a nada más que a lo suyo, y rotar la credencial maestra no
    // obliga a tocar los equipos instalados.
    'POST /api/agent-auth/login': async (req, res, cuerpo) => {
      const usuario = String(cuerpo.email || '').trim().toLowerCase();
      const claveIntento = String(cuerpo.password || '');
      const trabaClave = `agente:${usuario}:${ipDe(req)}`;

      if (S.estaBloqueado(db, trabaClave)) {
        return json(res, 429, { error: 'Demasiados intentos. Esperá unos minutos.' });
      }

      const cuenta = db.prepare('SELECT * FROM cuentas WHERE email = ?').get(usuario);
      if (!cuenta || !S.verificarClave(claveIntento, cuenta.clave_hash)) {
        S.registrarIntento(db, trabaClave);
        // Mismo mensaje para los dos casos: si dijera cuál está mal, se podría
        // averiguar quiénes son los clientes probando direcciones.
        return json(res, 401, { error: 'El email o la contraseña no coinciden.' });
      }
      S.limpiarIntentos(db, trabaClave);

      // Segundo factor. El programa manda `totp` cuando el usuario lo escribe;
      // en el primer intento todavía no lo tiene, así que se le avisa.
      if (cuenta.mfa_activo) {
        const codigo = String(cuerpo.totp || '').trim();
        if (!codigo) {
          return json(res, 401, {
            necesitaSegundoFactor: true,
            error: 'Escribí el código de tu aplicación de autenticación.',
          });
        }
        const trabaMfa = `agente-mfa:${cuenta.id}:${ipDe(req)}`;
        if (S.estaBloqueado(db, trabaMfa)) {
          return json(res, 429, { error: 'Demasiados intentos. Esperá unos minutos.' });
        }
        if (!S.verificarTotp(cuenta.mfa_secreto, codigo)) {
          S.registrarIntento(db, trabaMfa);
          return json(res, 401, { necesitaSegundoFactor: true, error: 'El código no coincide.' });
        }
        S.limpiarIntentos(db, trabaMfa);
      }

      // Una cuenta suspendida no respalda. Se aclara el motivo: que el cliente
      // sepa que sus archivos siguen guardados es lo primero que va a preguntar.
      if (cuenta.estado === 'suspendida' || cuenta.estado === 'cancelada') {
        return json(res, 403, {
          error: 'Tu suscripción no está activa. Tus archivos siguen guardados; ' +
                 'entrá al portal para reactivarla.',
        });
      }

      // El espacio del cliente se crea acá si todavía no existe. Un cliente que
      // paga y baja el agente antes de que termine el alta no puede quedarse
      // esperando.
      let prefijo = cuenta.prefijo;
      if (!prefijo) {
        try {
          prefijo = await provisionar(cuenta);
        } catch (e) {
          auditar(db, cuenta.email, 'no se pudo crear el espacio', String(e.message));
          return json(res, 503, {
            error: 'Estamos terminando de preparar tu espacio. Probá de nuevo en unos minutos.',
          });
        }
      }

      // Alta del equipo. Se identifica por nombre dentro de la cuenta: volver a
      // ingresar desde la misma máquina actualiza el registro en lugar de
      // duplicarlo, que es lo que pasaría si se usara un id nuevo cada vez.
      const nombre = String(cuerpo.deviceName || '').trim().slice(0, 80) || 'Equipo sin nombre';
      const version = String(cuerpo.agentVersion || '').slice(0, 20);
      let equipo = db.prepare('SELECT * FROM equipos WHERE cuenta_id = ? AND nombre = ?')
        .get(cuenta.id, nombre);
      if (equipo) {
        db.prepare('UPDATE equipos SET version = ?, ultimo_aviso = ? WHERE id = ?')
          .run(version, new Date().toISOString(), equipo.id);
      } else {
        // Hoy ningún plan limita la cantidad de equipos ("Equipos ilimitados"),
        // así que esto no se aplica. Queda escrito para el día que se agregue el
        // campo `equipos` a un plan: es preferible que el agente reciba un aviso
        // claro a que el cliente descubra el tope de una forma rara.
        const limite = plan(cuenta.plan_id)?.equipos;
        const cuantos = db.prepare('SELECT COUNT(*) c FROM equipos WHERE cuenta_id = ?')
          .get(cuenta.id).c;
        if (limite && cuantos >= limite) {
          return json(res, 409, {
            error: `Tu plan permite ${limite} equipo${limite === 1 ? '' : 's'} y ya los tenés ` +
                   `en uso. Podés quitar uno desde el portal o cambiar de plan.`,
          });
        }
        const id = S.idCorto();
        db.prepare(`INSERT INTO equipos (id, cuenta_id, nombre, version, ultimo_aviso)
                    VALUES (?, ?, ?, ?, ?)`)
          .run(id, cuenta.id, nombre, version, new Date().toISOString());
        equipo = { id, cuenta_id: cuenta.id, nombre, version };
        auditar(db, cuenta.email, 'equipo dado de alta', nombre, ipDe(req));
      }

      // Token largo: el equipo respalda solo, sin nadie delante que pueda volver
      // a escribir la contraseña cuando venza.
      const token = S.crearSesion(db, cuenta.id, {
        tipo: 'agente', ip: ipDe(req),
        agente: `${nombre} (${version})`, dias: 365,
      });

      auditar(db, cuenta.email, 'ingreso desde el agente', nombre, ipDe(req));

      const elegido = plan(cuenta.plan_id) || planes()[0];
      const cuota = estadoDeCuota(cuenta);
      const cfgE2 = ajuste(db, 'e2', {});
      json(res, 200, {
        agentToken: token,
        // Ya en el ingreso, para que el programa pueda mostrar el consumo sin
        // esperar al primer respaldo.
        cuota, mensajeCuota: mensajeDeCuota(cuota),
        device: { id: equipo.id, name: nombre },
        /**
         * Dónde van los archivos de ESTE cliente.
         *
         * Es lo que hace que el alta deje de ser manual: antes había que cargar
         * esto a mano en cada máquina. Ahora el cliente pone su email y su
         * contraseña y el servidor le dice dónde respaldar.
         *
         * NO viajan las claves del almacenamiento. El agente recibe su destino;
         * las credenciales se resuelven aparte. Una llave de larga vida en la
         * máquina de un cliente es la llave que se lleva el ransomware.
         */
        almacenamiento: {
          prefijo,
          bucketPropio: cfgE2.modo === 'bucket',
          // Con bucket propio el prefijo es "<bucket>/": el bucket es lo que va
          // antes de la primera barra.
          bucket: cfgE2.modo === 'bucket' ? String(prefijo).split('/')[0] : null,
          region: cfgE2.region || null,
        },
        account: {
          email: cuenta.email,
          organizacion: cuenta.organizacion,
          plan: elegido.nombre,
          estado: cuenta.estado,
          // El campo del plan es `espacioGB`. Con el nombre equivocado esto
          // devolvía null siempre y el agente no podía mostrar cuánto espacio
          // tiene el cliente.
          cuotaBytes: elegido.espacioGB ? elegido.espacioGB * 1024 * 1024 * 1024 : null,
          espacioGB: elegido.espacioGB || null,
        },
      });
    },

    // ── Consumo informado por el programa de escritorio ────────────────────
    //
    // El equipo manda su total ABSOLUTO, no la diferencia. Con diferencias, un
    // aviso perdido o repetido desajusta la cuenta para siempre y nadie se
    // entera hasta que el número no cierra con la factura.
    'POST /api/agent/uso': (req, res, cuerpo) => {
      const s = sesionDe(req);
      if (!s || s.tipo !== 'agente') return json(res, 401, { error: 'Falta iniciar sesión.' });
      const cuenta = db.prepare('SELECT * FROM cuentas WHERE id = ?').get(s.cuenta_id);
      if (!cuenta) return json(res, 401, { error: 'Falta iniciar sesión.' });

      const nombre = String(cuerpo.deviceName || '').trim().slice(0, 80);
      const equipo = nombre
        ? db.prepare('SELECT * FROM equipos WHERE cuenta_id = ? AND nombre = ?').get(cuenta.id, nombre)
        : null;
      if (!equipo) return json(res, 404, { error: 'Ese equipo no está registrado.' });

      const bytes = Math.max(0, Math.floor(Number(cuerpo.bytes) || 0));
      const archivos = Math.max(0, Math.floor(Number(cuerpo.archivos) || 0));

      // Lo que el trabajo actual ya no cubre. Viene calculado por el agente, que
      // es el único que sabe qué carpetas se están respaldando hoy. Si no lo
      // informa —agente viejo— se deja lo anterior en vez de ponerlo en cero:
      // un cero inventado le diría al cliente que no tiene nada congelado.
      const fuera = cuerpo.fueraDelRespaldo;
      if (fuera && typeof fuera === 'object') {
        db.prepare('UPDATE equipos SET fuera_archivos = ?, fuera_bytes = ?, fuera_desde = ? WHERE id = ?')
          .run(Math.max(0, Math.floor(Number(fuera.archivos) || 0)),
               Math.max(0, Math.floor(Number(fuera.bytes) || 0)),
               fuera.desdeMs ? new Date(Number(fuera.desdeMs)).toISOString() : null,
               equipo.id);
      }

      db.prepare('UPDATE equipos SET bytes = ?, archivos = ?, ultimo_aviso = ? WHERE id = ?')
        .run(bytes, archivos, new Date().toISOString(), equipo.id);

      // Se devuelve el estado ya calculado: el programa lo muestra sin tener que
      // preguntar de nuevo, y así el número es SIEMPRE el mismo que el del
      // portal, porque sale de la misma función.
      const cuota = estadoDeCuota(cuenta);
      json(res, 200, { ok: true, cuota, mensaje: mensajeDeCuota(cuota) });
    },

    // Para el botón "consultar" del programa. Mismo cálculo, misma respuesta.
    /**
     * El agente avisa que frenó el respaldo por sospecha de cifrado masivo.
     *
     * Queda registrado del lado del servidor a propósito: si solo existiera la
     * notificación en la máquina del cliente, un ransomware que corre un sábado
     * a la madrugada lo ve nadie. Acá Ariel lo tiene en Auditoría y le llega por
     * mail, y puede llamar al cliente antes de que el lunes sea tarde.
     */
    'POST /api/agent/alerta': (req, res, cuerpo) => {
      const s = sesionDe(req);
      if (!s || s.tipo !== 'agente') return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      const cuenta = db.prepare('SELECT * FROM cuentas WHERE id = ?').get(s.cuenta_id);
      if (!cuenta) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });

      const equipo = String(cuerpo.deviceName || 'equipo sin nombre');
      const motivos = Array.isArray(cuerpo.motivos) ? cuerpo.motivos.slice(0, 10).join(' · ') : '';
      const detalle = `${equipo}: ${motivos}`.slice(0, 900);

      auditar(db, cuenta.email, 'ALERTA de cifrado masivo — respaldo frenado', detalle, ipDe(req));
      encolarAviso(db, {
        cuentaId: cuenta.id, para: cuenta.email,
        asunto: 'Frenamos tu respaldo: podría ser ransomware',
        cuerpo: `En ${equipo} cambiaron muchos archivos de golpe y parecen cifrados. ` +
                'Frenamos el respaldo para no pisar tus copias buenas.\n\n' + motivos +
                '\n\nTus copias anteriores están a salvo y las podés restaurar. ' +
                'Desconectá ese equipo de la red y escribinos.',
      });

      // El aviso a Ariel va aparte: el cliente puede estar sin poder leer el mail.
      const admin = ajuste(db, 'admin', {});
      if (admin.email) {
        encolarAviso(db, {
          cuentaId: cuenta.id, para: admin.email,
          asunto: `ALERTA ransomware — ${cuenta.organizacion}`,
          cuerpo: `${cuenta.organizacion} (${cuenta.email})\n${detalle}\n\n` +
                  'El respaldo de ese equipo quedó frenado.',
        });
      }

      json(res, 200, {
        ok: true,
        mensaje: 'Alerta registrada. Tus copias anteriores están a salvo.',
      });
    },

    'GET /api/agent/cuota': (req, res) => {
      const s = sesionDe(req);
      if (!s || s.tipo !== 'agente') return json(res, 401, { error: 'Falta iniciar sesión.' });
      const cuenta = db.prepare('SELECT * FROM cuentas WHERE id = ?').get(s.cuenta_id);
      if (!cuenta) return json(res, 401, { error: 'Falta iniciar sesión.' });
      const cuota = estadoDeCuota(cuenta);
      json(res, 200, {
        cuota,
        mensaje: mensajeDeCuota(cuota),
        equipos: db.prepare(`SELECT nombre, bytes, archivos, ultimo_aviso,
                             fuera_archivos, fuera_bytes, fuera_desde
                             FROM equipos WHERE cuenta_id = ?`).all(cuenta.id),
      });
    },

    'POST /api/cuenta/mfa/iniciar': (req, res) => {
      const cuenta = cuentaDe(req);
      if (!cuenta) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      // El secreto se guarda pero mfa_activo queda en 0 hasta que el cliente
      // demuestre que su teléfono genera códigos válidos. Si se activara acá,
      // alguien que escanee mal el código queda afuera de su propia cuenta.
      const secreto = S.secretoTotp();
      db.prepare('UPDATE cuentas SET mfa_secreto = ?, mfa_activo = 0 WHERE id = ?')
        .run(secreto, cuenta.id);
      json(res, 200, { secreto, url: S.urlTotp(secreto, cuenta.email) });
    },

    'POST /api/cuenta/mfa/confirmar': (req, res, cuerpo) => {
      const cuenta = cuentaDe(req);
      if (!cuenta) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      if (!cuenta.mfa_secreto) {
        return json(res, 400, { mensaje: 'Primero hay que empezar la activación.' });
      }
      if (!S.verificarTotp(cuenta.mfa_secreto, cuerpo.codigo)) {
        return json(res, 400, { mensaje: 'Ese código no coincide. Probá con el siguiente.' });
      }
      db.prepare('UPDATE cuentas SET mfa_activo = 1 WHERE id = ?').run(cuenta.id);
      auditar(db, cuenta.email, 'activó el segundo factor', null, ipDe(req));
      json(res, 200, { ok: true, activo: true });
    },

    /* ── Autogestión del cliente ─────────────────────────────────────────
       Todo lo de acá abajo lo tenía que hacer Ariel a mano en la base o por
       teléfono. Cada cosa que el cliente puede resolver solo es una llamada
       menos un sábado. */

    /** Cambiar la propia contraseña, ya estando adentro. */
    'POST /api/cuenta/clave': (req, res, cuerpo) => {
      const cuenta = cuentaDe(req);
      if (!cuenta) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      if (!S.verificarClave(cuerpo.actual, cuenta.clave_hash)) {
        return json(res, 401, { campo: 'actual', mensaje: 'La contraseña actual no coincide.' });
      }
      const problema = S.claveAceptable(cuerpo.nueva, 10);
      if (problema) return json(res, 400, { campo: 'nueva', mensaje: problema });

      db.prepare('UPDATE cuentas SET clave_hash = ? WHERE id = ?')
        .run(S.hashClave(cuerpo.nueva), cuenta.id);
      // Se cierran las demás sesiones: si la cambió porque se la robaron, que
      // el que la tenía quede afuera. La actual sigue viva para no echarlo a él.
      const s = sesionDe(req);
      S.cerrarTodas(db, 'cliente', s && s.token);
      auditar(db, cuenta.email, 'cambió su contraseña', null, ipDe(req));
      json(res, 200, { ok: true, mensaje: 'Listo. Las demás sesiones quedaron cerradas.' });
    },

    /** Corregir los datos de facturación. */
    'PUT /api/cuenta/datos': (req, res, cuerpo) => {
      const cuenta = cuentaDe(req);
      if (!cuenta) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });

      const organizacion = String(cuerpo.organizacion || '').trim();
      if (organizacion.length < 2) {
        return json(res, 400, { campo: 'organizacion', mensaje: 'Falta la razón social.' });
      }
      const cuit = String(cuerpo.cuit || '').trim();
      if (cuit && !S.cuitValido(cuit)) {
        return json(res, 400, { campo: 'cuit', mensaje: 'El CUIT no es válido.' });
      }
      // El email NO se cambia acá: es la identidad con la que entra el agente
      // en todas las máquinas. Cambiarlo de un formulario dejaría a los equipos
      // sin poder autenticarse y nadie entendería por qué.
      db.prepare(`UPDATE cuentas SET organizacion = ?, cuit = ?, celular = ?,
                  telefono = ?, direccion = ?, localidad = ?, provincia = ? WHERE id = ?`)
        .run(organizacion, cuit || null,
             cuerpo.celular || null, cuerpo.telefono || null, cuerpo.direccion || null,
             cuerpo.localidad || null, cuerpo.provincia || null, cuenta.id);
      auditar(db, cuenta.email, 'corrigió sus datos de facturación', null, ipDe(req));
      json(res, 200, { ok: true, cuenta: publica(db.prepare('SELECT * FROM cuentas WHERE id = ?').get(cuenta.id)) });
    },

    /** Desvincular un equipo (se vendió la PC, se cambió el nombre). */
    'POST /api/cuenta/equipos/desvincular': (req, res, cuerpo) => {
      const cuenta = cuentaDe(req);
      if (!cuenta) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      const equipo = db.prepare('SELECT * FROM equipos WHERE cuenta_id = ? AND nombre = ?')
        .get(cuenta.id, String(cuerpo.nombre || ''));
      if (!equipo) return json(res, 404, { mensaje: 'No existe ese equipo en tu cuenta.' });

      db.prepare('DELETE FROM equipos WHERE id = ?').run(equipo.id);
      auditar(db, cuenta.email, 'desvinculó el equipo ' + equipo.nombre, null, ipDe(req));
      // Los archivos NO se borran: desvincular es sacarlo de la lista, no
      // destruir el respaldo. El que vendió la PC todavía quiere sus archivos.
      json(res, 200, {
        ok: true,
        mensaje: 'El equipo salió de la lista. Los archivos que ya había respaldado siguen guardados.',
      });
    },

    /** Dar de baja la suscripción. */
    'POST /api/suscripciones/cancelar': (req, res, cuerpo) => {
      const cuenta = cuentaDe(req);
      if (!cuenta) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      if (!S.verificarClave(cuerpo.clave, cuenta.clave_hash)) {
        return json(res, 401, { campo: 'clave', mensaje: 'La contraseña no coincide.' });
      }
      if (cuenta.estado === 'cancelada') {
        return json(res, 200, { ok: true, mensaje: 'Tu suscripción ya estaba dada de baja.' });
      }
      db.prepare('UPDATE cuentas SET estado = ? WHERE id = ?').run('cancelada', cuenta.id);
      auditar(db, cuenta.email, 'dio de baja la suscripción', cuerpo.motivo || null, ipDe(req));
      encolarAviso(db, {
        cuentaId: cuenta.id, para: cuenta.email, asunto: 'Diste de baja BackupPrime',
        cuerpo: 'Tus archivos guardados siguen estando y los podés restaurar. ' +
                'Los respaldos nuevos quedaron detenidos. Si fue un error, escribinos.',
      });
      // No se borra nada. Restaurar nunca se bloquea, ni siquiera de baja: el
      // cliente que se va tiene derecho a llevarse lo suyo.
      json(res, 200, {
        ok: true,
        mensaje: 'Tu suscripción quedó dada de baja. Tus archivos siguen guardados y los podés restaurar.',
      });
    },

    'POST /api/cuenta/mfa/desactivar': (req, res, cuerpo) => {
      const cuenta = cuentaDe(req);
      if (!cuenta) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      // Se pide la contraseña: si alguien te robó la sesión abierta, que no
      // pueda bajarle la seguridad a la cuenta de un clic.
      if (!S.verificarClave(cuerpo.clave, cuenta.clave_hash)) {
        return json(res, 401, { mensaje: 'La contraseña no coincide.' });
      }
      db.prepare('UPDATE cuentas SET mfa_activo = 0, mfa_secreto = NULL WHERE id = ?').run(cuenta.id);
      auditar(db, cuenta.email, 'desactivó el segundo factor', null, ipDe(req));
      json(res, 200, { ok: true, activo: false });
    },

    'GET /api/cuenta/sesiones': (req, res) => {
      const cuenta = cuentaDe(req);
      if (!cuenta) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      json(res, 200, {
        sesiones: db.prepare(`SELECT token, ip, agente, creada FROM sesiones
                              WHERE cuenta_id = ? AND pendiente = 0 ORDER BY creada DESC`)
          .all(cuenta.id)
          // Nunca devolver el token entero: alcanzaría para usurpar la sesión.
          .map((x) => ({ id: x.token.slice(0, 8), ip: x.ip, agente: x.agente, creada: x.creada })),
      });
    },

    'POST /api/cuenta/sesiones/cerrar': (req, res) => {
      const s = sesionDe(req);
      const cuenta = cuentaDe(req);
      if (!cuenta) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      S.cerrarTodas(db, cuenta.id, s.token);
      auditar(db, cuenta.email, 'cerró las otras sesiones', null, ipDe(req));
      json(res, 200, { ok: true });
    },

    // ── Administración ──────────────────────────────────────────────────────

    'GET /api/admin/resumen': (req, res) => {
      if (!esAdmin(req)) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      const c = db.prepare(`SELECT
          COUNT(*) total,
          SUM(estado = 'activa') activas,
          SUM(estado = 'prueba') prueba,
          SUM(moroso = 1) morosas FROM cuentas`).get();
      const facturado = db.prepare(`SELECT COALESCE(SUM(monto), 0) m FROM facturas
                                    WHERE estado = 'pagada' AND emitida >= ?`)
        .get(new Date(Date.now() - 30 * 864e5).toISOString()).m;
      json(res, 200, { cuentas: c, facturadoUltimos30: facturado,
                       claveInicial: !!ajuste(db, 'admin').claveInicial });
    },

    /* ── Las tres puertas de rescate ─────────────────────────────────────
       Sin esto, el admin mira la lista de clientes y no puede hacer nada. Un
       contador que se queda afuera de su cuenta un 30 de abril necesita que
       alguien pueda ayudarlo sin tocar la base a mano.

       Todas piden la contraseña del admin: la sesión abierta del panel no
       alcanza para intervenir la cuenta de otro. Y todas quedan auditadas con
       nombre y apellido de quién lo hizo. */

    /** Ficha de un cliente, con sus equipos. */
    'POST /api/admin/clientes/ficha': (req, res, cuerpo) => {
      if (!esAdmin(req)) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      const cuenta = db.prepare('SELECT * FROM cuentas WHERE id = ?').get(String(cuerpo.id || ''));
      if (!cuenta) return json(res, 404, { mensaje: 'No existe ese cliente.' });
      json(res, 200, {
        // El mismo cálculo de cuota que ve el cliente y que ve el agente. Si el
        // panel hiciera su propia cuenta, Ariel vería un número y el cliente
        // otro, discutiendo por teléfono cuál de los dos está bien.
        cliente: { ...publica(cuenta), cuota: estadoDeCuota(cuenta) },
        equipos: db.prepare('SELECT nombre, version, ultimo_aviso, bytes, archivos FROM equipos WHERE cuenta_id = ?')
          .all(cuenta.id),
        sesiones: db.prepare('SELECT COUNT(*) AS n FROM sesiones WHERE cuenta_id = ?').get(cuenta.id).n,
      });
    },

    /** Puerta 1: restablecer la contraseña de un cliente. */
    'POST /api/admin/clientes/clave': (req, res, cuerpo) => {
      const s = esAdmin(req);
      if (!s) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      const admin = ajuste(db, 'admin');
      if (!S.verificarClave(cuerpo.claveAdmin, admin.claveHash)) {
        return json(res, 401, { campo: 'claveAdmin', mensaje: 'Tu contraseña de administrador no coincide.' });
      }
      const cuenta = db.prepare('SELECT * FROM cuentas WHERE id = ?').get(String(cuerpo.id || ''));
      if (!cuenta) return json(res, 404, { mensaje: 'No existe ese cliente.' });

      // No se elige la contraseña por el cliente ni se manda por mail: se
      // genera una provisoria que se le dicta por teléfono. El mail puede estar
      // justamente en la máquina que no arranca.
      const provisoria = S.idCorto(4) + '-' + S.idCorto(4) + '-' + S.idCorto(4);
      db.prepare('UPDATE cuentas SET clave_hash = ? WHERE id = ?')
        .run(S.hashClave(provisoria), cuenta.id);
      S.cerrarTodas(db, 'cliente', null);
      auditar(db, admin.usuario, 'restableció la contraseña de ' + cuenta.email, null, ipDe(req));
      json(res, 200, {
        ok: true, provisoria,
        mensaje: 'Dictale esta contraseña por teléfono. Pedile que la cambie al entrar.',
      });
    },

    /** Puerta 2: desactivar el segundo factor de un cliente que perdió el teléfono. */
    'POST /api/admin/clientes/mfa': (req, res, cuerpo) => {
      const s = esAdmin(req);
      if (!s) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      const admin = ajuste(db, 'admin');
      if (!S.verificarClave(cuerpo.claveAdmin, admin.claveHash)) {
        return json(res, 401, { campo: 'claveAdmin', mensaje: 'Tu contraseña de administrador no coincide.' });
      }
      const cuenta = db.prepare('SELECT * FROM cuentas WHERE id = ?').get(String(cuerpo.id || ''));
      if (!cuenta) return json(res, 404, { mensaje: 'No existe ese cliente.' });
      if (!cuenta.mfa_activo) {
        return json(res, 200, { ok: true, mensaje: 'Ese cliente no tenía el segundo factor activo.' });
      }
      db.prepare('UPDATE cuentas SET mfa_activo = 0, mfa_secreto = NULL WHERE id = ?').run(cuenta.id);
      auditar(db, admin.usuario, 'desactivó el segundo factor de ' + cuenta.email,
        cuerpo.motivo || null, ipDe(req));
      encolarAviso(db, {
        cuentaId: cuenta.id, para: cuenta.email,
        asunto: 'Se desactivó la verificación en dos pasos de tu cuenta',
        cuerpo: 'Lo hicimos a pedido, desde soporte. Si no fuiste vos, escribinos ya mismo. ' +
                'Te conviene volver a activarla desde el portal.',
      });
      json(res, 200, { ok: true, mensaje: 'Listo. Se le avisó por mail.' });
    },

    /** Puerta 3: destrabar a un cliente bloqueado por intentos fallidos. */
    'POST /api/admin/clientes/destrabar': (req, res, cuerpo) => {
      const s = esAdmin(req);
      if (!s) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      const cuenta = db.prepare('SELECT * FROM cuentas WHERE id = ?').get(String(cuerpo.id || ''));
      if (!cuenta) return json(res, 404, { mensaje: 'No existe ese cliente.' });
      S.limpiarIntentos(db, `clave:${cuenta.email}`);
      S.limpiarIntentos(db, `mfa:${cuenta.id}`);
      auditar(db, ajuste(db, 'admin').usuario, 'destrabó los intentos de ' + cuenta.email, null, ipDe(req));
      json(res, 200, { ok: true, mensaje: 'Ya puede volver a intentar entrar.' });
    },

    /** Cobros: sin esto el secreto del webhook solo entraba por variable de
        entorno, y el circuito de pago devolvía 503 sin explicar por qué. */
    /* ── Aprovisionamiento automático (iDrive e2) ────────────────────────
       Sin esto, cada cliente nuevo son quince minutos de Ariel creando el
       bucket a mano y cargando las claves en cada máquina. */
    'GET /api/admin/e2': (req, res) => {
      if (!esAdmin(req)) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      const c = ajuste(db, 'e2', {});
      json(res, 200, {
        // La clave API no vuelve nunca al navegador: solo si está puesta.
        tieneApiKey: !!c.apiKey,
        modo: c.modo === 'bucket' ? 'bucket' : 'prefijo',
        region: c.region || '',
        prefijoBucket: c.prefijoBucket || 'bp',
        retencionDias: c.retencionDias == null ? 20 : Number(c.retencionDias),
        modoRetencion: c.modoRetencion === 'COMPLIANCE' ? 'COMPLIANCE' : 'GOVERNANCE',
        conBucketPropio: db.prepare(
          "SELECT COUNT(*) n FROM cuentas WHERE prefijo IS NOT NULL AND prefijo LIKE ?")
          .get((c.prefijoBucket || 'bp') + '-%').n,
      });
    },

    'PUT /api/admin/e2': (req, res, cuerpo) => {
      if (!esAdmin(req)) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      const previo = ajuste(db, 'e2', {});
      const modo = cuerpo.modo === 'bucket' ? 'bucket' : 'prefijo';
      if (modo === 'bucket' && !(cuerpo.region || previo.region)) {
        return json(res, 400, { campo: 'region',
          mensaje: 'Falta la región. Sin región no se sabe dónde crear el bucket.' });
      }
      const dias = cuerpo.retencionDias == null ? previo.retencionDias : Number(cuerpo.retencionDias);
      if (dias != null && (!isFinite(dias) || dias < 0 || dias > 3650)) {
        return json(res, 400, { campo: 'retencionDias',
          mensaje: 'La retención tiene que estar entre 0 y 3650 días.' });
      }
      guardarAjuste(db, 'e2', {
        // Campo vacío = no lo toques: así se cambia la región sin volver a
        // tipear la clave, que no se muestra.
        apiKey: cuerpo.apiKey ? String(cuerpo.apiKey).trim() : previo.apiKey,
        modo,
        region: cuerpo.region !== undefined ? String(cuerpo.region).trim() : previo.region,
        prefijoBucket: (cuerpo.prefijoBucket || previo.prefijoBucket || 'bp')
          .toString().toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 12) || 'bp',
        retencionDias: dias == null ? 20 : dias,
        modoRetencion: cuerpo.modoRetencion === 'COMPLIANCE' ? 'COMPLIANCE' : 'GOVERNANCE',
      });
      auditar(db, ajuste(db, 'admin').usuario, 'cambió el aprovisionamiento', modo, ipDe(req));
      json(res, 200, { ok: true, modo });
    },

    /** Prueba el alta completa contra un bucket descartable. */
    'POST /api/admin/e2/probar': async (req, res) => {
      if (!esAdmin(req)) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      const cfg = ajuste(db, 'e2', {});
      const bucket = `${cfg.prefijoBucket || 'bp'}-prueba-${S.idCorto(6).toLowerCase()}`;
      try {
        const almacenPrueba = almacenamiento.crear({
          ...ajuste(db, 'almacenamiento', ALMACEN_INICIAL), bucket,
        });
        if (typeof almacenPrueba.peticion !== 'function') {
          return json(res, 200, { ok: false, pasos: [{
            que: 'el proveedor permite crear buckets', ok: false,
            detalle: 'El almacenamiento configurado no es compatible con S3. ' +
                     'Configuralo en Almacenamiento antes de activar el alta automática.' }] });
        }
        const r = await e2.prepararBucket({
          pedir: almacenPrueba.peticion, bucket,
          retencionDias: Number(cfg.retencionDias) || 0,
          modoRetencion: cfg.modoRetencion === 'COMPLIANCE' ? 'COMPLIANCE' : 'GOVERNANCE',
        });
        json(res, 200, { ok: r.ok, conLock: r.conLock, pasos: r.pasos, bucket });
      } catch (e) {
        json(res, 200, { ok: false, pasos: [{ que: 'conectar con el proveedor', ok: false, detalle: e.message }] });
      }
    },

    'GET /api/admin/mercadopago': (req, res) => {
      if (!esAdmin(req)) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      const mp = ajuste(db, 'mercadopago', {});
      json(res, 200, {
        // Los secretos no vuelven al navegador: solo si están puestos o no.
        tieneAccessToken: !!mp.accessToken,
        tieneWebhookSecret: !!mp.webhookSecret,
        publicKey: mp.publicKey || '',
        modo: mp.accessToken ? 'real' : 'simulado',
      });
    },

    'PUT /api/admin/mercadopago': (req, res, cuerpo) => {
      if (!esAdmin(req)) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      const previo = ajuste(db, 'mercadopago', {});
      // Campo vacío = no lo toques. Así se puede cambiar el webhook sin volver
      // a tipear el access token, que no se muestra.
      const nuevo = {
        accessToken: cuerpo.accessToken ? String(cuerpo.accessToken).trim() : previo.accessToken,
        webhookSecret: cuerpo.webhookSecret ? String(cuerpo.webhookSecret).trim() : previo.webhookSecret,
        publicKey: cuerpo.publicKey !== undefined ? String(cuerpo.publicKey).trim() : previo.publicKey,
      };
      if (cuerpo.borrarAccessToken) nuevo.accessToken = null;
      guardarAjuste(db, 'mercadopago', nuevo);
      auditar(db, ajuste(db, 'admin').usuario, 'cambió la configuración de cobros', null, ipDe(req));
      json(res, 200, {
        ok: true,
        tieneAccessToken: !!nuevo.accessToken,
        tieneWebhookSecret: !!nuevo.webhookSecret,
        modo: nuevo.accessToken ? 'real' : 'simulado',
      });
    },

    'GET /api/admin/clientes': (req, res) => {
      if (!esAdmin(req)) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      json(res, 200, {
        clientes: db.prepare('SELECT * FROM cuentas ORDER BY creada DESC LIMIT 500')
          .all().map(publica),
      });
    },

    'POST /api/admin/clave': (req, res, cuerpo) => {
      const s = esAdmin(req);
      if (!s) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      const admin = ajuste(db, 'admin');
      if (!S.verificarClave(cuerpo.actual, admin.claveHash)) {
        return json(res, 401, { mensaje: 'La contraseña actual no coincide.' });
      }
      const problema = S.claveAceptable(cuerpo.nueva, 12);
      if (problema) return json(res, 400, { campo: 'nueva', mensaje: problema });

      guardarAjuste(db, 'admin', { usuario: admin.usuario, claveHash: S.hashClave(cuerpo.nueva), claveInicial: false });
      S.cerrarTodas(db, 'admin', s.token);
      auditar(db, admin.usuario, 'cambió su contraseña', null, ipDe(req));
      json(res, 200, { ok: true });
    },

    // ── Correo saliente ─────────────────────────────────────────────────────

    'GET /api/admin/correo/catalogo': (req, res) => {
      if (!esAdmin(req)) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      const actual = { ...ajuste(db, 'correo', { proveedor: 'donweb' }) };
      delete actual.clave;   // nunca se devuelve la contraseña al navegador
      json(res, 200, { catalogo: correo.CATALOGO, actual });
    },

    'POST /api/admin/correo/probar': async (req, res, cuerpo) => {
      if (!esAdmin(req)) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      try {
        const config = cuerpo.clave ? cuerpo : { ...ajuste(db, 'correo', {}), ...cuerpo };
        json(res, 200, await correo.crear(config).probar(cuerpo.destinatario));
      } catch (e) {
        json(res, 200, { ok: false, detalle: e.message });
      }
    },

    'PUT /api/admin/correo': async (req, res, cuerpo) => {
      if (!esAdmin(req)) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      // Igual que con el almacenamiento: no se guarda algo que no funciona. Un
      // correo mal configurado no se nota hasta que un cliente no recibe su
      // factura, y para entonces ya perdiste una semana.
      let prueba;
      try { prueba = await correo.crear(cuerpo).probar(cuerpo.destinatario); }
      catch (e) { prueba = { ok: false, detalle: e.message }; }
      if (!prueba.ok) return json(res, 400, { mensaje: prueba.detalle });

      guardarAjuste(db, 'correo', cuerpo);
      auditar(db, 'admin', 'cambió el correo saliente', cuerpo.proveedor, ipDe(req));
      json(res, 200, { ok: true, detalle: prueba.detalle });
    },

    'POST /api/admin/correo/despachar': async (req, res) => {
      if (!esAdmin(req)) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      json(res, 200, await despachar());
    },

    'GET /api/admin/almacenamiento/catalogo': (req, res) => {
      if (!esAdmin(req)) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      json(res, 200, { catalogo: almacenamiento.CATALOGO, actual: ajuste(db, 'almacenamiento') });
    },

    'POST /api/admin/almacenamiento/probar': async (req, res, cuerpo) => {
      if (!esAdmin(req)) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      try {
        json(res, 200, await almacenamiento.crear(cuerpo).probar());
      } catch (e) {
        json(res, 200, { ok: false, detalle: e.message });
      }
    },

    'PUT /api/admin/almacenamiento': async (req, res, cuerpo) => {
      if (!esAdmin(req)) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      // No se guarda una configuración que no funcione: quedaría el servicio
      // caído sin que nadie se entere hasta el próximo respaldo.
      let prueba;
      try { prueba = await almacenamiento.crear(cuerpo).probar(); }
      catch (e) { prueba = { ok: false, detalle: e.message }; }
      if (!prueba.ok) return json(res, 400, { mensaje: prueba.detalle });

      guardarAjuste(db, 'almacenamiento', cuerpo);
      auditar(db, 'admin', 'cambió el almacenamiento', cuerpo.proveedor, ipDe(req));
      json(res, 200, { ok: true, detalle: prueba.detalle });
    },

    'GET /api/admin/planes': (req, res) => {
      if (!esAdmin(req)) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      json(res, 200, { planes: planes() });
    },

    'PUT /api/admin/planes': (req, res, cuerpo) => {
      if (!esAdmin(req)) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      if (!Array.isArray(cuerpo.planes) || !cuerpo.planes.length) {
        return json(res, 400, { mensaje: 'Faltan los planes.' });
      }
      guardarAjuste(db, 'planes', cuerpo.planes);
      auditar(db, 'admin', 'cambió los planes', cuerpo.planes.map((p) => `${p.id}:${p.precioMensual}`).join(', '), ipDe(req));
      json(res, 200, { ok: true });
    },

    'GET /api/admin/mora': (req, res) => {
      if (!esAdmin(req)) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      json(res, 200, { mora: ajuste(db, 'mora', MORA_INICIAL) });
    },

    'PUT /api/admin/mora': (req, res, cuerpo) => {
      if (!esAdmin(req)) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      guardarAjuste(db, 'mora', cuerpo.mora || cuerpo);
      auditar(db, 'admin', 'cambió la escalera de mora', JSON.stringify(cuerpo.mora || cuerpo), ipDe(req));
      json(res, 200, { ok: true });
    },

    'GET /api/admin/auditoria': (req, res) => {
      if (!esAdmin(req)) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      json(res, 200, {
        eventos: db.prepare('SELECT * FROM auditoria ORDER BY id DESC LIMIT 200').all(),
      });
    },

    'GET /api/admin/avisos': (req, res) => {
      if (!esAdmin(req)) return json(res, 401, { mensaje: 'Falta iniciar sesión.' });
      json(res, 200, {
        avisos: db.prepare('SELECT * FROM avisos ORDER BY id DESC LIMIT 200').all(),
      });
    },

    // Solo existe mientras no haya credenciales de Mercado Pago. Con MP
    // configurado devuelve 404: no puede quedar una puerta para acreditar
    // pagos a mano en producción.
    'POST /api/pago-simulado': (req, res, cuerpo) => {
      const mp = ajuste(db, 'mercadopago', {});
      if (mp.accessToken) return json(res, 404, { mensaje: 'No existe esa ruta.' });
      const secreto = mp.webhookSecret || process.env.MP_WEBHOOK_SECRET;
      if (!secreto) {
        return json(res, 503, { ok: false,
          mensaje: 'Falta configurar el secreto del webhook. Cargalo en Administración → Cobros.' });
      }
      if (!cuerpo.referencia) {
        return json(res, 400, { ok: false,
          mensaje: 'Falta la referencia de la suscripción. Volvé a empezar el pago desde tu plan.' });
      }

      const aviso = JSON.stringify({
        id: 'sim_' + crypto.randomUUID(),
        referencia: cuerpo.referencia,
        estado: cuerpo.estado === 'approved' ? 'approved' : 'rejected',
      });
      const firma = crypto.createHmac('sha256', secreto).update(aviso).digest('hex');

      const peticion = http.request({
        host: '127.0.0.1', port: req.socket.localPort,
        path: '/api/webhooks/mercadopago', method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-signature': firma,
                   'Content-Length': Buffer.byteLength(aviso) },
      }, (rr) => { rr.resume(); rr.on('end', () => json(res, 200, { ok: true })); });
      peticion.on('error', (e) => json(res, 502, { ok: false, mensaje: e.message }));
      peticion.end(aviso);
    },

    /**
     * Datos del instalador, con la huella calculada del archivo de verdad.
     *
     * Escribir una huella a mano es garantía de que algún día quede vieja, y
     * una huella equivocada es peor que ninguna: el cliente cuidadoso que la
     * verifica concluye que le dieron un archivo adulterado. Se calcula acá y
     * se guarda en memoria hasta que cambie el archivo.
     */
    /**
     * La versión publicada sale de la CARPETA, no de una constante.
     *
     * Antes había un `0.7.1` escrito a mano acá y otro en descargas.html. Se
     * desincronizaron y el sitio anunciaba una versión de hace catorce
     * versiones, con el archivo ni siquiera subido. Ahora el flujo es: compilás,
     * copiás el .exe a `descargas/`, y listo — el número, el peso y la huella
     * salen del archivo real. Si no hay archivo, se dice que no hay.
     */
    'GET /api/descargas/windows': (req, res) => {
      const carpeta = path.join(RAIZ_SITIO, 'descargas');
      let candidatos = [];
      try {
        candidatos = fs.readdirSync(carpeta)
          .filter((n) => /^BackupPrime-Setup-\d+\.\d+\.\d+\.exe$/i.test(n))
          .map((n) => ({ nombre: n, version: n.match(/(\d+\.\d+\.\d+)/)[1] }))
          .sort((a, b) => comparaVersiones(b.version, a.version));   // la más nueva primero
      } catch { /* la carpeta puede no existir todavía */ }

      if (!candidatos.length) {
        // No se anuncia una versión que no se puede bajar: un botón que lleva a
        // un 404 en una reunión de venta es peor que decir la verdad.
        return json(res, 200, {
          disponible: false, version: null, url: null, sha256: null,
          mensaje: 'Todavía no hay un instalador publicado. Copiá el .exe en la ' +
                   'carpeta "descargas" del servidor.',
        });
      }

      const elegido = candidatos[0];
      const archivo = path.join(carpeta, elegido.nombre);
      const st = fs.statSync(archivo);
      const marca = `${archivo}:${st.size}:${st.mtimeMs}`;
      if (!huellaCache || huellaCache.marca !== marca) {
        // La huella se calcula del archivo real, nunca se escribe a mano: una
        // huella equivocada es peor que no publicar ninguna.
        huellaCache = {
          marca,
          sha256: createHash('sha256').update(fs.readFileSync(archivo)).digest('hex'),
          bytes: st.size,
        };
      }
      json(res, 200, {
        disponible: true,
        version: elegido.version,
        url: '/descargas/' + elegido.nombre,
        sha256: huellaCache.sha256,
        bytes: huellaCache.bytes,
        megas: Math.round(huellaCache.bytes / 1048576),
        publicado: st.mtime.toISOString(),
        otras: candidatos.slice(1).map((c) => c.version),
      });
    },

    'POST /api/avisarme': (req, res, cuerpo) => {
      if (!S.emailValido(cuerpo.email)) {
        return json(res, 400, { mensaje: 'Revisá el email.' });
      }
      encolarAviso(db, { para: cuerpo.email,
        asunto: 'Anotado en la lista de espera',
        cuerpo: `Te avisamos cuando esté lista la aplicación para ${cuerpo.sobre || 'el celular'}.` });
      auditar(db, cuerpo.email, 'se anotó en la lista de espera', cuerpo.sobre || null, ipDe(req));
      json(res, 200, { ok: true });
    },
  };

  // ── Servidor ─────────────────────────────────────────────────────────────

  const TIPOS = {
    '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
    '.js': 'application/javascript; charset=utf-8', '.svg': 'image/svg+xml',
    '.png': 'image/png', '.ico': 'image/x-icon', '.exe': 'application/octet-stream',
  };

  const servidor = http.createServer(async (req, res) => {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const clave = `${req.method} ${url.pathname}`;

    if (rutas[clave]) {
      let crudo = '';
      let cuerpo = {};
      if (req.method !== 'GET') {
        try {
          crudo = await new Promise((resolver, rechazar) => {
            let d = '', largo = 0;
            req.on('data', (c) => {
              largo += c.length;
              if (largo > 1e6) { req.destroy(); rechazar(new Error('Cuerpo demasiado grande')); return; }
              d += c;
            });
            req.on('end', () => resolver(d));
            req.on('error', rechazar);
          });
          cuerpo = crudo ? JSON.parse(crudo) : {};
        } catch (e) {
          return json(res, 400, { mensaje: 'El cuerpo no es JSON válido.' });
        }
      }
      try {
        return await rutas[clave](req, res, cuerpo, url, crudo);
      } catch (e) {
        auditar(db, 'sistema', 'error en ' + clave, e.message);
        return json(res, 500, { mensaje: 'Algo falló de nuestro lado. Ya quedó registrado.' });
      }
    }

    if (url.pathname.startsWith('/api/')) return json(res, 404, { mensaje: 'No existe esa ruta.' });

    // Archivos del sitio
    const pedido = url.pathname === '/' ? '/index.html' : url.pathname;
    const destino = path.join(RAIZ_SITIO, path.normalize(pedido).replace(/^(\.\.[/\\])+/, ''));
    if (!destino.startsWith(RAIZ_SITIO)) { res.writeHead(403); return res.end('Prohibido'); }
    fs.readFile(destino, (err, datos) => {
      if (err) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('No encontrado'); }
      res.writeHead(200, {
        'Content-Type': TIPOS[path.extname(destino)] || 'application/octet-stream',
        'X-Content-Type-Options': 'nosniff',
      });
      res.end(datos);
    });
  });

  // Cada minuto sale lo que haya encolado. Un intervalo, no un cron: el
  // programa ya está corriendo y no hace falta nada más.
  const relojCorreo = setInterval(() => { despachar().catch(() => {}); }, 60000);

  /* Papelera vencida.
   *
   * Corre en el servidor y no en el agente: un cliente que apaga la máquina un
   * mes nunca liberaría el espacio.
   *
   * Hoy solo QUITA la marca y lo deja registrado. El borrado real de los
   * bloques necesita recolección con conteo de referencias —los bloques se
   * comparten entre versiones y entre archivos— y eso todavía no existe. Borrar
   * a ciegas dejaría un archivo vivo sin un pedazo, y eso no se nota hasta que
   * alguien restaura. */
  function vaciarPapeleraVencida() {
    const vencidos = db.prepare(
      'SELECT id, cuenta_id, ruta, bytes FROM papelera WHERE vence_el <= ?')
      .all(new Date().toISOString());
    if (!vencidos.length) return 0;

    const sacar = db.prepare('DELETE FROM papelera WHERE id = ?');
    for (const v of vencidos) {
      sacar.run(v.id);
      auditar(db, 'sistema', 'venció en la papelera',
        `${v.ruta} (${v.bytes} bytes) — pendiente de borrado real`);
    }
    return vencidos.length;
  }
  const relojPapelera = setInterval(() => {
    try { vaciarPapeleraVencida(); } catch { /* se reintenta en la próxima vuelta */ }
  }, 3600000);
  relojCorreo.unref();
  relojPapelera.unref();

  return { servidor, db, planes, despachar, vaciarPapeleraVencida, ajuste: (k, d) => ajuste(db, k, d), guardarAjuste: (k, v) => guardarAjuste(db, k, v) };
}

module.exports = { crearAplicacion, PLANES_INICIALES, MORA_INICIAL };

if (require.main === module) {
  const app = crearAplicacion();
  const puerto = Number(process.env.PORT) || 4000;
  app.servidor.listen(puerto, () => {
    console.log(`\n  BackupPrime — servidor`);
    console.log(`  http://localhost:${puerto}`);
    if (app.ajuste('admin').claveInicial) {
      console.log(`\n  ⚠ El panel está con la contraseña inicial (admin / admin).`);
      console.log(`    Cambiala desde Administración → Mi cuenta antes de publicar.\n`);
    }
  });
}
