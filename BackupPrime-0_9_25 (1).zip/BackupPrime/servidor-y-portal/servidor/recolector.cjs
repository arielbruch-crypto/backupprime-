'use strict';
/* ═══════════════════════════════════════════════════════════════════════════
   Recolección de bloques.

   Es lo que hace que borrar libere espacio de verdad. Y es lo más peligroso que
   tiene este producto: `pruebas/bloques-referenciados.cjs` demuestra, corriendo,
   que borrar un bloque todavía en uso deja el índice intacto, el archivo
   visible en la lista, y la restauración rota. El cliente no se entera hasta
   que lo necesita.

   Por eso acá manda una sola regla: **ante la duda, no se borra.**

   ── Cómo funciona ──────────────────────────────────────────────────────────

   Dos tiempos. En la primera pasada un bloque que sobra NO se borra: se anota
   como candidato, con la fecha. En una pasada posterior se borra solo si sigue
   sobrando.

   El plazo entre pasadas no es burocracia: cubre la carrera real. Un cliente
   respaldando puede REUTILIZAR un bloque que ya existe —por deduplicación ni
   lo sube, solo lo nombra en su índice nuevo— mientras el recolector lo daba
   por muerto. Si se borrara en la misma pasada, ese archivo nace roto.

   ── Barandas ───────────────────────────────────────────────────────────────

   · Un índice ilegible aborta TODO. Podía ser justo el que retenía esos bloques.
   · Los bloques recién subidos no se tocan, aunque parezcan huérfanos: puede
     ser un respaldo en curso cuyo índice todavía no llegó.
   · Si una corrida quiere borrar más de cierta proporción del almacén, se
     detiene y avisa. Un recolector que se volvió loco se parece mucho a un
     ransomware.
   · Simulación por defecto: informa qué borraría, sin borrar.
   ═══════════════════════════════════════════════════════════════════════════ */

const fsp = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');

const HORA = 3600000;

const POR_DEFECTO = {
  // Un bloque tiene que estar sobrando en DOS pasadas separadas por este plazo.
  graciaHoras: 48,
  // Los subidos hace menos de esto no se miran: puede haber un respaldo a medias.
  edadMinimaHoras: 24,
  // Si una corrida quiere borrar más que esto del total, se planta.
  topeProporcion: 0.05,
};

async function leerTexto(almacen, clave) {
  const ruta = path.join(os.tmpdir(),
    `bp-gc-${process.pid}-${crypto.randomBytes(6).toString('hex')}`);
  try {
    await almacen.leer(clave, ruta);
    return await fsp.readFile(ruta, 'utf8');
  } finally {
    try { await fsp.unlink(ruta); } catch { /* ya no está */ }
  }
}

const huellaDeClave = (clave) => clave.split('/').pop();

/**
 * Recorre los índices vivos y arma el conjunto de bloques EN USO.
 *
 * Si un índice no se puede leer, no devuelve una lista incompleta: falla. Una
 * lista incompleta acá se traduce en bloques borrados de más.
 */
async function bloquesEnUso({ almacen, prefijo = '' }) {
  const { archivos } = await almacen.listar(`${prefijo}indices/`);
  const indices = archivos.filter((a) => a.clave.endsWith('.bpi'));

  const enUso = new Set();
  const ilegibles = [];

  for (const ind of indices) {
    let datos = null;
    try {
      datos = JSON.parse(await leerTexto(almacen, ind.clave));
    } catch (e) {
      // Se intenta la copia antes de darlo por perdido: para eso existe.
      const copia = ind.clave.replace(`${prefijo}indices/`, `${prefijo}indices-copia/`);
      try { datos = JSON.parse(await leerTexto(almacen, copia)); }
      catch { ilegibles.push({ clave: ind.clave, motivo: e.message }); continue; }
    }
    if (!datos || !Array.isArray(datos.bloques)) {
      ilegibles.push({ clave: ind.clave, motivo: 'no tiene lista de bloques' });
      continue;
    }
    for (const b of datos.bloques) if (b && b.h) enUso.add(b.h);
  }

  return { enUso, indices: indices.length, ilegibles };
}

/**
 * Inventario: qué sobra y cuánto es. NO BORRA NADA.
 *
 * Es el primer paso y se puede correr siempre: sin esto no se sabe si el
 * problema es de 200 MB o de 200 GB.
 */
async function inventariar({ almacen, prefijo = '', opciones = {} }) {
  const cfg = { ...POR_DEFECTO, ...opciones };
  const ahora = opciones.ahora == null ? Date.now() : opciones.ahora;

  const uso = await bloquesEnUso({ almacen, prefijo });

  const { archivos: todos } = await almacen.listar(`${prefijo}bloques/`);
  let bytesTotales = 0, bytesSobrantes = 0, recientes = 0;
  const sobrantes = [];

  for (const b of todos) {
    bytesTotales += Number(b.size) || 0;
    const huella = huellaDeClave(b.clave);
    if (uso.enUso.has(huella)) continue;

    // Recién subido: puede ser un respaldo en curso cuyo índice no llegó.
    const edad = b.modificado ? ahora - new Date(b.modificado).getTime() : Infinity;
    if (edad < cfg.edadMinimaHoras * HORA) { recientes++; continue; }

    sobrantes.push({ clave: b.clave, huella, bytes: Number(b.size) || 0 });
    bytesSobrantes += Number(b.size) || 0;
  }

  return {
    indices: uso.indices,
    ilegibles: uso.ilegibles,
    bloquesTotales: todos.length,
    bloquesEnUso: uso.enUso.size,
    bloquesSobrantes: sobrantes.length,
    bloquesRecientes: recientes,
    bytesTotales,
    bytesSobrantes,
    proporcion: bytesTotales > 0 ? bytesSobrantes / bytesTotales : 0,
    sobrantes,
    // Si hay un índice ilegible, este inventario NO sirve para borrar.
    confiable: uso.ilegibles.length === 0,
  };
}

/**
 * Recolección en dos tiempos.
 *
 * @param candidatos  lo anotado en la pasada anterior: { huella: fechaISO }
 * @param opciones.borrar  false (por defecto) simula; true borra de verdad
 * @returns { borrados, candidatos, motivoCorte, ... }
 */
async function recolectar({ almacen, prefijo = '', candidatos = {}, opciones = {} }) {
  const cfg = { ...POR_DEFECTO, ...opciones };
  const ahora = opciones.ahora == null ? Date.now() : opciones.ahora;
  const inv = await inventariar({ almacen, prefijo, opciones });

  const resultado = {
    ...inv, borrados: [], bytesLiberados: 0,
    nuevosCandidatos: {}, motivoCorte: null, simulado: !opciones.borrar,
  };

  // ── Baranda 1: un índice ilegible aborta todo ──
  if (!inv.confiable) {
    resultado.motivoCorte =
      `No se pudieron leer ${inv.ilegibles.length} índice(s). No se borra nada: ` +
      'ese índice podía ser justo el que retiene estos bloques.';
    resultado.nuevosCandidatos = candidatos;
    return resultado;
  }

  // ── Baranda 2: tope por corrida ──
  if (inv.proporcion > cfg.topeProporcion) {
    resultado.motivoCorte =
      `Habría que borrar el ${(inv.proporcion * 100).toFixed(1)}% del almacén, ` +
      `más que el ${(cfg.topeProporcion * 100).toFixed(0)}% permitido por corrida. ` +
      'Se frena por las dudas: revisá el inventario antes de habilitarlo.';
    resultado.nuevosCandidatos = candidatos;
    return resultado;
  }

  // ── Dos tiempos ──
  const listos = [];
  for (const s of inv.sobrantes) {
    const desde = candidatos[s.huella];
    if (!desde) {
      // Primera vez que sobra: se anota, no se borra.
      resultado.nuevosCandidatos[s.huella] = new Date(ahora).toISOString();
      continue;
    }
    resultado.nuevosCandidatos[s.huella] = desde;
    if (ahora - new Date(desde).getTime() >= cfg.graciaHoras * HORA) listos.push(s);
  }

  if (!opciones.borrar) {
    resultado.borrariaAhora = listos.length;
    resultado.bytesQueLiberaria = listos.reduce((n, s) => n + s.bytes, 0);
    return resultado;
  }

  for (const s of listos) {
    try {
      await almacen.borrar(s.clave);
      resultado.borrados.push(s.clave);
      resultado.bytesLiberados += s.bytes;
      delete resultado.nuevosCandidatos[s.huella];
    } catch (e) {
      // Un borrado que falla no corta la corrida: el bloque sigue anotado y se
      // reintenta. Lo que no se hace es darlo por borrado.
      resultado.motivoCorte = resultado.motivoCorte ||
        `Algunos bloques no se pudieron borrar: ${e.message}`;
    }
  }
  return resultado;
}

module.exports = { inventariar, recolectar, bloquesEnUso, POR_DEFECTO };
