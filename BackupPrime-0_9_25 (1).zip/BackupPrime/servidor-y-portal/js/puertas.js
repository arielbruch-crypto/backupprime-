/* ───────────────────────────────────────────────────────────────────────────
   "¿Qué querés proteger?"

   Una sola página tiene que hablarle a una familia, a un contador y a una
   empresa. Si les habla a todos a la vez no le habla a nadie, así que cada uno
   elige su puerta y ve sus propios ejemplos y su plan sugerido.
   ─────────────────────────────────────────────────────────────────────────── */
(function () {
  'use strict';
  var caja = document.getElementById('vitrina');
  if (!caja) return;

  var CASOS = {
    familia: {
      cita: 'Hay archivos que no ocupan mucho espacio, pero ocupan un lugar enorme en tu vida.',
      texto: 'Las fotos de los cumpleaños, los videos de cuando eran chicos, los escaneos del ' +
             'DNI y el pasaporte, la carpeta de la escuela. Nada de eso se puede volver a sacar.',
      lista: ['Fotos y videos de todas las computadoras de casa',
              'Documentos escaneados y trámites',
              'Versiones anteriores por si alguien pisa un archivo',
              'Sin límite de equipos en tu casa'],
      plan: 'personal',
    },
    profesional: {
      cita: 'Vendés conocimiento. Perder información es perder tiempo, plata y confianza.',
      texto: 'Contadores, abogados, arquitectos, diseñadores, médicos. Los papeles de trabajo ' +
             'de tus clientes son tu responsabilidad, y hay documentación que tenés obligación ' +
             'de conservar durante años.',
      lista: ['Toda la carpeta de clientes, respaldada sola',
              'Hasta 30 versiones de cada archivo',
              'Restauración desde la web, sin instalar nada',
              'Verificación en dos pasos para entrar'],
      plan: 'estudio',
    },
    empresa: {
      cita: 'No compran almacenamiento: compran seguir trabajando el día después.',
      texto: 'Cuando se cae un equipo en una empresa, lo caro no es el archivo perdido: es el ' +
             'tiempo con la gente parada esperando que alguien lo rehaga.',
      lista: ['Servidores y carpetas de red',
              'Equipos ilimitados, se paga por espacio',
              'Aviso por mail si una máquina deja de respaldar',
              'Informe mensual de qué se respaldó y qué no'],
      plan: 'empresa',
    },
    celular: {
      cita: 'Tu vida ya no está en una sola computadora. Tu backup tampoco debería estarlo.',
      texto: 'Las fotos, los videos y los contactos del teléfono son lo primero que se pierde ' +
             'y lo último que alguien respalda. La aplicación para Android y iPhone está en ' +
             'camino: dejanos tu mail y te avisamos el día que salga.',
      lista: ['Fotos y videos del teléfono',
              'Contactos y agenda',
              'La misma cuenta que tus computadoras'],
      plan: null,
      pronto: true,
    },
  };

  var puertas = [].slice.call(document.querySelectorAll('.puerta'));
  var planes = [];

  function pintar(cual) {
    var c = CASOS[cual];
    var plan = planes.filter(function (p) { return p.id === c.plan; })[0];
    var pesos = window.BackupPrime.planes.pesos;

    var lado = c.pronto
      ? '<div class="vitrina-plan">' +
          '<div class="plan-etiqueta" style="position:static;display:inline-block;margin-bottom:14px;">En camino</div>' +
          '<p style="font-size:.94rem;color:var(--tinta-media);margin-bottom:16px;">' +
            'Avisame cuando esté lista la aplicación para el celular.</p>' +
          '<div class="campo"><input type="email" id="mailAviso" placeholder="vos@email.com" /></div>' +
          '<button class="boton boton-lleno boton-ancho" id="avisarme">Quiero que me avisen</button>' +
          '<p class="campo-ayuda" id="avisoListo" style="margin-top:10px;"></p>' +
        '</div>'
      : (plan ? '<div class="vitrina-plan">' +
          '<div class="plan-nombre">Plan ' + plan.nombre + '</div>' +
          '<div class="plan-para">' + plan.para + '</div>' +
          '<div class="plan-precio" style="margin-top:16px;">' +
            '<span class="plan-monto">' + pesos.format(plan.precioMensual) + '</span>' +
            '<span class="plan-periodo">por mes</span></div>' +
          '<div class="plan-espacio">' + window.BackupPrime.planes.espacioLegible(plan.espacioGB) + ' de espacio</div>' +
          (plan.id === 'personal'
            ? '<p class="campo-ayuda" style="margin-top:12px;">Lo que salen tres cafés.</p>' : '') +
          '<a class="boton boton-lleno boton-ancho" style="margin-top:20px;" ' +
             'href="registro.html?plan=' + plan.id + '">Probarlo 14 días gratis</a>' +
        '</div>' : '');

    caja.innerHTML =
      '<div>' +
        '<div class="vitrina-cita">' + c.cita + '</div>' +
        '<p>' + c.texto + '</p>' +
        '<ul class="vitrina-lista">' +
          c.lista.map(function (i) { return '<li>' + i + '</li>'; }).join('') +
        '</ul>' +
      '</div>' + lado;

    var boton = document.getElementById('avisarme');
    if (boton) {
      boton.addEventListener('click', function () {
        var mail = document.getElementById('mailAviso').value.trim();
        var salida = document.getElementById('avisoListo');
        if (!/^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(mail)) {
          salida.textContent = 'Revisá el email.';
          return;
        }
        salida.textContent = 'Listo, te avisamos.';
        boton.disabled = true;
        fetch((window.BACKUPPRIME_API || '/api') + '/avisarme', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: mail, sobre: 'celular' }),
        }).catch(function () {});
      });
    }

    puertas.forEach(function (p) {
      p.setAttribute('aria-selected', p.dataset.puerta === cual ? 'true' : 'false');
    });
  }

  puertas.forEach(function (p) {
    p.addEventListener('click', function () { pintar(p.dataset.puerta); });
  });

  window.BackupPrime.planes.pedir().then(function (lista) {
    planes = lista;
    pintar('familia');
  });
})();
