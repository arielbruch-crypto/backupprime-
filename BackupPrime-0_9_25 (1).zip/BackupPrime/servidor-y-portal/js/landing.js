/* Dibuja los planes en la portada. Vive aparte de planes.js porque ese módulo
   lo comparten la portada y el formulario de registro, y cada página decide
   dónde y cómo mostrarlos. */
(function () {
  'use strict';
  var caja = document.getElementById('listaPlanes');
  if (!caja) return;
  window.BackupPrime.planes.pedir().then(function (planes) {
    window.BackupPrime.planes.pintar(planes, caja);
  });
})();
