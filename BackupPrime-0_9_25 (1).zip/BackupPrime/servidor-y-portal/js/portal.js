/* ───────────────────────────────────────────────────────────────────────────
   Portal del cliente.

   Regla de esta pantalla: NADA se muestra si no vino del backend. La versión
   anterior de este archivo no llamaba a la API ni una vez — los equipos, el
   espacio usado y las facturas estaban escritos a mano en el HTML. Un cliente
   veía "PC-Ana · Al día" sin tener ninguna PC-Ana, y eso es exactamente la
   falla que el producto existe para no cometer: un respaldo que parece estar y
   no está es peor que no tener respaldo.

   La sesión viaja en una cookie HttpOnly, así que alcanza con `credentials`.
   ─────────────────────────────────────────────────────────────────────────── */
(function () {
  'use strict';

  var API = '/api';
  var $ = function (id) { return document.getElementById(id); };
  var estado = { cuenta: null, planes: [] };

  // ── Puente con el backend ────────────────────────────────────────────────

  function pedir(ruta, opciones) {
    var o = opciones || {};
    return fetch(API + ruta, {
      method: o.metodo || 'GET',
      credentials: 'same-origin',
      headers: o.cuerpo ? { 'Content-Type': 'application/json' } : undefined,
      body: o.cuerpo ? JSON.stringify(o.cuerpo) : undefined,
    }).then(function (r) {
      // Sin sesión no se muestra una pantalla vacía: se manda a ingresar.
      if (r.status === 401) { window.location.href = 'ingreso.html'; throw new Error('sin sesion'); }
      return r.json().catch(function () { return {}; }).then(function (d) {
        if (!r.ok) throw new Error(d.mensaje || d.error || 'No se pudo completar el pedido.');
        return d;
      });
    });
  }

  // ── Formato ──────────────────────────────────────────────────────────────

  function escapar(t) {
    return String(t == null ? '' : t)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function tamano(bytes) {
    var b = Number(bytes);
    if (!isFinite(b) || b < 0) return '—';
    if (b === 0) return '0 B';
    var u = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'], i = 0;
    while (b >= 1024 && i < u.length - 1) { b /= 1024; i++; }
    var dec = b < 10 && i > 1 ? 1 : 0;
    return b.toFixed(dec).replace('.', ',') + ' ' + u[i];
  }

  function numero(n) {
    var v = Number(n);
    if (!isFinite(v)) return '—';
    return Math.round(v).toLocaleString('es-AR');
  }

  function pesos(n) {
    var v = Number(n);
    if (!isFinite(v)) return '—';
    return '$ ' + Math.round(v).toLocaleString('es-AR');
  }

  function fecha(iso) {
    if (!iso) return null;
    var d = new Date(iso);
    if (isNaN(d.getTime())) return null;
    return d;
  }

  function fechaCorta(iso) {
    var d = fecha(iso);
    if (!d) return '—';
    return d.toLocaleDateString('es-AR', { day: 'numeric', month: 'short', year: 'numeric' });
  }

  // Cuánto hace. Es el dato que importa en un producto de respaldo: no "cuándo
  // fue" sino "cuánto hace que no sé nada".
  function hace(iso) {
    var d = fecha(iso);
    if (!d) return { texto: 'nunca informó', dias: Infinity };
    var min = Math.floor((Date.now() - d.getTime()) / 60000);
    if (min < 0) min = 0;
    var dias = Math.floor(min / 1440);
    var texto;
    if (min < 2) texto = 'hace un instante';
    else if (min < 60) texto = 'hace ' + min + ' min';
    else if (min < 1440) texto = 'hace ' + Math.floor(min / 60) + ' h';
    else if (dias === 1) texto = 'ayer';
    else texto = 'hace ' + dias + ' días';
    return { texto: texto, dias: dias };
  }

  // Un equipo que dejó de informar es el caso peligroso, y se gradúa. Ámbar y
  // rojo son SOLO para cosas que están mal.
  function salud(iso) {
    var h = hace(iso);
    if (h.dias === Infinity) return { clase: 'mala', rotulo: 'Nunca informó', h: h };
    if (h.dias >= 7) return { clase: 'mala', rotulo: h.texto, h: h };
    if (h.dias >= 3) return { clase: 'alerta', rotulo: h.texto, h: h };
    return { clase: 'ok', rotulo: 'Al día', h: h };
  }

  // ── Navegación entre paneles ─────────────────────────────────────────────

  var TITULOS = {
    inicio: 'Inicio', equipos: 'Equipos', restaurar: 'Restaurar',
    cuenta: 'Cuenta y facturas', seguridad: 'Seguridad',
  };

  function mostrar(nombre) {
    if (!TITULOS[nombre]) nombre = 'inicio';
    if (!$('menuPortal')) return;
    var paneles = document.querySelectorAll('.panel');
    for (var i = 0; i < paneles.length; i++) {
      paneles[i].classList.toggle('activo', paneles[i].id === 'panel-' + nombre);
    }
    var enlaces = $('menuPortal').querySelectorAll('a');
    for (var j = 0; j < enlaces.length; j++) {
      enlaces[j].classList.toggle('activa', enlaces[j].getAttribute('data-panel') === nombre);
    }
    $('titulo').textContent = TITULOS[nombre];
  }

  function arrancarNavegacion() {
    document.addEventListener('click', function (e) {
      var a = e.target.closest ? e.target.closest('[data-panel], [data-ir]') : null;
      if (!a) return;
      var destino = a.getAttribute('data-panel') || a.getAttribute('data-ir');
      if (!destino) return;
      e.preventDefault();
      window.location.hash = destino;
      mostrar(destino);
    });
    window.addEventListener('hashchange', function () {
      mostrar((window.location.hash || '#inicio').slice(1));
    });
    mostrar((window.location.hash || '#inicio').slice(1));
  }

  // ── Pintado ──────────────────────────────────────────────────────────────

  // Escribir en un nodo que no existe corta el arranque y mata todo lo que
  // viene después. Se escribe solo si el nodo está.
  function poner(id, html) { var e = $(id); if (e) e.innerHTML = html; }
  function texto(id, t) { var e = $(id); if (e) e.textContent = t; }

  function pintarIdentidad(c) {
    var nombre = c.organizacion || c.email || 'Mi cuenta';
    $('yoNombre').textContent = nombre;
    $('yoEmail').textContent = c.email || '';
    var iniciales = nombre.trim().split(/\s+/).slice(0, 2)
      .map(function (p) { return p.charAt(0).toUpperCase(); }).join('');
    $('avatar').textContent = iniciales || '··';
  }

  // El aviso de arriba: solo si hay algo que el cliente tenga que hacer.
  function pintarAvisoGlobal(c) {
    var caja = $('avisoGlobal');
    var avisos = [];

    if (c.mensajeCuota) {
      var cl = c.cuota && c.cuota.estado === 'frenado' ? 'aviso-mal' : 'aviso-ambar';
      avisos.push('<div class="aviso ' + cl + '"><span>⚠</span><div>' +
        escapar(c.mensajeCuota) + '</div></div>');
    }
    if (c.moroso) {
      avisos.push('<div class="aviso aviso-mal"><span>⚠</span><div><b>Hay un pago pendiente</b>' +
        'Tus archivos siguen guardados. Regularizá el pago para que los respaldos ' +
        'nuevos no se interrumpan.</div></div>');
    }
    if (c.estado === 'suspendida' || c.estado === 'cancelada') {
      avisos.push('<div class="aviso aviso-mal"><span>⚠</span><div>' +
        '<b>Tu suscripción no está activa</b>Tus archivos guardados siguen a salvo y los ' +
        'podés restaurar. Los respaldos nuevos están detenidos.</div></div>');
    }

    // Equipos que dejaron de informar.
    var callados = (c.equipos || []).filter(function (e) { return salud(e.ultimo_aviso).clase !== 'ok'; });
    if (callados.length) {
      var lista = callados.map(function (e) {
        return escapar(e.nombre) + ' (' + salud(e.ultimo_aviso).rotulo.toLowerCase() + ')';
      }).join(', ');
      avisos.push('<div class="aviso aviso-ambar"><span>⚠</span><div>' +
        '<b>' + (callados.length === 1 ? 'Un equipo no informa' : callados.length + ' equipos no informan') + '</b>' +
        lista + '. No dieron ningún error: dejaron de reportar. Puede ser que estén ' +
        'apagados, sin internet o con el programa cerrado. ' +
        '<a href="#equipos" data-ir="equipos" style="color:inherit;font-weight:600;">Ver los equipos →</a>' +
        '</div></div>');
    }

    if (!(c.equipos || []).length) {
      avisos.push('<div class="aviso aviso-ambar"><span>⚠</span><div>' +
        '<b>Todavía no hay ningún equipo respaldando</b>' +
        'Bajá el programa, entrá con este mismo email y contraseña, y elegí qué carpetas ' +
        'querés respaldar. Hasta que eso pase, no hay copias de nada.</div></div>');
    }

    caja.innerHTML = avisos.join('');
  }

  function pintarEstadoGeneral(c) {
    var equipos = c.equipos || [];
    var cuota = c.cuota || {};
    var caja = $('estadoGeneral');

    if (!equipos.length) { caja.innerHTML = ''; return; }

    var callados = equipos.filter(function (e) { return salud(e.ultimo_aviso).clase !== 'ok'; });
    if (callados.length || cuota.estado === 'frenado') { caja.innerHTML = ''; return; }

    // Verde solo cuando no hay nada que hacer. Y sin prometer nada absoluto:
    // se dice qué se sabe y de cuándo, no "estás 100% protegido".
    var ultimo = equipos.map(function (e) { return e.ultimo_aviso; })
      .sort().reverse()[0];
    caja.innerHTML = '<div class="aviso aviso-ok"><span>✓</span><div>' +
      '<b>Tus ' + (equipos.length === 1 ? 'equipo está informando' : 'equipos están informando') + '</b>' +
      'El último aviso llegó ' + escapar(hace(ultimo).texto) + '. Lo que ves acá es lo que ' +
      'informaron tus equipos, no una comprobación hecha desde esta página.' +
      '</div></div>';
  }

  function pintarTarjetas(c) {
    var cuota = c.cuota || {};
    var equipos = c.equipos || [];
    var archivos = equipos.reduce(function (a, e) { return a + (Number(e.archivos) || 0); }, 0);
    var ultimo = equipos.length
      ? equipos.map(function (e) { return e.ultimo_aviso; }).sort().reverse()[0] : null;
    var s = ultimo ? salud(ultimo) : null;
    var plan = estado.planes.filter(function (p) { return p.id === c.planId; })[0];

    var t = [];
    t.push(tarjeta('Último aviso de un equipo', ultimo ? hace(ultimo).texto : 'Sin equipos',
      ultimo ? 'De ' + escapar(equipos.length === 1 ? equipos[0].nombre : equipos.length + ' equipos') : 'Todavía no instalaste el programa',
      s ? (s.clase === 'ok' ? 'ok' : s.clase === 'alerta' ? 'alerta' : 'mal') : '', 'reloj'));
    t.push(tarjeta('Datos respaldados', tamano(cuota.usadoBytes),
      'Según lo que informaron tus equipos', '', 'disco'));
    t.push(tarjeta('Archivos respaldados', archivos ? numero(archivos) : '—',
      archivos ? 'Sumando todos los equipos' : 'Sin datos todavía', '', 'hojas'));
    t.push(tarjeta('Equipos', numero(equipos.length),
      equipos.length ? 'Vinculados a tu cuenta' : 'Ninguno vinculado', '', 'equipo'));
    t.push(tarjeta('Tu plan', plan ? plan.nombre : (c.planId || '—'),
      c.espacioGB ? c.espacioGB >= 1000 ? (c.espacioGB / 1000) + ' TB de espacio' : c.espacioGB + ' GB de espacio' : '', '', 'plan'));

    $('tarjetasInicio').innerHTML = t.join('');
  }

  // Los íconos son decoración: nunca reemplazan al texto ni cambian el dato.
  var ICONOS = {
    reloj:  '<path d="M12 7v5l3 2"/><circle cx="12" cy="12" r="9"/>',
    disco:  '<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6"/><path d="M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/>',
    hojas:  '<path d="M4 5.5A1.5 1.5 0 0 1 5.5 4H14l6 6v9.5a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 19.5z"/><path d="M14 4v6h6"/>',
    equipo: '<rect x="3" y="4" width="18" height="12" rx="1.5"/><path d="M8 20h8"/>',
    plan:   '<path d="M12 3l7 3v6c0 4.4-3 7.9-7 9-4-1.1-7-4.6-7-9V6z"/>',
  };

  function tarjeta(rotulo, dato, pie, clasePie, icono) {
    var svg = ICONOS[icono]
      ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">' +
        ICONOS[icono] + '</svg>'
      : '';
    return '<div class="tarjeta"><div class="rotulo">' + svg + escapar(rotulo) + '</div>' +
      '<div class="dato">' + escapar(dato) + '</div>' +
      '<div class="pie ' + (clasePie || '') + '">' + pie + '</div></div>';
  }

  // Lo que quedó guardado y el respaldo actual ya no cubre. El cliente lo puede
  // restaurar, pero no se está actualizando: verlo es lo que evita que crea que
  // una carpeta está protegida cuando hace meses que no se toca.
  function fueraDelRespaldo(c) {
    var eq = c.equipos || [];
    var archivos = 0, bytes = 0, desde = null;
    for (var i = 0; i < eq.length; i++) {
      archivos += Number(eq[i].fuera_archivos) || 0;
      bytes += Number(eq[i].fuera_bytes) || 0;
      if (eq[i].fuera_desde && (!desde || eq[i].fuera_desde < desde)) desde = eq[i].fuera_desde;
    }
    return { archivos: archivos, bytes: bytes, desde: desde };
  }

  function pintarEspacio(c) {
    var cuota = c.cuota || {};
    var plan = estado.planes.filter(function (p) { return p.id === c.planId; })[0];
    $('espacioPlan').textContent = 'De tu plan ' + (plan ? plan.nombre : (c.planId || ''));
    $('espacioNum').innerHTML = escapar(tamano(cuota.usadoBytes)) +
      ' <span class="espacio-de">de ' + escapar(tamano(cuota.limiteBytes)) + '</span>';

    var pct = Number(cuota.porcentaje);
    if (!isFinite(pct) || pct < 0) pct = 0;
    var barra = $('espacioBarra');
    barra.className = 'barra-uso' +
      (cuota.estado === 'frenado' || cuota.estado === 'excedido' ? ' mal'
        : cuota.estado === 'aviso' ? ' alerta' : '');
    barra.firstChild.style.width = Math.max(0, Math.min(100, pct)) + '%';

    var nota = (isFinite(pct) ? pct.toFixed(pct < 10 ? 1 : 0).replace('.', ',') + '% usado' : '');
    if (cuota.medidoEn) nota += ' · medido ' + hace(cuota.medidoEn).texto;
    if (cuota.puedeRestaurar) nota += ' · podés restaurar siempre, incluso con el espacio lleno';
    $('espacioNota').textContent = nota;

    var f = fueraDelRespaldo(c);
    var caja = $('espacioFuera');
    if (caja) {
      caja.innerHTML = f.archivos
        ? '<div class="aviso aviso-ambar" style="margin-top:14px;"><span>ℹ</span><div>' +
          '<b>' + escapar(tamano(f.bytes)) + ' de archivos que el respaldo actual ya no cubre</b>' +
          escapar(numero(f.archivos)) + ' archivo(s) guardados que quedaron fuera del respaldo' +
          (f.desde ? ' desde ' + escapar(fechaCorta(f.desde)) : '') + '. ' +
          'Los podés restaurar desde el programa, pero <b>no se están actualizando</b>.' +
          '</div></div>'
        : '';
    }
  }

  function pintarEquipos(c) {
    var equipos = c.equipos || [];

    if (!equipos.length) {
      var vacio = '<div class="vacio">Todavía no hay ningún equipo.<br />' +
        'Bajá el programa y entrá con tu email y contraseña: el equipo se registra solo.</div>';
      $('equiposResumen').innerHTML = vacio;
      $('tablaEquipos').innerHTML = vacio;
      return;
    }

    var ordenados = equipos.slice().sort(function (a, b) {
      return String(b.ultimo_aviso || '').localeCompare(String(a.ultimo_aviso || ''));
    });

    $('equiposResumen').innerHTML = ordenados.slice(0, 5).map(function (e) {
      var s = salud(e.ultimo_aviso);
      return '<div class="equipo">' +
        '<div class="equipo-icono">💻</div><div>' +
        '<div class="equipo-nombre">' + escapar(e.nombre) + '</div>' +
        '<div class="equipo-detalle">' + escapar(hace(e.ultimo_aviso).texto) + ' · ' +
        escapar(tamano(e.bytes)) + ' · ' + escapar(numero(e.archivos)) + ' archivos</div>' +
        '</div><span class="pastilla ' + s.clase + '">' + escapar(s.rotulo) + '</span></div>';
    }).join('');

    $('tablaEquipos').innerHTML = '<table><tr><th>Equipo</th><th>Archivos</th>' +
      '<th>Datos</th><th>Último aviso</th><th>Estado</th><th></th></tr>' +
      ordenados.map(function (e) {
        var s = salud(e.ultimo_aviso);
        return '<tr><td><b>' + escapar(e.nombre) + '</b></td>' +
          '<td class="num">' + escapar(numero(e.archivos)) + '</td>' +
          '<td class="num">' + escapar(tamano(e.bytes)) + '</td>' +
          '<td>' + escapar(hace(e.ultimo_aviso).texto) + '<br />' +
          '<small style="color:var(--tinta-suave)">' + escapar(fechaCorta(e.ultimo_aviso)) + '</small></td>' +
          '<td><span class="pastilla ' + s.clase + '">' + escapar(s.rotulo) + '</span></td>' +
          '<td><button class="boton boton-linea" data-desvincular="' + escapar(e.nombre) + '" ' +
          'style="padding:5px 11px;font-size:.82rem;">Desvincular</button></td></tr>';
      }).join('') + '</table>';
  }

  function pintarPlan(c) {
    var plan = estado.planes.filter(function (p) { return p.id === c.planId; })[0];
    var esPrueba = c.estado === 'prueba';
    var html = '<div style="display:flex;align-items:baseline;gap:8px;">' +
      '<span style="font-family:var(--display);font-size:1.6rem;font-weight:600;">' +
      escapar(plan ? plan.nombre : (c.planId || '—')) + '</span>' +
      '<span style="color:var(--tinta-suave);">· ' +
      escapar(c.espacioGB >= 1000 ? (c.espacioGB / 1000) + ' TB' : c.espacioGB + ' GB') + '</span></div>';

    if (plan && plan.precioMensual) {
      html += '<div style="font-family:var(--display);font-size:1.8rem;font-weight:600;' +
        'margin-top:10px;font-variant-numeric:tabular-nums;">' + escapar(pesos(plan.precioMensual)) +
        '<span style="font-size:.9rem;font-weight:400;color:var(--tinta-suave);"> por mes</span></div>';
    }

    var pastilla = esPrueba ? 'alerta' : c.estado === 'activa' ? 'ok' : 'mala';
    html += '<div style="margin-top:12px;"><span class="pastilla ' + pastilla + '">' +
      escapar(esPrueba ? 'En prueba' : c.estado || '—') + '</span></div>';

    if (esPrueba && c.pruebaHasta) {
      var h = hace(c.pruebaHasta);
      var d = fecha(c.pruebaHasta);
      var quedan = d ? Math.ceil((d.getTime() - Date.now()) / 86400000) : null;
      html += '<div class="campo-ayuda" style="margin-top:8px;">' +
        (quedan != null && quedan > 0
          ? 'Tu prueba termina el ' + escapar(fechaCorta(c.pruebaHasta)) + ' (' + quedan + ' días).'
          : 'Tu prueba venció el ' + escapar(fechaCorta(c.pruebaHasta)) + '.') + '</div>';
    }

    $('planActual').innerHTML = html;

    var botones = [];
    if (esPrueba || c.estado !== 'activa') {
      botones.push('<button class="boton boton-lleno" data-pagar="1">Activar la suscripción</button>');
    }
    botones.push('<button class="boton boton-linea" data-cambiar="1">Cambiar de plan</button>');
    $('planBotones').innerHTML = botones.join('');
  }

  function pintarFormaPago(c) {
    // No se inventa una tarjeta: si no hay medio de pago registrado, se dice.
    var activa = c.estado === 'activa' && !c.moroso;
    $('formaPago').innerHTML = '<div class="caja">' +
      '<span style="font-size:1.4rem;">💳</span><div>' +
      '<div style="font-weight:600;font-size:.93rem;">Mercado Pago</div>' +
      '<div class="campo-ayuda">Débito automático de la suscripción</div></div>' +
      '<span class="pastilla ' + (activa ? 'ok' : 'neutra') + '">' +
      (activa ? 'Activa' : 'Sin suscripción activa') + '</span></div>' +
      (activa ? '' : '<div class="campo-ayuda" style="margin-top:12px;">' +
        'Todavía no hay una suscripción cobrándose. Podés activarla desde «Tu plan».</div>');
  }

  function pintarDatos(c) {
    var filas = [
      ['Razón social', c.organizacion], ['CUIT', c.cuit],
      ['Email', c.email], ['Celular', c.celular], ['Teléfono', c.telefono],
      ['Dirección', c.direccion], ['Localidad', c.localidad], ['Provincia', c.provincia],
    ];
    poner('datosVista', '<div class="datos-lista">' + filas.map(function (f) {
      return '<div><span>' + escapar(f[0]) + '</span>' +
        escapar(f[1] || '—') + '</div>';
    }).join('') + '</div>');

    var puso = { dOrganizacion: c.organizacion, dCuit: c.cuit, dCelular: c.celular,
      dTelefono: c.telefono, dDireccion: c.direccion, dLocalidad: c.localidad,
      dProvincia: c.provincia };
    Object.keys(puso).forEach(function (id) {
      var e = $(id); if (e) e.value = puso[id] || '';
    });

    // Una cuenta ya dada de baja no vuelve a mostrar el botón de baja.
    var baja = $('bloqueBaja');
    if (baja) baja.style.display = c.estado === 'cancelada' ? 'none' : '';
  }

  function pintarFacturas(c) {
    var f = c.facturas || [];
    if (!f.length) {
      $('tablaFacturas').innerHTML = '<div class="vacio">Todavía no hay facturas.<br />' +
        'Cuando se cobre la primera suscripción vas a verla acá.</div>';
      return;
    }
    $('tablaFacturas').innerHTML = '<table><tr><th>Fecha</th><th>Comprobante</th>' +
      '<th>Concepto</th><th>Importe</th><th>Estado</th></tr>' +
      f.map(function (x) {
        var pagada = x.estado === 'pagada';
        return '<tr><td>' + escapar(fechaCorta(x.fecha || x.creada)) + '</td>' +
          '<td>' + escapar(x.numero || x.comprobante || '—') + '</td>' +
          '<td>' + escapar(x.concepto || '—') + '</td>' +
          '<td class="num">' + escapar(pesos(x.importe || x.monto)) + '</td>' +
          '<td><span class="pastilla ' + (pagada ? 'ok' : 'neutra') + '">' +
          escapar(x.estado || '—') + '</span></td></tr>';
      }).join('') + '</table>';
  }

  function pintarMfa(c) {
    var activo = !!c.mfa;
    var p = $('mfaEstado');
    p.className = 'pastilla ' + (activo ? 'ok' : 'alerta');
    p.textContent = activo ? 'Activada' : 'Sin activar';
    $('mfaBotones').innerHTML = activo
      ? '<button class="boton boton-linea" data-mfa="desactivar">Desactivar</button>'
      : '<button class="boton boton-lleno" data-mfa="activar">Activar ahora</button>';
    $('mfaActivar').classList.add('oculto');
    $('mfaDesactivar').classList.add('oculto');
  }

  function pintarSesiones(sesiones) {
    if (!sesiones.length) {
      $('tablaSesiones').innerHTML = '<div class="vacio">No hay sesiones abiertas.</div>';
      return;
    }
    $('tablaSesiones').innerHTML = '<table><tr><th>Dónde</th><th>Desde</th>' +
      '<th>Abierta</th><th></th></tr>' +
      sesiones.map(function (s) {
        return '<tr><td><b>' + escapar(s.agente || 'Desconocido') + '</b></td>' +
          '<td>' + escapar(s.ip || '—') + '</td>' +
          '<td>' + escapar(hace(s.creada).texto) + '</td>' +
          '<td><button class="boton boton-linea" data-cerrar="' + escapar(s.id) + '" ' +
          'style="padding:5px 11px;font-size:.82rem;">Cerrar</button></td></tr>';
      }).join('') + '</table>';
  }

  // ── Carga ────────────────────────────────────────────────────────────────

  function cargarCuenta() {
    return pedir('/cuenta').then(function (c) {
      estado.cuenta = c;
      pintarIdentidad(c);
      pintarAvisoGlobal(c);
      pintarEstadoGeneral(c);
      pintarTarjetas(c);
      pintarEspacio(c);
      pintarEquipos(c);
      pintarPlan(c);
      pintarFormaPago(c);
      pintarDatos(c);
      pintarFacturas(c);
      pintarMfa(c);
    });
  }

  /* ── Restaurar desde la web ─────────────────────────────────────────────── */

  var ARCHIVOS = { puedeDescargar: true, topeMB: 512 };

  function pintarArchivos(d) {
    ARCHIVOS = d;
    var caja = $('listaArchivos');
    if (!caja) return;

    // Frase privada: no es una falla, es la promesa de ese modo. Se explica y se
    // da la salida, en vez de mostrar una lista con todos los botones apagados.
    if (d.puedeDescargar === false) {
      poner('restaurarAviso', '<div class="aviso aviso-info"><span>ℹ</span><div>' +
        '<b>Tu cuenta usa frase privada</b>' + escapar(d.mensaje || '') + '</div></div>');
    } else if (d.mensaje) {
      poner('restaurarAviso', '<div class="aviso aviso-ambar"><span>⚠</span><div>' +
        escapar(d.mensaje) + '</div></div>');
    } else {
      poner('restaurarAviso', '');
    }

    var lista = d.archivos || [];
    if (!lista.length) {
      caja.innerHTML = '<div class="vacio">' +
        (d.total === 0 && !$('buscarArchivo').value
          ? 'Todavía no hay archivos respaldados.'
          : 'Ningún archivo coincide con lo que buscaste.') + '</div>';
      return;
    }

    caja.innerHTML = lista.map(function (a) {
      return '<div class="archivo">' +
        '<span style="font-size:1.1rem;">📄</span>' +
        '<div><div class="archivo-nombre">' + escapar(a.nombre) +
        (a.fueraDelRespaldo
          ? ' <span class="pastilla alerta" title="Está guardado y lo podés bajar, ' +
            'pero el respaldo actual ya no lo cubre: no se está actualizando.">fuera del respaldo</span>'
          : '') +
        '</div><div class="archivo-ruta">' + escapar(a.carpeta || '') + '</div></div>' +
        '<span class="archivo-peso">' + escapar(tamano(a.bytes)) + '</span>' +
        '<span style="display:flex;gap:6px;">' +
        (d.puedeDescargar === false
          ? '<span class="campo-ayuda">Desde el programa</span>'
          : '<button class="boton boton-linea" data-bajar="' + escapar(a.ruta) + '" ' +
            'style="padding:5px 12px;font-size:.83rem;">Bajar</button>') +
        '<button class="boton boton-linea" data-borrar="' + escapar(a.ruta) + '" ' +
        'data-bytes="' + escapar(a.bytes) + '" title="Mandar a la papelera" ' +
        'style="padding:5px 10px;font-size:.83rem;">🗑️</button></span>' +
        '</div>';
    }).join('') +
    (d.recortado
      ? '<div class="campo-ayuda" style="margin-top:12px;">Se muestran los 500 más ' +
        'recientes de ' + escapar(numero(d.total)) + '. Buscá por nombre para encontrar el resto.</div>'
      : '');
  }

  function cargarArchivos(buscar) {
    var caja = $('listaArchivos');
    if (caja) caja.innerHTML = '<div class="cargando">Buscando…</div>';
    return pedir('/portal/archivos' + (buscar ? '?buscar=' + encodeURIComponent(buscar) : ''))
      .then(pintarArchivos)
      .catch(function (err) {
        if (caja) caja.innerHTML = '<div class="vacio">No se pudo cargar la lista. ' +
          escapar(err.message) + '</div>';
      });
  }

  function pintarPapelera(d) {
    var caja = $('listaPapelera');
    if (!caja) return;
    texto('papeleraResumen', d.total
      ? d.total + ' archivo(s) · ' + tamano(d.bytes) + ' que dejaron de ocupar espacio'
      : '');
    if (!d.total) {
      caja.innerHTML = '<div class="vacio">La papelera está vacía.</div>';
      return;
    }
    caja.innerHTML = d.archivos.map(function (a) {
      return '<div class="archivo">' +
        '<span style="font-size:1.1rem;">🗑️</span>' +
        '<div><div class="archivo-nombre">' + escapar(a.nombre) + '</div>' +
        '<div class="archivo-ruta">' + escapar(a.ruta) +
        (a.equipo ? ' · de ' + escapar(a.equipo) : '') + '</div></div>' +
        '<span class="archivo-peso">' + escapar(tamano(a.bytes)) + '<br />' +
        '<small>' + escapar(a.diasRestantes) + ' días</small></span>' +
        '<button class="boton boton-linea" data-recuperar="' + escapar(a.id) + '" ' +
        'style="padding:5px 12px;font-size:.83rem;">Recuperar</button>' +
        '</div>';
    }).join('');
  }

  function cargarPapelera() {
    return pedir('/portal/papelera').then(pintarPapelera).catch(function () {});
  }

  function cargarSesiones() {
    return pedir('/cuenta/sesiones')
      .then(function (d) { pintarSesiones(d.sesiones || []); })
      .catch(function () {
        $('tablaSesiones').innerHTML = '<div class="vacio">No se pudieron cargar las sesiones.</div>';
      });
  }

  function cargarPlanes() {
    return pedir('/planes').then(function (d) { estado.planes = d.planes || []; })
      .catch(function () { estado.planes = []; });
  }

  function cargarDescarga() {
    return pedir('/descargas/windows').then(function (d) {
      if (d && d.version) {
        $('botonBajar').textContent = 'Descargar BackupPrime ' + d.version;
      }
    }).catch(function () { /* el botón queda con su texto */ });
  }

  function aviso(caja, texto, clase) {
    if (!$(caja)) return;
    $(caja).innerHTML = '<div class="aviso ' + (clase || 'aviso-info') + '" style="margin-top:14px;">' +
      '<span>' + (clase === 'aviso-mal' ? '⚠' : 'ℹ') + '</span><div>' + escapar(texto) + '</div></div>';
  }

  // ── Acciones ─────────────────────────────────────────────────────────────

  function arrancarAcciones() {
    document.addEventListener('click', function (e) {
      var t = e.target;
      if (!t || !t.closest) return;

      var pagar = t.closest('[data-pagar]');
      if (pagar) {
        e.preventDefault();
        pagar.disabled = true;
        pedir('/suscripciones/checkout', {
          metodo: 'POST', cuerpo: { planId: estado.cuenta.planId },
        }).then(function (d) {
          if (!d.checkoutUrl) throw new Error('El servidor no devolvió el link de pago.');
          window.location.href = d.checkoutUrl;
        }).catch(function (err) {
          pagar.disabled = false;
          aviso('planAviso', err.message, 'aviso-mal');
        });
        return;
      }

      var cambiar = t.closest('[data-cambiar]');
      if (cambiar) {
        e.preventDefault();
        var otros = estado.planes.filter(function (p) { return p.id !== estado.cuenta.planId; });
        if (!otros.length) { aviso('planAviso', 'No hay otros planes disponibles.'); return; }
        $('planAviso').innerHTML = '<div class="aviso aviso-info" style="margin-top:14px;">' +
          '<span>ℹ</span><div><b>Elegí el plan nuevo</b>' +
          otros.map(function (p) {
            return '<button class="boton boton-linea" data-plan="' + escapar(p.id) + '" ' +
              'style="margin:6px 6px 0 0;">' + escapar(p.nombre) + ' · ' +
              escapar(p.espacioGB >= 1000 ? (p.espacioGB / 1000) + ' TB' : p.espacioGB + ' GB') +
              ' · ' + escapar(pesos(p.precioMensual)) + '</button>';
          }).join('') + '</div></div>';
        return;
      }

      var elegido = t.closest('[data-plan]');
      if (elegido) {
        e.preventDefault();
        var id = elegido.getAttribute('data-plan');
        elegido.disabled = true;
        pedir('/suscripciones/plan', { metodo: 'POST', cuerpo: { planId: id } })
          .then(function () { return cargarCuenta(); })
          .then(function () { aviso('planAviso', 'Listo, el plan quedó cambiado.', 'aviso-ok'); })
          .catch(function (err) { aviso('planAviso', err.message, 'aviso-mal'); });
        return;
      }

      var mfa = t.closest('[data-mfa]');
      if (mfa) {
        e.preventDefault();
        var que = mfa.getAttribute('data-mfa');
        $('mfaMensaje').innerHTML = '';
        if (que === 'activar') {
          pedir('/cuenta/mfa/iniciar', { metodo: 'POST', cuerpo: {} }).then(function (d) {
            $('mfaSecreto').textContent = d.secreto || '';
            $('mfaActivar').classList.remove('oculto');
            $('mfaBotones').innerHTML = '';
          }).catch(function (err) { aviso('mfaMensaje', err.message, 'aviso-mal'); });
        } else {
          $('mfaDesactivar').classList.remove('oculto');
          $('mfaBotones').innerHTML = '';
        }
        return;
      }

      if (t.id === 'mfaConfirmar') {
        e.preventDefault();
        pedir('/cuenta/mfa/confirmar', { metodo: 'POST', cuerpo: { codigo: $('mfaCodigo').value.trim() } })
          .then(function () { return cargarCuenta(); })
          .then(function () { aviso('mfaMensaje', 'El segundo factor quedó activado.', 'aviso-ok'); })
          .catch(function (err) { aviso('mfaMensaje', err.message, 'aviso-mal'); });
        return;
      }

      if (t.id === 'mfaDesactivarOk') {
        e.preventDefault();
        pedir('/cuenta/mfa/desactivar', { metodo: 'POST', cuerpo: { clave: $('mfaClave').value } })
          .then(function () { $('mfaClave').value = ''; return cargarCuenta(); })
          .then(function () { aviso('mfaMensaje', 'El segundo factor quedó desactivado.', 'aviso-ambar'); })
          .catch(function (err) { aviso('mfaMensaje', err.message, 'aviso-mal'); });
        return;
      }

      if (t.id === 'mfaCancelar' || t.id === 'mfaDesactivarNo') {
        e.preventDefault();
        pintarMfa(estado.cuenta || {});
        return;
      }

      var cerrar = t.closest('[data-cerrar]');
      if (cerrar) {
        e.preventDefault();
        cerrar.disabled = true;
        pedir('/cuenta/sesiones/cerrar', { metodo: 'POST', cuerpo: { id: cerrar.getAttribute('data-cerrar') } })
          .then(function () { return cargarSesiones(); })
          .catch(function () { cerrar.disabled = false; });
        return;
      }

      if (t.id === 'cerrarOtras') {
        e.preventDefault();
        pedir('/cuenta/sesiones/cerrar', { metodo: 'POST', cuerpo: { otras: true } })
          .then(function () { return cargarSesiones(); })
          .catch(function () { /* nada */ });
        return;
      }

      if (t.id === 'cambiarClave') {
        e.preventDefault();
        var nueva = $('claveNueva').value, repetir = $('claveRepetir').value;
        if (nueva !== repetir) {
          return aviso('claveMensaje', 'Las dos contraseñas nuevas no coinciden.', 'aviso-mal');
        }
        pedir('/cuenta/clave', { metodo: 'POST',
          cuerpo: { actual: $('claveActual').value, nueva: nueva } })
          .then(function (d) {
            $('claveActual').value = $('claveNueva').value = $('claveRepetir').value = '';
            aviso('claveMensaje', d.mensaje || 'Listo.', 'aviso-ok');
            return cargarSesiones();
          })
          .catch(function (err) { aviso('claveMensaje', err.message, 'aviso-mal'); });
        return;
      }

      if (t.id === 'editarDatos') {
        e.preventDefault();
        $('datosVista').classList.add('oculto');
        $('datosForm').classList.remove('oculto');
        return;
      }
      if (t.id === 'cancelarDatos') {
        e.preventDefault();
        $('datosForm').classList.add('oculto');
        $('datosVista').classList.remove('oculto');
        $('datosMensaje').innerHTML = '';
        return;
      }
      if (t.id === 'guardarDatos') {
        e.preventDefault();
        pedir('/cuenta/datos', { metodo: 'PUT', cuerpo: {
          organizacion: $('dOrganizacion').value, cuit: $('dCuit').value,
          celular: $('dCelular').value, telefono: $('dTelefono').value,
          direccion: $('dDireccion').value, localidad: $('dLocalidad').value,
          provincia: $('dProvincia').value } })
          .then(function () { return cargarCuenta(); })
          .then(function () {
            $('datosForm').classList.add('oculto');
            $('datosVista').classList.remove('oculto');
            aviso('datosMensaje', 'Datos guardados.', 'aviso-ok');
          })
          .catch(function (err) { aviso('datosMensaje', err.message, 'aviso-mal'); });
        return;
      }

      var desvincular = t.closest('[data-desvincular]');
      if (desvincular) {
        e.preventDefault();
        var nombre = desvincular.getAttribute('data-desvincular');
        // Se avisa lo que NO pasa: el miedo del cliente es perder los archivos.
        if (!window.confirm('¿Sacar "' + nombre + '" de la lista?\n\n' +
            'Los archivos que ya respaldó siguen guardados y los vas a poder restaurar.')) return;
        desvincular.disabled = true;
        pedir('/cuenta/equipos/desvincular', { metodo: 'POST', cuerpo: { nombre: nombre } })
          .then(function () { return cargarCuenta(); })
          .catch(function (err) {
            desvincular.disabled = false;
            aviso('avisoGlobal', err.message, 'aviso-mal');
          });
        return;
      }

      if (t.id === 'pedirBaja') { e.preventDefault(); $('bajaForm').classList.remove('oculto'); return; }
      if (t.id === 'cancelarBaja') {
        e.preventDefault();
        $('bajaForm').classList.add('oculto');
        $('bajaMensaje').innerHTML = '';
        return;
      }
      if (t.id === 'confirmarBaja') {
        e.preventDefault();
        pedir('/suscripciones/cancelar', { metodo: 'POST',
          cuerpo: { clave: $('bajaClave').value, motivo: $('bajaMotivo').value } })
          .then(function (d) {
            $('bajaClave').value = '';
            $('bajaForm').classList.add('oculto');
            aviso('bajaMensaje', d.mensaje, 'aviso-ambar');
            return cargarCuenta();
          })
          .catch(function (err) { aviso('bajaMensaje', err.message, 'aviso-mal'); });
        return;
      }

      var bajar = t.closest('[data-bajar]');
      if (bajar) {
        e.preventDefault();
        var ruta = bajar.getAttribute('data-bajar');
        var textoPrevio = bajar.textContent;
        bajar.disabled = true;
        bajar.textContent = 'Armando…';
        $('descargaMensaje').innerHTML = '';

        // El archivo se arma en el servidor: se junta de sus pedazos y se
        // descifra. Puede tardar, así que el botón lo dice.
        fetch(API + '/portal/descargar', {
          method: 'POST', credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ruta: ruta }),
        }).then(function (r) {
          if (!r.ok) {
            return r.json().catch(function () { return {}; }).then(function (d) {
              throw new Error(d.mensaje || 'No se pudo bajar el archivo.');
            });
          }
          return r.blob().then(function (blob) {
            var url = URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            a.download = ruta.split('/').pop();
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            setTimeout(function () { URL.revokeObjectURL(url); }, 30000);
          });
        }).catch(function (err) {
          aviso('descargaMensaje', err.message, 'aviso-mal');
        }).then(function () {
          bajar.disabled = false;
          bajar.textContent = textoPrevio;
        });
        return;
      }

      var borrar = t.closest('[data-borrar]');
      if (borrar) {
        e.preventDefault();
        var rutaB = borrar.getAttribute('data-borrar');
        if (!window.confirm('¿Mandar "' + rutaB.split('/').pop() + '" a la papelera?\n\n' +
            'Deja de ocupar espacio de tu plan y lo podés recuperar durante 30 días.')) return;
        pedir('/portal/papelera/mandar', { metodo: 'POST',
          cuerpo: { archivos: [{ ruta: rutaB, bytes: Number(borrar.getAttribute('data-bytes')) || 0 }] } })
          .then(function (d) {
            aviso('papeleraMensaje', d.mensaje, 'aviso-ok');
            return Promise.all([cargarArchivos($('buscarArchivo').value), cargarPapelera(), cargarCuenta()]);
          })
          .catch(function (err) { aviso('papeleraMensaje', err.message, 'aviso-mal'); });
        return;
      }

      var recuperar = t.closest('[data-recuperar]');
      if (recuperar) {
        e.preventDefault();
        recuperar.disabled = true;
        pedir('/portal/papelera/recuperar', { metodo: 'POST',
          cuerpo: { id: recuperar.getAttribute('data-recuperar') } })
          .then(function (d) {
            aviso('papeleraMensaje', d.mensaje, 'aviso-ok');
            return Promise.all([cargarArchivos($('buscarArchivo').value), cargarPapelera(), cargarCuenta()]);
          })
          .catch(function (err) {
            recuperar.disabled = false;
            aviso('papeleraMensaje', err.message, 'aviso-mal');
          });
        return;
      }

      if (t.id === 'salir') {
        e.preventDefault();
        pedir('/sesion/salir', { metodo: 'POST', cuerpo: {} })
          .then(function () { window.location.href = 'index.html'; })
          .catch(function () { window.location.href = 'index.html'; });
      }
    });
  }

  // ── Arranque ─────────────────────────────────────────────────────────────

  var relojBusqueda = null;
  document.addEventListener('input', function (e) {
    if (!e.target || e.target.id !== 'buscarArchivo') return;
    clearTimeout(relojBusqueda);
    var valor = e.target.value;
    relojBusqueda = setTimeout(function () { cargarArchivos(valor); }, 300);
  });

  arrancarNavegacion();
  arrancarAcciones();
  cargarPlanes()
    .then(cargarCuenta)
    .then(cargarSesiones)
    .then(function () { return cargarArchivos(''); })
    .then(cargarPapelera)
    .then(cargarDescarga)
    .catch(function (err) {
      if (String(err && err.message) === 'sin sesion') return;
      if (!$('avisoGlobal')) return;
      $('avisoGlobal').innerHTML = '<div class="aviso aviso-mal"><span>⚠</span><div>' +
        '<b>No se pudieron cargar tus datos</b>' + escapar(err.message) +
        ' Probá recargar la página.</div></div>';
    });

})();
