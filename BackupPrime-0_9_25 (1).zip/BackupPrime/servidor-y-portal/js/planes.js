/* ───────────────────────────────────────────────────────────────────────────
   Los planes se piden al backend, no están escritos en el sitio.

   Así cambiás un precio en un solo lugar y queda cambiado en la página, en el
   formulario de registro y en la factura. Si el backend no responde, se usa la
   copia de abajo para que la página nunca quede sin precios — pero se marca en
   la consola, porque un precio viejo en pantalla es un problema comercial.
   ─────────────────────────────────────────────────────────────────────────── */
window.BackupPrime = window.BackupPrime || {};

(function () {
  'use strict';

  var API = window.BACKUPPRIME_API || '/api';

  // Copia de emergencia. Los valores reales mandan desde el backend.
  var RESPALDO = [
    {
      id: 'personal', nombre: 'Personal', para: 'Para vos y tu familia',
      precioMensual: 16000, espacioGB: 200, destacado: false,
      incluye: [
        'Todas las computadoras de tu casa',
        '200 GB de espacio',
        'Fotos, documentos y lo que elijas',
        'Versiones anteriores de cada archivo',
        'Restauración desde la web'
      ]
    },
    {
      id: 'estudio', nombre: 'Estudio', para: 'Estudios y comercios de hasta 15 personas',
      precioMensual: 34900, espacioGB: 1000, destacado: true,
      incluye: [
        'Equipos ilimitados',
        '1 TB de espacio',
        'Hasta 30 versiones por archivo',
        'Respaldo de carpetas de red',
        'Verificación en dos pasos',
        'Soporte por WhatsApp'
      ]
    },
    {
      id: 'empresa', nombre: 'Empresa', para: 'Más de 15 personas o servidores',
      precioMensual: 74900, espacioGB: 3000, destacado: false,
      incluye: [
        'Todo lo del plan Estudio',
        '3 TB de espacio',
        'Respaldo de servidores',
        'Usuarios con permisos separados',
        'Informe mensual por mail',
        'Soporte telefónico prioritario'
      ]
    }
  ];

  var pesos = new Intl.NumberFormat('es-AR', {
    style: 'currency', currency: 'ARS', maximumFractionDigits: 0
  });

  function espacioLegible(gb) {
    return gb >= 1000 ? (gb / 1000) + ' TB' : gb + ' GB';
  }

  function pedirPlanes() {
    return fetch(API + '/planes', { headers: { Accept: 'application/json' } })
      .then(function (r) {
        if (!r.ok) throw new Error('El servidor respondió ' + r.status);
        return r.json();
      })
      .then(function (d) {
        var planes = d.planes || d;
        if (!Array.isArray(planes) || !planes.length) throw new Error('Sin planes');
        return planes;
      })
      .catch(function (e) {
        console.warn('No se pudieron traer los planes del servidor, se muestran los de respaldo:', e.message);
        return RESPALDO;
      });
  }

  function pintarPlanes(planes, contenedor) {
    contenedor.innerHTML = planes.map(function (p) {
      return '' +
      '<div class="plan' + (p.destacado ? ' destacado' : '') + '">' +
        (p.destacado ? '<span class="plan-etiqueta">El más elegido</span>' : '') +
        '<div>' +
          '<div class="plan-nombre">' + p.nombre + '</div>' +
          '<div class="plan-para">' + p.para + '</div>' +
        '</div>' +
        '<div>' +
          '<div class="plan-precio">' +
            '<span class="plan-monto">' + pesos.format(p.precioMensual) + '</span>' +
            '<span class="plan-periodo">por mes</span>' +
          '</div>' +
          '<div class="plan-espacio">' + espacioLegible(p.espacioGB) + ' de espacio</div>' +
        '</div>' +
        '<ul>' + p.incluye.map(function (i) { return '<li>' + i + '</li>'; }).join('') + '</ul>' +
        '<a class="boton ' + (p.destacado ? 'boton-lleno' : 'boton-linea') + ' boton-ancho" ' +
           'href="registro.html?plan=' + encodeURIComponent(p.id) + '">Empezar con ' + p.nombre + '</a>' +
      '</div>';
    }).join('');
  }

  window.BackupPrime.planes = {
    pedir: pedirPlanes,
    pintar: pintarPlanes,
    pesos: pesos,
    espacioLegible: espacioLegible
  };

})();
