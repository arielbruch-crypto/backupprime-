/* ───────────────────────────────────────────────────────────────────────────
   Panel de administración.

   El formulario del proveedor de almacenamiento se dibuja a partir del catálogo
   que expone el backend (`GET /api/admin/almacenamiento/catalogo`, que sale de
   almacenamiento/index.cjs). Agregar un proveedor nuevo es agregarlo en ese
   archivo: esta pantalla se acomoda sola, sin tocar HTML.
   ─────────────────────────────────────────────────────────────────────────── */
(function () {
  'use strict';

  var API = window.BACKUPPRIME_API || '/api';
  var $ = function (id) { return document.getElementById(id); };

  // Copia local del catálogo, por si el backend no responde.
  var CATALOGO = window.BACKUPPRIME_CATALOGO || [
    { id: 'idrive-e2', nombre: 'iDrive e2', nota: 'Barato y sin cargo por subida. Sin región en Sudamérica.',
      campos: ['endpoint', 'region', 'bucket', 'accessKey', 'secretKey'],
      capacidades: { enlacesFirmados: true, objectLock: true, credencialesAcotadas: null } },
    { id: 'backblaze-b2', nombre: 'Backblaze B2', nota: 'Alternativa directa a e2, compatible con S3.',
      campos: ['endpoint', 'region', 'bucket', 'accessKey', 'secretKey'],
      capacidades: { enlacesFirmados: true, objectLock: true, credencialesAcotadas: true } },
    { id: 'wasabi', nombre: 'Wasabi', nota: 'Precio plano, sin cargo por bajada.',
      campos: ['endpoint', 'region', 'bucket', 'accessKey', 'secretKey'],
      capacidades: { enlacesFirmados: true, objectLock: true, credencialesAcotadas: true } },
    { id: 'aws-s3', nombre: 'Amazon S3', nota: 'El más caro de la lista. Útil si un cliente lo exige.',
      campos: ['region', 'bucket', 'accessKey', 'secretKey'],
      capacidades: { enlacesFirmados: true, objectLock: true, credencialesAcotadas: true } },
    { id: 'minio', nombre: 'MinIO (equipos propios)',
      nota: 'S3 sobre tus propios servidores. Vos manejás discos, redundancia y respaldo del respaldo.',
      campos: ['endpoint', 'region', 'bucket', 'accessKey', 'secretKey'],
      capacidades: { enlacesFirmados: true, objectLock: true, credencialesAcotadas: true } },
    { id: 'disco', nombre: 'Carpeta del servidor', nota: 'Para desarrollo y pruebas.',
      campos: ['raiz', 'urlPublica'],
      capacidades: { enlacesFirmados: true, objectLock: false, credencialesAcotadas: false } }
  ];

  var ETIQUETAS = {
    endpoint: ['Dirección del servicio', 'https://p4d8.la.idrivee2-14.com'],
    region: ['Región', 'us-east-1'],
    bucket: ['Bucket', 'backupprime'],
    accessKey: ['Clave de acceso', 'AKIA…'],
    secretKey: ['Clave secreta', '••••••••••••'],
    raiz: ['Carpeta en el servidor', '/var/backupprime/datos'],
    urlPublica: ['Dirección pública de descarga', 'https://backupprime.com/descargas']
  };

  var NOMBRE_CAPACIDAD = {
    enlacesFirmados: 'Descarga directa desde el proveedor',
    objectLock: 'Inmutabilidad contra ransomware',
    credencialesAcotadas: 'Credenciales limitadas por cliente'
  };

  function proveedorActual() {
    var id = $('proveedor').value;
    return CATALOGO.filter(function (p) { return p.id === id; })[0];
  }

  function pintarCampos() {
    var p = proveedorActual();
    $('notaProveedor').textContent = p.nota || '';

    $('camposProveedor').innerHTML = p.campos.map(function (c) {
      var e = ETIQUETAS[c] || [c, ''];
      var tipo = /secret|clave/i.test(c) ? 'password' : 'text';
      return '<div class="campo">' +
        '<label for="cfg-' + c + '">' + e[0] + '</label>' +
        '<input type="' + tipo + '" id="cfg-' + c + '" placeholder="' + e[1] + '" autocomplete="off" />' +
        '</div>';
    }).join('');

    var caps = p.capacidades || {};
    $('capacidades').innerHTML = Object.keys(NOMBRE_CAPACIDAD).map(function (k) {
      var v = caps[k];
      var clase = v === true ? 'si' : (v === false ? 'no' : 'duda');
      var texto = NOMBRE_CAPACIDAD[k] + (v === null ? ' (hay que confirmarlo con el proveedor)' : '');
      return '<span class="capacidad ' + clase + '">' + texto + '</span>';
    }).join('');

    var avisos = {
      disco: ['cuidado', 'Una carpeta en un servidor no es redundante. Si ese disco se rompe, ' +
              'se pierden los respaldos de todos tus clientes a la vez. Para producción ' +
              'necesitás RAID, una segunda copia en otro edificio y alguien mirando los discos.'],
      minio: ['cuidado', 'Con equipos propios el que responde por los discos, la energía, la ' +
              'conexión y el respaldo del respaldo sos vos. Tiene sentido a partir de varios ' +
              'cientos de TB, no antes.'],
      'idrive-e2': ['info', 'No tiene región en Sudamérica. Antes de elegir la región, mirá qué ' +
              'implica legalmente sacar datos de clientes argentinos a Estados Unidos o Europa.']
    };
    var a = avisos[p.id];
    $('avisoProveedor').innerHTML = a
      ? '<div class="aviso aviso-' + a[0] + '">' + a[1] + '</div>'
      : '';

    $('resultadoPrueba').textContent = '';
    $('resultadoPrueba').className = 'prueba-resultado';
  }

  function juntarConfig() {
    var p = proveedorActual();
    var cfg = { proveedor: p.id };
    p.campos.forEach(function (c) {
      var el = $('cfg-' + c);
      if (el) cfg[c] = el.value;
    });
    return cfg;
  }

  // ── Navegación ────────────────────────────────────────────────────────────
  function mostrarPanel(nombre) {
    var paneles = document.querySelectorAll('.panel');
    for (var i = 0; i < paneles.length; i++) paneles[i].classList.remove('activo');
    var destino = $('panel-' + nombre);
    if (destino) destino.classList.add('activo');
    var enlaces = $('menu').querySelectorAll('a');
    for (var j = 0; j < enlaces.length; j++) {
      enlaces[j].classList.toggle('activa', enlaces[j].dataset.panel === nombre);
    }
  }

  $('menu').addEventListener('click', function (e) {
    var a = e.target.closest('a');
    if (!a) return;
    e.preventDefault();
    mostrarPanel(a.dataset.panel);
    history.replaceState(null, '', '#' + a.dataset.panel);
  });

  if (location.hash) mostrarPanel(location.hash.slice(1));

  // ── Proveedor ─────────────────────────────────────────────────────────────
  $('proveedor').innerHTML = CATALOGO.map(function (p) {
    return '<option value="' + p.id + '">' + p.nombre + '</option>';
  }).join('');
  $('proveedor').addEventListener('change', pintarCampos);
  pintarCampos();

  $('probar').addEventListener('click', function () {
    var boton = $('probar');
    var salida = $('resultadoPrueba');
    boton.disabled = true;
    salida.className = 'prueba-resultado';
    salida.textContent = 'Probando…';

    fetch(API + '/admin/almacenamiento/probar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(juntarConfig())
    }).then(function (r) { return r.json(); })
      .then(function (d) {
        salida.className = 'prueba-resultado ' + (d.ok ? 'ok' : 'mal');
        salida.textContent = (d.ok ? '✓ ' : '✕ ') + d.detalle;
      })
      .catch(function (e) {
        salida.className = 'prueba-resultado mal';
        salida.textContent = '✕ No se pudo probar: ' + e.message;
      })
      .then(function () { boton.disabled = false; });
  });

  // ── Correo saliente ───────────────────────────────────────────────────────
  // El formulario se dibuja desde el catálogo que expone el backend, igual que
  // el de almacenamiento: agregar un proveedor no requiere tocar esta pantalla.
  var CORREO = window.BACKUPPRIME_CORREO || [
    { id: 'donweb', nombre: 'DonWeb', host: 'smtp.donweb.com', puerto: 587,
      nota: 'Una sola factura, en pesos y sin tarjeta internacional. Confirmá con ellos ' +
            'que se pueda mandar de a un mail desde una aplicación, y no solo campañas.' },
    { id: 'brevo', nombre: 'Brevo', host: 'smtp-relay.brevo.com', puerto: 587,
      nota: 'Tramo gratis amplio. Pensado para mails transaccionales.' },
    { id: 'postmark', nombre: 'Postmark', host: 'smtp.postmarkapp.com', puerto: 587,
      nota: 'El que mejor entrega, y el más caro.' },
    { id: 'ses', nombre: 'Amazon SES', host: 'email-smtp.us-east-1.amazonaws.com', puerto: 587,
      nota: 'El más barato por volumen. Hay que pedir salir del entorno de pruebas.' },
    { id: 'google', nombre: 'Google Workspace', host: 'smtp.gmail.com', puerto: 587,
      nota: 'Sirve para arrancar. Tiene límite diario: no lo dejes cuando crezcas.' },
    { id: 'personalizado', nombre: 'Otro servidor SMTP', host: '', puerto: 587,
      nota: 'Cualquier proveedor que dé SMTP autenticado.' }
  ];

  var CAMPOS_CORREO = {
    host: ['Servidor SMTP', 'smtp.proveedor.com'],
    puerto: ['Puerto', '587'],
    usuario: ['Usuario', 'avisos@backupprime.com'],
    clave: ['Contraseña', '••••••••'],
    de: ['Enviar desde', 'avisos@backupprime.com'],
    deNombre: ['Nombre visible', 'BackupPrime']
  };

  function proveedorCorreo() {
    var sel = $('correoProveedor');
    if (!sel) return null;
    for (var i = 0; i < CORREO.length; i++) if (CORREO[i].id === sel.value) return CORREO[i];
    return CORREO[0];
  }

  function pintarCorreo() {
    var p = proveedorCorreo();
    if (!p) return;
    $('correoNota').textContent = p.nota || '';
    $('correoCampos').innerHTML = Object.keys(CAMPOS_CORREO).map(function (c) {
      var e = CAMPOS_CORREO[c];
      var valor = c === 'host' ? (p.host || '') : (c === 'puerto' ? (p.puerto || 587) : '');
      var tipo = c === 'clave' ? 'password' : 'text';
      return '<div class="campo"><label for="correo-' + c + '">' + e[0] + '</label>' +
        '<input type="' + tipo + '" id="correo-' + c + '" placeholder="' + e[1] + '" ' +
        'value="' + valor + '" autocomplete="off" /></div>';
    }).join('');
    $('correoResultado').textContent = '';
    $('correoResultado').className = 'prueba-resultado';
  }

  function configCorreo() {
    var cfg = { proveedor: $('correoProveedor').value, destinatario: $('correoDestino').value };
    Object.keys(CAMPOS_CORREO).forEach(function (c) {
      var el = $('correo-' + c);
      if (el && el.value) cfg[c] = el.value;
    });
    return cfg;
  }

  if ($('correoProveedor')) {
    $('correoProveedor').innerHTML = CORREO.map(function (p) {
      return '<option value="' + p.id + '">' + p.nombre + '</option>';
    }).join('');
    $('correoProveedor').addEventListener('change', pintarCorreo);
    pintarCorreo();

    $('correoProbar').addEventListener('click', function () {
      var salida = $('correoResultado');
      salida.className = 'prueba-resultado';
      salida.textContent = 'Mandando…';
      fetch(API + '/admin/correo/probar', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(configCorreo())
      }).then(function (r) { return r.json(); }).then(function (d) {
        salida.className = 'prueba-resultado ' + (d.ok ? 'ok' : 'mal');
        salida.textContent = (d.ok ? '✓ ' : '✕ ') + d.detalle;
      }).catch(function (e) {
        salida.className = 'prueba-resultado mal';
        salida.textContent = '✕ ' + e.message;
      });
    });

    $('correoGuardar').addEventListener('click', function () {
      var aviso = $('correoGuardado');
      fetch(API + '/admin/correo', {
        method: 'PUT', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(configCorreo())
      }).then(function (r) { return r.json().then(function (d) { return { ok: r.ok, d: d }; }); })
        .then(function (r) {
          aviso.textContent = r.ok ? 'Guardado' : (r.d.mensaje || 'No se pudo guardar');
          aviso.classList.add('visible');
          setTimeout(function () { aviso.classList.remove('visible'); }, 3000);
        });
    });

    $('correoDespachar').addEventListener('click', function () {
      var b = $('correoDespachar');
      b.disabled = true; b.textContent = 'Mandando…';
      fetch(API + '/admin/correo/despachar', { method: 'POST' })
        .then(function (r) { return r.json(); })
        .then(function (d) {
          b.textContent = 'Mandados: ' + (d.enviados || 0);
          setTimeout(function () { b.textContent = 'Mandar ahora'; b.disabled = false; }, 2500);
        }).catch(function () { b.textContent = 'Mandar ahora'; b.disabled = false; });
    });
  }

  // ── Facturación ───────────────────────────────────────────────────────────
  var TEXTOS = {
    pdf: 'Se abrió el comprobante en una pestaña nueva.',
    reenviar: 'Comprobante reenviado al mail del cliente.',
    cupon: 'Cupón generado y mandado. Cuando pague, la factura se marca sola.',
    reintentar: 'Se pidió un cobro nuevo a Mercado Pago. La respuesta llega en unos minutos.'
  };
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('[data-accion]');
    if (!b) return;
    var salida = $('resultadoFactura');
    if (!salida) return;
    salida.innerHTML = '<div class="aviso aviso-info">' + TEXTOS[b.dataset.accion] + '</div>';
  });

  var generar = $('generarCupon');
  if (generar) {
    generar.addEventListener('click', function () {
      var aviso = $('avisoCupon');
      generar.disabled = true;
      generar.textContent = 'Generando…';
      setTimeout(function () {
        generar.disabled = false;
        generar.textContent = 'Generar y mandar el cupón';
        aviso.classList.add('visible');
        setTimeout(function () { aviso.classList.remove('visible'); }, 2600);
      }, 700);
    });
  }

  // ── Mi cuenta ─────────────────────────────────────────────────────────────
  function fuerzaClave(v) {
    var puntos = 0;
    if (v.length >= 12) puntos++;
    if (v.length >= 16) puntos++;
    if (/[a-z]/.test(v) && /[A-Z]/.test(v)) puntos++;
    if (/\d/.test(v) || /[^\w\s]/.test(v)) puntos++;
    if (/^(.)\1+$/.test(v)) puntos = 1;
    return Math.min(4, puntos);
  }

  var nueva = $('claveNueva');
  if (nueva) {
    nueva.addEventListener('input', function () {
      var n = fuerzaClave(this.value);
      $('fuerzaAdmin').className = 'fuerza n' + n;
      $('fuerzaAdminTexto').textContent = ['',
        'Muy corta para una cuenta que ve todos los clientes.',
        'Corta. Sumale un par de palabras más.',
        'Va bien.',
        'Buena contraseña.'][n] || 'Una frase larga que recuerdes.';
    });

    $('guardarClave').addEventListener('click', function () {
      var caja = $('avisoClave');
      var marcarCampo = function (id, mensaje) {
        var campo = $(id).closest('.campo');
        var salida = campo.querySelector('.campo-error');
        campo.classList.toggle('con-error', !!mensaje);
        salida.textContent = mensaje || '';
        salida.hidden = !mensaje;
        return !mensaje;
      };

      caja.innerHTML = '';
      var ok = marcarCampo('claveVieja', $('claveVieja').value ? '' : 'Escribí tu contraseña actual.');
      ok = marcarCampo('claveNueva', $('claveNueva').value.length >= 12
        ? '' : 'La nueva necesita al menos 12 caracteres.') && ok;
      ok = marcarCampo('claveRepetir', $('claveRepetir').value === $('claveNueva').value
        ? '' : 'Las dos contraseñas no coinciden.') && ok;
      if (ok && $('claveNueva').value === $('claveVieja').value) {
        ok = marcarCampo('claveNueva', 'La nueva tiene que ser distinta de la actual.');
      }
      if (!ok) return;

      var boton = $('guardarClave');
      boton.disabled = true;
      boton.textContent = 'Cambiando…';

      fetch(API + '/admin/clave', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ actual: $('claveVieja').value, nueva: $('claveNueva').value })
      }).then(function (r) {
        if (!r.ok) throw new Error('La contraseña actual no coincide.');
        return r.json().catch(function () { return {}; });
      }).then(function () {
        ['claveVieja', 'claveNueva', 'claveRepetir'].forEach(function (id) { $(id).value = ''; });
        $('fuerzaAdmin').className = 'fuerza';
        $('claveGuardada').classList.add('visible');
        setTimeout(function () { $('claveGuardada').classList.remove('visible'); }, 2600);
      }).catch(function (e) {
        caja.innerHTML = '<div class="aviso aviso-cuidado">' + e.message + '</div>';
      }).then(function () {
        boton.disabled = false;
        boton.textContent = 'Cambiar la contraseña';
      });
    });

    $('activarMfa').addEventListener('click', function () {
      $('activarMfa').textContent = 'Escaneá el código con tu aplicación…';
      $('activarMfa').disabled = true;
    });
  }

  $('guardarAlmacen').addEventListener('click', function () {
    var aviso = $('guardadoAlmacen');
    fetch(API + '/admin/almacenamiento', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(juntarConfig())
    }).then(function () {
      aviso.classList.add('visible');
      setTimeout(function () { aviso.classList.remove('visible'); }, 2200);
    }).catch(function () {
      aviso.textContent = 'No se pudo guardar';
      aviso.classList.add('visible');
    });
  });

  /* ── Clientes y rescate ──────────────────────────────────────────────────
     Este panel era una maqueta: "Estudio Molina", "Contadores Ruiz". Ahora sale
     de /api/admin/clientes, y desde la ficha se puede ayudar a un cliente que
     quedó afuera de su cuenta sin tocar la base a mano. */

  var $$ = function (id) { return document.getElementById(id); };
  var CLIENTES = [];
  var elegido = null;

  function esc(t) {
    return String(t == null ? '' : t).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function tam(b) {
    var n = Number(b); if (!isFinite(n) || n < 0) return '—';
    if (n === 0) return '0 B';
    var u = ['B', 'KB', 'MB', 'GB', 'TB'], i = 0;
    while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
    return n.toFixed(n < 10 && i > 1 ? 1 : 0).replace('.', ',') + ' ' + u[i];
  }
  function hace(iso) {
    if (!iso) return 'nunca informó';
    var m = Math.floor((Date.now() - new Date(iso).getTime()) / 60000);
    if (!isFinite(m)) return '—';
    if (m < 60) return 'hace ' + Math.max(0, m) + ' min';
    if (m < 1440) return 'hace ' + Math.floor(m / 60) + ' h';
    return 'hace ' + Math.floor(m / 1440) + ' días';
  }
  function avisoEn(id, texto, clase) {
    var e = $$(id); if (!e) return;
    e.innerHTML = '<div class="aviso ' + (clase || 'aviso-info') + '" style="margin-top:14px;">' +
      esc(texto) + '</div>';
  }

  function pintarClientes(filtro) {
    var caja = $$('tablaClientes'); if (!caja) return;
    var f = String(filtro || '').toLowerCase().trim();
    var lista = CLIENTES.filter(function (c) {
      if (!f) return true;
      return [c.email, c.organizacion, c.cuit].join(' ').toLowerCase().indexOf(f) >= 0;
    });
    if (!lista.length) {
      caja.innerHTML = '<div class="cargando">' +
        (CLIENTES.length ? 'Ningún cliente coincide con la búsqueda.' : 'Todavía no hay clientes.') +
        '</div>';
      return;
    }
    caja.innerHTML = '<table><tr><th>Cliente</th><th>Plan</th><th>Espacio usado</th>' +
      '<th>Estado</th><th></th></tr>' + lista.map(function (c) {
        var q = c.cuota || {};
        var pastilla = c.estado === 'activa' ? 'ok' : c.estado === 'prueba' ? 'neutra' : 'mala';
        return '<tr><td><b>' + esc(c.organizacion) + '</b><br />' +
          '<small style="color:var(--tinta-suave)">' + esc(c.email) + '</small></td>' +
          '<td>' + esc(c.planId || '—') + '</td>' +
          '<td>' + esc(tam(q.usadoBytes)) + ' de ' + esc(tam(q.limiteBytes)) + '</td>' +
          '<td><span class="pastilla ' + pastilla + '">' + esc(c.estado) +
          (c.moroso ? ' · en mora' : '') + '</span></td>' +
          '<td><button class="boton boton-linea" data-ficha="' + esc(c.id) +
          '" style="padding:5px 11px;font-size:.82rem;">Ver ficha</button></td></tr>';
      }).join('') + '</table>';
  }

  function cargarClientes() {
    return fetch(API + '/admin/clientes', { credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (d) { CLIENTES = d.clientes || []; pintarClientes($$('buscarCliente') && $$('buscarCliente').value); })
      .catch(function () {
        if ($$('tablaClientes')) $$('tablaClientes').innerHTML =
          '<div class="cargando">No se pudieron cargar los clientes.</div>';
      });
  }

  function abrirFicha(id) {
    return fetch(API + '/admin/clientes/ficha', {
      method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: id }),
    }).then(function (r) { return r.json(); }).then(function (d) {
      if (!d.cliente) return;
      elegido = d.cliente.id;
      $$('fichaCliente').classList.remove('oculto');
      $$('fichaNombre').textContent = d.cliente.organizacion;
      var q = d.cliente.cuota || {};
      $$('fichaDatos').innerHTML =
        '<table><tr><th>Email</th><th>CUIT</th><th>Plan</th><th>Estado</th>' +
        '<th>Espacio</th><th>2FA</th></tr><tr>' +
        '<td>' + esc(d.cliente.email) + '</td><td>' + esc(d.cliente.cuit || '—') + '</td>' +
        '<td>' + esc(d.cliente.planId || '—') + '</td>' +
        '<td>' + esc(d.cliente.estado) + (d.cliente.moroso ? ' · en mora' : '') + '</td>' +
        '<td>' + esc(tam(q.usadoBytes)) + ' de ' + esc(tam(q.limiteBytes)) + '</td>' +
        '<td>' + (d.cliente.mfa ? 'Activado' : 'Sin activar') + '</td></tr></table>';
      $$('fichaEquipos').innerHTML = (d.equipos || []).length
        ? '<table><tr><th>Equipo</th><th>Versión</th><th>Datos</th><th>Último aviso</th></tr>' +
          d.equipos.map(function (e) {
            return '<tr><td><b>' + esc(e.nombre) + '</b></td><td>' + esc(e.version || '—') + '</td>' +
              '<td>' + esc(tam(e.bytes)) + '</td><td>' + esc(hace(e.ultimo_aviso)) + '</td></tr>';
          }).join('') + '</table>'
        : '<div class="cargando">Este cliente todavía no vinculó ningún equipo.</div>';
      $$('rescateMensaje').innerHTML = '';
    });
  }

  function rescatar(ruta, extra, exito) {
    if (!elegido) return;
    var cuerpo = Object.assign({ id: elegido }, extra || {});
    fetch(API + '/admin/clientes/' + ruta, {
      method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(cuerpo),
    }).then(function (r) { return r.json().then(function (d) { return { codigo: r.status, d: d }; }); })
      .then(function (r) {
        if (r.codigo >= 300) return avisoEn('rescateMensaje', r.d.mensaje || 'No se pudo.', 'aviso-mal');
        exito(r.d);
        return cargarClientes();
      })
      .catch(function () { avisoEn('rescateMensaje', 'No se pudo completar.', 'aviso-mal'); });
  }

  /* ── Cobros ── */
  function cargarMp() {
    return fetch(API + '/admin/mercadopago', { credentials: 'same-origin' })
      .then(function (r) { return r.json(); }).then(function (d) {
        if (!$$('mpEstado')) return;
        var falta = !d.tieneWebhookSecret;
        $$('mpEstado').innerHTML =
          '<div class="aviso ' + (falta ? 'aviso-mal' : 'aviso-ok') + '">' +
          (falta
            ? 'Falta el secreto del webhook: los pagos no se acreditan y el alta de clientes queda cortada.'
            : 'El secreto del webhook está cargado. Modo ' + esc(d.modo) + '.') + '</div>';
        if ($$('mpPublic')) $$('mpPublic').value = d.publicKey || '';
      }).catch(function () {});
  }

  document.addEventListener('click', function (e) {
    var t = e.target; if (!t || !t.closest) return;

    var ficha = t.closest('[data-ficha]');
    if (ficha) { e.preventDefault(); abrirFicha(ficha.getAttribute('data-ficha')); return; }

    if (t.id === 'cerrarFicha') { e.preventDefault(); $$('fichaCliente').classList.add('oculto'); return; }

    if (t.id === 'rescateClave') {
      e.preventDefault();
      if (!window.confirm('Esto cambia la contraseña del cliente y cierra sus sesiones. ¿Seguir?')) return;
      rescatar('clave', { claveAdmin: $$('claveAdminRescate').value }, function (d) {
        avisoEn('rescateMensaje', 'Contraseña provisoria: ' + d.provisoria +
          ' — dictásela por teléfono y pedile que la cambie al entrar.', 'aviso-ok');
        $$('claveAdminRescate').value = '';
      });
      return;
    }
    if (t.id === 'rescateMfa') {
      e.preventDefault();
      if (!window.confirm('Esto le desactiva la verificación en dos pasos. ¿Seguir?')) return;
      rescatar('mfa', { claveAdmin: $$('claveAdminRescate').value }, function (d) {
        avisoEn('rescateMensaje', d.mensaje || 'Listo.', 'aviso-ok');
        $$('claveAdminRescate').value = '';
        abrirFicha(elegido);
      });
      return;
    }
    if (t.id === 'rescateDestrabar') {
      e.preventDefault();
      rescatar('destrabar', {}, function (d) { avisoEn('rescateMensaje', d.mensaje || 'Listo.', 'aviso-ok'); });
      return;
    }

    if (t.id === 'guardarE2') {
      e.preventDefault();
      fetch(API + '/admin/e2', {
        method: 'PUT', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          modo: $$('e2Modo').value, region: $$('e2Region').value,
          prefijoBucket: $$('e2Prefijo').value, retencionDias: Number($$('e2Dias').value),
          modoRetencion: $$('e2ModoRet').value, apiKey: $$('e2ApiKey').value }),
      }).then(function (r) { return r.json().then(function (d) { return { codigo: r.status, d: d }; }); })
        .then(function (r) {
          if (r.codigo >= 300) return avisoEn('e2Mensaje', r.d.mensaje || 'No se pudo guardar.', 'aviso-mal');
          $$('e2ApiKey').value = '';
          avisoEn('e2Mensaje', 'Guardado.', 'aviso-ok');
          return cargarE2();
        }).catch(function () { avisoEn('e2Mensaje', 'No se pudo guardar.', 'aviso-mal'); });
      return;
    }

    if (t.id === 'probarE2') {
      e.preventDefault();
      t.disabled = true;
      avisoEn('e2Mensaje', 'Probando contra el proveedor…', 'aviso-info');
      fetch(API + '/admin/e2/probar', { method: 'POST', credentials: 'same-origin' })
        .then(function (r) { return r.json(); }).then(function (d) {
          t.disabled = false;
          $$('e2Mensaje').innerHTML = pintarPasos(d.pasos, d.ok) +
            (d.bucket ? '<div class="subtitulo">Bucket de prueba: ' + esc(d.bucket) +
                        ' — borralo desde la consola de e2 cuando quieras.</div>' : '');
        }).catch(function () {
          t.disabled = false;
          avisoEn('e2Mensaje', 'No se pudo completar la prueba.', 'aviso-mal');
        });
      return;
    }

    if (t.id === 'guardarMp') {
      e.preventDefault();
      fetch(API + '/admin/mercadopago', {
        method: 'PUT', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          webhookSecret: $$('mpWebhook').value, accessToken: $$('mpToken').value,
          publicKey: $$('mpPublic').value }),
      }).then(function (r) { return r.json(); }).then(function () {
        $$('mpWebhook').value = ''; $$('mpToken').value = '';
        avisoEn('mpMensaje', 'Guardado.', 'aviso-ok');
        return cargarMp();
      }).catch(function () { avisoEn('mpMensaje', 'No se pudo guardar.', 'aviso-mal'); });
    }
  });

  document.addEventListener('input', function (e) {
    if (e.target && e.target.id === 'buscarCliente') pintarClientes(e.target.value);
  });

  function cargarE2() {
    return fetch(API + '/admin/e2', { credentials: 'same-origin' })
      .then(function (r) { return r.json(); }).then(function (d) {
        if (!$$('e2Estado')) return;
        var porBucket = d.modo === 'bucket';
        $$('e2Estado').innerHTML =
          '<div class="aviso ' + (porBucket ? 'aviso-ok' : 'aviso-ambar') + '">' +
          (porBucket
            ? 'Alta automática <b>activa</b>: cada cliente nuevo recibe su propio bucket.'
            : 'Alta por carpeta dentro de un bucket común. La separación entre ' +
              'clientes es lógica: la garantiza el código, no el proveedor.') +
          (d.tieneApiKey ? '' : '<br /><small>Sin clave API de revendedor cargada.</small>') +
          '</div>';
        if ($$('e2Modo')) $$('e2Modo').value = d.modo;
        if ($$('e2Region')) $$('e2Region').value = d.region || '';
        if ($$('e2Prefijo')) $$('e2Prefijo').value = d.prefijoBucket || 'bp';
        if ($$('e2Dias')) $$('e2Dias').value = d.retencionDias;
        if ($$('e2ModoRet')) $$('e2ModoRet').value = d.modoRetencion;
      }).catch(function () {});
  }

  function pintarPasos(pasos, ok) {
    return '<div class="aviso ' + (ok ? 'aviso-ok' : 'aviso-mal') + '">' +
      (ok ? '<b>El alta funciona de punta a punta.</b>'
          : '<b>El alta NO funciona. No lo habilites así.</b>') +
      '<ul style="margin:8px 0 0;padding-left:20px;">' +
      (pasos || []).map(function (p) {
        return '<li>' + (p.ok ? '✓ ' : '✗ ') + esc(p.que) +
          (p.detalle ? ' — <small>' + esc(p.detalle) + '</small>' : '') + '</li>';
      }).join('') + '</ul></div>';
  }

  function cargarInstalador() {
    return fetch(API + '/descargas/windows', { credentials: 'same-origin' })
      .then(function (r) { return r.json(); }).then(function (d) {
        if (!$$('instaladorEstado')) return;
        if (d.disponible === false) {
          $$('instaladorEstado').innerHTML = '<div class="aviso aviso-mal">' +
            'No hay ningún instalador publicado. El sitio no ofrece la descarga.' +
            '</div>';
          return;
        }
        var viejo = d.version && CLIENTE_ESPERADO && d.version !== CLIENTE_ESPERADO;
        $$('instaladorEstado').innerHTML =
          '<div class="aviso ' + (viejo ? 'aviso-ambar' : 'aviso-ok') + '">' +
          'Publicada la <b>' + esc(d.version) + '</b> · ' + esc(d.megas || '?') + ' MB' +
          (d.sha256 ? '<br /><small>SHA-256 ' + esc(d.sha256) + '</small>' : '') +
          '</div>' +
          (d.otras && d.otras.length
            ? '<div class="subtitulo">También hay en la carpeta: ' + esc(d.otras.join(', ')) + '</div>'
            : '');
      }).catch(function () {});
  }
  var CLIENTE_ESPERADO = null;

  cargarClientes();
  cargarMp();
  cargarInstalador();
  cargarE2();

})();
