/* Dispara el webhook firmado, igual que lo haría Mercado Pago, para poder
   recorrer el circuito de cobro completo antes de tener las credenciales.
   El servidor solo acepta esta ruta cuando no hay Mercado Pago configurado. */
(function () {
  'use strict';
  var ref = new URLSearchParams(location.search).get('ref') || '';
  var salida = document.getElementById('resultado');

  function avisar(estado) {
    salida.textContent = 'Avisando al servidor…';
    fetch('/api/pago-simulado', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ referencia: ref, estado: estado })
    }).then(function (r) { return r.json(); }).then(function (d) {
      if (d.ok === false) { salida.textContent = d.mensaje || 'No se pudo.'; return; }
      location.href = 'registro.html?pago=' + (estado === 'approved' ? 'ok' : 'error');
    }).catch(function (e) { salida.textContent = 'No se pudo avisar: ' + e.message; });
  }

  document.getElementById('aprobar').onclick = function () { avisar('approved'); };
  document.getElementById('rechazar').onclick = function () { avisar('rejected'); };
})();
