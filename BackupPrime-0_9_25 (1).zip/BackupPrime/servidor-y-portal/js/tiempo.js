/* ───────────────────────────────────────────────────────────────────────────
   La línea de tiempo del hero.

   Muestra la misma carpeta en distintos días. El día 4 un virus cifra todo;
   arrastrando para atrás se ve la versión sana. Es el producto explicado sin
   una sola palabra de marketing.
   ─────────────────────────────────────────────────────────────────────────── */
(function () {
  'use strict';

  var lista    = document.getElementById('tiempoLista');
  if (!lista) return;

  var rango     = document.getElementById('tiempoRango');
  var fechaEl   = document.getElementById('tiempoFecha');
  var relEl     = document.getElementById('tiempoRelativo');
  var descEl    = document.getElementById('tiempoDesc');
  var estadoEl  = document.getElementById('tiempoEstado');
  var marcasEl  = document.getElementById('tiempoMarcas');
  var botonEl   = document.getElementById('tiempoRestaurar');

  var DIAS = [
    {
      fecha: 'Lunes 27', rel: 'hace 6 días', estado: 'Respaldado',
      desc: 'Arranca la semana. La carpeta tiene los balances cerrados del mes pasado.',
      archivos: [
        { n: 'Balance Ferretería Ruiz.xlsx', p: '2,4 MB' },
        { n: 'Papeles de trabajo.docx',      p: '840 KB' },
        { n: 'IVA marzo.pdf',                p: '312 KB' }
      ]
    },
    {
      fecha: 'Martes 28', rel: 'hace 5 días', estado: 'Respaldado',
      desc: 'Se agrega el balance de un cliente nuevo.',
      archivos: [
        { n: 'Balance Ferretería Ruiz.xlsx', p: '2,4 MB' },
        { n: 'Balance Textil Norte.xlsx',    p: '1,9 MB', nuevo: true },
        { n: 'Papeles de trabajo.docx',      p: '840 KB' },
        { n: 'IVA marzo.pdf',                p: '312 KB' }
      ]
    },
    {
      fecha: 'Miércoles 29', rel: 'hace 4 días', estado: 'Respaldado',
      desc: 'Se corrige el balance de Ferretería Ruiz. La versión anterior queda guardada igual.',
      archivos: [
        { n: 'Balance Ferretería Ruiz.xlsx', p: '2,6 MB', nuevo: true },
        { n: 'Balance Textil Norte.xlsx',    p: '1,9 MB' },
        { n: 'Papeles de trabajo.docx',      p: '840 KB' },
        { n: 'IVA marzo.pdf',                p: '312 KB' }
      ]
    },
    {
      fecha: 'Jueves 30', rel: 'hace 3 días', estado: 'Respaldado',
      desc: 'Se suma la declaración jurada y el detalle de retenciones.',
      archivos: [
        { n: 'Balance Ferretería Ruiz.xlsx', p: '2,6 MB' },
        { n: 'Balance Textil Norte.xlsx',    p: '1,9 MB' },
        { n: 'DDJJ Ganancias.pdf',           p: '1,1 MB', nuevo: true },
        { n: 'Papeles de trabajo.docx',      p: '840 KB' },
        { n: 'IVA marzo.pdf',                p: '312 KB' }
      ]
    },
    {
      fecha: 'Viernes 31', rel: 'hace 2 días', estado: 'Archivos cifrados',
      malo: true,
      desc: '<strong>Alguien abrió un adjunto.</strong> A las 14:20 un virus renombra y cifra todo lo de la carpeta. Los archivos siguen ahí, pero no abren.',
      archivos: [
        { n: 'Balance Ferretería Ruiz.xlsx.locked', p: '2,6 MB', cifrado: true },
        { n: 'Balance Textil Norte.xlsx.locked',    p: '1,9 MB', cifrado: true },
        { n: 'DDJJ Ganancias.pdf.locked',           p: '1,1 MB', cifrado: true },
        { n: 'Papeles de trabajo.docx.locked',      p: '840 KB', cifrado: true },
        { n: 'LEER_PARA_RECUPERAR.txt',             p: '2 KB',   cifrado: true }
      ]
    },
    {
      fecha: 'Hoy', rel: 'restaurado desde el jueves', estado: 'Restaurado',
      desc: 'Se restauró la carpeta al jueves a la noche. Se perdieron unas horas de trabajo, no cinco años de archivos.',
      archivos: [
        { n: 'Balance Ferretería Ruiz.xlsx', p: '2,6 MB', nuevo: true },
        { n: 'Balance Textil Norte.xlsx',    p: '1,9 MB', nuevo: true },
        { n: 'DDJJ Ganancias.pdf',           p: '1,1 MB', nuevo: true },
        { n: 'Papeles de trabajo.docx',      p: '840 KB', nuevo: true },
        { n: 'IVA marzo.pdf',                p: '312 KB', nuevo: true }
      ]
    }
  ];

  var iconos = { xlsx: '📊', pdf: '📕', docx: '📄', txt: '📃', locked: '🔒' };
  function icono(nombre) {
    if (/\.locked$/.test(nombre)) return iconos.locked;
    var ext = (nombre.split('.').pop() || '').toLowerCase();
    return iconos[ext] || '📄';
  }

  function escapar(t) {
    return String(t).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }

  function pintar(i) {
    var dia = DIAS[i];

    lista.innerHTML = dia.archivos.map(function (a) {
      var clase = a.cifrado ? ' cifrado' : (a.nuevo ? ' nuevo' : '');
      return '<div class="archivo' + clase + '">' +
               '<span class="archivo-icono">' + icono(a.n) + '</span>' +
               '<span class="archivo-nombre">' + escapar(a.n) + '</span>' +
               '<span class="archivo-peso">' + a.p + '</span>' +
             '</div>';
    }).join('');

    fechaEl.textContent = dia.fecha;
    relEl.textContent = dia.rel;
    descEl.innerHTML = dia.desc;
    estadoEl.textContent = dia.estado;
    estadoEl.classList.toggle('malo', !!dia.malo);

    botonEl.textContent = (i === DIAS.length - 1)
      ? 'Este es el estado actual'
      : 'Restaurar el ' + dia.fecha.toLowerCase();
    botonEl.disabled = (i === DIAS.length - 1);

    [].forEach.call(marcasEl.children, function (m, j) {
      m.style.color = (j === i) ? 'var(--marca)' : '';
      m.style.fontWeight = (j === i) ? '600' : '';
    });
  }

  marcasEl.innerHTML = DIAS.map(function (d) {
    return '<span>' + d.fecha.split(' ')[0] + '</span>';
  }).join('');

  rango.max = String(DIAS.length - 1);
  rango.value = String(DIAS.length - 1);
  rango.addEventListener('input', function () { pintar(Number(rango.value)); });

  botonEl.addEventListener('click', function () {
    var i = Number(rango.value);
    // Restaurar un día lleva al estado final, que es exactamente lo que hace
    // el producto: traer de vuelta la versión sana.
    rango.value = String(DIAS.length - 1);
    pintar(DIAS.length - 1);
    descEl.innerHTML = '<strong>Listo.</strong> Así se ve después de restaurar ' +
      'desde el ' + DIAS[i].fecha.toLowerCase() + '. En el programa real tarda lo que ' +
      'tarde en bajar los archivos.';
  });

  pintar(DIAS.length - 1);

  // Al llegar el hero a la pantalla, mostrar una vez el día del desastre:
  // explica el producto sin que el visitante tenga que descubrir el control.
  var yaMostrado = false;
  var quietud = typeof window.matchMedia === 'function' &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (!quietud && 'IntersectionObserver' in window) {
    var obs = new IntersectionObserver(function (entradas) {
      entradas.forEach(function (e) {
        if (!e.isIntersecting || yaMostrado) return;
        yaMostrado = true;
        setTimeout(function () {
          var i = 4;
          rango.value = String(i);
          pintar(i);
        }, 1400);
      });
    }, { threshold: .4 });
    obs.observe(document.getElementById('tiempo'));
  }
})();
