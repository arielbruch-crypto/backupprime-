/* ───────────────────────────────────────────────────────────────────────────
   Alta de cuenta: datos → plan → pago.

   Reglas que sigue este formulario:
   · La cuenta se crea en el paso 1, antes de elegir plan. Si alguien abandona
     en el paso 3 igual quedó registrado y le podemos escribir.
   · La validación de acá es para ayudar a completar, no para proteger nada.
     El backend valida todo de nuevo: esto corre en la computadora del visitante
     y cualquiera puede saltearlo.
   · La contraseña nunca se guarda en el navegador ni viaja en la URL.
   ─────────────────────────────────────────────────────────────────────────── */
(function () {
  'use strict';

  var API = window.BACKUPPRIME_API || '/api';
  var $ = function (id) { return document.getElementById(id); };

  var estado = {
    planes: [],
    planId: new URLSearchParams(location.search).get('plan') || null,
    cuenta: null,      // { id, email, token } que devuelve el backend
  };

  // ── Utilidades ────────────────────────────────────────────────────────────

  function mostrarError(caja, texto) {
    caja.innerHTML = '<div class="aviso aviso-error">' + texto + '</div>';
  }
  function limpiarError(caja) { caja.innerHTML = ''; }

  function marcarCampo(id, mensaje) {
    var campo = $(id).closest('.campo');
    var error = campo.querySelector('.campo-error');
    if (mensaje) {
      campo.classList.add('con-error');
      error.textContent = mensaje;
      error.hidden = false;
    } else {
      campo.classList.remove('con-error');
      error.hidden = true;
    }
    return !mensaje;
  }

  var soloNumeros = function (v) { return String(v || '').replace(/\D/g, ''); };

  /** Un celular argentino con característica tiene 10 dígitos sin el 0 ni el 15. */
  function celularValido(v) {
    var d = soloNumeros(v);
    return d.length >= 10 && d.length <= 13;
  }

  function emailValido(v) {
    return /^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(v.trim());
  }

  /** Validación del CUIT con su dígito verificador. Un CUIT mal tipeado hoy es
   *  una factura rechazada el mes que viene. */
  function cuitValido(v) {
    var d = String(v).replace(/\D/g, '');
    if (d.length !== 11) return false;
    var pesos = [5, 4, 3, 2, 7, 6, 5, 4, 3, 2];
    var suma = 0;
    for (var i = 0; i < 10; i++) suma += Number(d[i]) * pesos[i];
    var resto = suma % 11;
    var verificador = resto === 0 ? 0 : (resto === 1 ? 9 : 11 - resto);
    return verificador === Number(d[10]);
  }

  function fuerzaClave(v) {
    var puntos = 0;
    if (v.length >= 10) puntos++;
    if (v.length >= 14) puntos++;
    if (/[a-z]/.test(v) && /[A-Z]/.test(v)) puntos++;
    if (/\d/.test(v) || /[^\w\s]/.test(v)) puntos++;
    if (/^(.)\1+$/.test(v)) puntos = 1;
    return Math.min(4, puntos);
  }

  function pedir(ruta, cuerpo, token) {
    // Envuelto para que un fallo inmediato de fetch llegue como promesa
    // rechazada y el formulario pueda mostrar el error, en vez de colgarse.
    try { return enviar(ruta, cuerpo, token); }
    catch (e) { return Promise.reject(e); }
  }

  function enviar(ruta, cuerpo, token) {
    var cabeceras = { 'Content-Type': 'application/json', Accept: 'application/json' };
    if (token) cabeceras.Authorization = 'Bearer ' + token;
    return fetch(API + ruta, {
      method: 'POST',
      headers: cabeceras,
      body: JSON.stringify(cuerpo),
    }).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (d) {
        if (!r.ok) {
          var e = new Error(d.mensaje || d.error || ('El servidor respondió ' + r.status));
          e.campo = d.campo;
          e.status = r.status;
          throw e;
        }
        return d;
      });
    });
  }

  function irAEtapa(n) {
    ['etapa1', 'etapa2', 'etapa3', 'etapaListo'].forEach(function (id) {
      $(id).classList.remove('activa');
    });
    $(n).classList.add('activa');
    var barras = $('barraPasos').children;
    var indice = { etapa1: 1, etapa2: 2, etapa3: 3, etapaListo: 3 }[n];
    for (var i = 0; i < barras.length; i++) barras[i].classList.toggle('hecho', i < indice);
    $('resumen').style.display = (n === 'etapaListo') ? 'none' : '';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  // ── Planes ────────────────────────────────────────────────────────────────

  function pintarOpciones() {
    var pesos = window.BackupPrime.planes.pesos;
    var espacio = window.BackupPrime.planes.espacioLegible;

    $('opcionesPlan').innerHTML = estado.planes.map(function (p) {
      return '' +
      '<label class="opcion-plan' + (p.id === estado.planId ? ' elegida' : '') + '" data-plan="' + p.id + '">' +
        '<input type="radio" name="plan" value="' + p.id + '"' + (p.id === estado.planId ? ' checked' : '') + ' />' +
        '<span>' +
          '<span class="opcion-plan-nombre">' + p.nombre + '</span><br />' +
          '<span class="opcion-plan-detalle">' + espacio(p.espacioGB) + ' · ' + p.para + '</span>' +
        '</span>' +
        '<span class="opcion-plan-precio">' +
          '<b>' + pesos.format(p.precioMensual) + '</b><br />' +
          '<span class="opcion-plan-detalle">por mes</span>' +
        '</span>' +
      '</label>';
    }).join('');

    [].forEach.call($('opcionesPlan').querySelectorAll('.opcion-plan'), function (el) {
      el.addEventListener('click', function () {
        estado.planId = el.dataset.plan;
        pintarOpciones();
        pintarResumen();
      });
    });
  }

  function planActual() {
    return estado.planes.find(function (p) { return p.id === estado.planId; }) || estado.planes[0];
  }

  function pintarResumen() {
    var p = planActual();
    if (!p) return;
    $('rPlan').textContent = p.nombre;
    $('rEspacio').textContent = window.BackupPrime.planes.espacioLegible(p.espacioGB);
    $('rDespues').textContent = window.BackupPrime.planes.pesos.format(p.precioMensual);
  }

  // ── Paso 1: crear la cuenta ───────────────────────────────────────────────

  $('clave').addEventListener('input', function () {
    var n = fuerzaClave(this.value);
    $('fuerza').className = 'fuerza n' + n;
    $('fuerzaTexto').textContent = ['',
      'Muy corta: alguien la adivina en minutos.',
      'Corta. Sumale un par de palabras más.',
      'Va bien.',
      'Buena contraseña.'][n] || 'Usá una frase larga que recuerdes.';
  });

  $('cuit').addEventListener('blur', function () {
    if (this.value.trim()) marcarCampo('cuit', cuitValido(this.value) ? '' : 'Ese CUIT no es válido. Revisá los números.');
  });

  $('seguir1').addEventListener('click', function () {
    limpiarError($('errores1'));

    var ok = true;
    ok = marcarCampo('estudio', $('estudio').value.trim().length >= 2 ? '' : 'Poné el nombre de tu estudio o empresa.') && ok;
    ok = marcarCampo('email', emailValido($('email').value) ? '' : 'Revisá el email, parece incompleto.') && ok;
    ok = marcarCampo('clave', $('clave').value.length >= 10 ? '' : 'La contraseña necesita al menos 10 caracteres.') && ok;
    ok = marcarCampo('celular', celularValido($('celular').value)
      ? '' : 'Poné tu celular con característica, así te podemos avisar por mensaje.') && ok;
    ok = marcarCampo('direccion', $('direccion').value.trim().length >= 5
      ? '' : 'Escribí tu dirección para la factura.') && ok;
    ok = marcarCampo('localidad', $('localidad').value.trim().length >= 2
      ? '' : 'Falta la localidad.') && ok;
    ok = marcarCampo('provincia', $('provincia').value ? '' : 'Elegí tu provincia.') && ok;
    ok = marcarCampo('cuit', (!$('cuit').value.trim() || cuitValido($('cuit').value)) ? '' : 'Ese número no es válido. Revisá los dígitos.') && ok;
    if (!$('acepto').checked) { mostrarError($('errores1'), 'Para crear la cuenta hace falta aceptar los términos.'); ok = false; }
    if (!ok) return;

    var boton = $('seguir1');
    boton.disabled = true;
    boton.textContent = 'Creando tu cuenta…';

    pedir('/registro', {
      organizacion: $('estudio').value.trim(),
      email: $('email').value.trim().toLowerCase(),
      clave: $('clave').value,
      celular: soloNumeros($('celular').value),
      telefono: soloNumeros($('telefono').value) || null,
      direccion: $('direccion').value.trim(),
      localidad: $('localidad').value.trim(),
      provincia: $('provincia').value,
      cuit: $('cuit').value.replace(/\D/g, '') || null,
      planId: estado.planId || (estado.planes[0] && estado.planes[0].id),
    }).then(function (d) {
      estado.cuenta = d;
      // La contraseña no queda en ninguna variable de larga vida.
      $('clave').value = '';
      // El plan ya se eligió en el paso 1: de acá se va derecho al pago.
      irAEtapa('etapa3');
    }).catch(function (e) {
      if (e.status === 409) {
        mostrarError($('errores1'),
          'Ya hay una cuenta con ese email. <a href="/portal/">Entrá acá</a> o ' +
          '<a href="/portal/recuperar">recuperá tu contraseña</a>.');
      } else {
        mostrarError($('errores1'), e.message);
      }
      if (e.campo) marcarCampo(e.campo, e.message);
    }).then(function () {
      boton.disabled = false;
      boton.textContent = 'Seguir';
    });
  });

  // ── Paso 2: plan ──────────────────────────────────────────────────────────

  // Paso 1: elegir plan. Es lo primero porque es lo que la gente vino a hacer;
  // pedirle los datos antes de mostrarle qué contrata es al revés.
  $('seguirPlan').addEventListener('click', function () { irAEtapa('etapa2'); });
  $('volverPlan').addEventListener('click', function () { irAEtapa('etapa1'); });

  // ── Paso 3: pago ──────────────────────────────────────────────────────────

  $('volver3').addEventListener('click', function () { irAEtapa('etapa2'); });

  $('pagar').addEventListener('click', function () {
    limpiarError($('errores3'));
    var boton = $('pagar');
    boton.disabled = true;
    boton.textContent = 'Abriendo Mercado Pago…';

    pedir('/suscripciones/checkout', { planId: estado.planId }, estado.cuenta && estado.cuenta.token)
      .then(function (d) {
        if (!d.checkoutUrl) throw new Error('El servidor no devolvió el link de pago.');
        // Mercado Pago vuelve a /registro-listo con el resultado.
        window.location.href = d.checkoutUrl;
      })
      .catch(function (e) {
        mostrarError($('errores3'),
          e.message + ' Podés empezar la prueba igual y cargar la tarjeta después.');
        boton.disabled = false;
        boton.textContent = 'Cargar la tarjeta en Mercado Pago';
      });
  });

  $('sinTarjeta').addEventListener('click', function () { terminar(); });

  function terminar() {
    $('mailListo').textContent = (estado.cuenta && estado.cuenta.email) || $('email').value;
    $('bajarCliente').href = 'descargas.html';
    irAEtapa('etapaListo');
  }

  // Vuelta desde Mercado Pago
  if (new URLSearchParams(location.search).get('pago') === 'ok') {
    estado.cuenta = { email: new URLSearchParams(location.search).get('email') || '' };
    terminar();
  }

  // ── Arranque ──────────────────────────────────────────────────────────────
  window.BackupPrime.planes.pedir().then(function (planes) {
    estado.planes = planes;
    if (!estado.planId || !planes.some(function (p) { return p.id === estado.planId; })) {
      var destacado = planes.find(function (p) { return p.destacado; });
      estado.planId = (destacado || planes[0]).id;
    }
    pintarOpciones();
    pintarResumen();
  });

  // Si llegaron desde un plan de la portada, ese queda marcado y se puede seguir
  // de una sin volver a elegir.
})();
