/* La página de descargas pide al backend la versión vigente en lugar de tenerla
   escrita: así publicás una versión nueva y el sitio se actualiza solo, sin
   que quede un número viejo en pantalla. */
(function () {
  'use strict';
  var API = window.BACKUPPRIME_API || '/api';
  var $ = function (id) { return document.getElementById(id); };

  function pedir(ruta) {
    try { return fetch(API + ruta).then(function (r) { return r.json(); }); }
    catch (e) { return Promise.reject(e); }
  }

  pedir('/descargas/windows').then(function (d) {
    if (!d) return;

    // Sin instalador publicado no se ofrece un botón que lleva a un 404: se
    // desactiva y se dice qué pasa. Un enlace roto en una reunión de venta es
    // peor que un aviso honesto.
    if (d.disponible === false) {
      var boton = $('bajarWindows');
      if (boton) {
        boton.removeAttribute('href');
        boton.setAttribute('aria-disabled', 'true');
        boton.style.opacity = '.5';
        boton.style.pointerEvents = 'none';
        boton.textContent = 'Todavía no disponible';
      }
      if ($('version')) $('version').textContent = '—';
      if ($('peso')) $('peso').textContent = '—';
      if ($('huella')) $('huella').textContent = 'Todavía no está publicado el instalador.';
      return;
    }

    if (d.url) $('bajarWindows').href = d.url;
    if (d.version && $('version')) $('version').textContent = d.version;
    if (d.megas && $('peso')) $('peso').textContent = d.megas + ' MB';
    if ($('huella')) {
      // La huella la calcula el servidor del archivo real. Nunca se escribe a
      // mano: una huella vieja o equivocada es peor que no publicar ninguna.
      $('huella').textContent = d.sha256
        ? 'SHA-256 · ' + d.sha256
        : 'Todavía no está publicado el instalador.';
    }
  }).catch(function () {
    if ($('huella')) $('huella').textContent = 'No se pudo consultar en este momento.';
    // Sin backend queda el enlace por defecto; no se toca nada más para que la
    // página siga sirviendo aunque la API esté caída.
  });

  pedir('/cuenta').then(function (d) {
    if (d && d.email) $('tuEmail').textContent = d.email;
  }).catch(function () {});
})();
