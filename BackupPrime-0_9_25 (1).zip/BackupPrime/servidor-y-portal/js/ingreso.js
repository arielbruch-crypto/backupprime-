/* ───────────────────────────────────────────────────────────────────────────
   Ingreso.

   Dos cosas que este formulario hace a propósito y conviene no "arreglar":

   · Cuando el email o la contraseña están mal, dice "el email o la contraseña
     no coinciden", nunca cuál de los dos. Si dijera "ese email no existe",
     cualquiera podría averiguar quiénes son tus clientes probando direcciones.

   · Al pedir recuperar la contraseña siempre contesta lo mismo, exista o no la
     cuenta. Mismo motivo.
   ─────────────────────────────────────────────────────────────────────────── */
(function () {
  'use strict';

  var API = window.BACKUPPRIME_API || '/api';
  var modo = 'cliente';
  var $ = function (id) { return document.getElementById(id); };
  var etapas = ['etapaClave', 'etapaCodigo', 'etapaOlvide', 'etapaMandado'];

  function ir(cual) {
    etapas.forEach(function (e) { $(e).classList.toggle('activa', e === cual); });
    var primero = $(cual).querySelector('input');
    if (primero) setTimeout(function () { primero.focus(); }, 60);
  }

  function error(caja, texto) {
    $(caja).innerHTML = texto ? '<div class="aviso aviso-error">' + texto + '</div>' : '';
  }

  function marcar(id, mensaje) {
    var campo = $(id).closest('.campo');
    var salida = campo.querySelector('.campo-error');
    campo.classList.toggle('con-error', !!mensaje);
    salida.textContent = mensaje || '';
    salida.hidden = !mensaje;
    return !mensaje;
  }

  var emailValido = function (v) { return /^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(String(v).trim()); };

  function pedir(ruta, cuerpo) {
    // Si fetch no está disponible o revienta de entrada, igual devolvemos una
    // promesa rechazada. Si no, el error se escapa del manejador del botón y
    // el formulario queda colgado sin decirle nada al usuario.
    try {
      return enviar(ruta, cuerpo);
    } catch (e) {
      return Promise.reject(e);
    }
  }

  function enviar(ruta, cuerpo) {
    return fetch(API + ruta, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify(cuerpo),
    }).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (d) {
        if (!r.ok) { var e = new Error(d.mensaje || 'No se pudo completar'); e.status = r.status; throw e; }
        return d;
      });
    });
  }

  // ── Cliente o administración ──────────────────────────────────────────────
  //
  // El ingreso de administración va por la misma pantalla solo por comodidad.
  // En producción tiene que estar en otro subdominio, con segundo factor
  // obligatorio y, si se puede, limitado a las direcciones de tu oficina: ese
  // usuario ve los datos de todos los clientes y es el blanco más valioso que
  // tenés.
  var botonesModo = [].slice.call(document.querySelectorAll('.modo button'));

  function cambiarModo(nuevo) {
    modo = nuevo;
    botonesModo.forEach(function (b) {
      var activo = b.dataset.modo === nuevo;
      b.classList.toggle('activo', activo);
      b.setAttribute('aria-selected', activo ? 'true' : 'false');
    });

    var esAdmin = nuevo === 'admin';
    $('tituloIngreso').textContent = esAdmin ? 'Panel de administración' : 'Entrá a tu cuenta';
    $('ayudaIngreso').textContent = esAdmin
      ? 'Acceso interno de BackupPrime.'
      : 'La misma que usás en el programa de tus computadoras.';
    $('etiquetaUsuario').textContent = esAdmin ? 'Usuario' : 'Email';
    $('email').type = esAdmin ? 'text' : 'email';
    $('email').placeholder = esAdmin ? 'admin' : 'vos@estudio.com.ar';
    $('pieCliente').style.display = esAdmin ? 'none' : '';
    $('avisoAdmin').innerHTML = esAdmin
      ? '<div class="aviso aviso-cuidado">Este ingreso queda registrado en la auditoría: quién entró, cuándo y desde dónde.</div>'
      : '';
    $('email').value = '';
    $('clave').value = '';
    error('errorClave', '');
    marcar('email', '');
    marcar('clave', '');
  }

  botonesModo.forEach(function (b) {
    b.addEventListener('click', function () { cambiarModo(b.dataset.modo); });
  });

  // Desde el pie del sitio se entra directo al modo administración.
  if ((window.location.hash || '').indexOf('admin') >= 0) cambiarModo('admin');

  // ── Entrar ────────────────────────────────────────────────────────────────
  $('entrar').addEventListener('click', function () {
    error('errorClave', '');
    var ok = modo === 'admin'
      ? marcar('email', $('email').value.trim() ? '' : 'Escribí tu usuario.')
      : marcar('email', emailValido($('email').value) ? '' : 'Revisá el email.');
    ok = marcar('clave', $('clave').value ? '' : 'Escribí tu contraseña.') && ok;
    if (!ok) return;

    var boton = $('entrar');
    boton.disabled = true;
    boton.textContent = 'Entrando…';

    pedir('/sesion', {
      modo: modo,
      email: $('email').value.trim().toLowerCase(),
      clave: $('clave').value,
      recordar: $('recordar').checked,
    }).then(function (d) {
      $('clave').value = '';
      if (d.necesitaSegundoFactor) return ir('etapaCodigo');
      window.location.href = d.destino || (modo === 'admin' ? 'admin.html' : 'portal.html');
    }).catch(function (e) {
      if (e.status === 429) {
        error('errorClave', 'Demasiados intentos. Esperá unos minutos antes de probar de nuevo.');
      } else {
        // Nunca decir cuál de los dos está mal.
        error('errorClave', modo === 'admin'
          ? 'El usuario o la contraseña no coinciden.'
          : 'El email o la contraseña no coinciden.');
      }
    }).then(function () {
      boton.disabled = false;
      boton.textContent = 'Entrar';
    });
  });

  $('clave').addEventListener('keydown', function (e) { if (e.key === 'Enter') $('entrar').click(); });
  $('email').addEventListener('keydown', function (e) { if (e.key === 'Enter') $('clave').focus(); });

  // ── Segundo factor: seis casillas que se comportan como una sola ─────────
  var casillas = [].slice.call($('codigo').querySelectorAll('input'));

  casillas.forEach(function (c, i) {
    c.addEventListener('input', function () {
      c.value = c.value.replace(/\D/g, '').slice(0, 1);
      if (c.value && i < casillas.length - 1) casillas[i + 1].focus();
      if (casillas.every(function (x) { return x.value; })) $('verificar').click();
    });
    c.addEventListener('keydown', function (e) {
      if (e.key === 'Backspace' && !c.value && i > 0) casillas[i - 1].focus();
      if (e.key === 'ArrowLeft' && i > 0) casillas[i - 1].focus();
      if (e.key === 'ArrowRight' && i < casillas.length - 1) casillas[i + 1].focus();
    });
    // Pegar el código entero desde la app de autenticación reparte los dígitos.
    c.addEventListener('paste', function (e) {
      var texto = (e.clipboardData || window.clipboardData).getData('text').replace(/\D/g, '');
      if (!texto) return;
      e.preventDefault();
      casillas.forEach(function (x, j) { x.value = texto[j] || ''; });
      (casillas[Math.min(texto.length, 5)] || casillas[5]).focus();
      if (texto.length >= 6) $('verificar').click();
    });
  });

  $('verificar').addEventListener('click', function () {
    var codigo = casillas.map(function (c) { return c.value; }).join('');
    if (codigo.length < 6) return error('errorCodigo', 'Faltan dígitos del código.');

    var boton = $('verificar');
    boton.disabled = true;
    boton.textContent = 'Verificando…';
    error('errorCodigo', '');

    pedir('/sesion/mfa', { codigo: codigo, modo: modo })
      .then(function (d) {
        window.location.href = d.destino || (modo === 'admin' ? 'admin.html' : 'portal.html');
      })
      .catch(function () {
        error('errorCodigo', 'Ese código no es válido o ya venció. Probá con el siguiente.');
        casillas.forEach(function (c) { c.value = ''; });
        casillas[0].focus();
      })
      .then(function () { boton.disabled = false; boton.textContent = 'Verificar'; });
  });

  $('usarRespaldo').addEventListener('click', function () {
    error('errorCodigo', 'Escribí uno de tus códigos de recuperación en las casillas. ' +
      'Cada uno sirve una sola vez.');
  });

  // ── Recuperar la contraseña ───────────────────────────────────────────────
  $('irOlvide').addEventListener('click', function () {
    $('emailOlvide').value = $('email').value;
    ir('etapaOlvide');
  });

  $('mandarEnlace').addEventListener('click', function () {
    if (!marcar('emailOlvide', emailValido($('emailOlvide').value) ? '' : 'Revisá el email.')) return;

    var boton = $('mandarEnlace');
    boton.disabled = true;
    boton.textContent = 'Mandando…';

    pedir('/clave/olvide', { email: $('emailOlvide').value.trim().toLowerCase() })
      .catch(function () { /* la respuesta es la misma exista o no la cuenta */ })
      .then(function () {
        $('mailMandado').textContent = $('emailOlvide').value.trim();
        ir('etapaMandado');
        boton.disabled = false;
        boton.textContent = 'Mandarme el enlace';
      });
  });

  ['volverClave', 'volverClave2', 'volverClave3'].forEach(function (id) {
    $(id).addEventListener('click', function () { ir('etapaClave'); });
  });
})();
