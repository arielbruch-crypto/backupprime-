# BackupPrime — sitio, portal, panel y backend

```
npm start          # servidor completo en http://localhost:4000
npm run pruebas    # 332 pruebas
npm run muestra    # arma vista-app.html: todas las pantallas en un archivo
```

**¿Venís a auditar o a revisar esto?** Empezá por `docs/AUDITORIA.md`: dice qué
hay, por qué está hecho así, qué falta y dónde están los riesgos que ya
conocemos.

## Qué hay acá

| Carpeta | Qué es |
|---|---|
| `index.html` y compañía | El sitio: portada, registro, ingreso, descargas |
| `portal.html` | Panel del cliente: archivos, equipos, facturas, seguridad |
| `admin.html` | Panel interno: clientes, almacenamiento, planes, mora, facturación |
| `servidor/` | El backend. Node solo, sin dependencias. SQLite adentro de Node 22 |
| `almacenamiento/` | Un solo contrato para iDrive e2, B2, Wasabi, S3, MinIO y disco |
| `pruebas/` | Todo se prueba por HTTP o con un navegador simulado |
| `docs/` | Auditoría, puesta en marcha, contrato de la API, decisiones |

## Primer arranque

```
npm start
```

Entrá a `http://localhost:4000`. El panel arranca con **admin / admin** y te avisa
hasta que la cambies desde Administración → Mi cuenta.

La base de datos es **un archivo**: `datos/backupprime.db`. Respaldarla es
copiarlo, y hay que hacerlo: si la perdés, los archivos de los clientes siguen en
el storage pero no sabés de quién es cada uno.

## Lo que todavía corre en modo simulado

- **Mercado Pago.** Sin credenciales, el checkout va a `pago-simulado.html` para
  poder probar el circuito completo. Con credenciales cargadas, esa ruta se
  apaga sola.
- **Facturación electrónica.** Hoy la factura se anota en la base sin CAE.
- **Correo.** Los avisos se encolan en la tabla `avisos` en lugar de enviarse.
  Se ven desde el panel.

## Para producción

Antes de publicar:

1. Cambiar la contraseña del panel.
2. `BACKUPPRIME_HTTPS=1` (por defecto) y servir detrás de HTTPS.
3. Configurar el almacenamiento real desde el panel.
4. Cargar las credenciales de Mercado Pago y el secreto del webhook.
5. Respaldo automático del archivo de base de datos.
