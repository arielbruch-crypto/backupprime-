# BackupPrime — concepto, plataforma y filosofía

Este documento existe para que **nadie pierda el contexto**, ni una persona nueva
ni una sesión de trabajo que arranca de cero. Explica **para qué existe** el
producto, **cómo está armado** y **con qué criterio se toman las decisiones**.

Para qué hace hoy, ver `FUNCIONES.md`. Para el estado del proyecto y los errores
ya pagados, ver `LEEME-PRIMERO.md`.

Versión de referencia: **0.9.21**.

---

## 1. Para qué existe

**La gente instala una cosa, se olvida, y el día del desastre sus datos están.**

Todo lo demás es medio para eso. Nadie compra "deduplicación por bloques":
compran no perder veinte años de trabajo.

Y hay una asimetría que define al producto entero: **BackupPrime se usa el peor
día de la vida de alguien.** Se quemó la computadora del estudio, entró un
ransomware, se robaron el equipo, se murió el disco. Ese día, esta ventana es lo
único que hay entre seguir trabajando y perderlo todo.

Un editor de texto que falla molesta. Un respaldo que falla arruina un estudio.
De esa diferencia sale todo lo que sigue.

---

## 2. Las tres reglas que no se negocian

### 1. Un respaldo que parece estar y no está es peor que no tener respaldo

Porque el cliente que se cree cubierto **no toma ninguna otra precaución**. No
hace una copia en un disco, no imprime lo importante, no desconfía. La falsa
tranquilidad es activamente peligrosa.

Consecuencias prácticas:

- Ante la duda, **avisar**. Un error visible es mejor que un éxito falso.
- Nunca marcar algo como verificado sin haberlo comprobado.
- Si el destino no se pudo leer, no se anota que se verificó.
- Si la clave de cifrado no está disponible, el respaldo **se detiene** en lugar
  de subir en claro.
- Al restaurar, si algo falla, el archivo con su nombre definitivo **no puede
  llegar a existir**: un archivo ilegible con nombre correcto parece restaurado.

### 2. El cliente no tiene que saber nada técnico

Si hace falta que entienda qué es UAC, un servicio de Windows, una instantánea de
volumen o dónde guarda Outlook el correo, **está mal hecho**.

Consecuencias prácticas:

- Accesos rápidos con nombres humanos: "Correo de Outlook", no
  `AppData\Local\Microsoft\Outlook`.
- El instalador crea la tarea programada elevada para que VSS funcione sin que el
  cliente vea un cartel de permisos.
- Los mensajes explican qué pasó y qué hacer, en castellano, sin códigos.
- Lo que el programa decide solo, se dice como información, no como alarma.

### 3. El cliente tiene que poder verificar

**La tranquilidad no viene de que ande; viene de poder ver qué se respaldó, cuándo
y qué falló.**

Consecuencias prácticas:

- Verificación programada semanal **y** rotativa en cada corrida.
- En pantalla no se muestra la fecha de la última revisión: se muestra **cuántos
  días hace que no se comprueba el archivo más olvidado**. "Verificado el martes"
  puede ser cierto y engañoso a la vez.
- El registro de actividad es completo y filtrable.
- La restauración **nunca se bloquea**, ni con la cuota excedida. Un cliente que
  no pagó sigue siendo alguien cuyos datos están en juego.

---

## 3. El negocio

**El modelo ya está validado.** Ariel tiene 8 clientes pagando hoy, sobre IDrive,
sin problemas. No se está construyendo para ver si alguien compra: BackupPrime
reemplaza la infraestructura de IDrive por la propia, y esos 8 clientes son la
primera migración — margen que hoy se va afuera, y gente que ya confía.

**El mercado:** estudios contables, estudios jurídicos y pymes en Argentina. Son
clientes que tienen datos irreemplazables —balances, declaraciones,
expedientes— y **ninguna capacidad técnica interna**. No tienen departamento de
sistemas. Tienen un técnico que viene cuando algo se rompe.

Eso define el producto más que cualquier decisión de arquitectura: **tiene que
funcionar sin que nadie lo mire.**

**IDrive es la referencia explícita.** Ante cualquier duda de comportamiento, la
respuesta no es el criterio de quien programe: es mirar qué hace IDrive y por
qué. La consigna es ser mejores en todo; donde no se pueda, igualar el piso.

Ejemplo de esto funcionando: IDrive **muestra en rojo** lo que está excluido, en
lugar de esconderlo. Es mejor que esconderlo — si el cliente no ve la carpeta, no
sabe si el programa la ignoró a propósito o si falló. Eso está en la lista para
copiarlo.

---

## 4. Cómo está armado

Dos partes que se hablan por HTTP y comparten un almacenamiento compatible con
S3.

### `cliente-windows/` — el agente de escritorio

Electron y Node.js. Corre en la máquina del cliente.

| Archivo | Qué hace |
|---|---|
| `backup-engine.cjs` | El motor: recorre, decide qué cambió, sube, verifica |
| `bloques.cjs` | Cortes por contenido, índices, restauración por bloques |
| `cifrado.cjs` | Claves, frases, comprobantes, cifrar y descifrar |
| `main.cjs` | Proceso principal de Electron; **todos** los `ipcMain.handle` |
| `preload.cjs` | El puente entre la pantalla y el proceso principal |
| `renderer.html` | Toda la interfaz, en un archivo |
| `vss.cjs` | Instantáneas de volumen (opcional) |
| `tarea-programada.cjs` | La tarea de Windows que corre desatendida |
| `restore-remoto.cjs` | Restauración desde destinos remotos |

El estado vive en `state.json`, en `%APPDATA%\BackupPrime`.

### `servidor-y-portal/` — sitio, portal, panel y backend

Node.js y SQLite. Sitio público, portal del cliente, panel de administración,
cuotas, pagos y avisos.

### El almacenamiento

iDrive e2 (compatible con S3), por API de revendedor. **El plan a largo plazo es
que BackupPrime reemplace a IDrive como infraestructura**, no que dependa de
ellos para siempre.

---

## 5. Las decisiones de arquitectura, y por qué

### El agente nunca recibe las credenciales del almacenamiento

Recibe **URLs firmadas**. Si alguien compromete la máquina de un cliente, no se
lleva las llaves del bucket de nadie. No es un detalle: es la diferencia entre un
incidente y una catástrofe.

### El cifrado ocurre en la máquina del cliente

Dos modos, con consecuencias distintas y dichas de frente:

- **Frase propia:** la frase nunca sale de la computadora. Nadie más puede leer
  los archivos, ni BackupPrime. **Si el cliente pierde la frase, pierde los
  archivos** — es la única función del producto que es irreversible por
  matemática y no por decisión nuestra, y la pantalla lo dice con esas palabras.
- **Clave administrada:** la clave la guarda el servidor, lo que permite rescatar
  a un cliente que olvidó su contraseña. A cambio, **BackupPrime puede
  técnicamente leer sus archivos**, y eso también se dice.

**Esto no se puede vender como cifrado de extremo a extremo.** En el modo
administrado no lo es, y llamarlo así sería mentir sobre lo único que el cliente
no puede comprobar por su cuenta.

### Los archivos grandes van por bloques para poder RETOMAR

No para deduplicar una ISO, que no cambia nunca. **Es para que una subida de ocho
horas que se corta no empiece de cero.** Una máquina de estudio se apaga a la
noche; sin bloques, esos archivos no se respaldarían jamás y el cliente no se
enteraría.

### La lista de bloques se pide una vez por corrida, nunca de a uno

Varios servicios compatibles con S3 contestan **403 en lugar de 404** cuando un
objeto no existe. Con un 403, el programa concluye que no está nada y resube
todo. **Ya pasó.** Medido: 4 operaciones contra 46.

### Los índices viven en ramas de servicio, no mezclados con los archivos

Hasta la 0.9.8 la copia del índice se guardaba pegada al archivo original, y el
listado de restaurar mostraba `respaldo.zip` y al lado `respaldo.zip.bpi` de
3 KB. **Quien elegía el equivocado se llevaba un JSON creyendo que restauró su
respaldo**, y se enteraba con el original ya borrado.

### Los puntos de corte de los bloques son sagrados

`pruebas/cortes-estables.cjs` los congela. **Si falla, no se actualizan los
números**: significa que se movieron los cortes, que ningún bloque viejo coincide
y que **cada cliente resube todo**. Para un cliente con 200 GB, eso son 200 GB de
subida y 200 GB de consumo de un día para el otro.

### El respaldo nunca borra nada del destino del cliente

Los objetos viejos que ya no corresponden se dejan de mostrar, **no se borran**.
Un producto de respaldo no borra cosas del bucket del cliente por su cuenta.

### El instalador crea una tarea programada elevada, no una entrada de arranque

Así VSS funciona sin que el cliente tenga que entender qué es UAC.

### Se descarta lo que se regenera solo

Caché de navegadores, temporales, `node_modules`. Cambian todo el tiempo, así que
se subirían en cada respaldo consumiendo cuota, y no le sirven a nadie. **Se
saltea la carpeta, nunca por nombre de archivo**: un archivo del cliente que se
llame parecido a una entrada de caché es del cliente.

---

## 6. Cómo se trabaja, y por qué así

Este proyecto tiene una particularidad que condiciona el método: **todo el código
lo escribió una IA, y Ariel no puede auditarlo por su cuenta.** No hay un segundo
programador que revise. Eso quiere decir que las pruebas que escribe la IA son su
propia tarea corregida por ella misma.

De ahí salen tres reglas de método que valen más que cualquier decisión técnica.

### 1. Al escribir una prueba, reintroducir el bug a propósito

Y confirmar que la prueba **falla**. Es lo único que distingue una prueba de una
opinión sobre el propio código.

Esto ya destapó, en esta línea de trabajo, pruebas que estaban en verde sin
probar nada:

- Un control que decía "no aparece ningún índice" y solo miraba que la clave no
  empezara con `indices/` — el `.bpi` pegado al archivo no empieza con eso.
- Un control de "se pidió la medición" que pasaba **mientras el handler no
  existía**, porque la prueba simulaba el otro lado.
- Un control de puentes huérfanos que no encontraba ningún puente, así que no
  había huérfanos que informar.

### 2. Cargar el programa, no leer el archivo

Una prueba que busca el texto `ipcMain.handle("x")` dentro de un archivo **no
puede saber si el programa arranca**. Un archivo que revienta a mitad tiene todo
su texto igual.

Pasó: se registró por error un handler duplicado, Electron explotó, `main.cjs` se
cortó y **murieron 18 puentes** —la pestaña Restaurar completa—. La prueba de
texto pasó en verde con la aplicación rota.

Por eso `pruebas/arranque-completo.cjs` **carga** `main.cjs` con Electron
simulado y cuenta los handlers que se registran de verdad. Va **primera en la
suite**: si el programa no arranca, nada más importa.

### 3. Medir antes de diagnosticar

Perseguir teorías sin medir costó, en una sola sesión, más tiempo que todos los
arreglos juntos. Ejemplos reales de teorías que resultaron **falsas**:

- "El `flush` del registro escribe por archivo" → tiene limitador de 2 segundos:
  8 escrituras en 15.000 archivos.
- "La verificación es el cuello" → 3.074 objetos en 0,24 segundos.
- "Falta el handler de medición" → existía; el canal se llamaba distinto que el
  método del preload.

Y cosas que **solo se vieron midiendo**: que el tamaño de bloque real era el
doble del configurado, que la caché del navegador era la mitad de los archivos,
que 25.000 líneas de registro tardaban 13,3 segundos en la pantalla.

### Y algo que hay que decir sin adornos

**Los bugs más graves los encontró Ariel usando el programa**, no la IA leyendo el
código: los `.bpi` en el bucket, un mail de una palabra que costaba 18 MB, el
cuelgue con 165.000 archivos, la caché del navegador, la búsqueda que no
encontraba el PST. Ninguna de esas cosas aparece en una revisión de código.

**Mirar el producto correr es irreemplazable.** Ninguna suite de pruebas lo
sustituye.

---

## 7. Cómo se comunica el producto

Reglas de escritura que ya están decididas:

- **Cero estadísticas inventadas.** Solo números medidos, y se dice cómo se
  midieron.
- **Nunca "100% seguro"** ni ninguna promesa absoluta.
- **Dos tiempos**, no solo miedo: qué se pierde **y** cómo se recupera.
- **Las consecuencias irreversibles se dicen de frente**, no en letra chica. Si
  perder la frase significa perder los archivos, se dice con esas palabras.
- **No prometer lo que no se hace.** Si el estudio está en Microsoft 365, su
  correo **no** lo respalda BackupPrime: está en el servidor de Microsoft.
  Vender "respaldamos tu correo" ahí sería falso y volvería como reclamo.

---

## 8. Lo que falta para vender

Separado por lo que **bloquea** y lo que no.

**Bloquea:**

1. **Restauración desde cero probada en una máquina limpia** — sin `state.json`,
   sin configuración, solo con la cuenta. Es el único escenario que importa el
   día del desastre y **nadie lo probó de punta a punta todavía**.
2. **El cifrado tiene que quedar activado en el alta**, no depender de que alguien
   se acuerde de prenderlo en cada instalación.
3. **Instalador firmado.** Sin firma, Windows muestra una advertencia de
   SmartScreen en plena reunión de venta.

**Se nota en la demo:** mostrar lo excluido en rojo, el menú de Electron en
inglés. (El tiempo restante global y el portal conectado se hicieron en 0.9.21.)

**Del recorrido del portal, sin arreglar todavía:** el pago simulado devuelve 503
porque el secreto del webhook solo se carga por variable de entorno y no hay
pantalla en el panel; `/api/descargas/windows` sirve la **0.7.1** con el agente en
0.9.21 y sin `sha256`; y el sitio promete "restauración desde la web", que el
portal no puede dar.

**Para cobrar:** Mercado Pago con credenciales reales, facturación con CAE,
aprovisionamiento automático de clientes.

**Después:** modo de clave administrada, tamaño de bloque, guardia
anti-ransomware, servicio de Windows.

---

## 9. Si estás leyendo esto porque sos nuevo

1. Leé `LEEME-PRIMERO.md` **antes de tocar nada**. Tiene los errores ya pagados,
   y cada uno costó horas.
2. Corré `npm run pruebas` en las dos partes. Es la autoridad, no la opinión de
   nadie.
3. `pruebas/cortes-estables.cjs` **no se toca nunca**. Si falla, algo se rompió.
4. Antes de cambiar algo que funcionaba, **verificá que esté roto de verdad**.
5. Al arreglar algo, escribí la prueba y **reintroducí el bug** para confirmar que
   se pone en rojo.
6. Cuando no sepas, decilo. Este producto se usa el peor día de la vida de
   alguien, y una certeza inventada ahí cuesta los datos de un estudio entero.
